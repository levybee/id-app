<?php
      error_reporting(E_ERROR | E_PARSE);

      // This hides errors from users but still logs everything.
      // error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT);

      // --- Enable full error visibility and logging ---
      // error_reporting(E_ALL);
      ini_set('display_errors', 1); // show in browser for dev
      ini_set('log_errors', 1);

      // create logs folder if not exists
      $logDir =  __DIR__ . '/../logs';
      if (!is_dir($logDir)) {
          mkdir($logDir, 0777, true);
      }

      // set error log path inside this folder
      $logFile = $logDir . '/php-error-' . date('Y-m-d') . '.log';
      ini_set('error_log', $logFile);

      // optional: confirm logging setup works
      // error_log("PHP error logging started at " . date('Y-m-d H:i:s'));

	// Start Session
		session_start();
		
		// Composer autoload for third-party libraries
	if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
		require_once __DIR__ . '/../vendor/autoload.php';
	}



	// fetch functions
		require('configs/functions.php'); 	// Standard Functions
		require('configs/functions.cms.php'); 	// CMS Functions
		require('configs/functions.jos.php'); 	// Job Order System (JOS) Functions

	// fetch required variables
		require('configs/variables.php');

	// load smarty library
		require('configs/setup.php');
		$smarty = new Smarty_Setup;

	// Modules
		require MODULES . 'logout/logout.php';
		require MODULES . 'configurations.php';
		require MODULES . 'login.php';

// 		if($_SESSION['user_id'] == 24){
// 		    $smarty->clearAllCache();
// 		    echo "Cleared";
// 		    exit;
// 		}



	// Working with mod_rewrite / template display issues
		if($_GET['section']) {

			$section = $_GET['section'];

			if($_GET['action']) {
				$action = $_GET['action'];
			} else {
				$action = 'index';
			}

		} else {
			$section = 'main';
			$action = 'index';
		}



    // Force drivers to vehicle schedule page
    if($user_data[0]['role_name'] == 'Drivers' && $section  != 'vehicle_schedule'){
        $url = '/vehicle_schedule/list?filter=1&schedule_date='.date('Y-m-d');
    	header("Location: $url");
    	exit;
    }

	// Working with Software Sections/Actions Pages
		$tpl_path = TEMPLATES . $section . '/' . $action . '.tpl';
		$module_path = MODULES . $section . '/' . $section . '.php';


		// DEBUG BEFORE
		if($debugg) {
			echo "<pre>$tpl_path<br>$module_path</pre>";
		}

		if(!file_exists($tpl_path) && $action !== 'ajax') {
			$message[] = 'Sorry, section/action not found.';
			$section = 'main';
			$action = 'index';

			// Force Dashboard Include
			include_once (MODULES . 'main/main.php');
		}


		if(file_exists($module_path) && !@ereg('logout.php', $module_path)) {
			include $module_path;
		}

		if(!$logged_in && $section != 'logout' & $section != 'main') {
			$message[] = 'Please login.';
			$section = 'main';
			$action = 'index';
		}

// 		if($_SESSION['user_id'] == 24){
// 		    $_SESSION['msg'] = ["some message"];
// 		}


		// Get messages from pages if any
		// Sht dont work!!
// 		if(isset($_SESSION['msg'])){
// 		    print_r($_SESSION['msg']);
//           $message = $_SESSION['msg'];

//         }


	// Working with Errors
		if(isset($message) && !empty($message)) {

			$num_messages = count($message);

			if($num_messages == 1) {
				$message_output = $message[0];
			} else {

				for($i=0; $i<$num_messages; $i++) {
					$message_output_temp .= '<li>' . $message[$i] . '</li>';
				}

				$message_output = '<ul>' . $message_output_temp . '</ul>';

			}

		}


	// Variables Pass - Smarty
		$smarty->assign ('user_name', $user_name);
		$smarty->assign ('user_ip', $user_ip);
		$smarty->assign ('message', $message_output);
		$smarty->assign ('authorized', $authorized);
		$smarty->assign ('msgColor', $msgColor);
		$smarty->assign ('logged_in', $logged_in);

	// Work with Editor
		$smarty->assign ('editor_use', $editor_use);
		$smarty->assign ('editor_field', $editor_field);

	// Work with Custom TPLs
		$smarty->assign ('custom_tpl_activate', $custom_tpl_activate);
		$smarty->assign ('custom_tpl', $custom_tpl);

	// Work with Smarty
		$smarty->assign ('software', $software);
		$smarty->assign ('section', $section);
		$smarty->assign ('action', $action);
		$timestamp = date('H:i', mktime(date('H')-1, date('i'), 0, 0, 0, 0));
		$smarty->assign ('timestamp', $timestamp);

	// Other Common Variables
		$smarty->assign('search_str', $search_str);
		$smarty->assign('filter_str', $filter_str);

		$menu_default = $section.'/'.$action;
		$smarty->assign('menu_default', $menu_default);

	// DEBUG AFTER
		if($debugg) {
			echo "<pre>$tpl_path<br>$module_path</pre>";
		}

	// end parsing smarty and display
		if($_GET['print'] == true) {
			$layout_tpl = 'print.tpl';
		} else if($_GET['popup'] == true) {
			$layout_tpl = 'popup.tpl';
		} else {
			$layout_tpl = 'layout.tpl';
		}

		if(file_exists(TEMPLATES . $section . '/plugins.tpl')){

		    $page_plugins = $section."/plugins.tpl";
		    $smarty->assign('page_plugins', $page_plugins);
		}


		$smarty->display ($layout_tpl);

	// Close database connection
		@mysql_close();

	  //  unset($_SESSION['msg']); // Unset message from inner pages - sht dont work!!

?>
