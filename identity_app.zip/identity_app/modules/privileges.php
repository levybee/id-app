<?
	
	// Privileges Management
	$role_data = smartsql('SELECT * FROM `cms_priv_roles` WHERE `role_id` = \'' . $role_id . '\';');
	$smarty->assign('role_data', $role_data);
		
	if(!$_SESSION['privileges']) {
		
		$priv_sql = 'SELECT task_section, task_action 
						FROM `cms_priv_tasks` as pt, `cms_priv_roles_tasks` as prt 
						WHERE pt.task_id = prt.task_id
						  AND prt.role_id = "' . $role_id . '"
						ORDER BY task_section;'; 
						
		// echo $priv_sql . "<br><br>";
		
		$priv_qry = mysql_query($priv_sql) or systemlog('CMS Internal Error - Please contact Support.', 'CMS Internal Error: Could not load privileges');
		$priv_sections = mysql_num_rows($priv_qry);
		
		// Privileges Array
		$privileges_data = array();
		
		if($priv_sections > 0) { 
			
			while($priv_sections_data = mysql_fetch_array($priv_qry)) {
				
				$task_action_temp = $priv_sections_data['task_action'];
				$task_section_temp = $priv_sections_data['task_section'];
				
				// Build Array
				$privileges_data[$task_section_temp][$task_action_temp] = 1;
				
				// echo "privileges_data[$task_section_temp][$task_action_temp]<br>";
				
			}
			
			/* 
			while($priv_sections_data = mysql_fetch_array($priv_qry, MYSQL_ASSOC)) {
				
				$task_section_temp = $priv_sections_data['task_section'];
				$actions_sql = 'SELECT `task_action` FROM `cms_priv_tasks` WHERE `task_section` = \'' . $task_section_temp . '\';';
				
				$actions_qry = mysql_query($actions_sql);
				
				while($actions_data = mysql_fetch_array($actions_qry, MYSQL_ASSOC)) { 
					$privileges_data[$task_section_temp][$actions_data['task_action']] = 1; 
				}
			
			}
			*/
		
			$_SESSION['privileges'] = $privileges_data;
			
		} 		
	
	} 
	
	$smarty->assign('privileges', $_SESSION['privileges']);
						
?>
