<?php
   header("Location: ../");
?>
