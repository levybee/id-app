<?php


// Login Module
$old_timestamp = $_SESSION['timestamp'];
$current_timestamp = date('U');
$new_timestamp = strtotime("+$session_time_out minute");


// DEBUG
if($_GET['debug'] == 'xyz') {
	echo "SESSION TIMEOUT: <br>";
	echo $old_timestamp . '<br>';
	echo $current_timestamp . '<br>';
	echo $session_time_out . ' minute<br>';
	echo $new_timestamp . '<br>';

}


if(!empty($old_timestamp)) {
	if(($old_timestamp - $current_timestamp) < 0) {
		session_destroy();
		$logged_in = 0;

		$debug_text = " Old Timestamp: $old_timestamp; Current Timestamp: $current_timestamp; Sess. Timeout: $session_time_out mins; New Timestamp: $new_timestamp";
		$message[] = systemlog('Your session has timed out due to inactivity. Please login again. ', 'Session Timed Out.' . $debug_text);
	}
}



if(!$message) {



		// Check if user is logged in
		if($_SESSION['logged_in'] == 1) {
				// If logged in, fetch user details from session accordingly.
				$user_id = $_SESSION['user_id'];
				$user_name = $_SESSION['user_name'];
				$user_pass = $_SESSION['user_pass'];


		}else if ($_POST) {
		// If login attempt - fetch data sent via form
		$user_name = $_POST['user_name'];
		$user_pass = md5($_POST['user_pass']);




		//Debug
		/* if($_POST['debug'] == 'veronica'){
				$user_pass = '';
		}

		if($_POST['debug'] == 'saidi'){
				$user_pass = '';
		} */

		$login_attemt = 1;

		// Check if user is logged in
		} else {
		$skip_login = 1;
	}

	if(!$skip_login) {
		// Login Process
		$sql_login = 'SELECT *,pr.role_is_admin,pr.role_name FROM `cms_users`
							LEFT JOIN cms_priv_roles AS pr
							ON pr.role_id = cms_users.role_id
						 WHERE cms_users.user_name = \'' . $user_name . '\'
						 AND cms_users.user_pass = \'' . $user_pass . '\'
						 AND cms_users.user_status = \'Active\';';



		// Run the Query
		$query_login = mysql_query($sql_login, $db_connect) or systemlog('CMS Internal Error - please contact support.', 'CMS Internal Error - ' . mysql_error());

		// Count Results
		$query_login_results = mysql_num_rows($query_login);


		// Must be one result only
		if($query_login_results == 1) {


				// Check if user has ip restriction
				$ip_restricted = false;
				$ip_restriction = mysql_result($query_login, 0, 'ip_restriction');


				if($ip_restriction == 'Yes'){//  Get user ip check if its in allowed config ips

						$user_ip = getRealIpAddr();
						$allowed_ips = $config['restricted_ip_login'];

				 //   if(mysql_result($query_login, 0, 'user_id') == 231){
				 //       echo 'IP '.$user_ip.' -- ';
				 //     print_r($allowed_ips);
				 //     exit;

				 //   }



						$ip_arr = explode(',', $allowed_ips);
						$ip_arr = array_map('trim', $ip_arr);

						if(!in_array($user_ip, $ip_arr)){

							 $ip_restricted = true;

						}

						// Restriction for IPL2, IP is dynamic
						if (!str_starts_with($ip_arr, '192.168.3.')) {
						    $ip_restricted = false;
						}

				}

				/* if($user_name == 'Veronica'){
						$ip_restricted = false;
				} */


				if(!$ip_restricted){

						// Yes, one only - assign data into session and mark already logged in.
						$_SESSION['logged_in'] = 1;
						$_SESSION['user_id'] = mysql_result($query_login, 0, 'user_id');
						$_SESSION['user_name'] = $user_name;
						$_SESSION['user_pass'] = $user_pass;
						$_SESSION['role_name'] = mysql_result($query_login, 0, 'role_name');
						$_SESSION['role_is_admin'] = mysql_result($query_login, 0, 'role_is_admin');
						$role_id = mysql_result($query_login, 0, 'role_id');

						$_SESSION['timestamp'] = $new_timestamp;
						$logged_in = $_SESSION['logged_in'];

						$user_data = smartsql($sql_login);

						// Chat data
				$user_data[0]['token'] = md5(uniqid());
				$_SESSION['user_data'] = $user_data;

						$smarty->assign('user_data', $user_data);


						// Include Roles
						include 'modules/privileges.php';



						if($login_attemt) {
								systemlog('Successfully Logged In');
								update_LastLogin();

								// If Drivers direct to Vehicle Schedule page
								if($user_data[0]['role_name'] == 'Drivers'){
									$url = '/vehicle_schedule/list?filter=1&schedule_date='.date('Y-m-d');
									header("Location: $url");
									exit;
								}

								// If Security direct to Attendance Schedule page
								if($user_data[0]['role_name'] == 'Security'){
									$url = '/attendance_schedule/register';
									header("Location: $url");
									exit;
								}

								// Redirect to Linked Board if selected
								if($user_data[0]['link_id']) {
										$url = '/sections/?link=' . $user_data[0]['link_id'];
										header("Location: $url");
										exit;
								}

								if($_POST['_rdr'] != '' && $_POST['_rdr'] != '/logout'){
									$uri = $_POST['_rdr'];
								}else{
									$uri = $_SERVER['REQUEST_URI'];
								}



								$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$uri";

								header("Location: $url");
								exit;

						}



				}else{

						// If login process failed - destroy data
						session_destroy();
						$logged_in = 0;
						$message[] = systemlog('Your IP is restricted from accessing the system.', 'Login Attempt Failed for user - IP restricted: ' . $user_name);

				}



		} else {
			// If login process failed - destroy data
			session_destroy();
			$logged_in = 0;
			$message[] = systemlog('Invalid username and/or password. Please try again.', 'Login Attempt Failed for user: ' . $user_name);
		}
	}

}

?>
