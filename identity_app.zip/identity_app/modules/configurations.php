<?

	// Configuration Module
	$config_sql = 'SELECT * FROM `cms_configurations`;';
	$config_qry = mysql_query($config_sql);
	
	// Array
	$config = array();
	
	if($config_qry) { 
	
		while($config_data = mysql_fetch_array($config_qry)) {
			
			$config_name = $config_data['config_name'];
			
			$config[$config_name] = $config_data['config_value'];
			
		}
		
	}
	 
	if(! isset($cron)){
		$smarty->assign('config', $config);
	}
	
?>
