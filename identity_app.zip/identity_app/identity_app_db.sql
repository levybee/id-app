-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 31, 2026 at 11:15 PM
-- Server version: 9.6.0
-- PHP Version: 8.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idlocal_db2`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms_categories`
--

CREATE TABLE `cms_categories` (
  `category_id` int NOT NULL,
  `category_name` varchar(50) NOT NULL DEFAULT '',
  `category_parent` int NOT NULL DEFAULT '0',
  `category_sort` int NOT NULL DEFAULT '0',
  `category_status` enum('Disabled','Enabled') NOT NULL DEFAULT 'Disabled'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_configurations`
--

CREATE TABLE `cms_configurations` (
  `config_name` varchar(40) NOT NULL DEFAULT '',
  `config_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_history`
--

CREATE TABLE `cms_history` (
  `history_id` int NOT NULL,
  `history_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `history_text` text NOT NULL,
  `history_link` varchar(255) NOT NULL DEFAULT '',
  `user_id` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_logs`
--

CREATE TABLE `cms_logs` (
  `log_id` int NOT NULL,
  `log_date` datetime DEFAULT NULL,
  `log_description` text NOT NULL,
  `log_page` varchar(255) NOT NULL DEFAULT '',
  `user_ip` varchar(15) NOT NULL DEFAULT '',
  `user_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_news`
--

CREATE TABLE `cms_news` (
  `news_id` int NOT NULL,
  `news_date` date NOT NULL DEFAULT '0000-00-00',
  `news_headline` varchar(255) NOT NULL DEFAULT '',
  `news_short` varchar(255) NOT NULL DEFAULT '',
  `news_body` text NOT NULL,
  `news_expire` date NOT NULL DEFAULT '0000-00-00',
  `news_show` enum('Y','N') NOT NULL DEFAULT 'Y',
  `user_id` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_priv_roles`
--

CREATE TABLE `cms_priv_roles` (
  `role_id` int NOT NULL,
  `role_name` varchar(32) NOT NULL DEFAULT '',
  `role_is_admin` enum('No','Yes') NOT NULL DEFAULT 'No',
  `role_status` enum('Active','Suspended') NOT NULL DEFAULT 'Active',
  `role_department` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_priv_roles_tasks`
--

CREATE TABLE `cms_priv_roles_tasks` (
  `roles_tasks_id` int NOT NULL,
  `role_id` int NOT NULL DEFAULT '0',
  `task_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_priv_tasks`
--

CREATE TABLE `cms_priv_tasks` (
  `task_id` int NOT NULL,
  `task_section` varchar(25) NOT NULL DEFAULT '',
  `task_action` varchar(25) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cms_users`
--

CREATE TABLE `cms_users` (
  `user_id` int NOT NULL,
  `user_name` varchar(32) NOT NULL DEFAULT '',
  `user_pass` varchar(32) NOT NULL DEFAULT '',
  `user_fname` varchar(30) NOT NULL DEFAULT '',
  `user_lname` varchar(30) NOT NULL DEFAULT '',
  `user_email` varchar(100) DEFAULT NULL,
  `user_image` varchar(100) DEFAULT NULL,
  `user_description` varchar(255) NOT NULL DEFAULT '',
  `role_id` int NOT NULL DEFAULT '0',
  `ip_restriction` enum('Yes','No') DEFAULT NULL,
  `user_status` enum('Active','Suspended') NOT NULL DEFAULT 'Active',
  `user_last_login` datetime DEFAULT NULL,
  `user_connection_id` int DEFAULT NULL,
  `user_online` tinyint NOT NULL DEFAULT '0',
  `user_token` varchar(255) DEFAULT NULL,
  `is_typing` enum('yes','no') NOT NULL DEFAULT 'no',
  `monthly_sales_target` decimal(12,2) DEFAULT NULL,
  `exclude_sales_reports` tinyint NOT NULL DEFAULT '0',
  `user_location` enum('IPL1','IPL2') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_account_transactions`
--

CREATE TABLE `jos_account_transactions` (
  `id` int NOT NULL,
  `type` enum('Receipt','Bank Transfer','Reconcile','Contra','Petty Cash','Payout') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `currency` enum('TZS','USD') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `exch_rate` decimal(13,2) NOT NULL,
  `link_id` int NOT NULL,
  `amount` decimal(18,6) NOT NULL,
  `account_balance` decimal(18,6) NOT NULL,
  `account_id` int NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_assets`
--

CREATE TABLE `jos_assets` (
  `id` int NOT NULL,
  `category` enum('Tools','Machines','Vehicles','Electronic Equipment','Furniture and Fixtures') NOT NULL,
  `quantity` int NOT NULL,
  `purchase_value` decimal(12,2) DEFAULT NULL,
  `status` enum('Active','Repair','Scrapped','Pending') NOT NULL DEFAULT 'Active',
  `asset_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_attachments`
--

CREATE TABLE `jos_attachments` (
  `attachment_id` int NOT NULL,
  `attachment_name` varchar(255) DEFAULT '',
  `attachment_path` varchar(255) NOT NULL DEFAULT '',
  `attachment_type` enum('quote','job','employee','receipt') DEFAULT NULL,
  `group_id` int NOT NULL DEFAULT '0',
  `employee_id` int DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_attendance_holidays`
--

CREATE TABLE `jos_attendance_holidays` (
  `id` int NOT NULL,
  `holiday_name` varchar(255) NOT NULL,
  `holiday_date` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_attendance_schedule`
--

CREATE TABLE `jos_attendance_schedule` (
  `id` int NOT NULL,
  `schedule_date` date NOT NULL,
  `employee_id` int NOT NULL,
  `attendance_shift_id` int NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  `break_time_in` time DEFAULT NULL,
  `break_time_out` time DEFAULT NULL,
  `status` enum('Present','Absent','Late','Holiday','On Leave','Excused','Pending') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Absent',
  `overtime` tinyint NOT NULL DEFAULT '0',
  `check_in_comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `check_out_comments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `amendment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `checked_in_user_id` int DEFAULT NULL,
  `checked_out_user_id` int DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_attendance_shift`
--

CREATE TABLE `jos_attendance_shift` (
  `id` int NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `weekend_end_time` time DEFAULT NULL,
  `break_start` time DEFAULT NULL,
  `break_end` time DEFAULT NULL,
  `late_time_period` int DEFAULT NULL,
  `schedule_start_time` time DEFAULT NULL,
  `schedule_end_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_bills`
--

CREATE TABLE `jos_bills` (
  `id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `invoice_id` int NOT NULL,
  `status` enum('Pending','Paid','Cancelled') NOT NULL DEFAULT 'Pending',
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_cash_account`
--

CREATE TABLE `jos_cash_account` (
  `id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `account_amount` decimal(12,2) NOT NULL,
  `received_from` varchar(100) NOT NULL,
  `currency` varchar(5) NOT NULL DEFAULT 'TZS',
  `action` varchar(30) NOT NULL DEFAULT 'Cash Added',
  `petty_cash_id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_cash_account_mobile`
--

CREATE TABLE `jos_cash_account_mobile` (
  `id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `account_amount` decimal(12,2) NOT NULL,
  `received_from` varchar(100) NOT NULL,
  `currency` varchar(5) NOT NULL DEFAULT 'TZS',
  `action` varchar(30) NOT NULL DEFAULT 'Cash Added',
  `petty_cash_id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `user_id` int NOT NULL,
  `ledger_processed` tinyint(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_casual_contractors`
--

CREATE TABLE `jos_casual_contractors` (
  `id` int NOT NULL,
  `supplier_id` int NOT NULL,
  `category_id` int NOT NULL,
  `contactor_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contractor_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contractor_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `payment_amount` decimal(12,2) NOT NULL,
  `advance_paid` decimal(12,2) DEFAULT NULL,
  `payment_terms` enum('40/60','100% In Advance','Payment On Completion','Per Piece Completed','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `payment_terms_other` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `contractor_status` enum('Draft','Approved','Completed','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Draft',
  `attachments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_casual_contractor_sow`
--

CREATE TABLE `jos_casual_contractor_sow` (
  `id` int NOT NULL,
  `job_id` int NOT NULL,
  `job_qty` decimal(12,2) NOT NULL,
  `unit_rate` decimal(9,2) DEFAULT NULL,
  `work_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_required` date NOT NULL,
  `casual_contractor_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_categories`
--

CREATE TABLE `jos_categories` (
  `category_id` int NOT NULL,
  `category_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `sales_target` decimal(12,2) NOT NULL DEFAULT '0.00',
  `status` enum('Active','Inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'Active',
  `product_cat` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_chat_groups`
--

CREATE TABLE `jos_chat_groups` (
  `group_id` int NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `group_avatar` text NOT NULL,
  `group_status` enum('Active','Inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_chat_group_users`
--

CREATE TABLE `jos_chat_group_users` (
  `cgu_id` int NOT NULL,
  `group_id` int NOT NULL,
  `user_id` int NOT NULL,
  `currently_active` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_chat_message`
--

CREATE TABLE `jos_chat_message` (
  `chat_message_id` int NOT NULL,
  `from_user_id` int NOT NULL,
  `to_user_id` int DEFAULT NULL,
  `to_group_id` int DEFAULT NULL,
  `chat_message` text NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` enum('No','Yes') NOT NULL DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_closed_jobs`
--

CREATE TABLE `jos_closed_jobs` (
  `job_closed_id` int NOT NULL,
  `date_closed` datetime NOT NULL,
  `job_id` int NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `item_quantity` decimal(9,2) NOT NULL,
  `item_price` decimal(12,2) DEFAULT NULL,
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_contractor_templates`
--

CREATE TABLE `jos_contractor_templates` (
  `id` int NOT NULL,
  `tpl_name` varchar(255) NOT NULL,
  `tpl_content` text NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_contracts`
--

CREATE TABLE `jos_contracts` (
  `id` int NOT NULL,
  `employee_id` int NOT NULL,
  `contract_type` enum('Permanent','Temporary') NOT NULL,
  `contract_tpl_id` int NOT NULL,
  `contract_start_date` date NOT NULL,
  `contract_end_date` date NOT NULL,
  `attachment` text NOT NULL,
  `user_id` int NOT NULL,
  `contract_status` enum('Draft','Approved','Issued','Closed','Cancelled','Expired') NOT NULL DEFAULT 'Draft',
  `approval_user_id` int DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_contract_templates`
--

CREATE TABLE `jos_contract_templates` (
  `id` int NOT NULL,
  `tpl_name` varchar(255) NOT NULL,
  `tpl_type` enum('Permanent','Temporary') NOT NULL,
  `tpl_content` text NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_credit_notes`
--

CREATE TABLE `jos_credit_notes` (
  `id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL,
  `invoice_id` int NOT NULL,
  `adjust_amount` decimal(12,2) DEFAULT NULL,
  `status` enum('Pending','Issued','Cancelled','Closed') NOT NULL DEFAULT 'Pending',
  `notes` text,
  `attachment` varchar(255) DEFAULT NULL,
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_customers`
--

CREATE TABLE `jos_customers` (
  `customer_id` int NOT NULL,
  `customer_fname` varchar(25) NOT NULL DEFAULT '',
  `customer_lname` varchar(25) NOT NULL DEFAULT '',
  `customer_email` varchar(65) NOT NULL DEFAULT '',
  `customer_password` varchar(32) NOT NULL DEFAULT '',
  `customer_phone` varchar(25) DEFAULT '',
  `customer_fax` varchar(32) DEFAULT '',
  `customer_mobile` varchar(25) NOT NULL DEFAULT '',
  `customer_address` varchar(255) DEFAULT '',
  `customer_city` varchar(25) DEFAULT '',
  `customer_country` varchar(25) DEFAULT '',
  `customer_tin` varchar(255) DEFAULT NULL,
  `customer_vrn` varchar(255) DEFAULT NULL,
  `group_id` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_customers_attachments`
--

CREATE TABLE `jos_customers_attachments` (
  `attachment_id` int NOT NULL,
  `attachment_name` varchar(30) NOT NULL DEFAULT '',
  `attachment_path` varchar(255) NOT NULL DEFAULT '',
  `group_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_customers_group`
--

CREATE TABLE `jos_customers_group` (
  `group_id` int NOT NULL,
  `group_type` enum('Cash','Account') DEFAULT 'Cash',
  `group_company` varchar(35) NOT NULL DEFAULT '',
  `group_email` varchar(65) NOT NULL DEFAULT '',
  `group_password` varchar(32) NOT NULL DEFAULT '',
  `group_phone` varchar(25) NOT NULL DEFAULT '',
  `group_fax` varchar(32) DEFAULT '',
  `tin` varchar(255) DEFAULT NULL,
  `vrn` varchar(255) DEFAULT NULL,
  `group_mobile` varchar(25) NOT NULL DEFAULT '',
  `group_address` varchar(255) NOT NULL DEFAULT '',
  `group_city` varchar(25) NOT NULL DEFAULT '',
  `group_country` varchar(25) NOT NULL DEFAULT '',
  `group_rating` int NOT NULL DEFAULT '0',
  `group_notes` text,
  `credit_terms` int DEFAULT NULL,
  `outstanding_report` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `credit_limit_currency` enum('TZS','USD') NOT NULL DEFAULT 'TZS',
  `credit_limit_amount` decimal(15,2) NOT NULL,
  `exempt_credit_amount` decimal(12,0) DEFAULT NULL,
  `exempt_credit_days` int DEFAULT NULL,
  `default_payment_terms` int DEFAULT NULL,
  `notification_email` varchar(150) DEFAULT NULL,
  `industry_id` int DEFAULT '0',
  `salesperson_user_id` int DEFAULT NULL,
  `commission_structure` enum('Key Account','Standard','Bulk') DEFAULT NULL,
  `company_type` enum('Distributor','Wholesale','Retail') DEFAULT NULL,
  `group_status` enum('Active','Inactive','Pending') NOT NULL DEFAULT 'Pending',
  `status` enum('Pending','Approved') NOT NULL DEFAULT 'Pending',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_customer_ledger_oa`
--

CREATE TABLE `jos_customer_ledger_oa` (
  `id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `type` enum('debit','credit') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `group_id` int NOT NULL,
  `currency` char(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'TZS'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_delivery_notes`
--

CREATE TABLE `jos_delivery_notes` (
  `dn_id` int NOT NULL,
  `dn_date_created` datetime DEFAULT NULL,
  `dn_date_modified` datetime DEFAULT NULL,
  `dn_date_delivery` date DEFAULT NULL,
  `dn_description` text,
  `dn_status` enum('Draft','Approved','Issued','Delivered','Closed','Cancelled') DEFAULT 'Draft',
  `dn_quantity` int DEFAULT NULL,
  `invoice_id` int DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `quote_id` int DEFAULT NULL,
  `customer_id` int NOT NULL,
  `delivery_person_name` varchar(255) DEFAULT NULL,
  `delivery_phone_number` varchar(100) DEFAULT NULL,
  `delivery_person_identity` varchar(25) DEFAULT NULL,
  `delivered_to` varchar(255) DEFAULT NULL,
  `attachement` varchar(255) DEFAULT NULL,
  `approval_user_id` int DEFAULT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `jos_departments`
--

CREATE TABLE `jos_departments` (
  `department_id` int NOT NULL,
  `department_name` varchar(50) NOT NULL,
  `department_show` enum('Y','N') NOT NULL,
  `system_department` tinyint NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_dn_items`
--

CREATE TABLE `jos_dn_items` (
  `dn_item_id` int NOT NULL,
  `job_id` int DEFAULT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `description` text,
  `qc_id` int DEFAULT NULL,
  `stock_id` int DEFAULT NULL,
  `dn_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_efa_payout`
--

CREATE TABLE `jos_efa_payout` (
  `id` int NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `purpose_of_pay` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `paid_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_electronics`
--

CREATE TABLE `jos_electronics` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `make` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `serial` varchar(255) NOT NULL,
  `year` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `date_purchased` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_employees`
--

CREATE TABLE `jos_employees` (
  `id` int NOT NULL,
  `staff_type` enum('Local','Expatriate') DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `middle_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) NOT NULL,
  `type` enum('Permanent','Temporary') NOT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `nida_id` varchar(60) DEFAULT NULL,
  `tin_no` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `doe` date DEFAULT NULL,
  `nssf_no` varchar(60) DEFAULT NULL,
  `department` varchar(60) DEFAULT NULL,
  `position` varchar(60) DEFAULT NULL,
  `salary_a` decimal(13,2) DEFAULT NULL,
  `salary_b` decimal(13,2) DEFAULT NULL,
  `hourly_pay_rate` decimal(13,2) DEFAULT NULL,
  `overtime_day_pay` decimal(13,2) NOT NULL DEFAULT '0.00',
  `casual_holiday_pay` decimal(13,2) NOT NULL DEFAULT '0.00',
  `handover_allowance` decimal(13,2) NOT NULL DEFAULT '0.00',
  `disable_ot` tinyint NOT NULL DEFAULT '0',
  `disable_attendance` tinyint NOT NULL DEFAULT '0',
  `disable_payroll` tinyint NOT NULL DEFAULT '0',
  `disable_autocheckout` tinyint NOT NULL DEFAULT '0',
  `night_shift_only` tinyint NOT NULL DEFAULT '0',
  `bank_account` varchar(45) DEFAULT NULL,
  `bank_branch` varchar(45) DEFAULT NULL,
  `contract_date_start` date DEFAULT NULL,
  `contract_date_end` date DEFAULT NULL,
  `emergency_contact` varchar(100) DEFAULT NULL,
  `emergency_contact_no` varchar(45) DEFAULT NULL,
  `benefit_type` varchar(255) DEFAULT NULL,
  `employee_category` enum('HOD','MACHINE OPERATOR','ASSISTANT','CASUAL','DRIVER') DEFAULT NULL,
  `benefit_description` text,
  `benefit_amount` decimal(12,2) DEFAULT NULL,
  `photo` text,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `employee_location` enum('IPL1','IPL2') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_employee_notice`
--

CREATE TABLE `jos_employee_notice` (
  `id` int NOT NULL,
  `employee_id` int NOT NULL,
  `notice_type` enum('Statutory','Contractual') NOT NULL,
  `reference` varchar(255) NOT NULL,
  `notice_tpl_id` int NOT NULL,
  `attachment` text,
  `notice_status` enum('Draft','Approved','Issued','Closed','Cancelled') NOT NULL,
  `user_id` int NOT NULL,
  `approval_user_id` int DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_employee_notice_tpl`
--

CREATE TABLE `jos_employee_notice_tpl` (
  `id` int NOT NULL,
  `tpl_name` varchar(255) NOT NULL,
  `tpl_type` enum('Statutory','Contractual') NOT NULL,
  `tpl_content` text NOT NULL,
  `user_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_employee_remarks`
--

CREATE TABLE `jos_employee_remarks` (
  `id` int NOT NULL,
  `employee_id` int NOT NULL,
  `remarks` text NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_exemptcash`
--

CREATE TABLE `jos_exemptcash` (
  `id` int NOT NULL,
  `reference` int DEFAULT NULL,
  `type` enum('Payout','Supplier') NOT NULL,
  `supplier_id` int DEFAULT NULL,
  `expense_id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `recipient` varchar(100) DEFAULT NULL,
  `remarks` text,
  `confirm_remarks` text,
  `other_remarks` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `account_id` int NOT NULL DEFAULT '6',
  `job_id` int DEFAULT NULL,
  `employee_id` int DEFAULT NULL,
  `paid_to` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `close_attachment` varchar(255) DEFAULT NULL,
  `user_id` int NOT NULL,
  `approval_user_id` int DEFAULT NULL,
  `status` enum('Pending','Confirmed','Approved','Issued','Closed','Cancelled') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Pending',
  `date_issued` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_exemptcash_items`
--

CREATE TABLE `jos_exemptcash_items` (
  `id` int NOT NULL,
  `exemptcash_id` int NOT NULL,
  `lpo_id` int DEFAULT NULL,
  `grn_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_exempt_float_account`
--

CREATE TABLE `jos_exempt_float_account` (
  `id` int NOT NULL,
  `balance` decimal(13,2) NOT NULL,
  `type` enum('Receipt','Payout','Receipt Cancel','Reconcile') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `amount` decimal(13,2) NOT NULL,
  `paid_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `confirm_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `status` enum('Pending','Confirmed','Approved','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Pending',
  `item_id` int DEFAULT NULL,
  `group_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_expenses`
--

CREATE TABLE `jos_expenses` (
  `expense_id` int NOT NULL,
  `expense_code` varchar(10) NOT NULL,
  `expense_name` varchar(255) NOT NULL,
  `expense_category` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `expense_status` enum('Active','Inactive') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Active'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_finance_expense_budgets`
--

CREATE TABLE `jos_finance_expense_budgets` (
  `id` int NOT NULL,
  `budget_month` date NOT NULL,
  `expense_id` int NOT NULL,
  `budget_amount` decimal(15,2) NOT NULL DEFAULT '0.00',
  `currency` char(3) NOT NULL DEFAULT 'TZS',
  `department_override` varchar(100) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `status` enum('Draft','Approved','Archived') NOT NULL DEFAULT 'Approved',
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_finance_report_allocations`
--

CREATE TABLE `jos_finance_report_allocations` (
  `id` int UNSIGNED NOT NULL,
  `allocation_basis` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `allocation_percent` decimal(10,6) NOT NULL DEFAULT '0.000000',
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_finance_report_mapping`
--

CREATE TABLE `jos_finance_report_mapping` (
  `id` int UNSIGNED NOT NULL,
  `source_type` varchar(50) NOT NULL,
  `source_id` varchar(100) NOT NULL,
  `report_section` varchar(50) NOT NULL,
  `report_line` varchar(150) NOT NULL,
  `department` varchar(50) DEFAULT NULL,
  `allocation_type` varchar(50) NOT NULL DEFAULT 'direct',
  `allocation_basis` varchar(50) DEFAULT NULL,
  `active_from` date DEFAULT NULL,
  `active_to` date DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_finance_report_rates`
--

CREATE TABLE `jos_finance_report_rates` (
  `id` int UNSIGNED NOT NULL,
  `rate_name` varchar(50) NOT NULL,
  `rate_value` decimal(12,8) NOT NULL DEFAULT '0.00000000',
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `notes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_finance_sales_targets`
--

CREATE TABLE `jos_finance_sales_targets` (
  `id` int UNSIGNED NOT NULL,
  `target_month` date NOT NULL,
  `department` varchar(50) NOT NULL,
  `target_amount` decimal(18,2) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TZS',
  `notes` varchar(255) DEFAULT NULL,
  `status` enum('Draft','Approved') NOT NULL DEFAULT 'Approved',
  `created_by` int UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_finance_wip_snapshots`
--

CREATE TABLE `jos_finance_wip_snapshots` (
  `id` int UNSIGNED NOT NULL,
  `snapshot_date` date NOT NULL,
  `job_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `department_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `wip_value` decimal(18,2) NOT NULL DEFAULT '0.00',
  `wip_qty` decimal(18,4) NOT NULL DEFAULT '0.0000',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_finishing`
--

CREATE TABLE `jos_finishing` (
  `finishing_id` int NOT NULL,
  `finishing_type` varchar(25) NOT NULL DEFAULT '',
  `finishing_both_sides` enum('N','Y','N/A') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_furniture`
--

CREATE TABLE `jos_furniture` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `make` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  `date_purchased` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_gmr`
--

CREATE TABLE `jos_gmr` (
  `gmr_id` int NOT NULL,
  `movement_from` enum('IPL1','IPL2','IPL1 Workshop (Swahili)','IPL1 Vehicle Branding (Outside)','IPL1 Flexo (Outside)','IPL2 Production','IPL2 Store','Magenta','Customer','Supplier','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `movement_to` enum('IPL1','IPL2','IPL1 Workshop (Swahili)','IPL1 Vehicle Branding (Outside)','IPL1 Flexo (Outside)','IPL2 Production','IPL2 Store','Magenta','Customer','Supplier','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `grm_type` enum('Job','Stock Transfer','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `supplier_id` int DEFAULT NULL,
  `supplier_from_id` int DEFAULT NULL,
  `group_from_id` int DEFAULT NULL,
  `group_to_id` int DEFAULT NULL,
  `other_from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `other_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sample` tinyint DEFAULT '0',
  `job_id` int DEFAULT NULL,
  `delivery_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `checked_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `approval_user_id` int NOT NULL,
  `user_id` int NOT NULL,
  `gmr_status` enum('Draft','Approved','Issued','Closed','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Draft',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_gmr_items`
--

CREATE TABLE `jos_gmr_items` (
  `gmri_id` int NOT NULL,
  `type` enum('job','stock','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `stock_id` int DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `quantity` decimal(12,2) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `material_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `size` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gmr_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_grn`
--

CREATE TABLE `jos_grn` (
  `grn_id` int NOT NULL,
  `grn_date` date NOT NULL,
  `grn_date_updated` datetime DEFAULT NULL,
  `lpo_id` int NOT NULL,
  `contractor_id` int DEFAULT NULL,
  `invoice_no` int DEFAULT NULL,
  `received_by` varchar(255) NOT NULL,
  `grn_type` enum('received','returned') NOT NULL DEFAULT 'received',
  `grn_destination` varchar(255) DEFAULT NULL,
  `remarks` text NOT NULL,
  `attachment_path` varchar(255) DEFAULT NULL,
  `images` text,
  `checklist` text,
  `invoice` tinyint DEFAULT NULL,
  `delivery_note` tinyint DEFAULT NULL,
  `efd` tinyint DEFAULT NULL,
  `price_difference` tinyint DEFAULT NULL,
  `none_vat` tinyint DEFAULT NULL,
  `status` enum('Draft','Issued','Closed','Cancelled') NOT NULL DEFAULT 'Draft',
  `payment_status` enum('Paid','Unpaid') NOT NULL DEFAULT 'Unpaid',
  `update_user_id` int DEFAULT NULL,
  `closed_user_id` int DEFAULT NULL,
  `checklist_approval_user_id` int DEFAULT NULL,
  `close_type` varchar(255) NOT NULL,
  `user_id` int NOT NULL,
  `grn_date_created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_grn_items`
--

CREATE TABLE `jos_grn_items` (
  `grn_item_id` int NOT NULL,
  `grn_id` int NOT NULL,
  `grn_item_qty` decimal(9,2) NOT NULL,
  `sow_unit_rate` decimal(9,2) DEFAULT NULL,
  `lpo_item_id` int NOT NULL,
  `date_expiry` date DEFAULT NULL,
  `job_id` int DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_industries`
--

CREATE TABLE `jos_industries` (
  `industry_id` int NOT NULL,
  `industry_name` varchar(25) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_invoices`
--

CREATE TABLE `jos_invoices` (
  `invoice_id` int NOT NULL,
  `invoice_date` datetime NOT NULL,
  `issue_date` datetime DEFAULT NULL,
  `customer_id` int NOT NULL,
  `invoice_quantity` int NOT NULL,
  `invoice_currency` enum('TZS','USD') NOT NULL,
  `exch_rate` decimal(12,2) DEFAULT '2600.00',
  `invoice_amount` decimal(12,2) NOT NULL,
  `invoice_status` enum('Draft','Issued','Approved','Complete','Cancelled') NOT NULL DEFAULT 'Draft',
  `dn_id` varchar(255) DEFAULT NULL,
  `dn_item_ids` varchar(255) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `notes` text,
  `approval_user_id` int DEFAULT NULL,
  `issuer_user_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `tax` varchar(25) DEFAULT NULL,
  `vat` int NOT NULL DEFAULT '18',
  `vfd_api_response` text,
  `vfd_api_data` text,
  `vfd_status` enum('Success','Processing','Pending','Cancelled') NOT NULL DEFAULT 'Pending',
  `qrcode_img` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_invoice_items`
--

CREATE TABLE `jos_invoice_items` (
  `invoice_item_id` int NOT NULL,
  `dn_item_id` int DEFAULT NULL,
  `qc_id` int DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `item_quantity` decimal(12,2) NOT NULL,
  `item_price` decimal(12,2) NOT NULL,
  `item_description` text,
  `invoice_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_issued_stock`
--

CREATE TABLE `jos_issued_stock` (
  `issued_stock_id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `requisition_id` int NOT NULL,
  `stock_id` int NOT NULL,
  `job_id` int DEFAULT NULL,
  `issued_qty` decimal(9,2) NOT NULL,
  `unit_price` decimal(9,2) DEFAULT NULL,
  `issued_to` varchar(255) DEFAULT NULL,
  `issued_by` varchar(255) DEFAULT NULL,
  `issued_location` varchar(255) DEFAULT NULL,
  `status` enum('Issued','Returned') NOT NULL DEFAULT 'Issued',
  `user_id` int DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_jobs`
--

CREATE TABLE `jos_jobs` (
  `job_id` int NOT NULL,
  `job_date` date DEFAULT NULL,
  `job_time` time NOT NULL DEFAULT '00:00:00',
  `job_reference` varchar(255) NOT NULL DEFAULT '',
  `job_priority` enum('Normal','High') NOT NULL DEFAULT 'Normal',
  `job_due_date` date DEFAULT NULL,
  `job_due_time` time NOT NULL DEFAULT '00:00:00',
  `job_sample` tinyint NOT NULL DEFAULT '0',
  `job_sample_due_date` datetime DEFAULT NULL,
  `job_delivery_info` text,
  `job_product` varchar(10) DEFAULT NULL,
  `job_product_other` varchar(255) DEFAULT NULL,
  `job_num_pages` varchar(10) NOT NULL DEFAULT '0',
  `job_paper_size_open` varchar(25) NOT NULL DEFAULT '',
  `job_paper_size_open_other` varchar(25) DEFAULT NULL,
  `job_paper_size_finished` varchar(25) DEFAULT NULL,
  `job_paper_size_finished_other` varchar(25) DEFAULT NULL,
  `job_description_remarks` text,
  `job_paper_quantity` decimal(10,2) NOT NULL DEFAULT '0.00',
  `job_cover_offset_info` text,
  `job_inner_offset_info` text,
  `job_inner_wide_format_info` text CHARACTER SET latin1 COLLATE latin1_swedish_ci,
  `job_cover_paper_type` varchar(25) NOT NULL DEFAULT '',
  `job_cover_paper_type_other` varchar(25) NOT NULL DEFAULT '',
  `job_cover_paper_desc` varchar(60) DEFAULT NULL,
  `job_cover_paper_weight` int NOT NULL DEFAULT '0',
  `job_cover_sheet_size` varchar(25) DEFAULT NULL,
  `job_cover_cut_size` varchar(25) DEFAULT NULL,
  `job_cover_cut_size_w` decimal(5,2) DEFAULT NULL,
  `job_cover_cut_size_h` decimal(5,2) DEFAULT NULL,
  `job_cover_num_sheets` decimal(10,0) NOT NULL DEFAULT '0',
  `job_cover_num_sheets_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `job_cover_plate_size` varchar(25) DEFAULT NULL,
  `job_cover_total_plates` int DEFAULT NULL,
  `job_inner_paper_type` varchar(25) DEFAULT NULL,
  `job_inner_paper_type_other` varchar(25) DEFAULT NULL,
  `job_inner_paper_desc` varchar(60) DEFAULT NULL,
  `job_inner_paper_weight` int DEFAULT '0',
  `job_inner_sheet_size` varchar(25) DEFAULT NULL,
  `job_inner_cut_size` varchar(25) DEFAULT NULL,
  `job_inner_cut_size_w` decimal(5,2) DEFAULT NULL,
  `job_inner_cut_size_h` decimal(5,2) DEFAULT NULL,
  `job_inner_num_sheets` decimal(10,0) NOT NULL DEFAULT '0',
  `job_inner_num_sheets_total` decimal(9,2) NOT NULL DEFAULT '0.00',
  `job_inner_plate_size` varchar(25) DEFAULT NULL,
  `job_inner_total_plates` int DEFAULT NULL,
  `job_film` enum('Y','N') DEFAULT 'N',
  `job_ctp` enum('Y','N') DEFAULT 'N',
  `job_ups` int DEFAULT '0',
  `job_plates` int DEFAULT '0',
  `job_inner_offset` enum('Y','N') DEFAULT 'N',
  `job_inner_digital` enum('Y','N') DEFAULT 'N',
  `job_inner_wide_format` enum('Y','N') DEFAULT 'N',
  `job_cover_offset` enum('Y','N') DEFAULT 'N',
  `job_cover_digital` enum('Y','N') DEFAULT 'N',
  `job_cover_wide_format` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_cover_promotional` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_inner_promotional` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_inner_machine` varchar(25) DEFAULT NULL,
  `job_cover_machine` varchar(25) DEFAULT NULL,
  `job_inner_impressions` decimal(9,0) DEFAULT '0',
  `job_cover_impressions` decimal(9,0) DEFAULT NULL,
  `job_inner_pre_press` enum('Work/Turn','Work/Tumble','Front/Back','One Side') DEFAULT NULL,
  `job_cover_pre_press` enum('Work/Turn','Work/Tumble','Front/Back','One Side') DEFAULT NULL,
  `job_color` varchar(255) DEFAULT NULL,
  `job_color_other` varchar(25) DEFAULT NULL,
  `job_color_details` varchar(255) DEFAULT NULL,
  `job_inner_no_colors` int DEFAULT NULL,
  `job_cover_no_colors` int DEFAULT NULL,
  `job_cover_print_options` varchar(25) DEFAULT NULL,
  `job_inner_print_options` varchar(25) DEFAULT NULL,
  `job_cover_material` varchar(45) DEFAULT NULL,
  `job_inner_material` varchar(45) DEFAULT NULL,
  `job_inner_total_sq_meter` decimal(8,2) DEFAULT NULL,
  `job_cover_total_sq_meter` decimal(8,2) DEFAULT NULL,
  `job_cover_quantity` int DEFAULT NULL,
  `job_cover_screen_printing` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_cover_embroidery` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_cover_heat_transfer` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_cover_screen_printing_notes` text,
  `job_cover_embroidery_notes` text,
  `job_cover_heat_transfer_notes` text,
  `job_inner_quantity` int DEFAULT NULL,
  `job_inner_screen_printing` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_inner_embroidery` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_inner_heat_transfer` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_inner_screen_printing_notes` text,
  `job_inner_embroidery_notes` text,
  `job_inner_heat_transfer_notes` text,
  `job_inner_notes` text,
  `job_cover_notes` text,
  `job_num_books` decimal(5,0) NOT NULL DEFAULT '0',
  `job_inner_cnc` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_cover_cnc` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_inner_cnc_process_data` text,
  `job_cover_cnc_process_data` text,
  `job_start_no` decimal(7,0) NOT NULL DEFAULT '0',
  `job_book_no` decimal(7,0) NOT NULL DEFAULT '0',
  `job_perforate_all` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_ncr_color` varchar(255) NOT NULL DEFAULT '',
  `job_ncr_color_other` varchar(25) NOT NULL DEFAULT '',
  `job_inner_stationary` enum('Y','N') NOT NULL DEFAULT 'N',
  `job_inner_stationary_type` varchar(255) DEFAULT NULL,
  `job_inner_stationary_notes` text,
  `job_ygbp_2` varchar(10) NOT NULL DEFAULT 'None',
  `job_ygbp_3` varchar(10) NOT NULL DEFAULT 'None',
  `job_ygbp_4` varchar(10) NOT NULL DEFAULT 'None',
  `job_ygbp_5` varchar(10) NOT NULL DEFAULT 'None',
  `job_ygbp_6` varchar(10) NOT NULL DEFAULT 'None',
  `job_ygbp_7` varchar(10) NOT NULL DEFAULT 'None',
  `job_finishing` text COMMENT 'Serialized Array',
  `job_remarks` text,
  `job_price_1` decimal(10,2) NOT NULL DEFAULT '0.00',
  `job_price_2` decimal(7,2) NOT NULL DEFAULT '0.00',
  `job_price_discount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `job_invoice_date` date DEFAULT NULL,
  `job_invoice_no` varchar(12) DEFAULT NULL,
  `job_status` enum('Pending','In Production','Production Complete','Complete','Cancelled') NOT NULL DEFAULT 'Pending',
  `job_status_notes` text,
  `status_remarks` text,
  `job_approval_date` datetime DEFAULT NULL,
  `approved_due_date` date DEFAULT NULL,
  `job_approval_user_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `warranty_expiry_date` date DEFAULT NULL,
  `type` enum('Sale','Production') NOT NULL DEFAULT 'Sale',
  `employee_id` int DEFAULT NULL,
  `group_id` int NOT NULL DEFAULT '0',
  `item_id` int NOT NULL DEFAULT '0',
  `closed_user_id` int DEFAULT NULL,
  `user_id` int NOT NULL DEFAULT '0',
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_jobs_groups`
--

CREATE TABLE `jos_jobs_groups` (
  `group_id` int NOT NULL,
  `customer_id` int NOT NULL DEFAULT '0',
  `customer_representative` text,
  `job_lpo` varchar(25) NOT NULL DEFAULT '',
  `job_lpo_other` varchar(25) NOT NULL DEFAULT '',
  `receipt_id` int DEFAULT NULL,
  `quote_id` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_jobs_progress`
--

CREATE TABLE `jos_jobs_progress` (
  `progress_id` int NOT NULL,
  `progress_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `progress_quantity` decimal(9,2) NOT NULL DEFAULT '0.00',
  `progress_user_id` int NOT NULL DEFAULT '0',
  `check_date` date NOT NULL DEFAULT '0000-00-00',
  `check_do` varchar(12) NOT NULL DEFAULT '',
  `dn_item_id` int DEFAULT NULL,
  `check_user_id` int NOT NULL DEFAULT '0',
  `checked_by` varchar(50) DEFAULT NULL,
  `delivery_person` varchar(50) DEFAULT NULL,
  `job_id` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_job_amendments`
--

CREATE TABLE `jos_job_amendments` (
  `id` int NOT NULL,
  `type` enum('Specifications','Quantity','Other') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `job_id` int NOT NULL,
  `changes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `status` enum('Pending','Approved','Rejected','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Pending',
  `emailed` tinyint DEFAULT NULL,
  `user_id` int NOT NULL,
  `approval_user_id` int DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_job_history`
--

CREATE TABLE `jos_job_history` (
  `log_id` int NOT NULL,
  `job_id` int NOT NULL,
  `datetime` datetime NOT NULL,
  `department_old` varchar(50) DEFAULT NULL,
  `department_new` varchar(50) DEFAULT NULL,
  `project_manager` varchar(255) NOT NULL,
  `log_type` varchar(50) NOT NULL DEFAULT 'department',
  `section_id` int DEFAULT NULL,
  `notes` text,
  `email_user_ids` varchar(250) DEFAULT NULL,
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_ledger_accounts`
--

CREATE TABLE `jos_ledger_accounts` (
  `id` int NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `currency` enum('USD','TZS') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `balance` decimal(18,6) NOT NULL DEFAULT '0.000000',
  `status` enum('Active','Closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Active',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_order` smallint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_ledger_oa`
--

CREATE TABLE `jos_ledger_oa` (
  `id` int NOT NULL,
  `date_from` date NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `group_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_loaned_tools`
--

CREATE TABLE `jos_loaned_tools` (
  `id` int NOT NULL,
  `tool_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `job_id` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `date_issued` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `status` enum('Pending','Issued','Returned') NOT NULL DEFAULT 'Pending',
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_lpo`
--

CREATE TABLE `jos_lpo` (
  `lpo_id` int NOT NULL,
  `lpo_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `supplier_id` int NOT NULL DEFAULT '0',
  `casual_supplier_name` varchar(255) DEFAULT NULL,
  `lpo_payment_terms` varchar(255) DEFAULT NULL,
  `payment_type` enum('Cash','Bank Transfer','Cheque','Credit') DEFAULT NULL,
  `payment_status` enum('Payment Approved','Transfer Approved') DEFAULT NULL,
  `lpo_info` text,
  `lpo_currency` enum('TZS','USD','KSHS','GBP') NOT NULL,
  `exch_rate` decimal(12,2) DEFAULT NULL,
  `lpo_tax` enum('Taxable','Exempt') NOT NULL,
  `lpo_supplier` text NOT NULL,
  `casual_supplier_phone` varchar(255) DEFAULT NULL,
  `supplier_reference` varchar(50) DEFAULT NULL,
  `lpo_destination` varchar(255) DEFAULT NULL,
  `lpo_attention` text NOT NULL,
  `lpo_urgent` enum('N','Y') NOT NULL DEFAULT 'N',
  `comments` text,
  `cancel_reason` text,
  `lpo_delivery_date` date DEFAULT NULL,
  `delivery_time` int DEFAULT NULL,
  `lpo_status` enum('Pending','Cancelled','Approved','Final Approved','Complete') NOT NULL DEFAULT 'Pending',
  `job_id` int DEFAULT NULL,
  `repair_ticket_id` int DEFAULT NULL,
  `approval_date` datetime DEFAULT NULL,
  `approval_user_id` int DEFAULT NULL,
  `cancelled_by_user_id` int DEFAULT NULL,
  `attachment` text,
  `cob` tinyint NOT NULL DEFAULT '0',
  `appealed` tinyint NOT NULL DEFAULT '0',
  `user_id` int NOT NULL DEFAULT '0',
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_lpo_items`
--

CREATE TABLE `jos_lpo_items` (
  `item_id` int NOT NULL,
  `item_description` text NOT NULL,
  `stock_id` int NOT NULL DEFAULT '0',
  `expense_id` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `asset_category` varchar(150) DEFAULT NULL,
  `asset_id` int DEFAULT NULL,
  `item_qty` decimal(9,2) NOT NULL DEFAULT '0.00',
  `item_qty_per_pack` decimal(9,2) NOT NULL DEFAULT '0.00',
  `item_unit_price` decimal(18,6) NOT NULL DEFAULT '0.000000',
  `item_general_notes` text,
  `invoice_no` varchar(100) DEFAULT NULL,
  `repair_ticket_id` int DEFAULT NULL,
  `lpo_id` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_materials`
--

CREATE TABLE `jos_materials` (
  `material_id` int NOT NULL,
  `material_name` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_notes`
--

CREATE TABLE `jos_notes` (
  `note_id` int NOT NULL,
  `note_date` date DEFAULT NULL,
  `note_body` text NOT NULL,
  `group_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_papers`
--

CREATE TABLE `jos_papers` (
  `paper_id` int NOT NULL,
  `paper_name` varchar(25) NOT NULL DEFAULT '',
  `paper_custom_weight` enum('N','Y','N/A') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payment_terms`
--

CREATE TABLE `jos_payment_terms` (
  `payment_id` int NOT NULL,
  `payment_term` varchar(50) NOT NULL DEFAULT '',
  `advance_required` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `advance_percentage` enum('0','50','100') DEFAULT NULL,
  `payment_on_delivery` enum('Yes','No') DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payrolls`
--

CREATE TABLE `jos_payrolls` (
  `id` int NOT NULL,
  `payroll_date` date NOT NULL,
  `status` enum('Draft','Processed','Cancelled') NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payroll_advances`
--

CREATE TABLE `jos_payroll_advances` (
  `id` int NOT NULL,
  `employee_id` int NOT NULL,
  `advance_date` date NOT NULL,
  `advance_month` varchar(10) NOT NULL,
  `advance_amount_a` decimal(13,2) NOT NULL,
  `advance_amount_b` decimal(13,2) NOT NULL,
  `currency` enum('TZS') NOT NULL DEFAULT 'TZS',
  `status` enum('Pending','Confirmed','Cancelled') NOT NULL DEFAULT 'Confirmed',
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payroll_damage_report`
--

CREATE TABLE `jos_payroll_damage_report` (
  `id` int NOT NULL,
  `employee_id` int NOT NULL,
  `date_applied` date DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `no_of_months` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `remarks` text NOT NULL,
  `attachment` text,
  `case_status` enum('Pending','Confirmed','Closed','Cancelled') NOT NULL DEFAULT 'Pending',
  `confirmed_user_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payroll_data`
--

CREATE TABLE `jos_payroll_data` (
  `id` int NOT NULL,
  `payroll_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `currency` enum('USD','TZS') NOT NULL DEFAULT 'TZS',
  `payroll_salary_a` decimal(13,2) DEFAULT NULL,
  `payroll_salary_b` decimal(13,2) DEFAULT NULL,
  `leave_pay_a` decimal(13,2) NOT NULL DEFAULT '0.00',
  `severance_pay_a` decimal(13,2) NOT NULL DEFAULT '0.00',
  `leave_pay_b` decimal(13,2) NOT NULL DEFAULT '0.00',
  `severance_pay_b` decimal(13,2) NOT NULL DEFAULT '0.00',
  `damage_deductions` decimal(13,2) DEFAULT '0.00',
  `deduction_addback` decimal(13,2) NOT NULL DEFAULT '0.00',
  `absent_days` int DEFAULT NULL,
  `advance_amount_a` decimal(13,2) NOT NULL DEFAULT '0.00',
  `advance_amount_b` int NOT NULL,
  `gross_salary` decimal(13,2) DEFAULT NULL,
  `nssf_pay` decimal(13,2) DEFAULT NULL,
  `paye_amount` decimal(13,2) DEFAULT NULL,
  `net_pay` decimal(13,2) DEFAULT NULL,
  `user_id` int NOT NULL,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payroll_leaves`
--

CREATE TABLE `jos_payroll_leaves` (
  `id` int NOT NULL,
  `employee_id` int NOT NULL,
  `leave_type` enum('Annual Leave','Sick Leave','Compassionate Leave','Unpaid Leave','Maternity Leave') NOT NULL,
  `year` year NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `duration` int NOT NULL,
  `leave_balance` int NOT NULL,
  `leave_status` enum('Pending','Confirmed','Closed','Cancelled') NOT NULL DEFAULT 'Pending',
  `attachment_path` varchar(255) DEFAULT NULL,
  `confirmed_user_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payroll_loans`
--

CREATE TABLE `jos_payroll_loans` (
  `id` int NOT NULL,
  `employee_id` int NOT NULL,
  `date_applied` date DEFAULT NULL,
  `no_of_months` int NOT NULL,
  `deduction_amount` decimal(12,2) NOT NULL,
  `remarks` text,
  `loan_status` enum('Pending','Confirmed','Closed','Cancelled') NOT NULL DEFAULT 'Pending',
  `confirmed_user_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payroll_security_funds`
--

CREATE TABLE `jos_payroll_security_funds` (
  `id` int NOT NULL,
  `country` enum('Tanzania') NOT NULL,
  `sf_name` varchar(25) NOT NULL,
  `contribution` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_payroll_taxes`
--

CREATE TABLE `jos_payroll_taxes` (
  `id` int NOT NULL,
  `tax_name` varchar(25) DEFAULT NULL,
  `tax_currency` enum('TZS') NOT NULL,
  `country` varchar(45) NOT NULL,
  `effective_from` date DEFAULT NULL,
  `applicable_on` enum('Gross Amount','Taxable Amount') NOT NULL,
  `type` enum('Fixed %','Tax Table') NOT NULL,
  `fixed_rate` decimal(5,2) DEFAULT NULL,
  `table_data` text,
  `status` enum('Active','Disabled') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `jos_pettycash_items`
--

CREATE TABLE `jos_pettycash_items` (
  `id` int NOT NULL,
  `pc_id` int NOT NULL,
  `lpo_id` int DEFAULT NULL,
  `grn_id` int DEFAULT NULL,
  `sow_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_pettycash_mobile_items`
--

CREATE TABLE `jos_pettycash_mobile_items` (
  `id` int NOT NULL,
  `pcm_id` int NOT NULL,
  `lpo_id` int DEFAULT NULL,
  `grn_id` int DEFAULT NULL,
  `sow_id` int DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_petty_cash`
--

CREATE TABLE `jos_petty_cash` (
  `id` int NOT NULL,
  `reference` int DEFAULT NULL,
  `type` enum('Miscellaneous','Job','Supplier','Direct') NOT NULL,
  `supplier_id` int DEFAULT NULL,
  `contractor_id` int DEFAULT NULL,
  `lpo_id` int DEFAULT NULL,
  `expense_id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `tax` enum('Taxable','Exempt') NOT NULL DEFAULT 'Exempt',
  `wht_tax` enum('Taxable','Exempt') NOT NULL DEFAULT 'Exempt',
  `recipient` varchar(100) DEFAULT NULL,
  `remarks` text,
  `confirm_remarks` text,
  `user_id` int NOT NULL,
  `employee_id` int DEFAULT NULL,
  `approval_user_id` int DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `account_id` int NOT NULL DEFAULT '12',
  `date_issued` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `approval_attachment` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_petty_cash_mobile`
--

CREATE TABLE `jos_petty_cash_mobile` (
  `id` int NOT NULL,
  `reference` int DEFAULT NULL,
  `type` enum('Miscellaneous','Job','Supplier','Direct','GEPG Payment','Contra','Customer') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `supplier_id` int DEFAULT NULL,
  `contractor_id` int DEFAULT NULL,
  `lpo_id` int DEFAULT NULL,
  `expense_id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `currency` char(3) DEFAULT NULL,
  `exch_rate` decimal(12,2) DEFAULT NULL,
  `tax` enum('Taxable','Exempt') NOT NULL DEFAULT 'Exempt',
  `wht_tax` enum('Taxable','Exempt') NOT NULL DEFAULT 'Exempt',
  `taxed_amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `wht_percent` int DEFAULT NULL,
  `recipient` varchar(100) DEFAULT NULL,
  `remarks` text,
  `issue_type` enum('Bank Transfer','Cheque') NOT NULL DEFAULT 'Bank Transfer',
  `issue_reference` varchar(255) NOT NULL,
  `issue_directly` tinyint DEFAULT NULL,
  `user_id` int NOT NULL,
  `employee_id` int DEFAULT NULL,
  `approval_user_id` int DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `account_id` int DEFAULT NULL,
  `to_account_id` int DEFAULT NULL,
  `gepg_type` enum('Import Duties','Statutory','TBS','Luku','Other') DEFAULT NULL,
  `control_number` varchar(255) DEFAULT NULL,
  `group_id` int DEFAULT NULL,
  `payment_type` enum('Quote','Receipt') DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `network` varchar(30) NOT NULL DEFAULT 'Tigo',
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `date_approved` datetime DEFAULT NULL,
  `date_processed` datetime DEFAULT NULL,
  `issued_by_user_id` int DEFAULT NULL,
  `processed_by_user_id` int DEFAULT NULL,
  `approval_attachment` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_printers`
--

CREATE TABLE `jos_printers` (
  `printer_id` int NOT NULL,
  `printer_name` varchar(25) NOT NULL DEFAULT '',
  `shift_capacity` decimal(12,2) DEFAULT NULL,
  `unit_of_shift` enum('Impressions','Pcs','Hours','SQM') DEFAULT NULL,
  `make` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `printer_show` enum('N','Y') NOT NULL DEFAULT 'Y'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_print_colors`
--

CREATE TABLE `jos_print_colors` (
  `color_id` int NOT NULL,
  `color_name` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_print_processes`
--

CREATE TABLE `jos_print_processes` (
  `print_process_id` int NOT NULL,
  `print_process_name` varchar(50) NOT NULL,
  `print_process_show` enum('Y','N') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_products`
--

CREATE TABLE `jos_products` (
  `product_id` int NOT NULL,
  `product_name` varchar(50) NOT NULL DEFAULT '',
  `product_type` enum('Standard','Paper','Books') NOT NULL,
  `product_ref` varchar(10) NOT NULL DEFAULT '',
  `category_id` int DEFAULT NULL,
  `product_2rows` enum('N','Y') NOT NULL DEFAULT 'N',
  `product_sort` int NOT NULL DEFAULT '100',
  `product_specifications` text,
  `bypass_sample_qc` tinyint DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_product_categories`
--

CREATE TABLE `jos_product_categories` (
  `id` int NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_product_papers`
--

CREATE TABLE `jos_product_papers` (
  `item_id` int NOT NULL DEFAULT '0',
  `paper_id` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_project_checklist`
--

CREATE TABLE `jos_project_checklist` (
  `id` int NOT NULL,
  `quote_id` int NOT NULL,
  `site_name` varchar(255) DEFAULT NULL,
  `checklist_status` enum('Open','Closed','Cancelled') NOT NULL DEFAULT 'Open',
  `attachment` varchar(255) NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_project_checklist_items`
--

CREATE TABLE `jos_project_checklist_items` (
  `id` int NOT NULL,
  `job_id` int NOT NULL,
  `completed` enum('Yes','No') NOT NULL,
  `comments` text NOT NULL,
  `checklist_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_qc`
--

CREATE TABLE `jos_qc` (
  `id` int NOT NULL,
  `type` enum('Normal','Sample') NOT NULL DEFAULT 'Normal',
  `job_id` int NOT NULL,
  `given_by_employee_id` int NOT NULL,
  `checked_by_user_id` int NOT NULL,
  `verified_by` varchar(255) DEFAULT NULL,
  `quantity` decimal(12,2) NOT NULL,
  `balance` decimal(12,2) NOT NULL,
  `rejected_quantity` decimal(12,2) DEFAULT NULL,
  `department_id` int NOT NULL,
  `comments` text,
  `rejection_comments` text,
  `delivered` tinyint DEFAULT NULL,
  `qc_status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `sample_approval_date` datetime DEFAULT NULL,
  `qc_duedate_review` date DEFAULT NULL,
  `qc_location` enum('IPL1','IPL2') NOT NULL,
  `sample_approval_user` int DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_quotes`
--

CREATE TABLE `jos_quotes` (
  `quote_id` int NOT NULL,
  `quote_date` datetime DEFAULT NULL,
  `customer_id` int NOT NULL DEFAULT '0',
  `quote_customer` text NOT NULL,
  `quote_total` decimal(10,2) NOT NULL,
  `quote_discount` decimal(10,2) NOT NULL,
  `quote_total_due` decimal(10,2) NOT NULL,
  `currency` enum('TZS','USD') NOT NULL DEFAULT 'TZS',
  `quote_payment_terms` varchar(200) DEFAULT NULL,
  `quote_validity` varchar(200) DEFAULT NULL,
  `tax` enum('Taxable','Exempt') NOT NULL,
  `vat` int NOT NULL DEFAULT '18',
  `exch_rate` decimal(12,2) DEFAULT NULL,
  `wht_amount` decimal(12,2) DEFAULT NULL,
  `quote_template` enum('Blank','Normal') NOT NULL DEFAULT 'Normal',
  `quote_status` enum('Pending','Cancelled','Confirmed','Approved','Closed') NOT NULL DEFAULT 'Pending',
  `approval_date` datetime DEFAULT NULL,
  `approval_user_id` int DEFAULT NULL,
  `confirmed_user_id` int DEFAULT NULL,
  `advance_amount` decimal(15,2) DEFAULT '0.00',
  `advance_mode` enum('Cash','Cheque','Transfer') DEFAULT NULL,
  `advance_info` text,
  `job_due_date` date DEFAULT NULL,
  `job_due_time` time DEFAULT NULL,
  `employee_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `quote_branch` varchar(255) NOT NULL,
  `job_delivery_data` text,
  `invoicing_type` enum('Partial Invoicing Applicable','Full Invoicing Applicable') DEFAULT NULL,
  `confirm_date` datetime DEFAULT NULL,
  `override_outstanding` tinyint DEFAULT NULL,
  `override_comments` text,
  `user_id` int NOT NULL DEFAULT '0',
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_confirmed` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_quotes_items`
--

CREATE TABLE `jos_quotes_items` (
  `item_id` int NOT NULL,
  `item_product` varchar(10) NOT NULL DEFAULT '',
  `item_product_other` varchar(25) NOT NULL DEFAULT '',
  `item_title` varchar(255) NOT NULL DEFAULT '',
  `item_origination` varchar(255) NOT NULL DEFAULT '',
  `item_delivery_days` int NOT NULL,
  `item_paper_size` varchar(25) NOT NULL DEFAULT '',
  `item_paper_size_other` varchar(25) NOT NULL DEFAULT '',
  `item_paper_size_w` decimal(8,0) NOT NULL DEFAULT '0',
  `item_paper_size_h` decimal(8,0) NOT NULL DEFAULT '0',
  `item_paper_size_open` varchar(25) NOT NULL DEFAULT '',
  `item_paper_size_open_other` varchar(25) NOT NULL DEFAULT '',
  `item_paper_size_open_w` decimal(8,0) NOT NULL DEFAULT '0',
  `item_paper_size_open_h` decimal(8,0) NOT NULL DEFAULT '0',
  `item_orientation` varchar(25) NOT NULL DEFAULT '',
  `item_num_pages` int DEFAULT NULL,
  `item_cover_paper_type` varchar(255) NOT NULL DEFAULT '',
  `item_cover_paper_type_other` varchar(25) NOT NULL DEFAULT '',
  `item_cover_paper_desc` varchar(255) NOT NULL DEFAULT '',
  `item_cover_paper_weight` int NOT NULL DEFAULT '0',
  `item_cover_color` varchar(255) NOT NULL DEFAULT '',
  `item_cover_color_other` varchar(25) NOT NULL DEFAULT '',
  `item_cover_print_options` varchar(25) NOT NULL DEFAULT '',
  `item_cover_sheet_size` varchar(30) DEFAULT NULL,
  `item_cover_cut_size` varchar(25) DEFAULT NULL,
  `item_cover_cut_size_w` varchar(30) DEFAULT NULL,
  `item_cover_cut_size_h` varchar(30) DEFAULT NULL,
  `item_cover_num_sheets` decimal(10,0) NOT NULL DEFAULT '0',
  `item_cover_num_sheets_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `item_cover_plate_size` varchar(25) NOT NULL,
  `item_cover_total_plates` int NOT NULL,
  `item_cover_offset` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_digital` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_wide_format` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_promotional` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_offset_data` text,
  `item_inner_cut_size_w` decimal(8,2) DEFAULT NULL,
  `item_inner_cut_size_h` decimal(8,2) DEFAULT NULL,
  `item_inner_paper_type` varchar(255) NOT NULL DEFAULT '',
  `item_inner_paper_type_other` varchar(25) NOT NULL DEFAULT '',
  `item_inner_paper_desc` varchar(255) NOT NULL DEFAULT '',
  `item_inner_paper_weight` char(5) NOT NULL,
  `item_inner_color` varchar(255) NOT NULL DEFAULT '',
  `item_inner_color_other` varchar(25) NOT NULL DEFAULT '',
  `item_inner_print_options` varchar(25) NOT NULL DEFAULT '',
  `item_inner_num_sheets` decimal(10,0) NOT NULL DEFAULT '0',
  `item_inner_num_sheets_total` decimal(9,2) NOT NULL DEFAULT '0.00',
  `item_inner_plate_size` varchar(25) NOT NULL,
  `item_inner_total_plates` int NOT NULL,
  `item_inner_digital` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_offset` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_wide_format` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_offset_data` text,
  `item_inner_wide_format_data` text,
  `item_print_process` varchar(255) NOT NULL DEFAULT '',
  `item_finishing` text NOT NULL COMMENT 'Serialized Array',
  `item_quantity_1` decimal(9,2) NOT NULL DEFAULT '0.00',
  `item_price_1` decimal(18,6) NOT NULL DEFAULT '0.000000',
  `item_quantity_2` decimal(7,2) NOT NULL DEFAULT '0.00',
  `item_price_2` decimal(7,2) NOT NULL DEFAULT '0.00',
  `item_quantity_3` decimal(7,2) NOT NULL DEFAULT '0.00',
  `item_price_3` decimal(7,2) NOT NULL DEFAULT '0.00',
  `item_description_text` text,
  `item_payment_terms` varchar(50) DEFAULT NULL,
  `item_notes` text NOT NULL,
  `item_special_remarks` text NOT NULL,
  `item_inner_promotional` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_machine` varchar(25) NOT NULL DEFAULT '',
  `item_cover_machine` varchar(25) NOT NULL,
  `item_inner_impressions` decimal(9,0) NOT NULL DEFAULT '0',
  `item_cover_impressions` decimal(9,0) NOT NULL,
  `item_inner_pre_press` enum('Work/Turn','Work/Tumble','Front/Back','One Side') NOT NULL,
  `item_cover_pre_press` enum('Work/Turn','Work/Tumble','Front/Back','One Side') DEFAULT NULL,
  `item_inner_no_colors` int NOT NULL,
  `item_cover_no_colors` int NOT NULL,
  `item_cover_material` varchar(45) NOT NULL,
  `item_inner_material` varchar(45) NOT NULL,
  `item_inner_total_sq_meter` decimal(8,2) NOT NULL,
  `item_cover_total_sq_meter` decimal(8,2) NOT NULL,
  `item_cover_quantity` int NOT NULL,
  `item_cover_screen_printing` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_embroidery` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_heat_transfer` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_screen_printing_notes` text NOT NULL,
  `item_cover_embroidery_notes` text NOT NULL,
  `item_cover_heat_transfer_notes` text NOT NULL,
  `item_inner_quantity` int NOT NULL,
  `item_inner_screen_printing` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_embroidery` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_heat_transfer` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_screen_printing_notes` text NOT NULL,
  `item_inner_embroidery_notes` text NOT NULL,
  `item_inner_heat_transfer_notes` text NOT NULL,
  `item_inner_notes` text NOT NULL,
  `item_cover_notes` text NOT NULL,
  `item_num_books` decimal(5,0) NOT NULL DEFAULT '0',
  `item_inner_cnc` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_cover_cnc` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_cnc_process_data` text NOT NULL,
  `item_cover_cnc_process_data` text NOT NULL,
  `item_start_no` decimal(7,0) NOT NULL DEFAULT '0',
  `item_book_no` decimal(7,0) NOT NULL DEFAULT '0',
  `item_perforate_all` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_ncr_color` varchar(255) NOT NULL DEFAULT '',
  `item_ncr_color_other` varchar(25) NOT NULL DEFAULT '',
  `item_inner_stationary` enum('Y','N') NOT NULL DEFAULT 'N',
  `item_inner_stationary_type` varchar(255) DEFAULT NULL,
  `item_inner_stationary_notes` text,
  `item_wht_amount` decimal(12,2) DEFAULT NULL,
  `item_job_due_date` datetime DEFAULT NULL,
  `item_job_sample` tinyint NOT NULL DEFAULT '0',
  `item_sample_due_date` datetime DEFAULT NULL,
  `stock_id` int DEFAULT NULL,
  `quote_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_quotes_outstanding`
--

CREATE TABLE `jos_quotes_outstanding` (
  `id` int NOT NULL,
  `quote_id` int NOT NULL,
  `status` enum('Pending','Paid','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Pending',
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_receipts`
--

CREATE TABLE `jos_receipts` (
  `receipt_id` int NOT NULL,
  `receipt_date` datetime NOT NULL,
  `receipt_date_updated` datetime DEFAULT NULL,
  `receipt_type` enum('Quote','Invoice','Allocation','Misceleneous') NOT NULL,
  `receipt_currency` enum('TZS','USD') NOT NULL,
  `exch_rate` decimal(12,2) DEFAULT NULL,
  `receipt_amount` decimal(12,2) NOT NULL,
  `receipt_method` enum('Cash','LKS') NOT NULL,
  `on_account` decimal(12,2) DEFAULT NULL,
  `total_received` decimal(12,2) NOT NULL DEFAULT '0.00',
  `wht` int DEFAULT NULL,
  `account_id` int DEFAULT NULL,
  `bank_account` varchar(255) DEFAULT NULL,
  `status` enum('Valid','Cancelled') NOT NULL DEFAULT 'Valid',
  `customer_id` int NOT NULL,
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_receipt_items`
--

CREATE TABLE `jos_receipt_items` (
  `ri_id` int NOT NULL,
  `quote_invoice_id` int NOT NULL,
  `item_amount` decimal(12,2) NOT NULL,
  `receipt_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_repair_ticket`
--

CREATE TABLE `jos_repair_ticket` (
  `id` int NOT NULL,
  `date_repaired` datetime DEFAULT NULL,
  `asset_category` enum('Tools','Machines','Vehicles','Electronic Equipment','Furniture and Fixtures','Other') DEFAULT NULL,
  `asset_id` int NOT NULL,
  `other_asset_name` varchar(255) NOT NULL,
  `printer_id` int DEFAULT NULL,
  `operator_user_id` int DEFAULT NULL,
  `description` text NOT NULL,
  `work_performed_by` varchar(255) NOT NULL,
  `remarks` text,
  `status` enum('Active','Closed') NOT NULL,
  `type` enum('Routine Service','New Problem') NOT NULL DEFAULT 'New Problem',
  `service_item` enum('Printer','Air Conditioner','Fan','Fire Extinguisher') DEFAULT NULL,
  `ticket_location` enum('IPL1','IPL2') NOT NULL DEFAULT 'IPL1',
  `attachment_path` varchar(255) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_repair_work`
--

CREATE TABLE `jos_repair_work` (
  `id` int NOT NULL,
  `ticket_id` int NOT NULL,
  `engineer_name` varchar(255) DEFAULT NULL,
  `remarks` text NOT NULL,
  `engineer_remarks` text,
  `hod_remarks` text,
  `start_time` datetime DEFAULT NULL,
  `stop_time` datetime DEFAULT NULL,
  `hod_user_id` int DEFAULT NULL,
  `user_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_requisition`
--

CREATE TABLE `jos_requisition` (
  `requisition_id` int NOT NULL,
  `job_id` int DEFAULT NULL,
  `requisition_location` enum('IPL1','IPL2') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `requisition_status` enum('Draft','Approved','Complete','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Draft',
  `requisition_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `approval_date` datetime DEFAULT NULL,
  `approval_user_id` int DEFAULT NULL,
  `cancel_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_requisitions`
--

CREATE TABLE `jos_requisitions` (
  `requisition_id` int NOT NULL,
  `requisition_date` datetime NOT NULL,
  `requisition_date_updated` datetime DEFAULT NULL,
  `requisition_for` enum('Job','Stock','Stock Refill','Stock Return') NOT NULL,
  `sample` tinyint DEFAULT NULL,
  `sample_image` text,
  `location` enum('IPL1','IPL2') NOT NULL,
  `date_required` date DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `stock_id` int DEFAULT NULL,
  `item_description` varchar(255) DEFAULT NULL,
  `quantity` decimal(9,2) NOT NULL,
  `issued_qty` decimal(9,2) NOT NULL,
  `issued_to` varchar(255) DEFAULT NULL,
  `issued_location` varchar(255) DEFAULT NULL,
  `approval_user_id` int NOT NULL,
  `approval_date` datetime NOT NULL,
  `status` enum('Draft','Approved','Complete','Cancelled') NOT NULL,
  `user_id` int NOT NULL,
  `remarks` text,
  `cancel_remarks` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_requisition_is`
--

CREATE TABLE `jos_requisition_is` (
  `ris_id` int NOT NULL,
  `status` enum('Issued','Returned') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Issued',
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_requisition_isi`
--

CREATE TABLE `jos_requisition_isi` (
  `risi_id` int NOT NULL,
  `issued_qty` decimal(9,2) NOT NULL,
  `issued_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `issued_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ri_id` int NOT NULL,
  `ris_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_requisition_issued_stock`
--

CREATE TABLE `jos_requisition_issued_stock` (
  `ris_id` int NOT NULL,
  `issued_qty` decimal(9,2) NOT NULL,
  `issued_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `issued_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` enum('Issued','Returned') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Issued',
  `ri_id` int NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_requisition_items`
--

CREATE TABLE `jos_requisition_items` (
  `ri_id` int NOT NULL,
  `type` enum('Normal','Stock','Stock Refill','Stock Return') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `stock_id` int DEFAULT NULL,
  `sample` tinyint DEFAULT NULL,
  `sample_image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `quantity` decimal(9,2) NOT NULL,
  `item_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `requisition_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_sales_report`
--

CREATE TABLE `jos_sales_report` (
  `id` int NOT NULL,
  `report_type` enum('Clients Visited','Jobs Follow Up','Quotes Issued','Other','Jobs Issued') NOT NULL,
  `group_id` int DEFAULT NULL,
  `job_id` int DEFAULT NULL,
  `collection_amount` decimal(13,2) DEFAULT NULL,
  `payment_expected_date` date DEFAULT NULL,
  `remarks` text,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_sales_visitplan`
--

CREATE TABLE `jos_sales_visitplan` (
  `vp_id` int NOT NULL,
  `vp_date` date DEFAULT NULL,
  `vp_time` time DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration` int DEFAULT NULL,
  `group_id` int DEFAULT NULL,
  `client_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `visit_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `contact_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `fare_amount` decimal(12,2) DEFAULT NULL,
  `user_id` int NOT NULL,
  `status` enum('Valid','Cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Valid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_schedule`
--

CREATE TABLE `jos_schedule` (
  `schedule_id` int NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `shift` enum('Day','Night') NOT NULL,
  `department_id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `user_id` int NOT NULL,
  `status` enum('Pending','Approved','Closed','Cancelled') NOT NULL DEFAULT 'Pending'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_schedule_drivers`
--

CREATE TABLE `jos_schedule_drivers` (
  `se_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `si_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_schedule_employees`
--

CREATE TABLE `jos_schedule_employees` (
  `se_id` int NOT NULL,
  `employee_id` int NOT NULL,
  `si_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_schedule_items`
--

CREATE TABLE `jos_schedule_items` (
  `si_id` int NOT NULL,
  `printer_id` int NOT NULL DEFAULT '0',
  `expected_qty` decimal(10,2) NOT NULL,
  `final_qty` decimal(10,2) NOT NULL,
  `task` text NOT NULL,
  `job_id` int NOT NULL DEFAULT '0',
  `schedule_id` int NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `stop_time` datetime DEFAULT NULL,
  `estimated_time` varchar(100) DEFAULT NULL,
  `comments` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_sizes`
--

CREATE TABLE `jos_sizes` (
  `size_id` int NOT NULL,
  `paper_category` enum('Open','Finished','Sheet','Cut') NOT NULL DEFAULT 'Open',
  `paper_size` varchar(25) NOT NULL DEFAULT '',
  `paper_width` decimal(5,2) NOT NULL DEFAULT '0.00',
  `paper_height` decimal(5,2) NOT NULL DEFAULT '0.00',
  `paper_custom` enum('N','Y') NOT NULL DEFAULT 'N'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_stock`
--

CREATE TABLE `jos_stock` (
  `stock_id` int NOT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `stock_name` varchar(255) NOT NULL,
  `category` enum('Offset Paper','Offset Consumables','Wide Format','Promotional','T-Shirt','Signage','Screen Printing Consumables','Misc','Building Material','Digital Printing','Embroidery','Administration','Parts','Fixed Assets','General Production','Stationary RM','Stationary FG','Flexo','Construction') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `main_category` varchar(255) DEFAULT NULL,
  `stock_qty` decimal(9,2) NOT NULL,
  `stock_min_qty` decimal(9,2) NOT NULL,
  `units` enum('Shts.','L.','Kg.','Rolls.','Pcs.','Box.','Bag.','Inch.','Pkt.','Meter.') NOT NULL,
  `unit_price` decimal(12,2) DEFAULT NULL,
  `currency` char(3) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `location_name` varchar(255) DEFAULT NULL,
  `location_id` int NOT NULL,
  `date_expiry` date DEFAULT NULL,
  `update_lpo_id` int DEFAULT NULL,
  `stock_show` enum('N','Y') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_stock_locations`
--

CREATE TABLE `jos_stock_locations` (
  `location_id` int NOT NULL,
  `location_date_created` datetime NOT NULL,
  `location_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `jos_stock_log`
--

CREATE TABLE `jos_stock_log` (
  `log_id` int NOT NULL,
  `log_date` datetime NOT NULL,
  `stock_id` int NOT NULL DEFAULT '0',
  `log_movement` enum('Out','In','Reconciliation','Stock Modification') NOT NULL DEFAULT 'Out',
  `log_quantity` decimal(12,2) NOT NULL DEFAULT '0.00',
  `current_balance` decimal(12,2) NOT NULL,
  `new_balance` decimal(12,2) NOT NULL,
  `received_by` varchar(255) DEFAULT NULL,
  `issued_to` varchar(255) DEFAULT NULL,
  `log_job_id` int NOT NULL DEFAULT '0',
  `log_lpo_item_id` int NOT NULL DEFAULT '0',
  `log_gmri_id` int DEFAULT NULL,
  `log_requisition_item_id` int DEFAULT NULL,
  `notes` text,
  `reversed` enum('Yes','No') DEFAULT NULL,
  `user_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_stock_reconciliation_report`
--

CREATE TABLE `jos_stock_reconciliation_report` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_stock_reconciliation_report_items`
--

CREATE TABLE `jos_stock_reconciliation_report_items` (
  `id` int NOT NULL,
  `stock_log_id` int NOT NULL,
  `stock_id` int NOT NULL,
  `qty` decimal(9,2) NOT NULL,
  `remarks` text,
  `reconciliation_report_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_stock_sale_pricing`
--

CREATE TABLE `jos_stock_sale_pricing` (
  `id` int NOT NULL,
  `stock_id` int NOT NULL,
  `pricing` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'json string',
  `status` enum('Active','Disabled') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_stock_value_summary`
--

CREATE TABLE `jos_stock_value_summary` (
  `id` int NOT NULL,
  `stock_id` int NOT NULL,
  `opening_value` decimal(14,2) DEFAULT NULL,
  `closing_value` decimal(14,2) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_suppliers`
--

CREATE TABLE `jos_suppliers` (
  `supplier_id` int NOT NULL,
  `supplier_category` enum('Supplier','Contractor') NOT NULL DEFAULT 'Supplier',
  `supplier_fname` varchar(25) NOT NULL DEFAULT '',
  `supplier_lname` varchar(25) NOT NULL DEFAULT '',
  `supplier_company` varchar(35) NOT NULL DEFAULT '',
  `supplier_type` varchar(25) NOT NULL DEFAULT '',
  `supplier_email` varchar(65) NOT NULL DEFAULT '',
  `supplier_password` varchar(32) NOT NULL DEFAULT '',
  `supplier_phone` varchar(25) NOT NULL DEFAULT '',
  `supplier_fax` varchar(32) NOT NULL DEFAULT '',
  `supplier_mobile` varchar(25) NOT NULL DEFAULT '',
  `supplier_address` varchar(255) NOT NULL DEFAULT '',
  `supplier_city` varchar(25) NOT NULL DEFAULT '',
  `supplier_tin` varchar(100) DEFAULT NULL,
  `supplier_vrn` varchar(100) DEFAULT NULL,
  `payment_id` int DEFAULT NULL,
  `supplier_currency` char(3) NOT NULL DEFAULT 'TZS',
  `supplier_country` varchar(25) NOT NULL DEFAULT '',
  `supplier_status` enum('Active','Inactive') CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Active'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_suppliers_attachments`
--

CREATE TABLE `jos_suppliers_attachments` (
  `attachment_id` int NOT NULL,
  `attachment_name` varchar(30) NOT NULL DEFAULT '',
  `attachment_path` varchar(255) NOT NULL DEFAULT '',
  `supplier_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_suppliers_notes`
--

CREATE TABLE `jos_suppliers_notes` (
  `note_id` int NOT NULL,
  `note_date` date DEFAULT NULL,
  `note_body` text NOT NULL,
  `supplier_id` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_supplier_ledger_oa`
--

CREATE TABLE `jos_supplier_ledger_oa` (
  `id` int NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `type` enum('debit','credit') NOT NULL,
  `remarks` text,
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `supplier_id` int NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'TZS'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jos_tools`
--

CREATE TABLE `jos_tools` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `make` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `serial` varchar(255) DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `quantity` int NOT NULL,
  `status` varchar(150) NOT NULL DEFAULT 'Active',
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_vehicles`
--

CREATE TABLE `jos_vehicles` (
  `id` int NOT NULL,
  `make` varchar(50) NOT NULL,
  `model` varchar(50) NOT NULL,
  `year` int NOT NULL,
  `chasis` varchar(150) DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `registration` varchar(50) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `status` enum('Active','Inactive') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_vehicle_schedule`
--

CREATE TABLE `jos_vehicle_schedule` (
  `id` int NOT NULL,
  `schedule_date` date NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Open',
  `user_id` int NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_vehicle_schedule_items`
--

CREATE TABLE `jos_vehicle_schedule_items` (
  `id` int NOT NULL,
  `type` enum('General','Delivery Note','Purchase Order') DEFAULT NULL,
  `dn_item_id` text,
  `lpo_item_id` text,
  `invoice_item_id` text,
  `gmr_item_id` text,
  `job_id` int NOT NULL,
  `task_type` text,
  `vehicle_id` int NOT NULL,
  `task` text NOT NULL,
  `start_time` datetime DEFAULT NULL,
  `stop_time` datetime DEFAULT NULL,
  `start_mileage` int DEFAULT NULL,
  `stop_mileage` int DEFAULT NULL,
  `fuel_amount` decimal(12,2) DEFAULT NULL,
  `comments` text,
  `job_reference` varchar(100) DEFAULT NULL,
  `driver_id` int DEFAULT NULL,
  `vehicle_schedule_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jos_weights`
--

CREATE TABLE `jos_weights` (
  `weight_id` int NOT NULL,
  `weight_value` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cms_categories`
--
ALTER TABLE `cms_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `category_name` (`category_name`,`category_parent`);

--
-- Indexes for table `cms_configurations`
--
ALTER TABLE `cms_configurations`
  ADD PRIMARY KEY (`config_name`);

--
-- Indexes for table `cms_logs`
--
ALTER TABLE `cms_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `cms_priv_roles`
--
ALTER TABLE `cms_priv_roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `cms_priv_roles_tasks`
--
ALTER TABLE `cms_priv_roles_tasks`
  ADD PRIMARY KEY (`roles_tasks_id`);

--
-- Indexes for table `cms_priv_tasks`
--
ALTER TABLE `cms_priv_tasks`
  ADD PRIMARY KEY (`task_id`),
  ADD UNIQUE KEY `task_section` (`task_section`,`task_action`);

--
-- Indexes for table `cms_users`
--
ALTER TABLE `cms_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `jos_account_transactions`
--
ALTER TABLE `jos_account_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_assets`
--
ALTER TABLE `jos_assets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_attachments`
--
ALTER TABLE `jos_attachments`
  ADD PRIMARY KEY (`attachment_id`);

--
-- Indexes for table `jos_attendance_holidays`
--
ALTER TABLE `jos_attendance_holidays`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_attendance_schedule`
--
ALTER TABLE `jos_attendance_schedule`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `schedule_date` (`schedule_date`,`employee_id`,`attendance_shift_id`);

--
-- Indexes for table `jos_attendance_shift`
--
ALTER TABLE `jos_attendance_shift`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_bills`
--
ALTER TABLE `jos_bills`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `invoice_id` (`invoice_id`);

--
-- Indexes for table `jos_cash_account`
--
ALTER TABLE `jos_cash_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_cash_account_mobile`
--
ALTER TABLE `jos_cash_account_mobile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_casual_contractors`
--
ALTER TABLE `jos_casual_contractors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_casual_contractor_sow`
--
ALTER TABLE `jos_casual_contractor_sow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_categories`
--
ALTER TABLE `jos_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `jos_chat_groups`
--
ALTER TABLE `jos_chat_groups`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `jos_chat_group_users`
--
ALTER TABLE `jos_chat_group_users`
  ADD PRIMARY KEY (`cgu_id`);

--
-- Indexes for table `jos_chat_message`
--
ALTER TABLE `jos_chat_message`
  ADD PRIMARY KEY (`chat_message_id`);

--
-- Indexes for table `jos_closed_jobs`
--
ALTER TABLE `jos_closed_jobs`
  ADD PRIMARY KEY (`job_closed_id`);

--
-- Indexes for table `jos_contractor_templates`
--
ALTER TABLE `jos_contractor_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_contracts`
--
ALTER TABLE `jos_contracts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_contract_templates`
--
ALTER TABLE `jos_contract_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_credit_notes`
--
ALTER TABLE `jos_credit_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_customers`
--
ALTER TABLE `jos_customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `jos_customers_attachments`
--
ALTER TABLE `jos_customers_attachments`
  ADD PRIMARY KEY (`attachment_id`);

--
-- Indexes for table `jos_customers_group`
--
ALTER TABLE `jos_customers_group`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `jos_customer_ledger_oa`
--
ALTER TABLE `jos_customer_ledger_oa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_delivery_notes`
--
ALTER TABLE `jos_delivery_notes`
  ADD PRIMARY KEY (`dn_id`);

--
-- Indexes for table `jos_departments`
--
ALTER TABLE `jos_departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `jos_dn_items`
--
ALTER TABLE `jos_dn_items`
  ADD PRIMARY KEY (`dn_item_id`),
  ADD KEY `dn_id` (`dn_id`);

--
-- Indexes for table `jos_efa_payout`
--
ALTER TABLE `jos_efa_payout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_electronics`
--
ALTER TABLE `jos_electronics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_employees`
--
ALTER TABLE `jos_employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_employee_notice`
--
ALTER TABLE `jos_employee_notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_employee_notice_tpl`
--
ALTER TABLE `jos_employee_notice_tpl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_employee_remarks`
--
ALTER TABLE `jos_employee_remarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_exemptcash`
--
ALTER TABLE `jos_exemptcash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_exemptcash_items`
--
ALTER TABLE `jos_exemptcash_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_exempt_float_account`
--
ALTER TABLE `jos_exempt_float_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_expenses`
--
ALTER TABLE `jos_expenses`
  ADD PRIMARY KEY (`expense_id`),
  ADD UNIQUE KEY `expense_code` (`expense_code`),
  ADD UNIQUE KEY `expense_name` (`expense_name`);

--
-- Indexes for table `jos_finance_expense_budgets`
--
ALTER TABLE `jos_finance_expense_budgets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_budget_month_expense` (`budget_month`,`expense_id`),
  ADD KEY `idx_budget_month` (`budget_month`),
  ADD KEY `idx_expense_id` (`expense_id`);

--
-- Indexes for table `jos_finance_report_allocations`
--
ALTER TABLE `jos_finance_report_allocations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_allocation` (`allocation_basis`,`effective_from`);

--
-- Indexes for table `jos_finance_report_mapping`
--
ALTER TABLE `jos_finance_report_mapping`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_active_mapping` (`source_type`,`source_id`,`report_line`);

--
-- Indexes for table `jos_finance_report_rates`
--
ALTER TABLE `jos_finance_report_rates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_rate_name` (`rate_name`);

--
-- Indexes for table `jos_finance_sales_targets`
--
ALTER TABLE `jos_finance_sales_targets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_month_department` (`target_month`,`department`);

--
-- Indexes for table `jos_finance_wip_snapshots`
--
ALTER TABLE `jos_finance_wip_snapshots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_wip_snapshot` (`snapshot_date`,`department_name`),
  ADD KEY `idx_wip_job` (`job_id`);

--
-- Indexes for table `jos_finishing`
--
ALTER TABLE `jos_finishing`
  ADD PRIMARY KEY (`finishing_id`),
  ADD UNIQUE KEY `finishing_type` (`finishing_type`);

--
-- Indexes for table `jos_furniture`
--
ALTER TABLE `jos_furniture`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_gmr`
--
ALTER TABLE `jos_gmr`
  ADD PRIMARY KEY (`gmr_id`);

--
-- Indexes for table `jos_gmr_items`
--
ALTER TABLE `jos_gmr_items`
  ADD PRIMARY KEY (`gmri_id`);

--
-- Indexes for table `jos_grn`
--
ALTER TABLE `jos_grn`
  ADD PRIMARY KEY (`grn_id`);

--
-- Indexes for table `jos_grn_items`
--
ALTER TABLE `jos_grn_items`
  ADD PRIMARY KEY (`grn_item_id`),
  ADD KEY `grn_id` (`grn_id`),
  ADD KEY `lpo_item_id` (`lpo_item_id`);

--
-- Indexes for table `jos_industries`
--
ALTER TABLE `jos_industries`
  ADD PRIMARY KEY (`industry_id`);

--
-- Indexes for table `jos_invoices`
--
ALTER TABLE `jos_invoices`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Indexes for table `jos_invoice_items`
--
ALTER TABLE `jos_invoice_items`
  ADD PRIMARY KEY (`invoice_item_id`),
  ADD KEY `invoice_id` (`invoice_id`),
  ADD KEY `dn_item_id` (`dn_item_id`);

--
-- Indexes for table `jos_issued_stock`
--
ALTER TABLE `jos_issued_stock`
  ADD PRIMARY KEY (`issued_stock_id`);

--
-- Indexes for table `jos_jobs`
--
ALTER TABLE `jos_jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `jos_jobs_groups`
--
ALTER TABLE `jos_jobs_groups`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `jos_jobs_progress`
--
ALTER TABLE `jos_jobs_progress`
  ADD PRIMARY KEY (`progress_id`);

--
-- Indexes for table `jos_job_amendments`
--
ALTER TABLE `jos_job_amendments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_job_history`
--
ALTER TABLE `jos_job_history`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `job_id` (`job_id`);

--
-- Indexes for table `jos_ledger_accounts`
--
ALTER TABLE `jos_ledger_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_ledger_oa`
--
ALTER TABLE `jos_ledger_oa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_loaned_tools`
--
ALTER TABLE `jos_loaned_tools`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_lpo`
--
ALTER TABLE `jos_lpo`
  ADD PRIMARY KEY (`lpo_id`);

--
-- Indexes for table `jos_lpo_items`
--
ALTER TABLE `jos_lpo_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `lpo_id` (`lpo_id`),
  ADD KEY `stock_id` (`stock_id`),
  ADD KEY `lpo_id_2` (`lpo_id`);

--
-- Indexes for table `jos_materials`
--
ALTER TABLE `jos_materials`
  ADD PRIMARY KEY (`material_id`);

--
-- Indexes for table `jos_notes`
--
ALTER TABLE `jos_notes`
  ADD PRIMARY KEY (`note_id`);

--
-- Indexes for table `jos_papers`
--
ALTER TABLE `jos_papers`
  ADD PRIMARY KEY (`paper_id`);

--
-- Indexes for table `jos_payment_terms`
--
ALTER TABLE `jos_payment_terms`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `jos_payrolls`
--
ALTER TABLE `jos_payrolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_payroll_advances`
--
ALTER TABLE `jos_payroll_advances`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_payroll_damage_report`
--
ALTER TABLE `jos_payroll_damage_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_payroll_data`
--
ALTER TABLE `jos_payroll_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_payroll_leaves`
--
ALTER TABLE `jos_payroll_leaves`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_payroll_loans`
--
ALTER TABLE `jos_payroll_loans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_payroll_security_funds`
--
ALTER TABLE `jos_payroll_security_funds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_payroll_taxes`
--
ALTER TABLE `jos_payroll_taxes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_pettycash_items`
--
ALTER TABLE `jos_pettycash_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_pettycash_mobile_items`
--
ALTER TABLE `jos_pettycash_mobile_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_petty_cash`
--
ALTER TABLE `jos_petty_cash`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_petty_cash_mobile`
--
ALTER TABLE `jos_petty_cash_mobile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_printers`
--
ALTER TABLE `jos_printers`
  ADD PRIMARY KEY (`printer_id`);

--
-- Indexes for table `jos_products`
--
ALTER TABLE `jos_products`
  ADD PRIMARY KEY (`product_id`),
  ADD UNIQUE KEY `product_name` (`product_name`),
  ADD UNIQUE KEY `product_ref` (`product_ref`);

--
-- Indexes for table `jos_product_categories`
--
ALTER TABLE `jos_product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_project_checklist`
--
ALTER TABLE `jos_project_checklist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_project_checklist_items`
--
ALTER TABLE `jos_project_checklist_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_qc`
--
ALTER TABLE `jos_qc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_quotes`
--
ALTER TABLE `jos_quotes`
  ADD PRIMARY KEY (`quote_id`);

--
-- Indexes for table `jos_quotes_items`
--
ALTER TABLE `jos_quotes_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `jos_quotes_outstanding`
--
ALTER TABLE `jos_quotes_outstanding`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_receipts`
--
ALTER TABLE `jos_receipts`
  ADD PRIMARY KEY (`receipt_id`);

--
-- Indexes for table `jos_receipt_items`
--
ALTER TABLE `jos_receipt_items`
  ADD PRIMARY KEY (`ri_id`);

--
-- Indexes for table `jos_repair_ticket`
--
ALTER TABLE `jos_repair_ticket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_repair_work`
--
ALTER TABLE `jos_repair_work`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_requisition`
--
ALTER TABLE `jos_requisition`
  ADD PRIMARY KEY (`requisition_id`);

--
-- Indexes for table `jos_requisitions`
--
ALTER TABLE `jos_requisitions`
  ADD PRIMARY KEY (`requisition_id`);

--
-- Indexes for table `jos_requisition_is`
--
ALTER TABLE `jos_requisition_is`
  ADD PRIMARY KEY (`ris_id`);

--
-- Indexes for table `jos_requisition_isi`
--
ALTER TABLE `jos_requisition_isi`
  ADD PRIMARY KEY (`risi_id`);

--
-- Indexes for table `jos_requisition_issued_stock`
--
ALTER TABLE `jos_requisition_issued_stock`
  ADD PRIMARY KEY (`ris_id`);

--
-- Indexes for table `jos_requisition_items`
--
ALTER TABLE `jos_requisition_items`
  ADD PRIMARY KEY (`ri_id`);

--
-- Indexes for table `jos_sales_visitplan`
--
ALTER TABLE `jos_sales_visitplan`
  ADD PRIMARY KEY (`vp_id`);

--
-- Indexes for table `jos_schedule`
--
ALTER TABLE `jos_schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `jos_schedule_drivers`
--
ALTER TABLE `jos_schedule_drivers`
  ADD PRIMARY KEY (`se_id`);

--
-- Indexes for table `jos_schedule_employees`
--
ALTER TABLE `jos_schedule_employees`
  ADD PRIMARY KEY (`se_id`);

--
-- Indexes for table `jos_schedule_items`
--
ALTER TABLE `jos_schedule_items`
  ADD PRIMARY KEY (`si_id`);

--
-- Indexes for table `jos_sizes`
--
ALTER TABLE `jos_sizes`
  ADD PRIMARY KEY (`size_id`);

--
-- Indexes for table `jos_stock`
--
ALTER TABLE `jos_stock`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `jos_stock_log`
--
ALTER TABLE `jos_stock_log`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `jos_stock_reconciliation_report`
--
ALTER TABLE `jos_stock_reconciliation_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_stock_reconciliation_report_items`
--
ALTER TABLE `jos_stock_reconciliation_report_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_stock_sale_pricing`
--
ALTER TABLE `jos_stock_sale_pricing`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_stock_value_summary`
--
ALTER TABLE `jos_stock_value_summary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_suppliers`
--
ALTER TABLE `jos_suppliers`
  ADD PRIMARY KEY (`supplier_id`);

--
-- Indexes for table `jos_supplier_ledger_oa`
--
ALTER TABLE `jos_supplier_ledger_oa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_vehicles`
--
ALTER TABLE `jos_vehicles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_vehicle_schedule`
--
ALTER TABLE `jos_vehicle_schedule`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_vehicle_schedule_items`
--
ALTER TABLE `jos_vehicle_schedule_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jos_weights`
--
ALTER TABLE `jos_weights`
  ADD PRIMARY KEY (`weight_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cms_logs`
--
ALTER TABLE `cms_logs`
  MODIFY `log_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4320;

--
-- AUTO_INCREMENT for table `cms_priv_roles`
--
ALTER TABLE `cms_priv_roles`
  MODIFY `role_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `cms_priv_roles_tasks`
--
ALTER TABLE `cms_priv_roles_tasks`
  MODIFY `roles_tasks_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59657;

--
-- AUTO_INCREMENT for table `cms_priv_tasks`
--
ALTER TABLE `cms_priv_tasks`
  MODIFY `task_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=481;

--
-- AUTO_INCREMENT for table `cms_users`
--
ALTER TABLE `cms_users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=193;

--
-- AUTO_INCREMENT for table `jos_account_transactions`
--
ALTER TABLE `jos_account_transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=202;

--
-- AUTO_INCREMENT for table `jos_assets`
--
ALTER TABLE `jos_assets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;

--
-- AUTO_INCREMENT for table `jos_attachments`
--
ALTER TABLE `jos_attachments`
  MODIFY `attachment_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `jos_attendance_holidays`
--
ALTER TABLE `jos_attendance_holidays`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `jos_attendance_schedule`
--
ALTER TABLE `jos_attendance_schedule`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164337;

--
-- AUTO_INCREMENT for table `jos_attendance_shift`
--
ALTER TABLE `jos_attendance_shift`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jos_bills`
--
ALTER TABLE `jos_bills`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `jos_cash_account`
--
ALTER TABLE `jos_cash_account`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `jos_cash_account_mobile`
--
ALTER TABLE `jos_cash_account_mobile`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `jos_casual_contractors`
--
ALTER TABLE `jos_casual_contractors`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=955;

--
-- AUTO_INCREMENT for table `jos_casual_contractor_sow`
--
ALTER TABLE `jos_casual_contractor_sow`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1197;

--
-- AUTO_INCREMENT for table `jos_categories`
--
ALTER TABLE `jos_categories`
  MODIFY `category_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `jos_chat_groups`
--
ALTER TABLE `jos_chat_groups`
  MODIFY `group_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jos_chat_group_users`
--
ALTER TABLE `jos_chat_group_users`
  MODIFY `cgu_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `jos_chat_message`
--
ALTER TABLE `jos_chat_message`
  MODIFY `chat_message_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `jos_contractor_templates`
--
ALTER TABLE `jos_contractor_templates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jos_contracts`
--
ALTER TABLE `jos_contracts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jos_contract_templates`
--
ALTER TABLE `jos_contract_templates`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jos_credit_notes`
--
ALTER TABLE `jos_credit_notes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=337;

--
-- AUTO_INCREMENT for table `jos_customers`
--
ALTER TABLE `jos_customers`
  MODIFY `customer_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2353;

--
-- AUTO_INCREMENT for table `jos_customers_group`
--
ALTER TABLE `jos_customers_group`
  MODIFY `group_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2384;

--
-- AUTO_INCREMENT for table `jos_customer_ledger_oa`
--
ALTER TABLE `jos_customer_ledger_oa`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `jos_delivery_notes`
--
ALTER TABLE `jos_delivery_notes`
  MODIFY `dn_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20391;

--
-- AUTO_INCREMENT for table `jos_departments`
--
ALTER TABLE `jos_departments`
  MODIFY `department_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `jos_dn_items`
--
ALTER TABLE `jos_dn_items`
  MODIFY `dn_item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30158;

--
-- AUTO_INCREMENT for table `jos_efa_payout`
--
ALTER TABLE `jos_efa_payout`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jos_electronics`
--
ALTER TABLE `jos_electronics`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `jos_employees`
--
ALTER TABLE `jos_employees`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1261;

--
-- AUTO_INCREMENT for table `jos_employee_notice`
--
ALTER TABLE `jos_employee_notice`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jos_employee_notice_tpl`
--
ALTER TABLE `jos_employee_notice_tpl`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jos_employee_remarks`
--
ALTER TABLE `jos_employee_remarks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jos_exemptcash`
--
ALTER TABLE `jos_exemptcash`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `jos_exemptcash_items`
--
ALTER TABLE `jos_exemptcash_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `jos_exempt_float_account`
--
ALTER TABLE `jos_exempt_float_account`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `jos_expenses`
--
ALTER TABLE `jos_expenses`
  MODIFY `expense_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2012;

--
-- AUTO_INCREMENT for table `jos_finance_expense_budgets`
--
ALTER TABLE `jos_finance_expense_budgets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `jos_finance_report_allocations`
--
ALTER TABLE `jos_finance_report_allocations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `jos_finance_report_mapping`
--
ALTER TABLE `jos_finance_report_mapping`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `jos_finance_report_rates`
--
ALTER TABLE `jos_finance_report_rates`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jos_finance_sales_targets`
--
ALTER TABLE `jos_finance_sales_targets`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `jos_finance_wip_snapshots`
--
ALTER TABLE `jos_finance_wip_snapshots`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `jos_finishing`
--
ALTER TABLE `jos_finishing`
  MODIFY `finishing_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `jos_gmr`
--
ALTER TABLE `jos_gmr`
  MODIFY `gmr_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `jos_gmr_items`
--
ALTER TABLE `jos_gmr_items`
  MODIFY `gmri_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `jos_grn`
--
ALTER TABLE `jos_grn`
  MODIFY `grn_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31691;

--
-- AUTO_INCREMENT for table `jos_grn_items`
--
ALTER TABLE `jos_grn_items`
  MODIFY `grn_item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63855;

--
-- AUTO_INCREMENT for table `jos_invoices`
--
ALTER TABLE `jos_invoices`
  MODIFY `invoice_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22119;

--
-- AUTO_INCREMENT for table `jos_invoice_items`
--
ALTER TABLE `jos_invoice_items`
  MODIFY `invoice_item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37043;

--
-- AUTO_INCREMENT for table `jos_issued_stock`
--
ALTER TABLE `jos_issued_stock`
  MODIFY `issued_stock_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jos_jobs`
--
ALTER TABLE `jos_jobs`
  MODIFY `job_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59566;

--
-- AUTO_INCREMENT for table `jos_jobs_groups`
--
ALTER TABLE `jos_jobs_groups`
  MODIFY `group_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36556;

--
-- AUTO_INCREMENT for table `jos_jobs_progress`
--
ALTER TABLE `jos_jobs_progress`
  MODIFY `progress_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27714;

--
-- AUTO_INCREMENT for table `jos_job_amendments`
--
ALTER TABLE `jos_job_amendments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `jos_job_history`
--
ALTER TABLE `jos_job_history`
  MODIFY `log_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `jos_ledger_accounts`
--
ALTER TABLE `jos_ledger_accounts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `jos_ledger_oa`
--
ALTER TABLE `jos_ledger_oa`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `jos_lpo`
--
ALTER TABLE `jos_lpo`
  MODIFY `lpo_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41982;

--
-- AUTO_INCREMENT for table `jos_lpo_items`
--
ALTER TABLE `jos_lpo_items`
  MODIFY `item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87763;

--
-- AUTO_INCREMENT for table `jos_materials`
--
ALTER TABLE `jos_materials`
  MODIFY `material_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `jos_papers`
--
ALTER TABLE `jos_papers`
  MODIFY `paper_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `jos_payrolls`
--
ALTER TABLE `jos_payrolls`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `jos_payroll_advances`
--
ALTER TABLE `jos_payroll_advances`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `jos_payroll_damage_report`
--
ALTER TABLE `jos_payroll_damage_report`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `jos_payroll_data`
--
ALTER TABLE `jos_payroll_data`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=615;

--
-- AUTO_INCREMENT for table `jos_payroll_leaves`
--
ALTER TABLE `jos_payroll_leaves`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jos_payroll_loans`
--
ALTER TABLE `jos_payroll_loans`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jos_payroll_security_funds`
--
ALTER TABLE `jos_payroll_security_funds`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jos_payroll_taxes`
--
ALTER TABLE `jos_payroll_taxes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jos_pettycash_items`
--
ALTER TABLE `jos_pettycash_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4805;

--
-- AUTO_INCREMENT for table `jos_pettycash_mobile_items`
--
ALTER TABLE `jos_pettycash_mobile_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14639;

--
-- AUTO_INCREMENT for table `jos_petty_cash`
--
ALTER TABLE `jos_petty_cash`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37422;

--
-- AUTO_INCREMENT for table `jos_petty_cash_mobile`
--
ALTER TABLE `jos_petty_cash_mobile`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13228;

--
-- AUTO_INCREMENT for table `jos_printers`
--
ALTER TABLE `jos_printers`
  MODIFY `printer_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `jos_products`
--
ALTER TABLE `jos_products`
  MODIFY `product_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `jos_product_categories`
--
ALTER TABLE `jos_product_categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jos_project_checklist`
--
ALTER TABLE `jos_project_checklist`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `jos_project_checklist_items`
--
ALTER TABLE `jos_project_checklist_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `jos_qc`
--
ALTER TABLE `jos_qc`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44077;

--
-- AUTO_INCREMENT for table `jos_quotes`
--
ALTER TABLE `jos_quotes`
  MODIFY `quote_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51839;

--
-- AUTO_INCREMENT for table `jos_quotes_items`
--
ALTER TABLE `jos_quotes_items`
  MODIFY `item_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113955;

--
-- AUTO_INCREMENT for table `jos_quotes_outstanding`
--
ALTER TABLE `jos_quotes_outstanding`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `jos_receipts`
--
ALTER TABLE `jos_receipts`
  MODIFY `receipt_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `jos_receipt_items`
--
ALTER TABLE `jos_receipt_items`
  MODIFY `ri_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `jos_repair_ticket`
--
ALTER TABLE `jos_repair_ticket`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `jos_repair_work`
--
ALTER TABLE `jos_repair_work`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=171;

--
-- AUTO_INCREMENT for table `jos_requisition`
--
ALTER TABLE `jos_requisition`
  MODIFY `requisition_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=230039;

--
-- AUTO_INCREMENT for table `jos_requisitions`
--
ALTER TABLE `jos_requisitions`
  MODIFY `requisition_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `jos_requisition_is`
--
ALTER TABLE `jos_requisition_is`
  MODIFY `ris_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `jos_requisition_isi`
--
ALTER TABLE `jos_requisition_isi`
  MODIFY `risi_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `jos_requisition_issued_stock`
--
ALTER TABLE `jos_requisition_issued_stock`
  MODIFY `ris_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `jos_requisition_items`
--
ALTER TABLE `jos_requisition_items`
  MODIFY `ri_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `jos_sales_visitplan`
--
ALTER TABLE `jos_sales_visitplan`
  MODIFY `vp_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `jos_schedule`
--
ALTER TABLE `jos_schedule`
  MODIFY `schedule_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `jos_schedule_drivers`
--
ALTER TABLE `jos_schedule_drivers`
  MODIFY `se_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jos_schedule_employees`
--
ALTER TABLE `jos_schedule_employees`
  MODIFY `se_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `jos_schedule_items`
--
ALTER TABLE `jos_schedule_items`
  MODIFY `si_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `jos_sizes`
--
ALTER TABLE `jos_sizes`
  MODIFY `size_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `jos_stock`
--
ALTER TABLE `jos_stock`
  MODIFY `stock_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4479;

--
-- AUTO_INCREMENT for table `jos_stock_log`
--
ALTER TABLE `jos_stock_log`
  MODIFY `log_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;

--
-- AUTO_INCREMENT for table `jos_stock_reconciliation_report`
--
ALTER TABLE `jos_stock_reconciliation_report`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `jos_stock_reconciliation_report_items`
--
ALTER TABLE `jos_stock_reconciliation_report_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `jos_stock_sale_pricing`
--
ALTER TABLE `jos_stock_sale_pricing`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `jos_stock_value_summary`
--
ALTER TABLE `jos_stock_value_summary`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58566;

--
-- AUTO_INCREMENT for table `jos_suppliers`
--
ALTER TABLE `jos_suppliers`
  MODIFY `supplier_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1040;

--
-- AUTO_INCREMENT for table `jos_supplier_ledger_oa`
--
ALTER TABLE `jos_supplier_ledger_oa`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jos_vehicles`
--
ALTER TABLE `jos_vehicles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `jos_vehicle_schedule`
--
ALTER TABLE `jos_vehicle_schedule`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `jos_vehicle_schedule_items`
--
ALTER TABLE `jos_vehicle_schedule_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `jos_weights`
--
ALTER TABLE `jos_weights`
  MODIFY `weight_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
