<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$with_jobs = isset($_GET['with_jobs'])? $_GET['with_jobs'] : '';

$sql = "SELECT cg.group_id as gpi,jc.customer_id, cg.group_company,pt.payment_term,
payment_id,jc.customer_fname,jc.customer_lname,jc.customer_email,cg.credit_terms, cg.company_type
FROM jos_customers_group as cg
LEFT JOIN jos_customers as jc ON(jc.group_id = cg.group_id)
 LEFT JOIN jos_payment_terms as pt ON(cg.default_payment_terms = pt.payment_id)
 WHERE group_company LIKE '%".$search."%' AND group_status = 'Active' ORDER BY `group_company` ASC;";
$result = mysql_query($sql);

if($with_jobs){
  $jobs_sql = mysql_query("SELECT j.job_id, j.job_date, j.job_reference, j.job_product, job_paper_quantity,
              cms_users.user_fname, cms_users.user_lname,
              jos_products.product_name
              FROM `jos_jobs` as j

              LEFT JOIN `jos_products`
              ON jos_products.product_ref = j.job_product

              LEFT JOIN `cms_users`
              ON cms_users.user_id = j.user_id

              LEFT JOIN `jos_jobs_groups` as jg
              ON jg.group_id = j.group_id

              LEFT JOIN `jos_quotes` as q
              ON q.quote_id = jg.quote_id");
}



if(mysql_num_rows($result) > 0) {

    if(isset($_GET['is_client'])){
      $data[] = array('id' => -1, 'text' => 'New Client');
    }else{
     // $data[] = array('id' => -1, 'text' => 'Add New Company/Group');
    }


    while ($row = mysql_fetch_assoc($result)) {

        $cid = $row['customer_id'];

        $job_id = '';
        $pro = '';
        if($with_jobs){
        if(mysql_num_rows($jobs_sql) > 0){
            while($j = mysql_fetch_array($jobs_sql,MYSQLI_ASSOC)){

                if(isset($j['customer_id']) && $j['customer_id'] == $cid){

                    $job_id = $j['job_id'];
                    $pro = $j['job_reference']." ".$j['product_name'];
                    break;

                }


            }
        }
      }

        $data[] = array('id' => $row['gpi'],
            'text' => $row['group_company'],
            'job_id'=>$job_id,
            'job_info'=>$pro,
            'payment_id'=>$row['payment_id'],
            'payment_term'=>$row['payment_term'],
            'company_type'=>$row['company_type'],
            'cf_name'=>$row['customer_fname'],
            'customer_id'=>$row['customer_id'],
            'cl_name'=>$row['customer_lname'],
            'credit_terms'=>$row['credit_terms'],
            'ce'=>$row['customer_email']);

    }

} else {

    $data[] = array('id' => '0', 'text' => 'No Results Found');
   // $data[] = array('id' => -1, 'text' => 'Add New Company/Group');
}

echo json_encode($data);
exit();
