<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$category = isset($_GET['category'])? $_GET['category'] : '';
$add_item = isset($_GET['add_item'])? $_GET['add_item']: '';
if($add_item){
    $data[] = array('id' => -1, 'text' => 'Select to Enter Item (Not in stock)');
}

$and_sql = "";
if($category){
    $and_sql = " AND category = '$category' ";
}

//$sql = "SELECT `stock_id`, `stock_name`, `units` FROM `jos_stock` WHERE stock_name LIKE '%".$search."%' ORDER BY `stock_name` ASC;";
$sql = "SELECT s.stock_id, s.stock_name, s.units, s.category, lpoi.lpo_id,
s.unit_price, sup.supplier_company, lpo.lpo_currency, lpo.exch_rate FROM jos_stock s
LEFT JOIN (SELECT item_id, lpo_id, stock_id FROM `jos_lpo_items` ORDER BY item_id DESC) as lpoi
ON lpoi.stock_id = s.stock_id
LEFT JOIN jos_lpo as lpo
ON lpo.lpo_id = lpoi.lpo_id
LEFT JOIN jos_suppliers as sup
ON sup.supplier_id  = lpo.supplier_id
WHERE s.stock_name LIKE '%$search%' $and_sql GROUP BY stock_id ORDER BY s.stock_name ASC";
$result = mysql_query($sql);

if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {
      
       if($row['lpo_currency'] == 'USD' && $row['exch_rate'] > 0){

        $row['unit_price'] = $row['unit_price'] / $row['exch_rate'];
       }

        $data[] = array('id' => $row['stock_id'],
                         'text' => $row['stock_name'],
                         'unit' => $row['units'],
                         'category' => $row['category'],
                         'lpo_currency' => $row['lpo_currency'],
                         'item_price' => $row['unit_price'],
                         'unit_price' => $row['lpo_currency'].' '.number_format(floatval($row['unit_price'])),
                         'supplier_company' =>  $row['supplier_company']);

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');


}

// return the result in json
echo json_encode($data);
