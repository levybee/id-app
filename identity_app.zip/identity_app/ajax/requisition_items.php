<?php


require("../configs/variables.php");
require("../configs/functions.php");
require("../modules/requisition/functions.php");

$req_id = isset($_GET['req_id'])?  mysql_real_escape_string($_GET['req_id']) : '';
$ri_id = isset($_GET['ri_id'])? mysql_real_escape_string($_GET['ri_id']) : '';
$params = ['requisition_id' => $req_id];
if(!$req_id){
  $params = ['ri_id' => $ri_id];
}

$reqItems = get_requisition_items($params);

echo json_encode($reqItems);
exit;
