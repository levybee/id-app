<?php

require("../configs/variables.php");

// $search = $_GET['q'];
$job_id = $_GET['job_id'];
$qty = $_GET['qty'];

//$sql = "SELECT `stock_id`, `stock_name`, `units` FROM `jos_stock` WHERE stock_name LIKE '%".$search."%' ORDER BY `stock_name` ASC;";
$sql = "SELECT id FROM jos_qc
WHERE job_id = '$job_id' AND quantity = '$qty' AND type = 'Normal'";
$result = mysql_query($sql);

$data = [];
if(mysql_num_rows($result) > 0) {
   $data['duplicate'] = true;
} else {
   $data['duplicate'] = false;
}

// return the result in json
echo json_encode($data);
die();
