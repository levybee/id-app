<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$status = $_GET['status']?? null;

$filter_sql = "";


if($status){

    $filter_sql .= " AND t.status = '$status' ";
}

 $ticket_sql = "SELECT t.*,
										 (CASE
										    WHEN t.asset_category = 'Other' THEN t.other_asset_name
											WHEN t.asset_category = 'Tools' THEN tl.name
											WHEN t.asset_category = 'Machines' THEN p.printer_name
											WHEN t.asset_category = 'Vehicles' THEN CONCAT(v.year,' ',v.make,' ',v.model)
											WHEN t.asset_category = 'Electronic Equipment' THEN CONCAT(e.name,' ',COALESCE(e.make, ''),' ',COALESCE(e.model, ''),' ',COALESCE(e.serial, ''))
											WHEN t.asset_category = 'Furniture and Fixtures' THEN CONCAT(f.name,' ',COALESCE(f.make, ''),' ',COALESCE(f.model, ''),' ',COALESCE(f.serial, ''))
										END) as asset_name

              FROM `jos_repair_ticket` as t

							LEFT JOIN jos_printers p ON p.printer_id = t.asset_id AND t.asset_category = 'Machines'
							LEFT JOIN jos_vehicles v ON v.id = t.asset_id AND t.asset_category = 'Vehicles'
							LEFT JOIN jos_tools tl ON tl.id = t.asset_id AND t.asset_category = 'Tools'
							LEFT JOIN jos_electronics e ON e.id = t.asset_id AND t.asset_category = 'Electronic Equipment'
							LEFT JOIN jos_furniture f ON f.id = t.asset_id AND t.asset_category = 'Furniture and Fixtures'

					 WHERE t.id LIKE '%$search%' $filter_sql ORDER BY t.id DESC LIMIT 15;";       

          if(isset($_GET['debug'])){
              echo $ticket_sql;
          }



$result = mysql_query($ticket_sql);


if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $data[] = array('id' => $row['id'],
                        'text' => '#'.$row['id'].': '.$row['asset_name']
                         );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
