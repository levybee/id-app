<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$status = $_GET['status'];

$filter_sql = "";


if($status){

    $filter_sql .= " AND dn.dn_status = '$status' ";
}

$dni_sql = "SELECT dni.*, dn.*, cg.group_company
            FROM `jos_dn_items` as dni
            LEFT JOIN `jos_delivery_notes` as dn
            ON dni.dn_id = dn.dn_id
            LEFT JOIN `jos_customers`  as cu
  					   ON cu.customer_id = dn.customer_id

  					LEFT JOIN `jos_customers_group` AS cg
  					   ON cg.group_id = cu.group_id

					WHERE dn.dn_id LIKE '%$search%' $filter_sql ORDER BY dni.dn_item_id DESC LIMIT 15;";

          if(isset($_GET['debug'])){
              echo $dni_sql;
          }



$result = mysql_query($dni_sql);


if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $data[] = array('id' => $row['dn_item_id'],
                        'text' => $row['dn_id'].': '.$row['description']. ' ('.$row['quantity'].')',
                        'customer_id' => $row['customer_id'],
                        'group_company' => $row['group_company'],
                        'dn_id' => $row['dn_id']
                         );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
