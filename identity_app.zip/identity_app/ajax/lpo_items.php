<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$status = $_GET['status'];

$filter_sql = "";


if($status){

    $filter_sql .= " AND lpo.lpo_status = '$status' ";
}

$lpoi_sql = "SELECT lpoi.*, lpo.*, sup.supplier_id, sup.supplier_company
            FROM `jos_lpo_items` as lpoi
            LEFT JOIN `jos_lpo` as lpo
            ON lpoi.lpo_id = lpo.lpo_id
				    LEFT JOIN `jos_suppliers` as sup
					   ON sup.supplier_id  = lpo.supplier_id

					WHERE lpo.lpo_id LIKE '%$search%' $filter_sql ORDER BY lpoi.item_id DESC LIMIT 15;";

          if(isset($_GET['debug'])){
              echo $dni_sql;
          }



$result = mysql_query($lpoi_sql);


if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $data[] = array('id' => $row['item_id'],
                        'text' => $row['lpo_id'].': '.$row['item_description'],
                        'supplier_id' => $row['supplier_id'],
                        'supplier' => $row['supplier_company'],
                        'lpo_id' => $row['lpo_id']
                         );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
