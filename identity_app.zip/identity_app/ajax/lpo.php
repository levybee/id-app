<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$supplier_id = isset($_GET['supplier_id'])? $_GET['supplier_id'] : '';
$status = isset($_GET['status'])? $_GET['status'] : '';
$balance = isset($_GET['balance'])? $_GET['balance'] : '' ;
$no_lpo_amount = isset($_GET['no_lpo_amount'])? $_GET['no_lpo_amount'] : '';


$filter_sql = "";

if($supplier_id > 0){

    $filter_sql .= " AND lpo.supplier_id = '$supplier_id' ";
}

if($status){

    $filter_sql .= " AND lpo.lpo_status = '$status' ";
}

$lpo_sql = "SELECT lpo.*, sup.supplier_id, sup.supplier_company, cms_users.user_fname, cms_users.user_lname,
                    ROUND(IF(lpo_amt.lpo_tax = 'Taxable', lpo_amt.lpo_amount + (lpo_amt.lpo_amount * 0.18), lpo_amt.lpo_amount), 2) as lpo_amount,
                    ROUND(
                            (IFNULL(
                                (
                                    amtp.amount_paid
                                ),
                                0
                            )) + (IFNULL(
                                (
                                    amtpm.amount_paid
                                ),
                                0
                            )),
                            2
                        ) AS amount_paid,
                    ROUND(((IF (lpo_amt.lpo_tax = 'Taxable', lpo_amt.lpo_amount + (lpo_amt.lpo_amount * 0.18), lpo_amt.lpo_amount)) - ((IFNULL(amtpm.amount_paid, 0)) + (IFNULL(amtp.amount_paid, 0)))), 2) as lpo_balance

					FROM `jos_lpo` as lpo

					LEFT JOIN `cms_users`
					   ON cms_users.user_id = lpo.user_id

				    LEFT JOIN `jos_suppliers` as sup
					   ON sup.supplier_id  = lpo.supplier_id

             LEFT JOIN (SELECT lpo.lpo_id, lpo.lpo_tax, SUM(
                               CASE
                                   WHEN lpo.lpo_currency = 'USD' THEN ((lpoi.item_qty * lpoi.item_unit_price) * 2312)
                                   WHEN lpo.lpo_currency = 'KSH' THEN ((lpoi.item_qty * lpoi.item_unit_price) * 21)
                                   WHEN lpo.lpo_currency = 'KSHS' THEN ((lpoi.item_qty * lpoi.item_unit_price) * 21)
                                   WHEN lpo.lpo_currency = 'GBP' THEN ((lpoi.item_qty * lpoi.item_unit_price) * 2858)
                                   WHEN lpo.lpo_currency = 'EUR' THEN ((lpoi.item_qty * lpoi.item_unit_price) * 2567)
                                   ELSE (lpoi.item_qty * lpoi.item_unit_price) END) as lpo_amount
                                   FROM `jos_lpo_items` as lpoi
                               LEFT JOIN `jos_lpo` as lpo
                               ON lpoi.lpo_id = lpo.lpo_id
                          GROUP BY lpoi.lpo_id) as lpo_amt ON lpo_amt.lpo_id = lpo.lpo_id

             LEFT JOIN (SELECT lpo_id, SUM(amount) as amount_paid
                        FROM `jos_petty_cash` WHERE status IN ('Issued','Closed') GROUP BY lpo_id) as amtp
                        ON amtp.lpo_id = lpo.lpo_id

            LEFT JOIN (SELECT lpo_id, SUM(amount) as amount_paid
                       FROM `jos_petty_cash_mobile` WHERE status IN ('Issued','Closed') GROUP BY lpo_id) as amtpm
                       ON amtpm.lpo_id = lpo.lpo_id

					WHERE lpo.lpo_id LIKE '%$search%' $filter_sql ORDER BY lpo.lpo_id DESC LIMIT 15;";

        //   if($_GET['debug']){
        //       echo $lpo_sql;
        //   }



$result = mysql_query($lpo_sql);


if(mysqli_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $amount = number_format($row['lpo_amount']);

        if(!$no_lpo_amount){
          $amount_display = ' ('.$amount .' '.$row['lpo_currency'].')';
        }

        $data[] = array('id' => $row['lpo_id'],
                        'text' => '#'.$row['lpo_id'].': '.$row['supplier_company']. $amount_display,
                        'supplier_id' => $row['supplier_id'],
                        'lpo_amount' => $row['lpo_amount'],
                        'amount_paid' => $row['amount_paid'],
                        'lpo_balance' => $row['lpo_balance']
                         );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
