<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$add_item = isset($_GET['add_item'])? $_GET['add_item'] : '' ;
$customer_id = isset($_GET['customer_id'])? $_GET['customer_id']: '';
$status = isset($_GET['status'])? $_GET['status'] :  '';
$quote_id = isset($_GET['quote_id'])? $_GET['quote_id'] : '';
$no_sample = isset($_GET['no_sample'])? $_GET['no_sample'] : '';



if($add_item){
    $data[] = array('id' => -1, 'text' => 'Select to Enter Item (Not in stock)');
}

$filter_sql = "";

if($customer_id > 0){

    $filter_sql .= " AND jc.customer_id = '$customer_id' ";
}

if($status){

    if($status == 'in_prod_deliv'){

        $filter_sql .= " AND (j.job_status = 'In Production' OR j.job_status = 'Delivery') ";

    }elseif ($status == 'not_pending') {

       $filter_sql .= " AND (j.job_status != 'Pending'  && j.job_status != 'Complete') ";

    }else{

        $filter_sql .= " AND j.job_status = '$status' ";
    }

}

if($quote_id > 0){

    $filter_sql .= " AND q.quote_id = '$quote_id' ";
}

if($no_sample){

    $filter_sql .= " AND jqi.item_price_1 > 0 ";
}

$job_sql = "SELECT
    j.job_id,
    j.job_date,
    IF(jqi.stock_id > 0, js.stock_name, j.job_reference) as job_reference,
    j.job_product,
    job_paper_quantity,
    j.type,jqi.stock_id,
    cms_users.user_fname,
    cms_users.user_lname,
    jos_products.product_name,
    jcg.group_company

FROM
    `jos_jobs` AS j
LEFT JOIN `jos_products` ON jos_products.product_ref = j.job_product
LEFT JOIN `cms_users` ON cms_users.user_id = j.user_id


LEFT JOIN jos_quotes_items as jqi
 ON jqi.item_id = j.item_id

LEFT JOIN `jos_quotes` AS q
ON
    q.quote_id = jqi.quote_id

LEFT JOIN `jos_customers` AS jc
ON
    jc.customer_id = q.customer_id
LEFT JOIN `jos_customers_group` AS jcg
ON
    jcg.group_id = jc.group_id

LEFT JOIN jos_stock js
ON js.stock_id = jqi.stock_id

					WHERE j.job_id LIKE '%$search%' $filter_sql GROUP BY j.job_id ORDER BY j.job_id DESC LIMIT 15;";

//   if($_SESSION['user_id'] == 24){
//       echo $job_sql;
//       exit;
//   }

$result = mysql_query($job_sql);


if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $description = $row['product_name']. ' - '. $row['job_reference'];
        $data[] = array('id' => $row['job_id'],
          'text' => $row['job_id'].': '.$row['job_reference']. ' - '. $row['product_name'],
          'description' => $description,
          'quantity' => $row['job_paper_quantity'],
          'type' => $row['type'],
          'product_ref' => $row['job_product'],
          'stock_id' => $row['stock_id'],
          'group_company' => $row['group_company']
        );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
