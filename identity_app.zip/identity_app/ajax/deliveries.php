<?php
/**
 * Created by PhpStorm.
 * User: FrankGalos
 * Date: 6/12/2018
 * Time: 2:51 PM
 */

require("../configs/variables.php");
$data = array();

if(isset($_POST['id']) && !empty($_POST['id'])){
      $id = $_POST['id'];

    $sql = "SELECT SUM(dni.quantity) as total_quantity FROM `jos_dn_items` as dni LEFT JOIN `jos_delivery_notes` as dn ON(dni.dn_id = dn.dn_id) WHERE dni.job_id = '$id' AND dn.dn_status != 'Cancelled' ";

    $result = mysql_query($sql);

    if(mysql_num_rows($result) > 0) {

        while ($row = mysql_fetch_assoc($result)) {

            $data[] = $row;

        }

    } else {

        $data[] = array('id' => '0', 'text' => "No record was found!");
    }
}else{
    $search = mysql_real_escape_string($_GET['q']);
    $customer_id = $_GET['customer_id'];

    $sql = "SELECT jn.dn_id,jn.customer_id,jj.currency, jn.dn_quantity, j.item_id, jqi.item_price_1 as price, jqi.item_title as description FROM jos_delivery_notes as jn LEFT JOIN jos_jobs as j ON(j.job_id = jn.job_id) LEFT JOIN jos_quotes_items as jqi ON(jqi.item_id = j.item_id)
 LEFT JOIN jos_quotes as jj ON(jqi.quote_id = jj.quote_id)
 WHERE jn.dn_id LIKE '%$search%' AND jn.customer_id = '$customer_id' ORDER BY jn.dn_id ASC ";
    $result = mysql_query($sql);

    if(mysql_num_rows($result) > 0) {

        while ($row = mysql_fetch_assoc($result)) {

            $data[] = array(
                'id' => $row['dn_id'],
                'customer_id'=>$row['customer_id'],
                'text' => $row['description'],
                'price'=>$row['price'],
                'currency'=>$row['currency'],
                'quantity'=>$row['dn_quantity']);

        }

    } else {

        $data[] = array('id' => '0', 'text' => "No record was found!");
    }
}

// return the result in json
echo json_encode($data);
