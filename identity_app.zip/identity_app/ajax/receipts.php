<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$customer_id = $_GET['customer_id'];
$not_linked = $_GET['no_order_link'];

$filter_sql = "";

if($customer_id > 0){

    $filter_sql .= " AND r.customer_id = '$customer_id' ";
}

if($not_linked){
  $filter_sql .= " AND r.receipt_id NOT IN 
  (SELECT jg.receipt_id
    FROM jos_jobs_groups jg
    LEFT JOIN jos_quotes q 
    ON q.quote_id = jg.quote_id
    LEFT JOIN jos_customers AS cu
    ON cu.customer_id = q.customer_id
    WHERE jg.receipt_id IS NOT NULL AND cu.customer_id = '$customer_id')";
}



$rcpt_sql = "SELECT r.*, cg.group_company, cu.customer_id, cu.customer_fname, cu.customer_lname, cu.customer_email

					FROM jos_receipts as r

					LEFT JOIN jos_customers  as cu
					   ON cu.customer_id = r.customer_id

					LEFT JOIN jos_customers_group AS cg
					   ON cg.group_id = cu.group_id

					WHERE r.receipt_id LIKE '%$search%' $filter_sql GROUP BY r.receipt_id ORDER BY r.receipt_id DESC LIMIT 15;";

$result = mysql_query($rcpt_sql);

if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {
      $amount = number_format($row['receipt_amount'], 2). ' '.$row['receipt_currency'];
      $data[] = array('id' => $row['receipt_id'],
        'text' => $row['receipt_id'].': '.$row['group_company']. ' ('. $amount.')',
        'receipt_id' => $row['receipt_id'],
        'group_company' => $row['group_company'],
        'receipt_amount' => $row['receipt_amount'],

      );

    }

} else {

   $data[] = array();


}

// return the result in json
echo json_encode($data);
die();
