<?php

require("../configs/variables.php");

$quote_id = mysql_real_escape_string($_GET['q']);
$customer_id = isset($_GET['customer_id'])? $_GET['customer_id'] : '';
$statuses = isset($_GET['status'])? $_GET['status'] : '';

$filter_sql = "";

if($customer_id > 0){

    $filter_sql .= " AND c.customer_id = '$customer_id' ";
}

if($statuses){

    $filter_sql .= " AND (q.quote_status IN ($statuses)) ";

}


$quote_sql = "SELECT q.quote_id, cg.group_company

        FROM jos_quotes as q

        LEFT JOIN jos_customers c
           ON c.customer_id = q.customer_id

        LEFT JOIN jos_customers_group cg
           ON cg.group_id = c.group_id

					WHERE q.quote_id LIKE '%$quote_id%' $filter_sql ORDER BY q.quote_id DESC LIMIT 15;";

        //   if($_GET['debug']){
        //     echo $quote_sql;
        //   }

$result = mysql_query($quote_sql);


if(mysqli_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $data[] = array('id' => $row['quote_id'],
          'text' => $row['quote_id'].': '.$row['group_company'],
          'group_company' => $row['group_company']
        );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
