<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$status = $_GET['status'];

$filter_sql = "";


if($status){
    $filter_sql .= " AND gmr.gmr_status = '$status' ";
}

$dni_sql = "SELECT gmr.*, jb.job_reference, sup.supplier_company,
    GROUP_CONCAT(COALESCE(s.stock_name,j.job_reference,gmri.description)) as items,
    IF(sup.supplier_company IS NULL OR sup.supplier_company = '', CONCAT(sup.supplier_fname, ' ', sup.supplier_lname), sup.supplier_company) as supplier_name
    FROM jos_gmr gmr
    LEFT JOIN jos_suppliers sup
    ON sup.supplier_id = gmr.supplier_id

    LEFT JOIN jos_jobs as jb
    ON jb.job_id = gmr.job_id

    LEFT JOIN  jos_gmr_items gmri
    ON gmr.gmr_id = gmri.gmr_id
    LEFT JOIN jos_stock s
    ON s.stock_id = gmri.stock_id
    LEFT JOIN jos_jobs as j
    ON j.job_id = gmri.job_id

		WHERE gmr.supplier_id > 0 AND gmr.gmr_id LIKE '%$search%' $filter_sql ORDER BY gmr.gmr_id DESC LIMIT 15;";

          if(isset($_GET['debug'])){
              echo $dni_sql;
          }



$result = mysql_query($dni_sql);


if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $data[] = array('id' => $row['gmr_id'],
                        'text' => '#'.$row['gmr_id'].': '.$row['supplier_name'],
                        'supplier_id' => $row['supplier_id'],
                        'supplier_company' => $row['supplier_company'],
                        'gmr_id' => $row['gmr_id']
                         );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
