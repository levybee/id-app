<?php


require("../configs/variables.php");
require("../configs/functions.php");
require("../modules/requisition/functions.php");

$req_id = mysql_real_escape_string($_GET['req_id']);
$reqItems = get_issued_stock(['requisition_id' => $req_id]);

echo json_encode($reqItems);
exit;
