<?php
require("../configs/variables.php");
require("../configs/functions.php");

$type = $_GET['type'];
$start = $_GET['start']?? null;
$end = $_GET['end']?? null;

if($type ==  'events'){

  $search_ext_sr = '';
  if($start && $end){
    $search_ext_sr = " WHERE vp.vp_date >= '$start' AND vp.vp_date <= '$end'";
  }

  $vp_list_sql = "SELECT vp.*,
      IF(vp.group_id > 0, g.group_company, vp.client_name) as client
      FROM  jos_sales_visitplan vp
      LEFT JOIN jos_customers_group g ON g.group_id = vp.group_id
      LEFT JOIN cms_users u ON u.user_id = vp.user_id
      $search_ext_sr
      ORDER BY vp.vp_date DESC";

$vp_list = smartsql($vp_list_sql);
$events = [];

header('Content-Type: application/json');
if (!empty($vp_list) && isset($vp_list[0]['vp_id'])) {
    $events = array_map(function ($vp) {
        // start datetime
        $start_time = "{$vp['vp_date']}T{$vp['vp_time']}";

        // default duration 30 mins if missing
        $duration  = !empty($vp['duration']) ? (int)$vp['duration'] : 30;

        // add duration to start
        $end_time = date('Y-m-d\TH:i:s', strtotime("$start_time +{$duration} minutes"));

        return [
            'id'       => $vp['vp_id'],
            'text'     => "{$vp['client']}: {$vp['remarks']} - {$vp['visit_location']}",
            'start'    => $start_time,
            'end'      => $end_time,
            'resource' => $vp['user_id'], // links to scheduler resource
        ];
    }, $vp_list);
}

echo json_encode($events);

}

if($type == 'resources'){

  $users = smartsql("SELECT user_id as id, CONCAT(user_fname, ' ', user_lname) as name
  FROM cms_users WHERE (role_id = 5 OR role_id = 18 OR role_id = 20)
  AND user_status = 'Active' ORDER BY user_fname ASC");

  echo json_encode($users);

}

 ?>
