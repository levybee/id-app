<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$status = $_GET['status'];

$filter_sql = "";


if($status){

    $filter_sql .= " AND inv.invoice_status = '$status' ";
}

$ii_sql = "SELECT ii.*, inv.*, cg.group_id, cg.group_company
            FROM `jos_invoice_items` as ii
            LEFT JOIN `jos_invoices` as inv
            ON ii.invoice_id = inv.invoice_id
            LEFT JOIN `jos_customers` as cu
      			   ON cu.customer_id = inv.customer_id

      			LEFT JOIN `jos_customers_group` as cg
      			   ON cg.group_id = cu.group_id

					WHERE inv.invoice_id LIKE '%$search%' $filter_sql ORDER BY ii.invoice_item_id DESC LIMIT 15;";

          if(isset($_GET['debug'])){
              echo $dni_sql;
          }



$result = mysql_query($ii_sql);


if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {

        $data[] = array('id' => $row['invoice_item_id'],
                        'text' => $row['invoice_id'].': '.$row['item_description'],
                        'group_id' => $row['group_id'],
                        'group_company' => $row['group_company'],
                        'invoice_id' => $row['invoice_id']
                         );

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
