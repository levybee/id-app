<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$customer_id = $_GET['customer_id'];
$job_id = $_GET['job_id']?? null;
$quote_id = $_GET['quote_id'];

$filter_sql = "";

if($customer_id > 0){

    $filter_sql .= " AND jg.customer_id = '$customer_id' ";
}

if($quote_id > 0){
    $filter_sql .= " AND jg.quote_id = '$quote_id' ";
}

$qc_sql = "SELECT qc.id, qc.quantity, j.job_id, j.job_reference, j.job_product, j.job_paper_quantity,
	          p.product_name
					FROM `jos_qc` as qc

          LEFT JOIN `jos_jobs` as j
           ON j.job_id = qc.job_id

           LEFT JOIN `jos_jobs_groups` as jg
            ON jg.group_id = j.group_id

        LEFT JOIN `jos_customers` as jc
            ON jc.customer_id = jg.customer_id

					LEFT JOIN `jos_products` as p
					   ON p.product_ref = j.job_product

					WHERE qc.id LIKE '%$search%' $filter_sql ORDER BY qc.id DESC LIMIT 15;";

          // if($_GET['debug']){
          //   echo $qc_sql;
          //   exit;
          // }

$result = mysql_query($qc_sql);

if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {



      $description = $row['product_name']. ' - '. $row['job_reference'];
      $data[] = array('id' => $row['id'],
        'text' => $row['id'].': '.$row['job_reference']. ' - '. $row['product_name'],
        'job_id' => $row['job_id'],
        'job_info' => $row['job_id'].': '.$row['job_reference']. ' - '. $row['product_name'],
        'job_quantity' => $row['job_paper_quantity'],
        'quantity' => $row['quantity'],
        'description' => $description,

      );

    }

} else {

   $data[] = array();


}

// return the result in json
echo json_encode($data);
die();
