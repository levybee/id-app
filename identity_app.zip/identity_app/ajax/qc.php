<?php

require("../configs/variables.php");

// $search = $_GET['q'];
$job_id = $_GET['job_id'];

//$sql = "SELECT `stock_id`, `stock_name`, `units` FROM `jos_stock` WHERE stock_name LIKE '%".$search."%' ORDER BY `stock_name` ASC;";
$sql = "SELECT id, balance FROM jos_qc
WHERE job_id = '$job_id' AND type = 'Normal' ORDER BY id DESC LIMIT 1";
$result = mysql_query($sql);

if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {



        $data = array('id' => $row['id'],
                         'balance' => $row['balance']
                        );

    }

} else {

   $data[] = array();


}

// return the result in json
echo json_encode($data);
die();
