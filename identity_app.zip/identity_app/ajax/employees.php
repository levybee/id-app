<?php

require("../configs/variables.php");

$search = mysql_real_escape_string($_GET['q']);
$add_item = isset($_GET['add_item'])? $_GET['add_item'] : '';
$show_type = isset($_GET['show_type'])? $_GET['show_type'] : '';

$employee_sql = "SELECT je.*,d.department_name FROM `jos_employees` as je
               LEFT JOIN `jos_departments` as d
                ON d.department_id = je.department

					WHERE (je.first_name LIKE '%$search%' OR  je.last_name LIKE '%$search%') AND je.status = 'Active' ORDER BY je.first_name ASC LIMIT 20;";

        //   if($_GET['debug']){
        //     echo $employee_sql;
        //   }

$result = mysql_query($employee_sql);


if(mysql_num_rows($result) > 0) {


    while ($row = mysql_fetch_assoc($result)) {
        $type = "";
        if($show_type){
          $type = substr($row['type'], 0, 1);
          $type = ($type == 'P')? " ($type)" : " (T)";
        }

        $data[] = array('id' => $row['id'], 'text' => $row['id'].': '.$row['first_name']. '  '. $row['last_name'].''.$type);

    }

} else {

   $data[] = array('id' => '0', 'text' => 'No Results Found');

}

// return the result in json
echo json_encode($data);
