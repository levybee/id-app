<?php

require_once 'libs/dompdf/autoload.inc.php';
include_once $_SERVER['DOCUMENT_ROOT']."/modules/receipts/functions.php";
use Dompdf\Dompdf;

/**
 * Generate and save a receipt PDF, return file path
 *
 * @param int $receipt_id
 * @return string|bool  Full path to saved PDF or false on failure
 */
function generateAndSaveReceiptPdf($receipt_id)
{
    global $smarty; // assuming Smarty is globally available

    // 1. Fetch receipt data (your existing function)
    $data = get_receipt($receipt_id);

    if (empty($data) || empty($data['receipt'])) {
        error_log("Receipt PDF: No data found for receipt ID $receipt_id");
        return false;
    }

    // 2. Special handling for group_id 51 (walk-in customer)
    if (isset($data['receipt'][0]['group_id']) && $data['receipt'][0]['group_id'] == 51) {
        if (isset($data['receipt_items'][0]['quote_customer']) && trim($data['receipt_items'][0]['quote_customer']) !== '') {
            $customerParts = explode(',', $data['receipt_items'][0]['quote_customer']);
            $data['receipt'][0]['customer_name'] = trim($customerParts[0]) . ' - Walk In Customer';
        }
    }

    // 3. Assign to Smarty
    $smarty->assign('data', $data);

    // 4. Prepare Dompdf
    $dompdf = new Dompdf();

    $receiptNo = sprintf("%05d", $receipt_id);
    $document_title = "Receipt #$receiptNo";

    $options = $dompdf->getOptions();
    $options->setDefaultFont('Helvetica');
    $options->set('isRemoteEnabled', true);
    $options->set('isHtml5ParserEnabled', true);
    $options->set('tempDir', sys_get_temp_dir()); // better than 'uploads/'
    $dompdf->setOptions($options);

    // 5. Render template
    $tpl_path = TEMPLATES . 'receipts/print-receipt.tpl';
    if (!file_exists($tpl_path)) {
        error_log("Receipt PDF: Template not found: $tpl_path");
        return false;
    }

    $html_output = $smarty->fetch($tpl_path);

    // 6. Load HTML and render PDF
    $dompdf->loadHtml($html_output);
    $dompdf->setPaper('A5', 'landscape');
    $dompdf->render();

    // Optional page number footer
    $font = $dompdf->getFontMetrics()->get_font("helvetica", "normal");
    $dompdf->getCanvas()->page_text(270, 800, "Page {PAGE_NUM} of {PAGE_COUNT}", $font, 8, [0,0,0]);

    // 7. Define save path
    $saveDir = 'uploads/receipts/';
    $fullSaveDir = __DIR__ . '/../' . $saveDir; // adjust path relative to your script
    if (!is_dir($saveDir)) {
        if (!mkdir($saveDir, 0755, true)) {
            error_log("Receipt PDF: Failed to create directory: $fullSaveDir");
            return false;
        }
    }

    $fileName = "receipt_{$receiptNo}.pdf";
    $relativePath = $saveDir . $fileName;
    $fullPath = $fullSaveDir . $fileName;

    // 8. Save PDF to disk
    $output = $dompdf->output();
    if (file_put_contents($relativePath, $output) === false) {
        error_log("Receipt PDF: Failed to save file: $fullPath");
        return false;
    }

    // 10. Return the relative path (for download link, email, etc.)
    return $relativePath;
}