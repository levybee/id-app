<?php

/* Autometed email that sends list of employees allowed overtime - 4pm
*/

header("Content-Type: text/plain");

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
$day = date('d F Y', strtotime('+1 day'));


require_once( __DIR__."/../configs/variables.php");
require_once( __DIR__."/../configs/functions.php");

$sql = 'SELECT
    j.group_id,
    j.job_id,
    j.job_date,
    j.job_time,
    j.job_due_date,
            j.job_due_time,
            j.job_status,
            IF(
                jqi.stock_id > 0,
                stck.stock_name,
                j.job_reference
            ) AS job_reference,
            j.job_product,
            j.job_paper_quantity,
            j.job_color,
            j.job_color_other,
            j.job_invoice_no,
            jos_customers_group.group_company,
            j.job_status_notes,
            jos_customers.customer_fname,
            jos_customers.customer_lname,
            jos_customers.customer_email,
            cms_users.user_fname,
            cms_users.user_lname,
            jos_departments.department_name,
            jos_products.product_name,
            jqi.item_price_1,
            jq.currency,
            (
            SELECT
                project_manager
            FROM
                jos_job_history
            WHERE
                log_type = "department" AND jos_departments.department_name = department_new AND job_id = j.job_id
            LIMIT 1
        ) AS project_manager, j.department_id, CONCAT(je.first_name, " ", je.last_name) AS designer, g.job_lpo_other
    FROM
        `jos_jobs` AS j
    LEFT JOIN `jos_jobs_groups` AS g
    ON
        g.group_id = j.group_id
    LEFT JOIN `jos_customers` ON jos_customers.customer_id = g.customer_id
    LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
    LEFT JOIN `jos_departments` ON jos_departments.department_id = j.department_id
    LEFT JOIN `jos_products` ON jos_products.product_ref = j.job_product
    LEFT JOIN `jos_employees` je ON
        je.id = j.employee_id
    LEFT JOIN `cms_users` ON cms_users.user_id = j.user_id
    LEFT JOIN `jos_quotes_items` AS jqi
    ON
        jqi.item_id = j.item_id
    LEFT JOIN `jos_stock` AS stck
    ON
        stck.stock_id = jqi.stock_id
    LEFT JOIN `jos_quotes` AS jq
    ON
        jq.quote_id = jqi.quote_id
    WHERE
        j.job_status = "In Production" AND j.job_due_date = DATE_ADD(CURDATE(), INTERVAL 1 DAY)
    GROUP BY
        j.job_id
    ORDER BY
        j.job_due_date ASC';

  $query = mysql_query($sql);
  $rows = mysqli_num_rows($query);

$cronDate = date('Y-m-d H:i:s');
echo "[Run Date $cronDate] $rows Records found..\n\n";
if($rows == 0){
  exit;
}

$report_array = array();

if($rows > 0) {

    $departments = [];
    $jobs_html = '';
    while ($row = mysql_fetch_assoc($query)) {
      $departments[$row['department_name']][] = $row;
    }
    

    foreach ($departments as $department => $jobs) {

      $jobs_html .= "<br><p><strong>{$department}</strong></p>";

              $jobs_html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
              $jobs_html .= "<thead>
                                      <tr>
                                          <th width='40' style='padding:3px;' bgcolor='#ccc'>JO #</th>
          							    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
          							    <th style='padding:3px 4px;' bgcolor='#ccc'>Product</th>
          							    <th style='padding:3px 4px;' bgcolor='#ccc'>Title</th>
                                          <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
                                          <th style='padding:3px 4px;' bgcolor='#ccc'>Quantity</th>
                                          <th style='padding:3px 4px;' bgcolor='#ccc'>Due Date</th>
                                      </tr>
                                  </thead>";
              $jobs_html .= "<tbody>";

             $bg_color1 = '#fcfcfc';
             $bg_color2 = '#e5e5e5';
             $row_color = $bg_color1;

             foreach($jobs as $k => $row){

               $job_date = date('d M Y', strtotime($row['job_date'])). '<br>'. $row['job_time'];
               $customer = $row['group_company']. ' - '.$row['customer_fname'].' '.$row['customer_lname'];
               $due_date = date('d M Y', strtotime($row['job_due_date'])). '<br>'. $row['job_due_time'];

               $jobs_html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['job_id']."</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$job_date."</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['product_name']."</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['job_reference']."</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$customer."</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['job_paper_quantity'], 0, '.', ',')."</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$due_date."</td>
                   </tr>";

                    if($row_color == $bg_color1){
                      $row_color = $bg_color2;
                    }elseif($row_color == $bg_color2){
                      $row_color = $bg_color1;
                    }

             }

             $jobs_html .= "</tbody></table>";


    }


         $msg_body = "<p>The following is a report of job orders that due tomorrow  $day</p>";
         $msg_body .= $jobs_html;

// echo $msg_body;
// exit;



    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
    require_once(__DIR__."/../libs/Postmark/class.postmark.php");

    $postmark = new Postmark\Mail($postmarkApiKey);
    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
    $postmark->subject("Identity App: Job Orders Delivery Report - $day");
     // $postmark->addTo('hasnain@identitytz.com');
     // $postmark->addTo('gm@identitytz.com');
     // $postmark->addTo('hr@identitytz.com');
      $postmark->addTo('kazim@identitytz.com');
     // $postmark->addTo('pm@identitytz.com');
    // $postmark->addTo('nabila@identitytz.com');
    // $postmark->addTo('procurement@identitytz.com');
    // $postmark->addTo('beecraq@gmail.com');



    $postmark->messageHTML($msg_body);

    if($postmark->send()){
        echo "Email sent\n\n";
    } else {
        echo "Sending failed.\n\n";
    }

}
