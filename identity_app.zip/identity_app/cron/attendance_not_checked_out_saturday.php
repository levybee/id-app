<?php

/* Autometed email that sends list of employees not checked out after 5:45pm
*/

use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require("/home/identity/public_html/app/modules/attendance_schedule/functions.php");

$ATTACHMENTS_DIR = $_SERVER['DOCUMENT_ROOT'] . '/tmp/';

$date = date('Y-m-d');
$shift_id = 1;
$order = 'je.first_name, je.last_name ASC';
$params['schedule_date']= $date;
$params['shift_id']=$shift_id;
$params['order'] = $order;
$params['employee_status'] = 'Active';
$params['no_time_out'] = 1;
$params['status'] = array('Present','Late');


$schedule_data = fetch_schedule($params);

$report_array = array();

if(count($schedule_data) > 0) {
    $count=0;
    // foreach($schedule_data as $k => $row){

    //     $count++;
    //     $report_array[] = array(

    //         'id' => $count,
    //         'employee_name' => $row['employee_name'],
    //         'type' => $row['type'],
    //         'department_name' => $row['department_name'],
    //         'time_in' => $row['time_in'],
    //         'status' => $row['status'],
    //     );

    // }


    // $today = date('d M Y');

    // $filename = "Employees-Not-Checked-Out-$date-".time().".csv";
    // $filepath = $ATTACHMENTS_DIR.$filename;



    // $file = fopen($filepath, 'w');
    // fputcsv($file, array('#','EMPLOYEE NAME','TYPE','DEPARTMENT','TIME IN','STATUS'));
    // foreach ($report_array as $line) {
    //     fputcsv($file, ($line));
    // }

    // fclose($file);
    $departments = [];
    $html = '';
    foreach ($schedule_data as $key => $value) {
      $departments[$value['department_name']][] = $value;
    }

    foreach ($departments as $department => $schData) {

      $html .= "<br><p>{$department}</p>";

      $html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
              $html .= "<thead>
                                  <tr>
                                  <th width='50' style='padding:3px;' bgcolor='#ccc'>#</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>EMPLOYEE NAME</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>TYPE</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>STATUS</th>
                                  </tr>
                       </thead>";
              $html .= "<tbody>";

             $bg_color1 = '#fcfcfc';
             $bg_color2 = '#e5e5e5';
             $row_color = $bg_color1;

             foreach($schData as $k => $row){

                 $count++;

                 $html .= "<tr>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$count</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['employee_name']}</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['type']}</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['status']}</td>
                    </tr>";

                    if($row_color == $bg_color1){
                      $row_color = $bg_color2;
                    }elseif($row_color == $bg_color2){
                      $row_color = $bg_color1;
                    }

             }

             $html .= "</tbody></table>";


    }


         $today = date('d M Y');
         $msg_body = "<p>The following is a report of employees that have not checked out $today - Day</p><br>";
         $msg_body .= $html;


    require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Employees Not Checked Out";

    $mail->addAddress('hasnain@identitytz.com');
    $mail->addAddress('gm@identitytz.com');
    $mail->addAddress('hr@identitytz.com');
    $mail->addAddress('kazim@identitytz.com');
    // $mail->addAddress('Admin@identitytz.com');
    // $mail->addAddress('nabila@identitytz.com');
    // $mail->addAddress('procurement@identitytz.com');
    // $mail->addAddress('beecraq@gmail.com');

   // $msg_body = "<p>Attached is a report for employees that have not checked out $today - Day</p><br>";

    $mail->Body = $msg_body;
   // $mail->addAttachment($filepath);

    if($mail->send()){
        echo "Email sent";
    } else {
        echo "Sending failed.";
    }

}
