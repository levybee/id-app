<?php

//      ini_set('display_errors', 1);
//  error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");


// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for wip report.\n";

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require($root_dir."configs/variables.php");
require($root_dir."configs/functions.php");
$ATTACHMENTS_DIR = $root_dir . 'tmp/';


$wip_sql = 'SELECT j.job_id, j.job_date, j.job_time, j.job_reference, j.job_paper_quantity,
            jos_customers_group.group_company,
               jos_departments.department_name,
               IFNULL(stckQry.stock_value, 0) as stock_value,
               IFNULL((invQry.qty_invoiced/j.job_paper_quantity) * 100, 0) as qty_invoiced,
               IFNULL(stckQry.stock_value, 0) * (1 - IFNULL((invQry.qty_invoiced/j.job_paper_quantity) * 100, 0)/100) as wip_value
            FROM `jos_jobs` as j

            LEFT JOIN `jos_jobs_groups` as g
            ON g.group_id = j.group_id

            LEFT JOIN `jos_customers`
            ON jos_customers.customer_id = g.customer_id

            LEFT JOIN `jos_customers_group`
            ON jos_customers_group.group_id = jos_customers.group_id

            LEFT JOIN `jos_departments`
            ON jos_departments.department_id = j.department_id

            LEFT JOIN (SELECT
            qc.job_id,
            SUM(ii.item_quantity) AS qty_invoiced
            FROM jos_invoice_items ii
            LEFT JOIN  `jos_invoices` i
            ON ii.invoice_id = i.invoice_id
            LEFT JOIN jos_qc qc ON
            ii.qc_id = qc.id
            GROUP BY qc.job_id) as invQry
            ON invQry.job_id = j.job_id

            LEFT JOIN (SELECT r.job_id, SUM(js.unit_price) as stock_value
                        FROM jos_requisition_is as jis
                        LEFT JOIN  jos_requisition_isi risi
                        ON jis.ris_id = risi.ris_id
                        LEFT JOIN jos_requisition_items ri
                        ON ri.ri_id = risi.ri_id
                        LEFT JOIN jos_stock as js
                           ON js.stock_id = ri.stock_id
                         LEFT JOIN jos_requisition r
                         ON r.requisition_id = ri.requisition_id
            WHERE jis.status = "Issued"
            GROUP BY r.job_id) as stckQry
            ON stckQry.job_id = j.job_id
            WHERE j.job_status = "In Production"
            GROUP BY j.job_id
            ORDER BY j.job_date DESC';



$result = mysql_query($wip_sql);


if(mysql_num_rows($result) > 0) {
   echo "Found data working on it..\n";
   $reportData = [];
   while ($row = mysql_fetch_assoc($result)) {
      $reportData[$row['department_name']][] = $row;
   }
   
  

   $year = date('Y');
   $stockfilename = "Stock-Value-WIP-Report-$year-".time().".csv";
      $stockfilepath = $ATTACHMENTS_DIR.$stockfilename;

      $file = fopen($stockfilepath, 'w');
      fputcsv($file, array('JO #','Customer','Job Ref','Stock Value', 'Qty Invoiced', 'WIP Value'));

    // print_r($reportData);
    // exit;
    $wip_html = '';
    foreach ($reportData as $department => $data) {

      $jobs_html = "<br><p><strong>$department</strong></p>";
      $jobs_html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
      $jobs_html .= "<thead>
                              <tr>
                                  <th width='40' style='padding:3px;' bgcolor='#ccc'>JO #</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Job Ref</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Stock Value</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Qty Invoiced</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>WIP Value</th>
                              </tr>
                          </thead>";
      $jobs_html .= "<tbody>";




      fputcsv($file, array("$department","","","","",""));


      foreach ($data as $key => $row) {

          $jo_no = $row['job_id']; //substr($row['job_date'], 0, 4). '-'.substr($row['job_date'], 5, 2).'-'.str_pad($row['job_id'], 5, '0', STR_PAD_LEFT);
          $customer = $row['group_company'];
          $qty_invoiced = ($row['qty_invoiced'] > 0)? number_format($row['qty_invoiced'], 2).'%' : '0';
          $wip_value = number_format($row['wip_value'], 2);
          $stock_value = number_format($row['stock_value'], 2);

          fputcsv($file, array("{$jo_no}","{$customer}","{$row['job_reference']}","{$stock_value}","$qty_invoiced","$wip_value"));

          $jobs_html .= "<tr>
            						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$jo_no</td>
            						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$customer</td>
            						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$row['job_reference']}</td>
            						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$stock_value</td>
            						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$qty_invoiced</td>
            						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$wip_value</td>
            						 </tr>";
      }

      $jobs_html .= "</tbody></table>";
      $wip_html .= $jobs_html;
      // code...

       fputcsv($file, array("","","",""));



    }

    fclose($file);


    $dateSum = date("F Y", strtotime("first day of previous month"));
    // $dateSum = date('F Y');

    require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Closing WIP Report For $dateSum";

     $mail->addAddress('hasnain@identitytz.com');
     $mail->addAddress('kazim@identitytz.com');
  //   $mail->addAddress('gm@identitytz.com');
     $mail->addAddress('admin@identitytz.com');
    $mail->addAddress('accounts2@identitytz.com');
    $mail->addAddress('vijay@identitytz.com');
    
    // $mail->addAddress('beecraq@gmail.com');

    $msg_body = "<p>The following is a WIP report for $dateSum:</p><br>".$wip_html;

    // echo $msg_body;
    // exit;

    $mail->Body = $msg_body;
    $mail->addAttachment($stockfilepath);

    if($mail->send()){
        echo "Email sent\n\n";
        unlink($stockfilepath);
    }

}else{
  echo "No records found\n\n";
}
