<?php

header("Content-Type: text/plain");

echo "Cron Run[" . date('Y-m-d H:i:s') . "]\n";
echo "Starting automation for daily receipts report.\n";

$local = false; // toggle local/production settings

require(__DIR__ . "/../configs/variables.php");
require(__DIR__ . "/../configs/functions.php");
require(__DIR__ . "/../configs/email.php");
require(__DIR__ . "/../modules/receipts/functions.php"); // get_receipt()

function h($v){
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function pick_first($arr, $keys, $default = ''){
    if(!is_array($arr)){ return $default; }
    foreach($keys as $k){
        if(isset($arr[$k]) && $arr[$k] !== ''){
            return $arr[$k];
        }
    }
    return $default;
}

function format_receipt_ref($r){
    $d = pick_first($r, array('receipt_date'));
    $yy = $d ? substr($d, 0, 4) : '';
    $mm = $d ? substr($d, 5, 2) : '';
    $id = leading_zero(pick_first($r, array('receipt_id'), 0), 5);
    return $yy . "-" . $mm . "-" . $id;
}

// Base receipts for today
$receipts_sql = "SELECT
        r.*,
        cg.group_company,
        cu.customer_fname,
        cu.customer_lname
    FROM jos_receipts r
    LEFT JOIN jos_customers cu ON cu.customer_id = r.customer_id
    LEFT JOIN jos_customers_group cg ON cg.group_id = cu.group_id
    WHERE DATE(r.receipt_date) = CURRENT_DATE
    ORDER BY r.receipt_id DESC";

$receipts = smartsql($receipts_sql);

if(!isset($receipts[0]['receipt_id'])){
    echo "No records found.\n";
    exit;
}

// Attach breakdown items exactly as receipts module does
foreach($receipts as $k => $row){
    $receipts[$k]['receipt_info'] = get_receipt($row['receipt_id']);
}

// Email HTML - match templates/receipts/list.tpl
$html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$html .= "<thead><tr>
<th style='padding:3px 4px;' bgcolor='#ccc'>Ref #</th>
<th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
<th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
<th style='padding:3px 4px;' bgcolor='#ccc'>Received Via</th>
<th style='padding:3px 4px;' bgcolor='#ccc'>Inv Amount</th>
<th style='padding:3px 4px;' bgcolor='#ccc'>Amount Received</th>
<th style='padding:3px 4px;' bgcolor='#ccc'>Receipt Amount</th>
<th style='padding:3px 4px;' bgcolor='#ccc'>On Account</th>
</tr></thead><tbody>";

$bg1 = '#fcfcfc';
$bg2 = '#e5e5e5';
$row_color = $bg1;
$grand_total_received = 0;

foreach($receipts as $r){
    $info         = (isset($r['receipt_info']) && is_array($r['receipt_info'])) ? $r['receipt_info'] : array();
    $receipt_head = (isset($info['receipt'][0]) && is_array($info['receipt'][0])) ? $info['receipt'][0] : array();
    $items        = (isset($info['receipt_items']) && is_array($info['receipt_items'])) ? $info['receipt_items'] : array();

    $receipt_type = pick_first($r, array('receipt_type'));
    $currency     = pick_first($r, array('receipt_currency'), '');

    $ref          = format_receipt_ref($r);
    $receipt_id   = pick_first($r, array('receipt_id'));
    $receipt_link = "https://app.identitytz.com/receipts/view?id=" . $receipt_id;

    $date_raw = pick_first($r, array('receipt_date'));
    $date     = $date_raw ? date('d F Y', strtotime($date_raw)) : '';

    $customer = pick_first($r, array('group_company'));
    if(!$customer){
        $customer = trim(pick_first($r, array('customer_fname')) . " " . pick_first($r, array('customer_lname')));
    }

    $account_name = pick_first($r, array('account_name'), pick_first($receipt_head, array('account_name')));
    $account_no   = pick_first($r, array('account_no'),   pick_first($receipt_head, array('account_no')));
    $received_via = trim($account_name);
    if($account_no !== ''){
        $received_via .= ($received_via ? " - " : "") . $account_no;
    }

    if($receipt_type == 'Invoice'){
        $inv_amount = (float) pick_first($info, array('invoice_amount_total'), pick_first($receipt_head, array('invoice_amount_total'), 0));
    } else {
        $inv_amount = (float) pick_first($info, array('quote_amount_total'), pick_first($receipt_head, array('quote_amount_total'), 0));
    }

    $amount_received = (float) pick_first($info, array('receipt_amount_total'), pick_first($receipt_head, array('receipt_amount_total'), 0));
    $receipt_amount  = (float) pick_first($r, array('total_received'), 0);
    $on_account      = (float) pick_first($r, array('on_account', 'amount_on_account'), 0);

    $grand_total_received += $amount_received;

    $html .= "<tr>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='left'><a href='" . h($receipt_link) . "'>" . h($ref) . "</a></td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='center'>" . h($date) . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='left'>" . h($customer) . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='left'>" . h($received_via) . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>" . h($currency) . " " . number_format($inv_amount, 2, '.', ',') . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>" . h($currency) . " " . number_format($amount_received, 2, '.', ',') . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>" . h($currency) . " " . number_format($receipt_amount, 2, '.', ',') . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>" . h($currency) . " " . number_format($on_account, 2, '.', ',') . "</td>
</tr>";

    $doc_label = ($receipt_type == 'Invoice') ? 'Invoice ID' : 'Quote ID';

    $html .= "<tr><td colspan='8' style='padding:0;' bgcolor='{$row_color}'>
<table width='100%' border='0' cellspacing='0' cellpadding='0' style='border-bottom:2px solid #ddd;'>
<tr>
<th style='padding:3px 4px;' bgcolor='{$row_color}'>&nbsp;</th>
<th style='padding:3px 4px;' bgcolor='{$row_color}' align='left'>{$doc_label}</th>
<th style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>Amount</th>
<th style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>Amount Paid</th>
<th style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>Balance</th>
<th style='padding:3px 4px;' bgcolor='{$row_color}'>&nbsp;</th>
</tr>";

    if(count($items)){
        foreach($items as $it){
            if(!is_array($it)){ continue; }

            if($receipt_type == 'Invoice'){
                $inv_date  = pick_first($it, array('invoice_date'));
                $inv_year  = $inv_date ? substr($inv_date, 0, 4) : '';
                $doc_id    = "TI/" . $inv_year . "/" . pick_first($it, array('invoice_id'));
                $doc_amount = (float) pick_first($it, array('invoice_amount'), 0);
            } else {
                $q_date    = pick_first($it, array('quote_date'));
                $q_yy      = $q_date ? substr($q_date, 0, 4) : '';
                $q_mm      = $q_date ? substr($q_date, 5, 2) : '';
                $doc_id    = $q_yy . "-" . $q_mm . "-" . leading_zero(pick_first($it, array('quote_id'), 0), 5);
                $doc_amount = (float) pick_first($it, array('quote_amount'), 0);
            }

            $paid    = (float) pick_first($it, array('item_amount'), 0);
            $balance = (float) pick_first($it, array('balance'), 0);

            $html .= "<tr>
<td style='padding:3px 4px;' bgcolor='{$row_color}'>&nbsp;</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='left'>" . h($doc_id) . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>" . number_format($doc_amount, 2, '.', ',') . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>" . number_format($paid, 2, '.', ',') . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}' align='right'>" . number_format($balance, 2, '.', ',') . "</td>
<td style='padding:3px 4px;' bgcolor='{$row_color}'>&nbsp;</td>
</tr>";
        }
    } else {
        $html .= "<tr>
<td colspan='8' style='padding:3px 4px;' bgcolor='{$row_color}' align='left'><em>No breakdown items</em></td>
</tr>";
    }

    $html .= "</table></td></tr>";

    $row_color = ($row_color === $bg1) ? $bg2 : $bg1;
}

// Total row
$html .= "<tr>
<td colspan='5' style='padding:6px 4px;' align='right'><strong>Total Amount Received:</strong></td>
<td style='padding:6px 4px;' align='right'><strong>" . number_format($grand_total_received, 2, '.', ',') . "</strong></td>
<td colspan='2'>&nbsp;</td>
</tr>";

$html .= "</tbody></table>";

$today = date('d M Y');
$msg_body  = "<p>The following are daily receipt records for {$today}</p><br>";
$msg_body .= $html;
$msg_body .= "<p>--------------</p>";
$msg_body .= "<p>This email was generated by Identity App (http://app.identitytz.com)</p>";

$email_to = array('directors@identitytz.com', 'vijay@identitytz.com');
// $email_to = array('beecraq@gmail.com'); // TEST

$params = array(
    'subject'  => "Identity App: Daily Receipts Report - {$today}",
    'email_to' => $email_to,
    'body'     => $msg_body
);

$sent = send_email($params);

echo $sent ? "Email sent\n" : "Sending failed.\n";