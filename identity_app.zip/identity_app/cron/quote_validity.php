<?php

use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");

$data = array();
// Quotes
$quote_sql = "SELECT q.*,count( jqi.quote_id ) AS quote_items_num,
jos_customers_group.group_company, CONCAT(u.user_fname,' ', u.user_lname) AS user,
ROUND(SUM(jqi.item_quantity_1 * jqi.item_price_1), 2) as item_total_price
FROM jos_quotes q
LEFT JOIN jos_quotes_items jqi ON jqi.quote_id = q.quote_id
LEFT JOIN jos_customers ON jos_customers.customer_id = q.customer_id
LEFT JOIN jos_customers_group ON jos_customers_group.group_id = jos_customers.group_id
LEFT JOIN cms_users as u
ON u.user_id = q.user_id
WHERE DATEDIFF(NOW(), q.quote_date) >= q.quote_validity
AND q.quote_validity != ''
AND q.quote_status = 'Pending' GROUP BY q.quote_id ORDER BY u.user_id, u.user_fname, u.user_lname ASC";


$result = mysql_query($quote_sql);

// Start
 echo "Starting automation for cancelling quotes that are past their validity period.\n";

if(mysql_num_rows($result) > 0) {

  echo "Found quotes past their validity period, cancelling them..\n";

  $quotes_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
  $quotes_html .= "<thead>
                          <tr>
                              <th width='40' style='padding:3px;' bgcolor='#ccc'>ID</th>
                              <th style='padding:3px 4px;' bgcolor='#ccc'>Quote Date</th>
                              <th style='padding:3px 4px;' bgcolor='#ccc'>Company</th>
                              <th style='padding:3px 4px;' bgcolor='#ccc'>No of Items</th>
                              <th style='padding:3px 4px;' bgcolor='#ccc'>Value</th>
                              <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                          </tr>
                      </thead>";
  $quotes_html .= "<tbody>";

  while ($row = mysql_fetch_assoc($result)) {

      $date = date('d M Y', strtotime($row['quote_date']));
      $value = number_format($row['item_total_price'])." ".$row['currency'];

      $quotes_html .= "<tr>
              <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>".$row['quote_id']."</a></td>
              <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$date."</td>
              <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['group_company']."</td>
              <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['quote_items_num']."</td>
              <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$value."</td>
              <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['user']."</a></td>
          </tr>";

  }

  $quotes_html .= "</tbody></table>";

  $cancel_sql = "UPDATE jos_quotes SET quote_status = 'Cancelled' WHERE DATEDIFF(NOW(), quote_date) >= quote_validity
  AND quote_validity != ''
  AND quote_status = 'Pending'";

  mysql_query($cancel_sql);
  echo "All done ".mysql_affected_rows()." records Cancelled.\n\n";

  require("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included


  // Server settings
  $mail->isSMTP();
  $mail->Host = SMTP_HOST;  // Replace with your SMTP server
  $mail->SMTPAuth = true;
  $mail->Username = SMTP_USERNAME; // SMTP username
  $mail->Password = SMTP_PASSWORD; // SMTP password
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587; // Usually 587 for TLS
  $mail->isHTML(true);

  $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
  $mail->Subject = "Identity App: Quotes Cancellation Report";

  $mail->addAddress('hasnain@identitytz.com');
  $mail->addAddress('kazim@identitytz.com');
//  $mail->addAddress('accounts@identitytz.com');
  $mail->addAddress('FC@identitytz.com');
 //  $mail->addAddress('beecraq@gmail.com');

  $msg_body = "<p>The following is a list of Cancelled Quotes:</p><br>".$quotes_html;

  // print_r($msg_body);
  // exit;

$mail->Body = $msg_body;

 if($mail->send()){
    // echo "Email sent";
  }

}
