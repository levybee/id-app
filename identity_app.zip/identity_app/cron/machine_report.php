<?php
use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");


$report_data = array();

$dep_sql = "SELECT department_id, department_name FROM jos_departments";
$dep_data = smartsql($dep_sql);

foreach ($dep_data as $dep) {

  $department_id = $dep['department_id'];

  // Fetch report data for each department_id

  $printers_performance = "SELECT p.printer_id, p.printer_name, si.expected_qty, si.final_qty, d.department_id, d.department_name,
                          IF(p.unit_of_shift = 'Hours' AND si.final_qty > 0, (si.final_qty / p.shift_capacity), 0) as qty_performance,
                           @diff:=ABS( UNIX_TIMESTAMP(si.start_time) - UNIX_TIMESTAMP(si.stop_time) ) ,
                                   CAST(@days := IF(@diff/86400 >= 1, floor(@diff / 86400 ),0) AS SIGNED) as days,
                                   CAST(@hours := IF(@diff/3600 >= 1, floor((@diff:=@diff-@days*86400) / 3600),0) AS SIGNED) as hours,
                                   CAST(@minutes := IF(@diff/60 >= 1, floor((@diff:=@diff-@hours*3600) / 60),0) AS SIGNED) as minutes,
                                           TIMESTAMPDIFF(HOUR, si.start_time, si.stop_time) as total_hours,

                           IF(si.final_qty IS NOT NULL, (TIMESTAMPDIFF(HOUR, si.start_time, si.stop_time) / 8 ), 0) AS hourly_performance
                           FROM `jos_schedule_items` si
                           LEFT JOIN jos_printers p
                           ON p.printer_id = si.printer_id
                           LEFT JOIN jos_schedule js
                            ON js.schedule_id = si.schedule_id
                            LEFT JOIN jos_departments d
                            ON d.department_id = js.department_id

                           WHERE p.department_id = $department_id
                           -- AND (js.schedule_date between  (DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH,'%Y-%m-01')) AND (LAST_DAY(NOW() - INTERVAL 1 MONTH)))
                           AND DATEDIFF(NOW(),js.schedule_date) <= 7
                            ORDER BY p.printer_name ASC";

  $performance_items = smartsql($printers_performance);

  if(is_array($performance_items) && count($performance_items) > 0){

    $total_final_qty = 0;
    $machine_items = [];


    foreach ($performance_items as $key => $value) {

      if(empty($machine_items)){
        $machine_items[] = $performance_items[$key];
      }else{

       // print_r($machine_items);
       $k=false;
       if(isset($value['printer_id'])){
         $k = array_search($value['printer_id'],  array_column($machine_items, 'printer_id'));
       }


        if($k !== false){

          $machine_items[$k]['expected_qty'] += $value['expected_qty'];
          $machine_items[$k]['final_qty'] += $value['final_qty'];

          if($value['qty_performance'] > 0){
            $machine_items[$k]['qty_performance'] += $value['qty_performance'];
          }

          if($value['total_hours'] > 0){
            $machine_items[$k]['total_hours'] += $value['total_hours'];
          }

          if($value['hourly_performance'] > 0){
            $machine_items[$k]['hourly_performance'] += $value['hourly_performance'];
          }

        }else{

          $machine_items[] = $performance_items[$key];

        }

        $total_final_qty += $value['final_qty'];
      }

    }

    $report_data[$department_id]['items'] = $machine_items;
    $report_data[$department_id]['total_final_qty'] = $total_final_qty;

  }

}



$result = false;


if(count($report_data) > 0) {

  echo "Records found..\n\n";

  // Rearrange by department
  $departments_arr = array();


		// Create Email Content
    $sc_html = "";
    foreach ($report_data as $key => $items) {

              $department_name = $items['items'][0]['department_name'];
              $sc_html .= "<br><p><strong>$department_name</strong></p>";
             $sc_html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
             $sc_html .= "<thead>
                                     <tr>
                                        <th style='padding:3px 4px;' bgcolor='#ccc'>Machine</th>
                                        <th style='padding:3px 4px;' bgcolor='#ccc'>Target Qty</th>
                                        <th style='padding:3px 4px;' bgcolor='#ccc'>Final Qty</th>
                                        <th style='padding:3px 4px;' bgcolor='#ccc'>Performance</th>
                                        <th style='padding:3px 4px;' bgcolor='#ccc'>Production Hrs</th>
                                        <th style='padding:3px 4px;' bgcolor='#ccc'>Performance</th>
                                     </tr>
                                 </thead>";
             $sc_html .= "<tbody>";

            $total_final_qty = $items['total_final_qty'];

             foreach ($items['items'] as $item) {

               $qty_performance = ($item['qty_performance'] > 0)? number_format($item['qty_performance'], 2) : "-";
               $hourly_performance = ($item['hourly_performance'] > 0)? number_format($item['hourly_performance'], 2) : "-";

               $sc_html .= "<tr>

                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['printer_name']."</td>
                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['expected_qty']."</td>
                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['final_qty']."</td>
                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$qty_performance</td>
                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['total_hours']."</td>
                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$hourly_performance</td>


                    </tr>";

             }

             $sc_html .= "<tr>
               <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><strong>TOTAL</strong></td><td></td>
               <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'> <strong>$total_final_qty</strong></td>
               <td colspan='3'></td></tr>";

             $sc_html .= "</tbody></table>";


    }

// echo $sc_html;
// exit;

    require("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $day = date('d M Y');
  //  $last_month = date('M Y', strtotime("last day of previous month"));

  //  $subject = "Machine Performance Report - $last_month";
    $subject = "Weekly Machine Performance Report - $day";
    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: $subject";
	// $mail->addAddress('beecraq@gmail.com');
    $mail->addAddress('hasnain@identitytz.com');
    $mail->addAddress('kazim@identitytz.com');
    $mail->addAddress('gm@identitytz.com');
    $mail->addAddress('pm@identitytz.com');
		// $mail->addAddress('accounts@identitytz.com');
		// $mail->addAddress('admin@identitytz.com');
		// $mail->addAddress('sachin@identitytz.com');

		$msg_body = "<h4>$subject</h4>";

		$msg_body .= $sc_html;

		  //echo $msg_body;
		  //exit;

    $mail->Body = $msg_body;

   if($mail->send()){
        echo "Email sent";
    }else{
			echo "something went wrong";
		}


}
