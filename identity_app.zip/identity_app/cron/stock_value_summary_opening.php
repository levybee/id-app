<?php

header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for updating stock value opening summary.\n";

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require($root_dir."configs/variables.php");
require($root_dir."configs/functions.php");


$stock_sql = "SELECT * FROM `jos_stock`";


$result = mysql_query($stock_sql);

if(mysql_num_rows($result) > 0) {

  echo "Found data working on it..\n";
    $sqlData = array();
    while ($row = mysql_fetch_assoc($result)) {

      if($row['unit_price'] > 0){
        $stock_id = $row['stock_id'];
        $value = $row['unit_price'] * $row['stock_qty'];
        $sqlData[] = "('$stock_id','$value')"; 
      }

    }

    $data_chunks = array_chunk($sqlData, 50);
    $no_affected_rows = 0;
    foreach($data_chunks as $data){
      
      $sql_values = implode(',', $data);
      $insert_sql = "INSERT INTO jos_stock_value_summary  (stock_id, opening_value)
          VALUES $sql_values";
      $no_affected_rows = mysql_query($insert_sql);

    }
    
    if($no_affected_rows){
      echo "All done records created.\n\n";
    }else{
      echo "Oh shoot!..read the error.\n\n";
    }
    

}else{
  echo "No records found\n\n";
}
