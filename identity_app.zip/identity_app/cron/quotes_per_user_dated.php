<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// 0 	18 	* 	* 	5 	php -q /home/identity/public_html/app/cron/quotes_per_user.php
header("Content-Type: text/plain");

$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for Sales Report Weekly Notice .\n\n";

$local = false;
$doc_root = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app';
$csvDir = $_SERVER['DOCUMENT_ROOT'] . '/tmp/';

require("$doc_root/configs/variables.php");
require("$doc_root/configs/functions.php");

require("$doc_root/vendor/autoload.php"); // Ensure PHPMailer is included


$th_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$th_html .= "<thead>
                        <tr>
                            <th width='110' style='padding:3px;' bgcolor='#ccc'>ID</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc' align='right'>Quote Value (TZS)</th>
                        </tr>
                    </thead>";
$th_html .= "<tbody>";

$users_sql = "SELECT user_id, user_email, role_id,
CONCAT(user_fname, ' ', user_lname) as user FROM cms_users WHERE user_status = 'Active'";
$users_qry = mysql_query($users_sql);
$approved_quotes_html = "<h2>Approved Quotes</h2>";
$pending_quotes_html = "<br><h2>Pending Quotes</h2>";
$cancelled_quotes_html = "<br><h2>Cancelled Quotes</h2>";
$new_clients_html = "<br><h2>New Clients</h2>";
$dormant_clients_html = "<br><h2>Dormant Clients</h2>";


$exch_rate = 2710;
while ($user_row = mysql_fetch_assoc($users_qry)) {


  $user_approved_html = "";
  $user_pending_html = "";
  $user_cancelled_html = "";

      $user_id = $user_row['user_id'];
      $monthTotal = 0;
      $monthly_target = 0;

      $totalSql = "SELECT  SUM( CASE  WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))
           ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value, u.monthly_sales_target
          FROM `jos_quotes` AS q
          LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
          LEFT JOIN `cms_users` u
             ON u.user_id = q.user_id
          WHERE q.approval_date BETWEEN DATE_FORMAT('2025-04-30','%Y-%m-01') AND '2025-04-30'
          AND q.quote_status = 'Approved'
          AND q.user_id = '$user_id'";

    $monthTotalResult = smartsql($totalSql);
    if($monthTotalResult[0]['quote_value'] > 0){
      $monthTotal = number_format($monthTotalResult[0]['quote_value'], 2);
    }
    $monthly_target = ($monthTotalResult[0]['monthly_sales_target'] > 0)? number_format($monthTotalResult[0]['monthly_sales_target'], 2) : 0;


      $approved_sql = "SELECT q.quote_id, q.quote_date, q.currency, jos_customers_group.group_company,

                          SUM(
                                 CASE
                                      WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))

                                         ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value

                          FROM `jos_quotes` AS q
                          LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
                          LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                          LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                          LEFT JOIN `cms_users` u
                             ON u.user_id = q.user_id
                          WHERE q.quote_status = 'Approved'
                          AND DATEDIFF('2025-05-02',q.approval_date) <= 7
                          AND q.user_id = '$user_id'
                          GROUP BY q.quote_id
                          ORDER BY q.quote_date DESC";

        $approved_result = mysql_query($approved_sql);


        $approved = "";
         if(mysql_num_rows($approved_result) > 0) {


           $total_value = 0;

           $approved_quotes_html .= "<h3>".$user_row['user']."</h3>";
           $approved .= $th_html;
           while ($row = mysql_fetch_assoc($approved_result)) {


               $date = date('d M Y', strtotime($row['quote_date']));
               $ref_yy = substr($row['quote_date'], 0, 4);
               $ref_mm = substr($row['quote_date'], 5, 2);
               $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
               $customer = $row['group_company'];
               $total_value += $row['quote_value'];
               $value = ($row['quote_value'] > 0)? number_format(floatval($row['quote_value']), 2): 0;


               $approved .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='#fcfcfc'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>$ref_no</a></td>
                      <td style='padding:3px 4px;' bgcolor='#fcfcfc'>".$customer."</td>
                      <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='right'>".$value."</td>
                  </tr>";

           }
           $total = number_format($total_value, 2);
           $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>TOTAL</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'>$total</td>
                                     </tr>";


          $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>Month Total</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'>$monthTotal</td>
                                     </tr>";
          $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>Monthly Sales Target</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'>$monthly_target</td>
                                     </tr>";

          $approved .= "</tbody></table>";

           $approved_quotes_html .= $approved;

           $user_approved_html = "<h2>Approved Quotes</h2>".$approved;

         }



         $pending_sql = "SELECT q.quote_id, q.quote_date, q.currency, jos_customers_group.group_company,

                             SUM(
                                    CASE
                                         WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))

                                            ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value
                             FROM `jos_quotes` AS q
                             LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
                             LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                             LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                             LEFT JOIN `cms_users` u
                                ON u.user_id = q.user_id
                             WHERE q.quote_status = 'Pending'
                             AND DATEDIFF('2025-05-02',q.quote_date) <= 7
                             AND q.user_id = '$user_id'
                             GROUP BY q.quote_id
                             ORDER BY q.quote_date DESC";

           $pending_result = mysql_query($pending_sql);

           $pending = "";
           if(mysql_num_rows($pending_result) > 0) {

             $total_value = 0;

             $pending_quotes_html .= "<h3>".$user_row['user']."</h3>";

             $pending .= $th_html;
             while ($row = mysql_fetch_assoc($pending_result)) {

                 $date = date('d M Y', strtotime($row['quote_date']));
                 $ref_yy = substr($row['quote_date'], 0, 4);
                 $ref_mm = substr($row['quote_date'], 5, 2);
                 $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
                 $customer = $row['group_company'];
                 $total_value += $row['quote_value'];
                 $value = number_format(floatval($row['quote_value']), 2);


                 $pending .= "<tr>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>$ref_no</a></td>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc'>".$customer."</td>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='right'>".$value."</td>
                    </tr>";

             }
             $total = number_format(floatval($total_value), 2);
             $pending .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>TOTAL</strong></td>
                                           <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'>$total</td>
                                       </tr>";
             $pending .= "</tbody></table>";

             $pending_quotes_html .= $pending;
             $user_pending_html = "<br><h2>Pending Quotes</h2>".$pending;


           }


           $cancelled_sql = "SELECT q.quote_id, q.quote_date, q.currency, jos_customers_group.group_company,

                             SUM(
                                    CASE
                                         WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))

                                            ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value
                             FROM `jos_quotes` AS q
                             LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
                             LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                             LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                             LEFT JOIN `cms_users` u
                                ON u.user_id = q.user_id
                             WHERE q.quote_status = 'Cancelled'
                             AND DATEDIFF('2025-05-02',q.quote_date) <= 7
                             AND q.user_id = '$user_id'
                             GROUP BY q.quote_id
                             ORDER BY q.quote_date DESC";

           $cancelled_result = mysql_query($cancelled_sql);

           $cancelled = "";
           if(mysql_num_rows($cancelled_result) > 0) {



             $total_value = 0;

             $cancelled_quotes_html .= "<h3>".$user_row['user']."</h3>";
             $cancelled .= $th_html;
             while ($row = mysql_fetch_assoc($cancelled_result)) {

                 $date = date('d M Y', strtotime($row['quote_date']));
                 $ref_yy = substr($row['quote_date'], 0, 4);
                 $ref_mm = substr($row['quote_date'], 5, 2);
                 $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
                 $customer = $row['group_company'];
                 $total_value += $row['quote_value'];
                 $value = number_format(floatval($row['quote_value']), 2);


                 $cancelled .= "<tr>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>$ref_no</a></td>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc'>".$customer."</td>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='right'>".$value."</td>
                    </tr>";

             }
             $total = number_format(floatval($total_value), 2);
             $cancelled .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>TOTAL</strong></td>
                                           <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'>$total</td>
                                       </tr>";
             $cancelled .= "</tbody></table>";

             $cancelled_quotes_html .= $cancelled;
             $user_cancelled_html = "<br><h2>Cancelled Quotes</h2>".$cancelled;
           }

          $mail = new PHPMailer(true);

          // Server settings
          $mail->isSMTP();
          $mail->Host = SMTP_HOST;  // Replace with your SMTP server
          $mail->SMTPAuth = true;
          $mail->Username = SMTP_USERNAME; // SMTP username
          $mail->Password = SMTP_PASSWORD; // SMTP password
          $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
          $mail->Port = 587; // Usually 587 for TLS
          $mail->isHTML(true);

          $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
          $mail->Subject = 'Identity App: Sales Report Weekly Notice';



       //   $mail->addAddress('beecraq@gmail.com');
          $msg_body = "<p>The following is a list of your Sales Report for the Week</p><br>";
          $msg_body .= $user_approved_html.$user_pending_html.$user_cancelled_html;


         echo "Checking if user ({$user_row['user']}) is in sales \n";
         $mail->Body = $msg_body;

            $uk = array_search($user_row['role_id'], [5,20,28]);
           if(is_numeric($uk) && isset($user_row['user_email']) && trim($user_row['user_email']) != ''){

            //   if($user_row['user_id'] == 19){
            //       $mail->addAddress('beecraq@gmail.com');
            //       $mail->send();
            //       exit;
            //   }
               $mail->addAddress(trim($user_row['user_email']));
              if($mail->send()){
                echo "Email sent to {$user_row['user_email']} \n";
              }

           }else{
             echo "User does not have email set up or is not sales \n";
           }





}


$th_html2 = "<table width='60%' border='0' cellspacing='0' cellpadding='0'>";
$th_html2 .= "<thead>
                        <tr>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                        </tr>
                    </thead>";
$th_html2 .= "<tbody>";


$dormant_clients_sql = "SELECT CONCAT(u.user_fname, ' ', u.user_lname) as user, jos_customers_group.group_company,
(SELECT DATEDIFF('2025-05-02', quote_date) FROM jos_quotes WHERE customer_id IN (GROUP_CONCAT(DISTINCT(jos_customers.customer_id)))
AND DATE(quote_date) <= ('2025-05-02' - INTERVAL 8 DAY) ORDER BY quote_date DESC LIMIT 1) as days

                          FROM `jos_quotes` AS q
                          LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
                          LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                          LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                          LEFT JOIN `cms_users` u
                             ON u.user_id = q.user_id
                          WHERE q.customer_id IN (
                            SELECT c.customer_id
                          FROM `jos_customers` AS c
                          LEFT OUTER JOIN jos_quotes q
                          ON q.customer_id = c.customer_id
                          AND DATE(q.quote_date) >= ('2025-05-02' - INTERVAL 12 MONTH) AND DATE(q.quote_date) <= ('2025-05-02' - INTERVAL 8 DAY)
                          WHERE q.customer_id IS NULL
                            ) AND DATEDIFF('2025-05-02',DATE(q.quote_date)) <= 7 AND  u.user_id IS NOT NULL
                          GROUP BY jos_customers_group.group_id
                          ORDER BY u.user_fname, u.user_lname ASC";

        $dormant_clients_result = smartsql($dormant_clients_sql);

$new_clients_sql = "SELECT CONCAT(u.user_fname, ' ', u.user_lname) as user, jos_customers_group.group_company
FROM `jos_quotes` AS q
LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
LEFT JOIN `cms_users` u
   ON u.user_id = q.user_id
WHERE DATEDIFF('2025-05-02',jos_customers_group.date_created) <= 7
GROUP BY jos_customers_group.group_id
ORDER BY u.user_fname, u.user_lname ASC";

$new_clients_result = mysql_query($new_clients_sql);


if(mysql_num_rows($new_clients_result) > 0) {

$total_value = 0;

//$new_clients_html .= "<h3>".$user_row['user']."</h3>";
$new_clients_html .= $th_html2;
while ($row = mysql_fetch_assoc($new_clients_result)) {

$key  = array_search($row['group_company'], array_column($dormant_clients_result, 'group_company'));
if(is_numeric($key)){
  continue;
}

// $date = date('d M Y', strtotime($row['quote_date']));
// $ref_yy = substr($row['quote_date'], 0, 4);
// $ref_mm = substr($row['quote_date'], 5, 2);
// $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
// $customer = $row['group_company'];
// $total_value += $row['quote_value'];
// $value = number_format(floatval($row['quote_value']), 2);
$customer = $row['group_company'];
$user = $row['user'];


$new_clients_html .= "<tr>
<td style='padding:3px 4px;' bgcolor='#fcfcfc'>".$customer."</td>
<td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$user."</td>
</tr>";

}
// $total = number_format($total_value, 2);
// $new_clients_html .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>TOTAL</strong></td>
//                <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>$total</td>
//            </tr>";
$new_clients_html .= "</tbody></table>";


}else{
  $new_clients_html .= "No records found\n";
}






        $th_html3 = "<table width='60%' border='0' cellspacing='0' cellpadding='0'>";
$th_html3 .= "<thead>
                        <tr>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Dormant For</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                        </tr>
                    </thead>";
$th_html3 .= "<tbody>";


         if(is_array($dormant_clients_result) && count($dormant_clients_result) > 0) {

           $total_value = 0;

          // $dormant_clients_html .= "<h3>".$user_row['user']."</h3>";
           $dormant_clients_html .= $th_html3;
           foreach ($dormant_clients_result as $row) {


              //  $date = date('d M Y', strtotime($row['quote_date']));
              //  $ref_yy = substr($row['quote_date'], 0, 4);
              //  $ref_mm = substr($row['quote_date'], 5, 2);
              //  $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
              //  $customer = $row['group_company'];
              //  $total_value += $row['quote_value'];
              //  $value = number_format(floatval($row['quote_value']), 2);
              $customer = $row['group_company'];
              $user = $row['user'];
              $days = ($row['days'] > 0)? $row['days'].' Days' : '-';


               $dormant_clients_html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='#fcfcfc'>".$customer."</td>
                      <td style='padding:3px 4px;' bgcolor='#fcfcfc'>".$days."</td>
                      <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$user."</td>
                  </tr>";

           }
           $total = number_format($total_value, 2);
           $dormant_clients_html .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>TOTAL</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>$total</td>
                                     </tr>";
           $dormant_clients_html .= "</tbody></table>";


         }else{
  $dormant_clients_html .= "No records found\n";
}


  //echo $msg_body;
  $msg_body = "<p>The following is a list of Approved/Pending Quotes per user for the week:</p><br>";
  $msg_body .= $approved_quotes_html.$pending_quotes_html.$new_clients_html.$dormant_clients_html;

// Visit Plan
$vp_list_sql = "SELECT
    vp.*,	IF(vp.group_id > 0, g.group_company, vp.client_name) as client,
    CONCAT( u.user_fname, ' ', u.user_lname) as username
    FROM  jos_sales_visitplan vp
    LEFT JOIN jos_customers_group g
    ON g.group_id = vp.group_id
LEFT JOIN cms_users u ON u.user_id = vp.user_id
WHERE DATEDIFF('2025-05-02',DATE(vp.date_created)) <= 7
ORDER BY u.user_fname, vp.date_created ASC";

$vp_list = smartsql($vp_list_sql);
$csvFiles = [];
if(isset($vp_list[0]['vp_id'])){

  // Group by users
  $vpListUsers = [];
  foreach ($vp_list as $key => $value) {
    $vpListUsers[$value['user_id']][] = $value;
  }

  // Group by date
  $vpListDates = [];
  foreach ($vpListUsers as $user_id => $arr) {
    foreach ($arr as $key => $value) {
      $date = date('Y-m-d', strtotime($value['date_created']));
      $vpListDates[$user_id][$date][] = [
        'date' => date('d/m/Y', strtotime($date)),
        'client' => $value['client'],
        'location' => $value['visit_location'],
        'contact' => $value['contact_person'],
        'remarks' => $value['remarks'],
        'fare' => $value['fare_amount'],
        'username' => $value['username']
      ];
    }
  }



  // Create CSVs
  foreach ($vpListDates as $userId => $userRecords) {
    foreach ($userRecords as $date => $records) {
        $username = trim(str_replace(' ', '', $records[0]['username']));
        $fileName = "$username-visit-plan.csv";
        $filePath = $csvDir.$fileName;
        $csvFiles[] = $filePath;

        // Generate CSV file
        generateCsvFile($userRecords, $filePath, $username);

      }
    }

}




    //echo $quotes_html;
    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = 'Identity App: Sales Report Weekly Notice';
    $mail->addAddress('hasnain@identitytz.com');
     $mail->addAddress('kazim@identitytz.com');
   //  $mail->addAddress('floor@identitytz.com');
    //  $mail->addAddress('hr@identitytz.com');
    // $mail->addAddress('andrew@identitytz.com');
    // $mail->addAddress('rakesh@identitytz.com');

    // $mail->addAddress('beecraq@gmail.com');


    $mail->Body = $msg_body;

    if(count($csvFiles) > 0){
      foreach ($csvFiles as $path) {
        $mail->addAttachment($path);
      }
    }


    if($mail->send()){
        echo "Overall Email sent\n";
    }

    foreach ($csvFiles as $path) {
      unlink($path);
    }


function generateCsvFile($data, $filePath, $username)
{
    $file = fopen($filePath, 'w');

    // Add CSV header
    fputcsv($file, [$username]);
    fputcsv($file, ['']);
    fputcsv($file, ['Date', 'Client Name', 'Location', 'Contact Person', 'Remarks', 'Fare']);

    // Add rows to CSV file
    foreach ($data as $date => $records) {
        $totalFare = 0;
        foreach ($records as $record) {
            array_pop($record); // delete username
            fputcsv($file, $record);
            if($record['fare'] > 0){
              $totalFare += $record['fare'];
            }
        }
        fputcsv($file, ['', '', '', '', '', $totalFare]);
        fputcsv($file, ['']);
    }

    fclose($file);
}
