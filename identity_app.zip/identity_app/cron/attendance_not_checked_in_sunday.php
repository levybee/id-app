<?php

/* Autometed email that sends list of employees not checked in after 08:30am
*/

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");
require(__DIR__."/../modules/attendance_schedule/functions.php");

$ATTACHMENTS_DIR = $_SERVER['DOCUMENT_ROOT'] . '/tmp/';

$date = date('Y-m-d');
$shift_id = 1;
$order = 'je.first_name, je.last_name ASC';
$params['schedule_date']= $date;
$params['shift_id']=$shift_id;
$params['order'] = $order;
$params['employee_status'] = 'Active';
$params['status'] = array('Absent','On Leave', 'Sick Leave');

$schedule_data = fetch_schedule($params);

$cronDate = date('Y-m-d H:i:s');
$rows = is_array($schedule_data) ? count($schedule_data) : 0;
echo "[Run Date $cronDate] $rows Records found..\n\n";


$report_array = array();
$schedule_dataIPL1 = [];
$schedule_dataIPL2 = [];

if(count($schedule_data) > 0) {

          foreach ($schedule_data as $key => $row) {
            if($row['employee_location']  == 'IPL1'){
              $schedule_dataIPL1[] = $row;
            }
            if($row['employee_location']  == 'IPL2'){
              $schedule_dataIPL2[] = $row;
            }
          }


            $count=0;

            $htmlIPL1 = '<h3>IPL 1</h3>';
            $htmlIPL2 = '<h3>IPL 2</h3>';

            $html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
            $html .= "<thead>
                                <tr>
                                <th width='50' style='padding:3px;' bgcolor='#ccc'>#</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>EMPLOYEE NAME</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>TYPE</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>DEPARTMENT</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>STATUS</th>
                                </tr>
                     </thead>";
            $html .= "<tbody>";

           $bg_color1 = '#fcfcfc';
           $bg_color2 = '#e5e5e5';
           $row_color = $bg_color1;


           $htmlBodyIPL1 = '';
           $htmlBodyIPL2 = '';
           foreach($schedule_dataIPL1 as $k => $row){

               $count++;

               $htmlBodyIPL1 .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$count</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['employee_name']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['type']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['department_name']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['status']}</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }

           foreach($schedule_dataIPL2 as $k => $row){

               $count++;

               $htmlBodyIPL2 .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$count</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['employee_name']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['type']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['department_name']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['status']}</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }

           $htmlIPL1 .= $html.$htmlBodyIPL1;
           $htmlIPL1 .= "</tbody></table>";

           $htmlIPL2 .= "<br/>".$html.$htmlBodyIPL2;
           $htmlIPL2 .= "</tbody></table>";




         $today = date('d M Y');
         $msg_body = "<p>The following is a report of employees that have not checked in (Absent) $today - Day</p><br>";
         $msg_body .= $htmlIPL1.$htmlIPL2;

    require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included
    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Employees Not Checked In (Absent - Sunday - Day Shift)";

    $mail->addAddress('hasnain@identitytz.com');
 //   $mail->addAddress('gm@identitytz.com');
    $mail->addAddress('hr@identitytz.com');
    $mail->addAddress('kazim@identitytz.com');
    $mail->addAddress('hr3@identitytz.com');
    // $mail->addAddress('FC@identitytz.com');
    // $mail->addAddress('pm@identitytz.com');
    // $mail->addAddress('beecraq@gmail.com');


    $mail->Body = $msg_body;

    if($mail->send()){
        echo "Email sent";
    } else {
        echo "Sending failed.";
    }

}
