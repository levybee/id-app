<?php

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

require("/home/identity/public_html/app/configs/variables.php");

$employee_sql = "SELECT t.employee_id,
       t.name,
       t.position,
       t.department_name,
       MIN(t.contract_start_date) AS contract_start_date,
       MIN(t.contract_end_date) AS contract_end_date,
       GROUP_CONCAT(DISTINCT t.source) AS sources,
       GROUP_CONCAT(DISTINCT t.contract_id) AS contract_ids,
       GROUP_CONCAT(DISTINCT t.contract_status) AS contract_statuses
FROM (
  SELECT e.id AS employee_id, CONCAT(e.first_name,' ',e.last_name) AS name, e.position,
         d.department_name, e.contract_date_start AS contract_start_date, e.contract_date_end AS contract_end_date, 'employee_record' AS source,
         NULL AS contract_id, NULL AS contract_status
  FROM jos_employees e
  LEFT JOIN jos_departments d ON d.department_id = e.department
  WHERE e.status = 'Active'
    AND e.contract_date_end IS NOT NULL
    AND MONTH(e.contract_date_end) = MONTH(CURDATE())
    AND YEAR(e.contract_date_end) = YEAR(CURDATE())

  UNION ALL

  SELECT c.employee_id AS employee_id, CONCAT(co.first_name,' ',co.last_name) AS name, co.position,
         d.department_name, c.contract_start_date, c.contract_end_date, 'contract' AS source,
         c.id AS contract_id, c.contract_status
  FROM jos_contracts c
  JOIN jos_employees co ON co.id = c.employee_id
  LEFT JOIN jos_departments d ON d.department_id = co.department
  WHERE c.contract_end_date IS NOT NULL
    AND MONTH(c.contract_end_date) = MONTH(CURDATE())
    AND YEAR(c.contract_end_date) = YEAR(CURDATE()) 
    AND c.contract_status IN ('Approved','Issued','Closed','Expired')
    AND co.status = 'Active'
) t
GROUP BY t.employee_id
ORDER BY name ASC;";


$result = mysql_query($employee_sql);
$rows = (mysql_num_rows($result) > 0) ? mysql_num_rows($result) : 0;
$cronDate = date('Y-m-d H:i:s');
echo "[Run Date $cronDate] $rows Records found..\n\n";

if(mysql_num_rows($result) > 0) {

    //var_dump($result);

    $employees_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $employees_html .= "<thead>
                            <tr>
                            <th width='40' style='padding:3px;' bgcolor='#ccc'>ID</th>
                            <th style='padding:3px 4px;' bgcolor='#ccc'>Name</th> 
                            <th style='padding:3px 4px;' bgcolor='#ccc'>Position</th>
                            <th style='padding:3px 4px;' bgcolor='#ccc'>Department</th>
                            <th style='padding:3px 4px;' bgcolor='#ccc'>Contract Start Date</th>
                            <th style='padding:3px 4px;' bgcolor='#ccc'>Contract End Date</th>
                            </tr>
                        </thead>";
    $employees_html .= "<tbody>";


    while ($row = mysql_fetch_assoc($result)) {

        $start_date = date('d M Y', strtotime($row['contract_start_date']));
        $end_date = date('d M Y', strtotime($row['contract_end_date']));

        $employees_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['employee_id']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc'>{$row['name']}</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['position']."</td>
                <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['department_name']."</td>
                <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$start_date</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$end_date</td>
						</tr>";

    }

    $employees_html .= "</tbody></table>";


    require("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included

  	$mail = new PHPMailer(true);

  	// Server settings
  	$mail->isSMTP();
  	$mail->Host = SMTP_HOST;  // Replace with your SMTP server
  	$mail->SMTPAuth = true;
  	$mail->Username = SMTP_USERNAME; // SMTP username
  	$mail->Password = SMTP_PASSWORD; // SMTP password
  	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  	$mail->Port = 587; // Usually 587 for TLS
  	$mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Employees Contract Expiry Notice";

    $mail->addAddress('hasnain@identitytz.com');
    $mail->addAddress('kazim@identitytz.com');
    $mail->addAddress('hr@identitytz.com');
    $mail->addAddress('hr4@identitytz.com');
    // $mail->addAddress('beecraq@gmail.com');

    $msg_body = "<p>The following employees' contracts expire this month:</p><br>".$employees_html;

    $mail->Body = $msg_body;


    if($mail->send()){
         echo "Email sent";
    }

}
