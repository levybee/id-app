<?php



  $no_days = 50;

  require("/home/identity/public_html/app/configs/variables.php");

  $jobs_sql = 'SELECT j.group_id, j.job_id, j.job_date, j.job_time, j.job_due_date, j.job_due_time, j.job_status,
               j.job_reference, j.job_product, j.job_paper_quantity, j.job_color, j.job_color_other, j.job_invoice_no,
  						 jos_customers_group.group_company, cms_users.user_fname, cms_users.user_lname, cms_users.user_email,
  						 jos_customers.customer_fname, jos_customers.customer_lname, jos_customers.customer_email,
               DATEDIFF(NOW(), j.job_date) as no_days, jos_departments.department_name, jos_products.product_name
  					FROM `jos_jobs` as j

  				    LEFT JOIN `jos_jobs_groups` as g
  					   ON g.group_id = j.group_id

  					LEFT JOIN `jos_customers`
  					   ON jos_customers.customer_id = g.customer_id

  					LEFT JOIN `jos_customers_group`
  					   ON jos_customers_group.group_id = jos_customers.group_id

  					LEFT JOIN `jos_departments`
  					   ON jos_departments.department_id = j.department_id

  					LEFT JOIN `jos_products`
  					   ON jos_products.product_ref = j.job_product
                      LEFT JOIN `cms_users`
  					   ON cms_users.user_id = j.user_id

  					WHERE j.job_status NOT LIKE "%Complete%" AND j.job_status != "Cancelled"
                      ORDER BY j.job_date DESC;';



  $result = mysql_query($jobs_sql);


  if(mysql_num_rows($result) > 0) {

      //var_dump($result);

      echo "--- Looping through jobs, this may take a while \n\n";
      while ($row = mysql_fetch_assoc($result)) {

          if((int) $row['no_days'] > $no_days){

            $job_id = $row['job_id'];
            $user_name = $row['user_fname'].' '.$row['user_lname'];
            $user_email = $row['user_email'];
            $days = $row['no_days'];
            $status = $row['job_status'];

            echo "--- Found job that exceeds $no_days ID[$job_id] User[$user_name] days[$days] status [$status] \n";
            echo "--- Setting up email content.. \n\n";

          }


      }

      exit;

      //echo $jobs_html;

      $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';


      require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');


      $postmark = new Postmark\Mail($postmarkApiKey);
      $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
      $postmark->subject('Identity App: Jobs Approval Notice');
      // $postmark->addTo('hasnain@identitytz.com');
      // $postmark->addTo('kazim@identitytz.com');

      $msg_body = "<p>The following jobs orders require approval:</p><br>".$jobs_html;

      $postmark->messageHTML($msg_body);

      if($postmark->send()){
         // echo "Email sent";
      }


  }
