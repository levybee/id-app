<?php

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation report for Stationary FG.\n";

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require($root_dir."configs/variables.php");
require($root_dir."configs/functions.php");
require($root_dir."vendor/autoload.php"); // PHPMailer


$today = date('d M Y');

$stock_sql = "SELECT * FROM jos_stock
                            WHERE category = 'Stationary FG'
                            ORDER BY stock_name ASC";

$result_stock = mysql_query($stock_sql);

if(mysql_num_rows($result_stock) > 0) {

	// print_r($stocks);
	// exit;

	// Create HTML email content
	$stock_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$stock_html .= "<thead>
                      <tr>
                            <th width='100' bgcolor='#ccc'>Stock ID</th>
               					    <th  bgcolor='#ccc'>Stock Name</th>
               					    <th  bgcolor='#ccc'>Category</th>
               					    <th  bgcolor='#ccc'>Quantity</th>
                         </tr>
											</thead>";
	$stock_html .= "<tbody>";

  $bg_color1 = '#fcfcfc';
  $bg_color2 = '#e5e5e5';
  $row_color = $bg_color1;

  while ($row = mysql_fetch_assoc($result_stock)) {

      $stock_qty = number_format($row['stock_qty'], 2);
      $stock_html .= "<tr>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['stock_id']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color'>{$row['stock_name']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['category']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$stock_qty</td>
           </tr>";

       if($row_color == $bg_color1){
         $row_color = $bg_color2;
       }elseif($row_color == $bg_color2){
         $row_color = $bg_color1;
       }
  }

  $stock_html .= "</tbody></table>";

  $mail = new PHPMailer(true);

  // Server settings
  $mail->isSMTP();
  $mail->Host = SMTP_HOST;  // Replace with your SMTP server
  $mail->SMTPAuth = true;
  $mail->Username = SMTP_USERNAME; // SMTP username
  $mail->Password = SMTP_PASSWORD; // SMTP password
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587; // Usually 587 for TLS
  $mail->isHTML(true);

   $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
   $mail->Subject = "Identity App: Stationary FG Stock Report for $today";

   $mail->addAddress('hasnain@identitytz.com');
   $mail->addAddress('kazim@identitytz.com');
   $mail->addAddress('stationary@identitytz.com');
   $mail->addAddress('magna@identitytz.com');
   $mail->addAddress('stores@identitytz.com');
   $mail->addAddress('vijay@identitytz.com');
   $mail->addAddress('ganesh@identitytz.com');
   
  // $mail->addAddress('beecraq@gmail.com');

  $msg_body = "<p>The following report of Stationary FG Stock records for today $today:</p><br>".$stock_html;

  // print_r($msg_body);
  // exit;

  $mail->Body = $msg_body;

 if($mail->send()){
     echo "Email sent";
  }
  
  @mysql_close();

}
