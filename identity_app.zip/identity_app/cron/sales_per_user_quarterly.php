<?php

use PHPMailer\PHPMailer\PHPMailer;

// 15 	0 	1 	*/3 	* php -q /home/identity/public_html/app/cron/sales_per_user_quarterly.php  - runs every fourth month picking each of the last 3 months
header("Content-Type: text/plain");

$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for Sales Report Quarterly.\n\n";

$local = false;
$doc_root = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app';

require("$doc_root/configs/variables.php");
require("$doc_root/configs/functions.php");

require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

$m1 = date("F Y", strtotime("-3 Months"));
$m2 = date("F Y", strtotime("-2 Months"));
$m3 = date("F Y", strtotime("-1 Months"));

$mon1 = date("F", strtotime("-3 Months"));
$mon2 = date("F", strtotime("-2 Months"));
$mon3 = date("F", strtotime("-1 Months"));
$months = "$mon1,$mon2,$mon3";

$th_html = "<table width='70%' border='0' cellspacing='0' cellpadding='0'>";
$th_html .= "<thead>
                        <tr>
                            <th width='110'  style='padding:3px;' bgcolor='#ccc'></th>
					    <th align='right' style='padding:3px 4px;' bgcolor='#ccc'>$m1</th>
					    <th align='right' style='padding:3px 4px;' bgcolor='#ccc'>$m2</th>
              <th align='right' style='padding:3px 4px;' bgcolor='#ccc'>$m3</th>
                        </tr>
                    </thead>";
$th_html .= "<tbody>";

$users_sql = "SELECT user_id, user_email, role_id,
CONCAT(user_fname, ' ', user_lname) as user FROM cms_users WHERE user_status = 'Active'
AND role_id IN (5,20,28) AND exclude_sales_reports = 0";
$users_qry = mysql_query($users_sql);

$reportHtml = "";
$dateSum = date("F Y", strtotime("first day of previous month"));
$exch_rate = 2710;
while ($user_row = mysql_fetch_assoc($users_qry)) {


  $user_approved_html = "";
  $user_issued_html = "";


      $user_id = $user_row['user_id'];


      $monthly_target = 0;

      $monthTotal = 0;
      $percentage = 0;
      $monthTotal2 = 0;
      $percentage2 = 0;
      $monthTotal3 = 0;
      $percentage3 = 0;

      $totalSql = "SELECT  SUM( CASE  WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))
           ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value, u.monthly_sales_target
          FROM `jos_quotes` AS q
          LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
          LEFT JOIN `cms_users` u
             ON u.user_id = q.user_id
          WHERE q.approval_date BETWEEN (DATE_FORMAT(CURDATE() - INTERVAL 3 MONTH,'%Y-%m-01'))
          AND (LAST_DAY(NOW() - INTERVAL 3 MONTH))
          AND q.user_id = '$user_id'";

    $monthTotalResult = smartsql($totalSql);
    if($monthTotalResult[0]['quote_value'] > 0){
      $monthTotal = number_format($monthTotalResult[0]['quote_value'], 2);
    }

     if($monthTotalResult[0]['monthly_sales_target'] > 0){
      $percentage = round(($monthTotalResult[0]['quote_value']/$monthTotalResult[0]['monthly_sales_target']) * 100, 2)."%";
      $monthly_target = number_format($monthTotalResult[0]['monthly_sales_target'], 2);
    }else{
      $percentage = "-";
    }

     $totalSql2 = "SELECT  SUM( CASE  WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))
          ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value, u.monthly_sales_target
         FROM `jos_quotes` AS q
         LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
         LEFT JOIN `cms_users` u
            ON u.user_id = q.user_id
         WHERE q.approval_date BETWEEN (DATE_FORMAT(CURDATE() - INTERVAL 2 MONTH,'%Y-%m-01'))
         AND (LAST_DAY(NOW() - INTERVAL 2 MONTH))
         AND q.user_id = '$user_id'";

   $monthTotalResult2 = smartsql($totalSql2);
   if($monthTotalResult2[0]['quote_value'] > 0){
     $monthTotal2 = number_format($monthTotalResult2[0]['quote_value'], 2);
   }

    if($monthTotalResult[0]['monthly_sales_target'] > 0){
     $percentage2 = round(($monthTotalResult2[0]['quote_value']/$monthTotalResult[0]['monthly_sales_target']) * 100, 2)."%";
   }else{
     $percentage2 = "-";
   }


    $totalSql3 = "SELECT  SUM( CASE  WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))
         ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value, u.monthly_sales_target
        FROM `jos_quotes` AS q
        LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
        LEFT JOIN `cms_users` u
           ON u.user_id = q.user_id
        WHERE q.approval_date BETWEEN (DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH,'%Y-%m-01'))
        AND (LAST_DAY(NOW() - INTERVAL 1 MONTH))
        AND q.user_id = '$user_id'";

  $monthTotalResult3 = smartsql($totalSql3);
  if($monthTotalResult3[0]['quote_value'] > 0){
    $monthTotal3 = number_format($monthTotalResult3[0]['quote_value'], 2);
  }

   if($monthTotalResult[0]['monthly_sales_target'] > 0){
    $percentage3 = round(($monthTotalResult3[0]['quote_value']/$monthTotalResult[0]['monthly_sales_target']) * 100, 2)."%";
   }else{
     $percentage3 = "-";
   }

             $quarter = "";
              //  $approved_quotes_html .= "<h3>".$user_row['user']."</h3>";
                $reportHtml .= "<h4>{$user_row['user']}</h4>";

                $quarter .= $th_html;
                $quarter .= "<tr>
                                <td style='padding:3px 4px;' bgcolor='#fcfcfc'>Month Sales Total</td>
                                <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$monthTotal</td>
                                <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$monthTotal2</td>
                                <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$monthTotal3</td>
                            </tr>";

                $quarter .= "<tr>
                                <td style='padding:3px 4px;' bgcolor='#fcfcfc'>Month Target</td>
                                <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$monthly_target</td>
                                <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$monthly_target</td>
                                <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$monthly_target</td>
                            </tr>";

            $quarter .= "<tr>
                            <td style='padding:3px 4px;' bgcolor='#fcfcfc'>Target Achieved</td>
                            <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$percentage</td>
                            <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$percentage2</td>
                            <td style='padding:3px 4px; bgcolor='#fcfcfc' align='right'>$percentage3</td>
                        </tr>";

               $quarter .= "</tbody></table>";

                $reportHtml .= $quarter;


}

  //echo $msg_body;
  $msg_body = "<p>The following is a Sales Quarter Annual Report per user for the Months of $months:</p>";
  $msg_body .= $reportHtml;


    //echo $quotes_html;

    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Sales Quarter Annual Report - $months";

     $mail->addAddress('hasnain@identitytz.com');
      $mail->addAddress('kazim@identitytz.com');
    //  $mail->addAddress('hr@identitytz.com');
    // $mail->addAddress('andrew@identitytz.com');
    // $mail->addAddress('rakesh@identitytz.com');

    // $mail->addAddress('beecraq@gmail.com');

    // echo $msg_body;
    // exit;

    $mail->Body = $msg_body;

    if($mail->send()){
        echo "Overall Email sent\n";
    }
