<?php

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

$local = false;
$cron = true;

if($local){
	$doc_root = $_SERVER['DOCUMENT_ROOT'];
}else{
	$doc_root = '/home/identity/public_html/app';
}

require("$doc_root/configs/variables.php");
require("$doc_root/configs/functions.php");
require ("$doc_root/modules/configurations.php");

$grn_items = array();
$grns = array();
$today = date('d M Y');
// $today = date('d M Y', strtotime('2026-06-23'));

$grn_sql = "SELECT grn.*,SUM(IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) * gi.grn_item_qty) as grn_value, CONCAT(u.user_fname,' ', u.user_lname) AS user,
            SUM(IF(lpo.lpo_tax = 'Taxable', (IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) * gi.grn_item_qty) * 0.18, 0)) as tax,
           lpo.lpo_supplier, s.supplier_id, s.supplier_fname, s.supplier_lname, s.supplier_company,dp.department_name,
					 lpo.lpo_currency
				FROM jos_grn grn
				LEFT JOIN jos_grn_items as gi
					 ON grn.grn_id = gi.grn_id
					 LEFT JOIN jos_lpo_items as li
							ON li.item_id = gi.lpo_item_id
			  LEFT JOIN jos_lpo as lpo
					 ON lpo.lpo_id = grn.lpo_id

			  LEFT JOIN jos_jobs j
                 ON j.job_id = lpo.job_id
              LEFT JOIN jos_departments dp
                 ON dp.department_id = j.department_id

                 LEFT JOIN cms_users as u
                   ON u.user_id = grn.user_id

				LEFT JOIN jos_suppliers as s
					 ON s.supplier_id = lpo.supplier_id
				WHERE grn_date = CURDATE() AND status != 'Cancelled' GROUP BY grn.grn_id";


$result_grn = mysql_query($grn_sql);

$cronDate = date('Y-m-d H:i:s');
$rows = mysql_num_rows($result_grn);
echo "[Run Date $cronDate] $rows Records found..\n\n";

if(mysql_num_rows($result_grn) > 0) {

  $attachments = [];
  $total_grn = 0;
  $total_tax = 0;
	while ($row = mysql_fetch_array($result_grn)) {

		if($row['status'] == 'Closed' && $row['attachment_path']){
			if(array_search($row['attachment_path'], $attachments) === false){
				$attachments[] =  $row['attachment_path'];
			}
		}

	   $grns[] = $row;
       $total_grn += $row['grn_value'];
       $total_tax += $row['tax'];
	}


	$grn_items_sql = "SELECT gi.*, grn.*, js.units, IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) as item_unit_price, gi.grn_item_qty, li.item_qty_per_pack,
														li.item_description, li.item_general_notes
													FROM jos_grn_items as gi
													LEFT JOIN jos_grn as grn
													  ON grn.grn_id = gi.grn_id
													LEFT JOIN jos_lpo_items as li
														 ON li.item_id = gi.lpo_item_id
														 LEFT JOIN jos_lpo as lpo
																ON lpo.lpo_id = li.lpo_id

													LEFT JOIN jos_stock as js
														 ON js.stock_id = li.stock_id

													WHERE grn.grn_date = CURDATE()";

	$result_items = mysql_query($grn_items_sql);
	while ($row = mysql_fetch_array($result_items)) {
	   $grn_items[] = $row;
	}


	// Create List of GRN with items
	foreach ($grns as $key => $value) {

		$grns[$key]['items'] = search_key_value($grn_items, 'grn_id', $value['grn_id']);

	}

	// print_r($grns);
	// exit;

	// Create HTML email content
	$grn_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$grn_html .= "<thead>
													<tr>
															<th width='10%' style='padding:3px;' bgcolor='#ccc'>ID</th>
															<th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Invoice No</th>
															<th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>LPO ID</th>
															<th width='35%' style='padding:3px 4px;' bgcolor='#ccc'>Supplier</th>
															<th width='15%' style='padding:3px 4px;' bgcolor='#ccc'>Issued By</th>
															<th width='20%' style='padding:3px 4px;' bgcolor='#ccc'>GRN Value</th>
													</tr>
											</thead>";
	$grn_html .= "<tbody>";

  if(count($grns) > 0){

    foreach ($grns as $key => $value) {


              $ref_yy = substr($value['grn_date'], 0, 4);
        	    $ref_no = 'GRN-'.$ref_yy . '-' . leading_zero($value['grn_id'], 5);

  						$supplier = $value['supplier_company'];


  						// if(isset($row['lpo_currency']) && $row['lpo_currency'] == 'USD'){
              //     $grn_value = number_format($value['grn_value'], 2);
  						// }else{
  							$grn_value = number_format($value['grn_value'], 0);
  					//	}

              $lpo_currency = 'TZS';

  						$grn_value = $grn_value." ".$lpo_currency;

  						$grn_html .= "<tr><td colspan='6'>
  									 <table width='100%'>
                     <tr>
                        <td colspan='6'>&nbsp;</td>
                     </tr>
  										 <tr>
  								    <td width='10%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$ref_no."</td>
  								    <td width='10%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$value['invoice_no']."</td>
  								    <td width='10%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$value['lpo_id']."</td>
  								    <td  width='35%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$supplier."</td>
  								    <td width='15%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$value['user']."</td>
  										<td  width='20%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$grn_value."</td>
  								     </tr>
  										";

  				$grn_html .= "<tr><td colspan='6'>
  					 <table width='100%'>
  						 <tr>
  							 <th>Item ID</th>
  							 <th>Description</th>
  							 <th>Quantity</th>
  							 <th>Unit Rate</th>
  							 <th>Price</th>
  						 </tr>";
          if(count($value['items']) > 0){

            foreach ($value['items'] as $item) {

    					// if(isset($row['lpo_currency']) && $row['lpo_currency'] == 'USD'){
							//
    					//     $item_price = number_format($item['item_unit_price'], 2);
    					// 		$item_total_price = number_format($item['item_unit_price'] * $item['grn_item_qty'], 2);
							//
    					// }else{

    					    $item_price = number_format($item['item_unit_price'], 0);
    							$item_total_price = number_format($item['item_unit_price'] * $item['grn_item_qty'], 0);

    				//	}



    					 $grn_html .= "<tr>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['grn_item_id']."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['item_description']."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['grn_item_qty']."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item_price."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item_total_price."</td>
    						</tr>";


    				}


          }else{

            $grn_html .= "<tr>
            <td colspan='5'><p>No records found</p></td>

             </tr>";
          }


  				$grn_html .= "</table></td></tr></table></td></tr>";
  	}




  }else{
    $grn_html .= "<tr>
    <td colspan='6'><p>No records found</p></td>

     </tr>";
  }

  $grn_html .= "<tr>
  <td colspan='5'>&nbsp;</td>

   </tr><tr>
   <td colspan='5'>&nbsp;</td>

    </tr>";

    $grn_html .= "<tr>
    <td align='left' colspan='2'><strong>Total GRN Value</strong></td><td colspan='2' align='left'>".number_format($total_grn, 0)." TZS</td>

     </tr><tr>
     <td align='left' colspan='2'><strong>Total VAT Value</strong></td><td colspan='2' align='left'>".number_format($total_tax, 0)." TZS</td>
      </tr>";

      $grandTotal = $total_grn + $total_tax;

    $grn_html .= "<tr>
    <td align='left' colspan='2'><strong>Grand Total</strong></td><td colspan='2' align='left'>".number_format($grandTotal, 0)." TZS</td>

     </tr>";


  $grn_html .= "</tbody></table>";


	require("$doc_root/vendor/autoload.php"); // Ensure PHPMailer is included

	$mail = new PHPMailer(true);

	// Server settings
	$mail->isSMTP();
	$mail->Host = SMTP_HOST;  // Replace with your SMTP server
	$mail->SMTPAuth = true;
	$mail->Username = SMTP_USERNAME; // SMTP username
	$mail->Password = SMTP_PASSWORD; // SMTP password
	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
	$mail->Port = 587; // Usually 587 for TLS
	$mail->isHTML(true);

  $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
  $mail->Subject = "Identity App: GRN Report for $today";
  $mail->addAddress('hasnain@identitytz.com');
  $mail->addAddress('kazim@identitytz.com');
  $mail->addAddress('accountsipl@identitytz.com');
  $mail->addAddress('store@identitytz.com');
  $mail->addAddress('procurement@identitytz.com');
//   $mail->addAddress('accounts2@identitytz.com');
//   $mail->addAddress('FC@identitytz.com');
//  $mail->addAddress('gm@identitytz.com');
 

  // $mail->addAddress('cfo@identitytz.com');

  // $mail->addAddress('beecraq@gmail.com');

  $msg_body = "<p>The following is a list of GRN records for today $today:</p><br>".$grn_html;
  
  


	$mail->Body = $msg_body;

  if(!empty($attachments)){

		foreach($attachments as $attch){
			$filepath = "$doc_root/{$config['attachment_dir']}$attch";
			$mail->addAttachment($filepath);
		}
	}


// 	  echo $msg_body;
//   print_r($attachments);
//   exit;

 if($mail->send()){
     echo "Email sent";
  }

}

@mysql_close();






function search_key_value($array, $key, $value)
{
		$results = array();

		if (is_array($array)) {
				if (isset($array[$key]) && $array[$key] == $value) {
						$results[] = $array;
				}

				foreach ($array as $subarray) {
						$results = array_merge($results, search_key_value($subarray, $key, $value));
				}
		}

		return $results;
}
