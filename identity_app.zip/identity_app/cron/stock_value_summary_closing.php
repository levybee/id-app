<?php

header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
 echo "Cron Run[$cronRun]:\n";
 echo "Starting automation for updating stock value closing summary.\n";

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require($root_dir."configs/variables.php");
require($root_dir."configs/functions.php");


$stock_sql = "SELECT * FROM `jos_stock`";


$result = mysql_query($stock_sql);

if(mysql_num_rows($result) > 0) {

  echo "Found data working on it..\n";
    $sqlData = array();
    $month = date('m');
    $year = date('Y');
    $no_affected_rows = 0;
    while ($row = mysql_fetch_assoc($result)) {
        $stock_id = $row['stock_id'];
        $value = 0;
        if($row['unit_price'] > 0){
             $value = $row['unit_price'] * $row['stock_qty'];
        }
       

        $updateSql = "UPDATE jos_stock_value_summary 
        SET closing_value = '$value',
        date_updated = '$cronRun'
        WHERE stock_id = '$stock_id' 
        AND MONTH(date_created) = '$month'
        AND YEAR(date_created) = '$year'";
       $no_affected_rows += mysql_query($updateSql);
    }
    
    if($no_affected_rows > 0){
      echo "All done $no_affected_rows records updated.\n\n";
    }else{
      echo "Oh shoot!..read the error.\n\n";
    }
    

}else{
  echo "No records found\n\n";
}
