<?php

require("/home/identity/public_html/app/configs/variables.php");

$date_from = date('Y-m-d').' 00:00:00';
$date_to = date('Y-m-d').' 11:59:59';
// $date_from = '2021-04-09 00:00:00';
// $date_to = '2021-04-09 11:59:59';


exit;


$log_list_sql = "SELECT pc.amount,CONCAT(u.user_fname,' ', u.user_lname) AS user,
									 pc.reference, pc.status, pc.remarks, CONCAT(je.first_name,' ', je.last_name) AS employee_name,
									 jexp.expense_name, lpo.lpo_id
					FROM `jos_petty_cash_mobile` as pc
					LEFT JOIN jos_expenses as jexp
					ON jexp.expense_id = pc.expense_id
					LEFT JOIN `cms_users` as u
						ON pc.user_id = u.user_id
					LEFT JOIN jos_employees as je
						ON je.id = pc.employee_id
						LEFT JOIN `jos_lpo` as lpo
						ON lpo.lpo_id = pc.lpo_id
					 WHERE (pc.date_created >= '$date_from' OR pc.date_updated >= '$date_from') AND (pc.status='Issued' OR pc.status='Closed')";

// echo $log_list_sql;
// exit;

$log_list_sql2 = "SELECT pc.id,pc.amount, CONCAT(u.user_fname,' ', u.user_lname) AS user,
										pc.status, pc.remarks, CONCAT(je.first_name,' ', je.last_name) AS employee_name,
									 jexp.expense_name, lpo.lpo_id
					FROM `jos_petty_cash_mobile` as pc
					LEFT JOIN jos_expenses as jexp
					ON jexp.expense_id = pc.expense_id
					LEFT JOIN `cms_users` as u
						ON pc.user_id = u.user_id
					LEFT JOIN jos_employees as je
						ON je.id = pc.employee_id
						LEFT JOIN `jos_lpo` as lpo
						ON lpo.lpo_id = pc.lpo_id
					 WHERE (pc.date_created >= '$date_from' OR pc.date_updated >= '$date_from') AND pc.status='Approved'";

$result = mysql_query($log_list_sql);

if(mysql_num_rows($result) > 0) {

  echo "Records found..\n\n";
	$aprroved_amount_sql = "SELECT SUM(IF(status = 'Approved', amount,0)) AS 'approved' FROM jos_petty_cash_mobile";

	$aprroved_amount_qry = mysql_query($aprroved_amount_sql);
	$aprroved_amount = mysql_fetch_array($aprroved_amount_qry, MYSQL_ASSOC)['approved'];

	$cash_sql ="SELECT account_amount FROM jos_cash_account_mobile ORDER BY id DESC LIMIT 1";
	$cash_amount_qry = mysql_query($cash_sql);
	$cash_balance = mysql_fetch_array($cash_amount_qry, MYSQL_ASSOC)['account_amount'];

	$cash_required = $aprroved_amount - $cash_balance + 1000000;

  echo "Approved: $aprroved_amount\n\n";
	echo "Balance: $cash_balance\n\n";
	echo "Required: $cash_required\n\n";


    $pcv_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $pcv_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>Reference</th>
																<th style='padding:3px 4px;' bgcolor='#ccc'>Status</th>
														    <th style='padding:3px 4px;' bgcolor='#ccc'>Expense Type</th>
														    <th style='padding:3px 4px;' bgcolor='#ccc'>Remarks</th>
					                      <th style='padding:3px 4px;' bgcolor='#ccc'>Amount</th>
					                      <th style='padding:3px 4px;' bgcolor='#ccc'>Issued To</th>
																<th style='padding:3px 4px;' bgcolor='#ccc'>LPO</th>
					                      <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                            </tr>
                        </thead>";
    $pcv_html .= "<tbody>";

    $today = date('d M Y');

    while ($row = mysql_fetch_assoc($result)) {

        $date = date('d M Y h:i:s', strtotime($row['date_created']));
        $payee = ($row['employee_name'] == '')? '-': $row['employee_name'];
        $amount = number_format(floatval($row['amount']));
        $account_amount = number_format(floatval($row['account_amount']));

        $pcv_html .= "<tr>

						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['reference']."</td>
								<td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['status']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['expense_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['remarks']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$amount TZS</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$payee</td>
								<td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$row['lpo_id']}</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['user']."</td>

						 </tr>";

    }

    $pcv_html .= "</tbody></table>";

    // echo $pcv_html;
		// exit;

		$result2 = mysql_query($log_list_sql2);

		$pcv_html2 = "<br><p>Approved cash log:</p>";

		if(mysql_num_rows($result2) > 0) {

			$pcv_html2 .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	    $pcv_html2 .= "<thead>
	                            <tr>
	                                <th width='40' style='padding:3px;' bgcolor='#ccc'>#</th>
															    <th style='padding:3px 4px;' bgcolor='#ccc'>Expense Type</th>
															    <th style='padding:3px 4px;' bgcolor='#ccc'>Remarks</th>
						                      <th style='padding:3px 4px;' bgcolor='#ccc'>Amount</th>
																	<th style='padding:3px 4px;' bgcolor='#ccc'>LPO</th>
						                      <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
	                            </tr>
	                        </thead>";
	    $pcv_html2 .= "<tbody>";

			while ($row = mysql_fetch_assoc($result2)) {

	        $amount = number_format($row['amount']);
	        $account_amount = number_format($row['account_amount']);

	        $pcv_html2 .= "<tr>

							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['id']."</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['expense_name']."</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['remarks']."</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$amount TZS</td>
									<td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$row['lpo_id']}</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['user']."</td>

							 </tr>";

	    }

		}else{
			$pcv_html2 .= "No records found";
		}

    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';


    require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');


    $postmark = new Postmark\Mail($postmarkApiKey);
    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
    $postmark->subject('Identity App: Todays Tigo Petty Cash Log');
	//	 $postmark->addTo('beecraq@gmail.com');
    $postmark->addTo('hasnain@identitytz.com');
    $postmark->addTo('kazim@identitytz.com');
    $mail->addAddress('accountsipl@identitytz.com');
// 		$postmark->addTo('accounts@identitytz.com');
// 		$postmark->addTo('admin@identitytz.com');
// 		$postmark->addTo('anil@identitytz.com');
    $tmrw = date('d M Y', strtotime('+1 day'));
    $cash_required = number_format(floatval($cash_required));

	$msg_body = "<p>Cash requirement for tomorrow ($tmrw) : $cash_required TZS </p>";
	$msg_body .= "<p>The following is a cash log for today ($today) :</p><br>".$pcv_html;
	$msg_body .= $pcv_html2;

echo $msg_body;
exit;

    $postmark->messageHTML($msg_body);

   if($postmark->send()){
        echo "Email sent";
    }else{
			echo "something went wrong";
		}


}
