<?php

use PHPMailer\PHPMailer\PHPMailer;

// 0 	1 	1 	* 	* 	php -q /home/identity/public_html/app/cron/sales_per_user_monthly.php
header("Content-Type: text/plain");

$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for Sales Report Monthly Notice .\n\n";

$local = false;
$doc_root = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app';

require("$doc_root/configs/variables.php");
require("$doc_root/configs/functions.php");
require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included


$th_html = "<table width='70%' border='0' cellspacing='0' cellpadding='0'>";
$th_html .= "<thead>
                        <tr>
                            <th width='110' style='padding:3px;' bgcolor='#ccc'>ID</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc' align='right'>Quote Value (TZS)</th>
                        </tr>
                    </thead>";
$th_html .= "<tbody>";

$users_sql = "SELECT user_id, user_email, role_id,
CONCAT(user_fname, ' ', user_lname) as user FROM cms_users WHERE user_status = 'Active' AND exclude_sales_reports = 0";
$users_qry = mysql_query($users_sql);

$issued_quotes_html = "<h2>Issued Quotes</h2>";
$approved_quotes_html = "<br><h2>Approved Quotes</h2>";
$reportHtml = "";
$dateSum = date("F Y", strtotime("first day of previous month"));
$exch_rate = 2710;
while ($user_row = mysql_fetch_assoc($users_qry)) {


  $user_approved_html = "";
  $user_issued_html = "";


      $user_id = $user_row['user_id'];
      $monthTotal = 0;
      $monthly_target = 0;
      $percentage = 0;

      $totalSql = "SELECT  SUM( CASE  WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))
           ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value, u.monthly_sales_target
          FROM `jos_quotes` AS q
          LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
          LEFT JOIN `cms_users` u
             ON u.user_id = q.user_id
          WHERE q.approval_date BETWEEN (DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH,'%Y-%m-01')) AND (LAST_DAY(NOW() - INTERVAL 1 MONTH))
          AND q.quote_status = 'Approved'
          AND q.user_id = '$user_id'";

    $monthTotalResult = smartsql($totalSql);
    if($monthTotalResult[0]['quote_value'] > 0){
      $monthTotal = number_format($monthTotalResult[0]['quote_value'], 2);
    }else{

        if(array_search($user_row['role_id'], [5,20,28]) === false){
           continue;
        }

    }
    $monthly_target = ($monthTotalResult[0]['monthly_sales_target'] > 0)? number_format($monthTotalResult[0]['monthly_sales_target'], 2) : 0;
     if($monthTotalResult[0]['monthly_sales_target'] > 0){
      $percentage = round(($monthTotalResult[0]['quote_value']/$monthTotalResult[0]['monthly_sales_target']) * 100)."%";
    }else{
      $percentage = "-";
    }



         $issued_sql = "SELECT q.quote_id, q.quote_date, q.currency, jos_customers_group.group_company,

                             SUM(
                                    CASE
                                         WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))

                                            ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value
                             FROM `jos_quotes` AS q
                             LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
                             LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                             LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                             LEFT JOIN `cms_users` u
                                ON u.user_id = q.user_id
                             WHERE q.quote_status != 'Cancelled'
                             AND q.quote_date BETWEEN (DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH,'%Y-%m-01')) AND (LAST_DAY(NOW() - INTERVAL 1 MONTH))
                             AND q.user_id = '$user_id'
                             GROUP BY q.quote_id
                             ORDER BY q.quote_date DESC";

           $issued_result = mysql_query($issued_sql);

           $issued = "";
           if(mysql_num_rows($issued_result) > 0) {

             $total_value = 0;

             $reportHtml .= "<h3>".$user_row['user']."</h3>";
             $reportHtml .= "<h4>Issued Quotes</h3>";

             $issued .= $th_html;
             while ($row = mysql_fetch_assoc($issued_result)) {

                 $date = date('d M Y', strtotime($row['quote_date']));
                 $ref_yy = substr($row['quote_date'], 0, 4);
                 $ref_mm = substr($row['quote_date'], 5, 2);
                 $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
                 $customer =  str_replace(array("\r", "\n"), ' ', $row['group_company']);
                 $total_value += $row['quote_value'];
                 $value = number_format(floatval($row['quote_value']), 2);


                 $issued .= "<tr>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>$ref_no</a></td>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc'>$customer</td>
                        <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='right'>".$value."</td>
                    </tr>";

             }
             $total = number_format(floatval($total_value), 2);
             $issued .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>TOTAL</strong></td>
                                           <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'>$total</td>
                                       </tr>";
             $issued .= "</tbody></table>";

             $reportHtml .= $issued;
            // $user_issued_html = $issued;


           }


           $approved_sql = "SELECT q.quote_id, q.quote_date, q.currency, jos_customers_group.group_company,

                               SUM(
                                      CASE
                                           WHEN q.currency = 'USD' THEN ((jqi.item_quantity_1 * jqi.item_price_1) * IF(q.exch_rate > 0, q.exch_rate, $exch_rate))

                                              ELSE (jqi.item_quantity_1 * jqi.item_price_1) END) as quote_value

                               FROM `jos_quotes` AS q
                               LEFT JOIN `jos_quotes_items` as jqi ON jqi.quote_id = q.quote_id
                               LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                               LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                               LEFT JOIN `cms_users` u
                                  ON u.user_id = q.user_id
                               WHERE q.quote_status = 'Approved'
                               AND q.quote_date BETWEEN (DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH,'%Y-%m-01')) AND (LAST_DAY(NOW() - INTERVAL 1 MONTH))
                               AND q.user_id = '$user_id'
                               GROUP BY q.quote_id
                               ORDER BY q.quote_date DESC";

             $approved_result = mysql_query($approved_sql);


             $approved = "";
              if(mysql_num_rows($approved_result) > 0) {


                $total_value = 0;

              //  $approved_quotes_html .= "<h3>".$user_row['user']."</h3>";
                $reportHtml .= "<br><h4>Approved Quotes</h4>";
                $approved .= $th_html;
                while ($row = mysql_fetch_assoc($approved_result)) {


                    $date = date('d M Y', strtotime($row['quote_date']));
                    $ref_yy = substr($row['quote_date'], 0, 4);
                    $ref_mm = substr($row['quote_date'], 5, 2);
                    $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
                    $customer = $row['group_company'];
                    $total_value += $row['quote_value'];
                    $value = ($row['quote_value'] > 0)? number_format(floatval($row['quote_value']), 2): 0;


                    $approved .= "<tr>
                           <td style='padding:3px 4px;' bgcolor='#fcfcfc'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>$ref_no</a></td>
                           <td style='padding:3px 4px;' bgcolor='#fcfcfc'>".$customer."</td>
                           <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='right'>".$value."</td>
                       </tr>";

                }
                $total = number_format($total_value, 2);
                $percentage_conversion = round((mysql_num_rows($approved_result) / mysql_num_rows($issued_result)) * 100, 2);

                $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'></td>
                                              <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'></td>
                                          </tr>";

               $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>Month Total</strong></td>
                                              <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'><strong>$monthTotal</strong></td>
                                          </tr>";
               $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>Monthly Sales Target</strong></td>
                                              <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'><strong>$monthly_target</strong></td>
                                          </tr>";

                if($monthly_target > 0){
                  $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>Sales Target Achieved</strong></td>
                                                <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'><strong>$percentage</strong></td>
                                            </tr>";
                }

                  $approved .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' colspan='2' align='right'><strong>Quotes Issued Vs Quotes Confirmed Conversion</strong></td>
                                                <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='#fcfcfc' align='right'><strong>$percentage_conversion%</strong></td>
                                            </tr>";

               $approved .= "</tbody></table>";

                $reportHtml .= $approved;

              //  $user_approved_html = "<br><h2>Approved Quotes</h2>".$approved;

              }


       //    $postmark = new Postmark\Mail($postmarkApiKey);
       //    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
       //    $postmark->subject("Identity App: Sales Report Monthly Notice - $dateSum");
       //
       //
       //
       // //   $mail->addAddress('beecraq@gmail.com');
       //    $msg_body = "<p>The following is a list of your Sales Report for the Month of $dateSum</p><br>";
       //    $msg_body .= $user_approved_html.$user_issued_html;
       //
       //
       //   echo "Checking if user ({$user_row['user']}) is in sales \n";
       //    $postmark->messageHTML($msg_body);
       //      $uk = array_search($user_row['role_id'], [5,20,28]);
       //     if(is_numeric($uk) && isset($user_row['user_email']) && trim($user_row['user_email']) != ''){
       //
       //      //   if($user_row['user_id'] == 19){
       //      //       $mail->addAddress('beecraq@gmail.com');
       //      //       $postmark->send();
       //      //       exit;
       //      //   }
       //         $mail->addAddress(trim($user_row['user_email']));
       //        if($postmark->send()){
       //          echo "Email sent to {$user_row['user_email']} \n";
       //        }
       //
       //     }else{
       //       echo "User does not have email set up or is not sales \n";
       //     }





}

  //echo $msg_body;
  $msg_body = "<p>The following is a Sales Report per user for the Month of $dateSum:</p><br>";
  $msg_body .= $reportHtml;


    //echo $quotes_html;

    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Monthly Sales Report - $dateSum";

    $mail->addAddress('hasnain@identitytz.com');
     $mail->addAddress('kazim@identitytz.com');
     $mail->addAddress('hr@identitytz.com');
    $mail->addAddress('andrew@identitytz.com');
    $mail->addAddress('rakesh@identitytz.com');

   // $mail->addAddress('beecraq@gmail.com');

    $mail->Body = $msg_body;

    if($mail->send()){
        echo "Overall Email sent\n";
    }
