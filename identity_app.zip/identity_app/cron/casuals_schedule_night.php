<?php

use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");

$date = date('Y-m-d');

// Is it sunday?
$tempSql = "e.type = 'Temporary' AND";
$dayofweek = date('w', strtotime($date));
if($dayofweek == 6){
  $tempSql = "";
}

$casuals_list_sql = "SELECT CONCAT(e.first_name, ' ', e.last_name) as employee_name, s.shift, si.task,
CONCAT(j.job_id, ': ', j.job_reference, ' - ', cg.group_company) as job_info, d.department_id, d.department_name

FROM jos_schedule_employees se
LEFT JOIN jos_employees e
ON e.id = se.employee_id
LEFT JOIN jos_schedule_items si
ON si.si_id = se.si_id
LEFT JOIN  jos_schedule s
ON s.schedule_id = si.schedule_id
LEFT JOIN jos_departments d
ON d.department_id = s.department_id
LEFT JOIN jos_jobs as j
ON j.job_id = si.job_id
LEFT JOIN jos_jobs_groups g
ON g.group_id = j.group_id
LEFT JOIN jos_customers c
ON c.customer_id = g.customer_id
LEFT JOIN jos_customers_group cg
ON cg.group_id = c.group_id
WHERE $tempSql s.shift = 'Day' AND s.status = 'Approved' AND s.schedule_date = DATE_ADD(CURDATE(),INTERVAL 1 DAY)";


$result = mysql_query($casuals_list_sql);


if(mysqli_num_rows($result) > 0) {

  echo "Records found..\n\n";

  // Rearrange by department
  $departments_arr = array();

  while ($row = mysql_fetch_assoc($result)) {




           $departments_arr[$row['department_id']][] = array(

               'employee_name' => $row['employee_name'],
               'job_info' => $row['job_info'],
               'task' => $row['task'],
               'department_name' => $row['department_name'],

           );


  }

//   echo "<pre>";
//   print_r($departments_arr);
//   echo "</pre>";
//   exit;

		// Create Email Content
    $sc_html = "";
    foreach ($departments_arr as $key => $value) {

              $department_name = $value[0]['department_name'];
              $sc_html .= "<br><p><strong>$department_name</strong></p>";
             $sc_html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
             $sc_html .= "<thead>
                                     <tr>
                                         <th style='padding:3px 4px;' bgcolor='#ccc'>Person</th>
         																<th style='padding:3px 4px;' bgcolor='#ccc'>Job</th>
         														    <th style='padding:3px 4px;' bgcolor='#ccc'>Task</th>
                                     </tr>
                                 </thead>";
             $sc_html .= "<tbody>";

             $schedule = array_sort($value, 'employee_name', SORT_ASC);



             foreach ($schedule as $sch) {

               $sc_html .= "<tr>

                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$sch['employee_name']."</td>
                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$sch['job_info']."</td>
                       <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$sch['task']."</td>

                    </tr>";

             }

             $sc_html .= "</tbody></table>";


    }




    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';

    $date = date('Y-m-d');
    $day = date('d M', strtotime($date. ' + 1 days'));
    $subject = "Casual Planner - Day Shift - $day";

    require("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included

  	$mail = new PHPMailer(true);

  	// Server settings
  	$mail->isSMTP();
  	$mail->Host = SMTP_HOST;  // Replace with your SMTP server
  	$mail->SMTPAuth = true;
  	$mail->Username = SMTP_USERNAME; // SMTP username
  	$mail->Password = SMTP_PASSWORD; // SMTP password
  	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  	$mail->Port = 587; // Usually 587 for TLS
  	$mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: $subject";

	//	 $mail->addAddress('beecraq@gmail.com');
     $mail->addAddress('hasnain@identitytz.com');
     $mail->addAddress('kazim@identitytz.com');
     $mail->addAddress('hr4@identitytz.com');
     $mail->addAddress('hr@identitytz.com');
     $mail->addAddress('pm@identitytz.com');
    //  $mail->addAddress('hr2@identitytz.com');
    //  $mail->addAddress('fc@identitytz.com');
    //  $mail->addAddress('anthony@identitytz.com');
		// $mail->addAddress('accounts@identitytz.com');
		// $mail->addAddress('admin@identitytz.com');
		// $mail->addAddress('sachin@identitytz.com');

		$msg_body = "<h4>$subject</h4>";

		$msg_body .= $sc_html;

		  // echo $msg_body;
		  // exit;

    $mail->Body = $msg_body;

   if($mail->send()){
        echo "Email sent";
    }else{
			echo "something went wrong";
		}

@mysql_close();
}else{
    echo "No Records found..\n\n";
}
