<?php

use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included


$head_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$head_html .= "<thead>
                        <tr>
                            <th width='110' style='padding:3px;' bgcolor='#ccc'>Ref #</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Product</th>
              <th style='padding:3px 4px;' bgcolor='#ccc'>Title</th>
              <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
              <th style='padding:3px 4px;' bgcolor='#ccc'>Quantity</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Value (TZS)</th>
                        </tr>
                    </thead>";
$head_html .= "<tbody>";

$users_sql = "SELECT user_id,CONCAT(user_fname, ' ', user_lname) as user FROM cms_users WHERE role_id = 5 AND user_status = 'Active' AND exclude_sales_reports = 0";
$users_qry = mysql_query($users_sql);

while ($user_row = mysql_fetch_assoc($users_qry)) {

      $user_name = $user_row['user'];
      $user_id = $user_row['user_id'];
      $user_email = $user_row['user_email'];

      $sip = "SELECT j.group_id, j.job_id, j.job_date, j.job_time, j.job_due_date,
      j.job_due_time, j.job_status, j.job_reference, j.job_product, j.job_paper_quantity, j.job_color, j.job_color_other, j.job_invoice_no,
    						 cg.group_company,j.job_status_notes,
    						 cms_users.user_fname, cms_users.user_lname,
    	                     d.department_name,
    	                     p.product_name,
                           jqi.item_price_1, jq.currency


    					FROM jos_jobs as j

              LEFT JOIN jos_jobs_groups jg
              ON jg.group_id = j.group_id

    					LEFT JOIN jos_customers c
    					   ON c.customer_id = jg.customer_id

    					LEFT JOIN jos_customers_group cg
    					   ON cg.group_id = c.group_id

    					LEFT JOIN jos_departments d
    					   ON d.department_id = j.department_id

    					LEFT JOIN jos_products p
    					   ON p.product_ref = j.job_product

             LEFT JOIN jos_employees je
    					   ON je.id = j.employee_id

    					LEFT JOIN cms_users
    					   ON cms_users.user_id = j.user_id

              LEFT JOIN jos_quotes_items as jqi
    					   ON jqi.item_id = j.item_id

              LEFT JOIN jos_quotes as jq
                 ON jq.quote_id = jqi.quote_id

              WHERE j.job_status = 'In Production'
              AND DATEDIFF(NOW(),j.job_date) <= 7 AND j.user_id = $user_id

              ORDER BY j.job_date DESC, j.job_id DESC";

        $sip_result = mysql_query($sip);


         if(mysql_num_rows($sip_result) > 0) {

           $total_value = 0;

           $sip_html = "";
           $sip_html .= $head_html;

           $bg_color1 = '#fcfcfc';
           $bg_color2 = '#e5e5e5';
           $row_color = $bg_color1;
           while ($row = mysql_fetch_assoc($sip_result)) {


               $date = date('d M Y', strtotime($row['job_date']));
               $ref_yy = substr($row['job_date'], 0, 4);
               $ref_mm = substr($row['job_date'], 5, 2);
               $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['job_id'], 5);
               $customer = $row['group_company'];
               $total_value += $row['item_price_1'];
               $value = number_format($row['item_price_1'], 2);


               $sip_html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='http://app.identitytz.com/jobs/progress/?id=".$row['job_id']."'>$ref_no</a></td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['product_name']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['job_reference']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$customer</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['job_paper_quantity']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$value</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }
           $total = number_format($total_value, 2);
           $sip_html .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' colspan='5' align='right'><strong>TOTAL</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' align='center'>$total</td>
                                     </tr>";
           $sip_html .= "</tbody></table>";


         }

         //echo $msg_body;
         $msg_body = "<p>Performance Report [$user_name]: Sales In Production Weekly.</p><br>";
         $msg_body .= $sip_html;

           $mail = new PHPMailer(true);

           // Server settings
           $mail->isSMTP();
           $mail->Host = SMTP_HOST;  // Replace with your SMTP server
           $mail->SMTPAuth = true;
           $mail->Username = SMTP_USERNAME; // SMTP username
           $mail->Password = SMTP_PASSWORD; // SMTP password
           $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
           $mail->Port = 587; // Usually 587 for TLS
           $mail->isHTML(true);

           $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
           $mail->Subject = 'Identity App: Performance Report - Sales In Production Weekly Notice';

           $mail->addAddress('hasnain@identitytz.com');
           // $mail->addAddress('kazim@identitytz.com');
           // $mail->addAddress('hr@identitytz.com');
           $mail->addAddress($user_email);

           // $mail->addAddress('beecraq@gmail.com');

           $mail->Body = $msg_body;

           if($mail->send()){
              // echo "Email sent";
           }

}
