<?php

/* Autometed email that sends list of job amendments pending 5pm
*/

header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for exempt sales report.\n";

require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");
require(__DIR__."/../configs/email.php");


$es_sql = "SELECT dn.dn_id, quote.quote_id, cg.group_company, dn.dn_status, quote.currency, quote.amount,
CONCAT(u.user_fname,' ',u.user_lname) as cms_user
					FROM `jos_delivery_notes` as dn
					LEFT JOIN `jos_customers`  as cu
					   ON cu.customer_id = dn.customer_id
					LEFT JOIN `jos_customers_group` AS cg
					   ON cg.group_id = cu.group_id
                    LEFT JOIN `jos_jobs`  as  j
					   ON j.job_id = dn.job_id
                   LEFT JOIN jos_quotes_items qi
                   ON qi.item_id = j.item_id
                   JOIN  (SELECT q.quote_id, q.currency, IF(dnQry.dn_amount > 0, dnQry.dn_amount, SUM(qi.item_quantity_1 * qi.item_price_1)) as amount

                   FROM jos_quotes q
                    LEFT JOIN jos_quotes_items qi
                               ON qi.quote_id = q.quote_id

                      LEFT JOIN jos_jobs AS jb
         ON jb.item_id = qi.item_id

           LEFT JOIN (SELECT SUM(dni.quantity * qi.item_price_1) as dn_amount, qi.quote_id
            FROM jos_dn_items dni 
            LEFT JOIN jos_jobs j ON j.job_id = dni.job_id 
            LEFT JOIN jos_quotes_items qi ON qi.item_id = j.item_id
            GROUP BY qi.quote_id 
            ) dnQry ON dnQry.quote_id = q.quote_id  

                       WHERE  q.tax = 'Exempt' AND q.customer_id != '62'
                    GROUP BY q.quote_id) as quote
                    ON quote.quote_id = qi.quote_id

					LEFT JOIN `cms_users`  as  u
					   ON u.user_id = cg.salesperson_user_id

                       WHERE dn.dn_status != 'Cancelled'
                      AND DATE(dn.dn_date_created) <= CURRENT_DATE
                       GROUP BY dn.dn_id,qi.quote_id";

$sales = smartsql($es_sql);

$report_array = array();
$ids = [];
if(isset($sales[0]['quote_id'])) {

	$quote_ids = array_column($sales, 'quote_id');
	$quote_ids = implode(',', $quote_ids);
	$items_sql = "SELECT qi.*, jp.product_name, jp.product_type, jp.product_ref, js.stock_name,
		 (IF(dni.quantity > 0, dni.quantity, qi.item_quantity_1) * qi.item_price_1) as item_total_price
		 FROM jos_quotes_items qi
     
    LEFT JOIN jos_jobs AS jb
         ON jb.item_id = qi.item_id

         LEFT JOIN jos_dn_items AS dni
          ON dni.job_id = jb.job_id

	LEFT JOIN jos_products as jp
		ON qi.item_product = jp.product_ref
	LEFT JOIN jos_stock as js
		 ON js.stock_id = qi.stock_id
	WHERE quote_id IN ($quote_ids)";
	$all_items = smartsql($items_sql);

	$items_map = [];
  foreach ($all_items as $item) {
      $items_map[$item['quote_id']][] = $item;
  }

      $html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
              $html .= "<thead>
                                  <tr>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>DN #</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Quote #</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Amount</th>
																	<th style='padding:3px 4px;' bgcolor='#ccc'>Sales Person</th>
                                  </tr>
                       </thead>";
              $html .= "<tbody>";

             $bg_color1 = '#fcfcfc';
             $bg_color2 = '#e5e5e5';
             $row_color = $bg_color1;
             $total = 0;
             foreach($sales as $k => $row){
               $total += $row['amount'];
              $amount = number_format($row['amount'], 0);
              $html .= "<tr>
                     <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['dn_id']}</td>
                     <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['quote_id']}</td>
                     <td style='padding:3px 4px;' bgcolor='$row_color' align='left'>{$row['group_company']}</td>
                     <td style='padding:3px 4px;' bgcolor='$row_color' align='right'>$amount {$row['currency']}</td>
										 <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['cms_user']}</td>

                 </tr>";


								 $html .= "<tr><td colspan='5'>
			   					 <table width='100%' style='border-bottom:4px solid #000;'>
			   						 <tr>
			   							 <th bgcolor='$row_color'>Product</th>
			   							 <th bgcolor='$row_color'>Quantity</th>
			   							 <th bgcolor='$row_color'>Unit Price</th>
			   							 <th bgcolor='$row_color'>Total</th>
			   						 </tr>";
			           if(isset($items_map[$row['quote_id']])){

			             foreach ($items_map[$row['quote_id']] as $item) {

			     				  $total = number_format($item['item_total_price'], 0);
                    $product = ($item['stock_id'] > 0)? $item['stock_name'] : $item['item_title'].' - '.$item['product_name'];
                    
                   
										$item_price = number_format($item['item_price_1'], 0);

			     					 $html .= "<tr>
			     					 <td style='padding:3px 4px;' bgcolor='$row_color' align='left'>$product</td>
			     					 <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$item['item_quantity_1']."</td>
			     					 <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$item_price {$row['currency']}</td>
			     					 <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$total {$row['currency']}</td>
			     						</tr>";


			     				}


			           }else{

			             $html .= "<tr>
			             <td colspan='5'><p>No records found</p></td>
			              </tr>";
			           }

								 $html .= "</table></td></tr>";

                 if($row_color == $bg_color1){
                   $row_color = $bg_color2;
                 }elseif($row_color == $bg_color2){
                   $row_color = $bg_color1;
                 }

             }

             // $html .= "<tr>
             // <td align='left'><strong>Total </strong></td><td colspan='3' align='left'>".number_format($total, 0)." TZS</td>
             //
             //  </tr>";

             $html .= "</tbody></table>";


         $today = date('d M Y');
       //  $today = date('d M Y', strtotime('2026-05-23'));
         $msg_body = "<p>The following are exempt sales records for $today</p><br>";
         $msg_body .= $html;

   $subject = "Identity App: Exempt Sales Report - $today";

   $msg_body .= "<p>--------------</p>";
   $msg_body .= "<p>This email was generated by Identity App (http://app.identitytz.com)</p>";

$email_to = ['directors@identitytz.com','vijay@identitytz.com','magna@identitytz.com'];

// $email_to = ['beecraq@gmail.com'];
$params  = [
  'subject' => $subject,
  'email_to' => $email_to,
  'body' => $msg_body
];

// echo $msg_body;
// exit;

$sent = send_email($params);

    if($sent){
        echo "Email sent\n";
    } else {
        echo "Sending failed.\n";
    }

}else{
  echo "No records found.\n";
}
