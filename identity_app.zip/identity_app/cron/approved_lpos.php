<?php
// This report will be sent at  on Fridays at 1pm

use PHPMailer\PHPMailer\PHPMailer;


header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for approved LPOs.\n";

$local = true;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");
require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

$ATTACHMENTS_DIR = $root_dir . '/tmp/';

$qcs = array();
$today = date('d M Y');
$sql_date = date('Y-m-d');

// Approved LPOs
$approved_lpo_sql = "SELECT
    l.*,
    s.supplier_id,
    s.supplier_fname,
    s.supplier_lname,
    s.supplier_company,
    s.supplier_type,
		CONCAT(u.user_fname, ' ', u.user_lname) AS user
FROM
    `jos_lpo` AS l
LEFT JOIN `jos_suppliers` AS s
ON
    s.supplier_id = l.supplier_id
LEFT JOIN `cms_users` AS u
ON u.user_id = l.user_id
WHERE l.lpo_status IN ('Approved')
GROUP BY
    l.lpo_id
ORDER BY l.lpo_date
DESC, l.lpo_id DESC";

$lpos = smartsql($approved_lpo_sql);

if(isset($lpos[0]['lpo_id'])) {

  echo "Found ".count($lpos)." LPOs.\n";

	$filename = "Approved-LPO-$sql_date.csv";
  $filepath = $ATTACHMENTS_DIR.$filename;

  // $file = fopen($filepath, 'w');
  // fputcsv($file, array('LPO ID','Date','Supplier','Destination','Comments','User'));
  // Group per supplier type
  $lposBySupplier = [];
  foreach ($lpos as $key => $value) {
    if(!empty($value['supplier_type'])){
      $lposBySupplier[$value['supplier_type']][] = $value;
    }
  }


  foreach ($lposBySupplier as $supplier_type => $slpos) {

    $html = '';
    $html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
            $html .= "<thead>
                                <tr>
                                <th width='100' style='padding:3px;' bgcolor='#ccc'>LPO ID</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Supplier</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Destination</th>
                                <th width='40%' style='padding:3px 4px;' bgcolor='#ccc'>Comments</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                                </tr>
                     </thead>";
            $html .= "<tbody>";
    $row_color = '#e5e5e5';
    foreach ($slpos as $row) {


		$date = date('d/m/Y', strtotime($row['date_created']));
		$time = date('H:i:s', strtotime($row['date_created']));
		$lpo_date = "$date <br>($time)";
		$supplier = ($row['supplier_id'] > 0)? $row['supplier_company'] : $row['supplier'];

    // Build extra info block (shipping info + attachments)
    $extraInfo = '';

    if (!empty($row['lpo_info'])) {
        $lpo_info = json_decode($row['lpo_info'], true);
        $extraInfo .= '<i>';
        if (!empty($lpo_info['shipped_by'])) {
            $extraInfo .= '<br>Shipped By: ' . htmlspecialchars($lpo_info['shipped_by']);
        }
        if (!empty($lpo_info['bl_no'])) {
            $extraInfo .= '<br>BL No: ' . htmlspecialchars($lpo_info['bl_no']);
        }
        if (!empty($lpo_info['tracking_no'])) {
            $extraInfo .= '<br>Tracking No: ' . htmlspecialchars($lpo_info['tracking_no']);
        }
        if (!empty($lpo_info['shipping_company'])) {
            $extraInfo .= '<br>Shipping Company: ' . htmlspecialchars($lpo_info['shipping_company']);
        }
        if (!empty($lpo_info['clearing_agent'])) {
            $extraInfo .= '<br>Clearing Agent: ' . htmlspecialchars($lpo_info['clearing_agent']);
        }
        if (!empty($lpo_info['idf'])) {
            $extraInfo .= '<br>IDF: ' . htmlspecialchars($lpo_info['idf']);
        }
        $extraInfo .= '</i>';
    }

    if (!empty($row['attachment'])) {
        $files = explode(',', $row['attachment']);
        $newFiles = [];
        foreach ($files as $k => $file) {
          $parts = explode('-', $file);
          $newFiles[$k]['file_name'] = str_replace('_', ' ', $parts[0]);

          if(file_exists($config['attachment_dir'].$file)){
            $newFiles[$k]['file_path'] = '/'.$config['attachment_dir'].$file;
          }else{
            $newFiles[$k]['file_path'] = "/uploads/lpo/$file";
          }
        }
        $row['attachments'] = $newFiles;
        foreach ($row['attachments'] as $file) {
            $extraInfo .= '<br><a title="' . htmlspecialchars($file['file_name']) . '" href="https://app.identitytz.com' . htmlspecialchars($file['file_path']) . '" target="_blank">' . htmlspecialchars($file['file_name']) . '</a>';
        }
    }

    $html .= "<tr>
           <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['lpo_id']}</td>
           <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$date}</td>
           <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$supplier}</td>
           <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['lpo_destination']}</td>
           <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>
           {$row['comments']}
           $extraInfo
           </td>
           <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['user']}</td>
       </tr>";


    //  fputcsv($file, array("{$row['lpo_id']}","$date","$supplier","{$row['lpo_destination']}","{$row['comments']}","{$row['user']}"));

      // PCV/Transfer
      $pc_list_sql = "SELECT 'pcv' as pc_type, pc.reference, pc.date_created, itmAmt.items_amount, pc.remarks, pc.status
		FROM jos_petty_cash as pc
	LEFT JOIN (SELECT pci.pc_id, pci.lpo_id, SUM(pci.amount) as items_amount
			   FROM  jos_pettycash_items as pci
			   LEFT JOIN jos_petty_cash pc
			   ON pc.id = pci.pc_id
			   GROUP BY pci.lpo_id) as itmAmt
			   ON itmAmt.pc_id = pc.id
			   WHERE itmAmt.lpo_id = {$row['lpo_id']}

			   UNION

			   (SELECT 'transfer' as pc_type, pc.reference, pc.date_created, itmAmt.items_amount, pc.remarks, pc.status
			   FROM jos_petty_cash_mobile as pc
	LEFT JOIN (SELECT pci.pcm_id, pci.lpo_id, SUM(pci.amount) as items_amount
			   FROM  jos_pettycash_mobile_items as pci
			   LEFT JOIN jos_petty_cash_mobile pc
			   ON pc.id = pci.pcm_id
			   GROUP BY pci.lpo_id) as itmAmt
			   ON itmAmt.pcm_id = pc.id
			   WHERE itmAmt.lpo_id = {$row['lpo_id']})";

        $pc_list = smartsql($pc_list_sql);
      //  $line = array("","","","","");

      $html .= "<tr><td colspan='6'>
         <table width='100%' style='border-bottom:3px solid #000;'>
           <tr>
             <th style='padding:3px 4px;' bgcolor='#fcfcfc'>Reference</th>
             <th style='padding:3px 4px;' bgcolor='#fcfcfc'>Date</th>
             <th style='padding:3px 4px;' bgcolor='#fcfcfc'>Amount</th>
             <th style='padding:3px 4px;' bgcolor='#fcfcfc'>Remarks</th>
             <th style='padding:3px 4px;' bgcolor='#fcfcfc'>Status</th>
           </tr>";

        if(isset($pc_list[0])){

        //  fputcsv($file, $line);
          foreach($pc_list as $pc){
            // fputcsv($file, ["Reference","Date","Amount","Remarks","Status"]);
            $pc_date = date('d/m/Y', strtotime($pc['date_created']));
            $amount = number_format($pc['items_amount'], 2);
            $ref = ($pc['pc_type'] == 'pcv')? "PCV {$pc['reference']}" : "Transfer {$pc['reference']}";
            //fputcsv($file, array("$ref","$pc_date","$amount","{$pc['remarks']}","{$pc['status']}"));
            $html .= "<tr>
            <td style='padding:3px 4px;' align='center'>$ref</td>
            <td style='padding:3px 4px;' align='center'>$pc_date</td>
            <td style='padding:3px 4px;' align='center'>$amount</td>
            <td style='padding:3px 4px;' align='center'>{$pc['remarks']}</td>
            <td style='padding:3px 4px;' align='center'>{$pc['status']}</td>
             </tr>";

          }

        }else{
          $html .= "<tr><td colspan='5'><p>No payment records found</p></td></tr>";
        }

        $html .= "</table></tr>";

      // fputcsv($file, $line);
      // fputcsv($file, $line);

    }

    $html .= "</tbody></table>";



      $mail = new PHPMailer(true);

      // Server settings
      $mail->isSMTP();
      $mail->Host = SMTP_HOST;  // Replace with your SMTP server
      $mail->SMTPAuth = true;
      $mail->Username = SMTP_USERNAME; // SMTP username
      $mail->Password = SMTP_PASSWORD; // SMTP password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      $mail->Port = 587; // Usually 587 for TLS
      $mail->isHTML(true);

      $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
      $mail->Subject = "Identity App: Approved LPOs For $supplier_type";
      $mail->addAddress('hasnain@identitytz.com');
      $mail->addAddress('procurement@identitytz.com');
      $mail->addAddress('kazim@identitytz.com');
      $mail->addAddress('accountsipl@identitytz.com');
     //$mail->addAddress('vijay@identitytz.com');
     // $mail->addAddress('controller@identitytz.com');

    // $mail->addAddress('operations@identitytz.com');
    //   $mail->addAddress('beecraq@gmail.com');

      $msg_body = "<p>The following is a report of Approved LPOs for $supplier_type.</p>$html";

     //  echo "$msg_body \n\n";
    //  exit;
      $mail->Body = $msg_body;
      // $mail->addAttachment($filepath);
     $sent = $mail->send();
     if($sent){
         echo "Email sent - $supplier_type \n";
      }


  }

  // echo $html;
  // exit;


}else{
  echo "No records found.\n";
}
