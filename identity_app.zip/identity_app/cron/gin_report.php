<?php

use PHPMailer\PHPMailer\PHPMailer;


header("Content-Type: text/plain");

$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for GIN Daily Report.\n\n";

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included
require("/home/identity/public_html/app/modules/requisition/functions.php");

$gin_items = array();
$gins = array();
$today = date('d M Y'); //date('d M Y', strtotime("-1 days"));

$date = date('Y-m-d');
$params = ['date_from' => $date, 'date_to' => $date, 'non_refills' => 1];
$issued_stock = get_issued_stock($params);

// print_r($issued_stock);
// exit;

if(count($issued_stock) > 0) {

	// print_r($gins);
	// exit;

	// Create HTML email content
	$gin_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$gin_html .= "<thead>
													<tr>
															<th width='5%' style='padding:3px;' bgcolor='#ccc'>ID</th>
                              <th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
															<th width='15%' style='padding:3px 4px;' bgcolor='#ccc'>Job</th>
															<th width='15%' style='padding:3px 4px;' bgcolor='#ccc'>Stock Name</th>
															<th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Issued Qty</th>
                              <th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Issued To</th>
                              <th width='15%' style='padding:3px 4px;' bgcolor='#ccc'>Issued By</th>
                              <th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Approval User</th>
                              <th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Remarks</th>
													</tr>
											</thead>";
	$gin_html .= "<tbody>";

  $bg_color1 = '#fcfcfc';
  $bg_color2 = '#e5e5e5';
  $row_color = $bg_color1;

  foreach ($issued_stock as $key => $row) {
      
      if(!isset($row['risi_id'])) {
          continue;
      }

  // while ($row = mysql_fetch_assoc($result_gin)) {

      $job_ref = ($row['job_id'] > 0)? $row['job_id'].": ".$row['job_reference'] : '-';

      $gin_html .= "<tr>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['ris_id']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['group_company']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$job_ref</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['stock_name']."</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['issued_qty']."</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['issued_to']."</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['user']."</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['approval_user']."</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['item_description']."</td>
           </tr>";

      if($row_color == $bg_color1){
        $row_color = $bg_color2;
      }elseif($row_color == $bg_color2){
        $row_color = $bg_color1;
      }
  }

  $gin_html .= "</tbody></table>";

  $mail = new PHPMailer(true);

  // Server settings
  $mail->isSMTP();
  $mail->Host = SMTP_HOST;  // Replace with your SMTP server
  $mail->SMTPAuth = true;
  $mail->Username = SMTP_USERNAME; // SMTP username
  $mail->Password = SMTP_PASSWORD; // SMTP password
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587; // Usually 587 for TLS
  $mail->isHTML(true);

  $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
  $mail->Subject = "Identity App: GIN Report for $today";

   $mail->addAddress('hasnain@identitytz.com');
   $mail->addAddress('kazim@identitytz.com');
   $mail->addAddress('accountsipl@identitytz.com');
   $mail->addAddress('store@identitytz.com');
   $mail->addAddress('procurement@identitytz.com');
   $mail->addAddress('ganesh@identitytz.com');
   // $mail->addAddress('FC@identitytz.com');
  // $mail->addAddress('gm@identitytz.com');
  // $mail->addAddress('store@identitytz.com');
  // $mail->addAddress('beecraq@gmail.com');

  $msg_body = "<p>The following is a list of GIN records issued for today $today:</p><br>".$gin_html;

//   print_r($msg_body);
//   exit;

  $mail->Body = $msg_body;

 if($mail->send()){
     echo "Email sent";
  }

}else{
  echo "No records found.\n\n";
}

@mysql_close();