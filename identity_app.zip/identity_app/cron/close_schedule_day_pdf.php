<?php



header("Content-Type: text/plain");

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';

require_once( __DIR__."/../configs/variables.php");
require_once( __DIR__."/../configs/functions.php");

$postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
require_once(__DIR__."/../libs/Postmark/class.postmark.php");
// require_once(__DIR__.'/../modules/job_schedule/print.class.php');



$schedule_list_sql = "SELECT s.*,
d.department_name FROM `jos_schedule` as s
LEFT JOIN `jos_departments` as d
ON d.department_id = s.department_id
WHERE s.schedule_date <= CURDATE()
AND s.shift = 'Day'
AND s.status = 'Open'";


$result = mysql_query($schedule_list_sql);
$schedule_ids = [];
$cronDate = date('Y-m-d H:i:s');
$rows = mysql_num_rows($result);

echo "[Run Date $cronDate] $rows Records found..\n\n";

if(mysql_num_rows($result) > 0) {



    $scheduleHtmlDesign = "";
    $scheduleHtml = "";
    while ($row = mysql_fetch_assoc($result)) {

      if($row['department_id'] == 2){

        }else{ // All departments

          $schedule_ids[] =  $row['schedule_id'];

        }

    }

    // print_r($schedule_ids);
    // exit;



		// Close schedules
		// $close_sql = "UPDATE jos_schedule SET status = 'closed'
		// WHERE schedule_date <= CURDATE() AND shift = 'Day' AND status = 'open';";
    //
		// echo "Closing..\n\n";
	//	 $close_query = mysql_query($close_sql);
     //  $scheduleHtmlDesign = '';

		// if(mysql_affected_rows() > 0) {
    //
		// 	echo mysql_num_rows($result)." schedules were closed, continuing processing..\n\n";
    //
		// }else{
		// 	echo "None closed";
		// }


	  $today = date('d M Y');

    if($schedule_ids){

      $ids = implode(',', $schedule_ids);
      echo "Schedule IDs: $ids..\n\n";

      $pdfFiles = [];
      $send_email = true;
      foreach($schedule_ids as $uid){
        include($root_dir.'modules/job_schedule/print.php');
        if(file_exists($schedule_path)){
           //     echo $schedule_path."\n";
        //  unlink($schedule_path);
        //  var_dump(file_exists($schedule_path));
        //  exit;
          $pdfFiles[] = $schedule_path;
         // $postmark->addAttachment($schedule_path);
        }

      }

      echo count($pdfFiles). " files created \n\n";

      print_r($pdfFiles);

    //   require_once($root_dir.'modules/pdf_classes/fpdf.php');
    //   require_once($root_dir.'modules/pdf_classes/fpdi/fpdi.php');
    //
    //
    //
    // //
    // //   exit;
    //
    //   $pdf  = new FPDI();
    //   foreach($pdfFiles as $file){
    //     $pagecount = $pdf->setSourceFile($file);
    //     for($i=0; $i < $pagecount; $i++){
    //       $tpl = $pdf->importPage($i + 1, '/MediaBox');
    //       $pdf->AddPage();
    //       $pdf->useTemplate($tpl);
    //     }
    //   }
    //
    //   $filename = "Job-Schedule-Report-".date('d-m-Y').".pdf";
    //   $attachment = $root_dir.'tmp/'. $filename;
    //   $pdf->Output($attachment, 'F');

        // $random = '?rand=' . date('U');
        // header("Location: /tmp/$filename$random");
        // exit;

     // $postmark->addAttachment($attachment);
     //
     // if($postmark->send()){
     //      echo "Email sent report.\n\n";
     //      unlink($attachment);
     //  }else{
     //   echo "something went wrong.\n\n";
     // }

    }else{
      echo "No Schedules IDs to send..\n";
    }

}else{
  echo "No records found..\n";
}
