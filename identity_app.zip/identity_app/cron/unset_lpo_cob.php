<?php

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");

$cob_sql = "SELECT lpo_id FROM jos_lpo WHERE  cob = 1";

$result = mysql_query($cob_sql);

if(mysql_num_rows($result) > 0) {

  echo "Records found..\n\n";

		// Update cob
		$close_sql = "UPDATE jos_lpo SET cob = 0
		WHERE cob = 1";

		echo "Updating..\n\n";
		$close_query = mysql_query($close_sql);

		if(mysql_affected_rows() > 0) {

			echo mysql_num_rows($result)." LPO records updated..\n\n";

		}else{
			echo "None updated";
		}

		exit;

}
