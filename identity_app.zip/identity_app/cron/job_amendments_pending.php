<?php

/* Autometed email that sends list of job amendments pending 5pm
*/

header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for job amendments.\n";

$local = true;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require($root_dir."configs/variables.php");
require($root_dir."configs/functions.php");
require($root_dir."configs/email.php");


$amends_sql = "SELECT ja.*, CONCAT(u.user_fname,' ', u.user_lname) AS user,
              g.group_company, j.job_reference
              FROM jos_job_amendments ja
              LEFT JOIN jos_jobs j
                ON j.job_id = ja.job_id
              LEFT JOIN jos_quotes_items as jqi
                 ON jqi.item_id = j.item_id
              LEFT JOIN jos_quotes as q
       					ON q.quote_id = jqi.quote_id
              LEFT JOIN jos_customers as c
              ON c.customer_id = q.customer_id
              LEFT JOIN jos_customers_group as g
              ON g.group_id = c.group_id
              LEFT JOIN cms_users as u
              ON u.user_id = ja.user_id
              WHERE DATE(ja.date_created) = CURDATE()
              AND ja.status = 'Pending' AND ja.emailed IS NULL
              ORDER BY ja.date_created DESC";

$amends = smartsql($amends_sql);

$report_array = array();
$ids = [];
if(isset($amends[0]['id'])) {

      $html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
              $html .= "<thead>
                                  <tr>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Job</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>Type</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>From</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>To</th>
                                  <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                                  <th width='100' style='padding:3px 4px;' bgcolor='#ccc'>Action</th>
                                  </tr>
                       </thead>";
              $html .= "<tbody>";

             $bg_color1 = '#fcfcfc';
             $bg_color2 = '#e5e5e5';
             $row_color = $bg_color1;

             foreach($amends as $k => $row){


              $ids[] = $row['id'];
              $cleanJson = cleanJsonString($row['changes']);
              $changes = json_decode($cleanJson, true);
              if(!$changes) continue;

              $amendFrom = '';
       				$amendTo = '';
       				foreach ($changes as $key => $value) {

       					// Old
       					if($value['new_value'] == 'N')
       					 $amendFrom .= $value['label'].' ';
       				  if(isset($value['old_value']) && $value['old_value'] != ''
                && (!isset($value['type']) || $value['type'] !== 'serialized')
       					  && $value['old_value'] != 'Y' && $value['old_value'] != 'N'
       						&& !isset($value['old_designer']) && !isset($value['old_department'])){
       							$amendFrom .= "{$value['label']}: {$value['old_value']}; ";
       					}
                 if(isset($value['old_designer']) && $value['old_designer'] != ''){
       					  $amendFrom .= "{$value['label']}: {$value['old_designer']}; ";
       					}

       					if(isset($value['old_department']) && $value['old_department'] != ''){
       					  $amendFrom .= "{$value['label']}: {$value['old_department']}; ";
       					}

       					// new
       					if($value['new_value'] == 'Y')
       					 $amendTo .= $value['label'].' ';
       				  if(isset($value['new_value']) && $value['new_value'] != ''
                && (!isset($value['type']) || $value['type'] !== 'serialized')
       					  && $value['new_value'] != 'Y' && $value['new_value'] != 'N'
       						&& !isset($value['new_designer']) && !isset($value['new_department'])){
       							$amendTo .= "{$value['label']}: {$value['new_value']}; ";
       					}
                 if(isset($value['new_designer']) && $value['new_designer'] != ''){
       					  $amendTo .= "{$value['label']}: {$value['new_designer']}; ";
       					}

       					if(isset($value['new_department']) && $value['new_department'] != ''){
       					  $amendTo .= "{$value['label']}: {$value['new_department']}; ";
       					}

       				}

              $job_ref = "{$row['job_id']}:{$row['job_reference']} - {$row['group_company']}";
              $date = date('d/m/Y', strtotime($row['date_created']));
              $link = "<a target='_blank' href='https://app.identitytz.com/jobs/progress?id={$row['job_id']}&sub_act=approve_amend&amend_id={$row['id']}'>Approve</a>";

                 $html .= "<tr>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$job_ref</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['type']}</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$amendFrom</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$amendTo</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['user']}</td>
                        <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$link</td>
                    </tr>";

                    if($row_color == $bg_color1){
                      $row_color = $bg_color2;
                    }elseif($row_color == $bg_color2){
                      $row_color = $bg_color1;
                    }

             }

             $html .= "</tbody></table>";


         $today = date('d M Y');
         $msg_body = "<p>The following are pedning job amemdment requests for $today</p><br>";
         $msg_body .= $html;

   $subject = "Identity App: Job Order Amendment Requests - $today";

   $msg_body .= "<p>--------------</p>";
   $msg_body .= "<p>This email was generated by Identity App (http://app.identitytz.com)</p>";

 $email_to = ['hasnain@identitytz.com','kazim@identitytz.com','accounts2@identitytz.com','vijay@identitytz.com'];
// $email_to = ['beecraq@gmail.com'];
$params  = [
  'subject' => $subject,
  'email_to' => $email_to,
  'body' => $msg_body
];

$sent = send_email($params);

    if($sent){
      if(count($ids) > 0){
        $ids = implode(',', $ids);
        $updateSql = "UPDATE jos_job_amendments SET emailed = '1' WHERE id IN ($ids)";
        mysql_query($updateSql);
      }
        echo "Email sent\n";
    } else {
        echo "Sending failed.\n";
    }

}else{
  echo "No records found.\n";
}
