<?php

require("/home/identity/public_html/app/configs/variables.php");


$delivery_sql = 'SELECT j.group_id, j.job_id, j.job_date, j.job_time, j.job_due_date, j.job_due_time, j.job_status, j.job_reference, j.job_product, j.job_paper_quantity, j.job_color, j.job_color_other, j.job_invoice_no,
						 jos_customers_group.group_company, cms_users.user_fname, cms_users.user_lname,
						 jos_customers.customer_fname, jos_customers.customer_lname, jos_customers.customer_email,
	                     jos_departments.department_name,
	                     jos_products.product_name
					FROM `jos_jobs` as j
			
				    LEFT JOIN `jos_jobs_groups` as g
					   ON g.group_id = j.group_id
			
					LEFT JOIN `jos_customers`
					   ON jos_customers.customer_id = g.customer_id
			
					LEFT JOIN `jos_customers_group`
					   ON jos_customers_group.group_id = jos_customers.group_id

					LEFT JOIN `jos_departments`
					   ON jos_departments.department_id = j.department_id
					
					LEFT JOIN `jos_products`
					   ON jos_products.product_ref = j.job_product
    
                    LEFT JOIN `cms_users` 
					   ON cms_users.user_id = j.user_id

					WHERE j.job_status = "In Production" AND j.department_id != 0 AND jos_departments.department_name = "Delivery"
                    ORDER BY jos_departments.department_name, j.job_date DESC;';



$delivery_result = mysql_query($delivery_sql);


$sales_sql = 'SELECT j.group_id, j.job_id, j.job_date, j.job_time, j.job_due_date, j.job_due_time, j.job_status, j.job_reference, j.job_product, j.job_paper_quantity, j.job_color, j.job_color_other, j.job_invoice_no,
						 jos_customers_group.group_company, cms_users.user_fname, cms_users.user_lname,
						 jos_customers.customer_fname, jos_customers.customer_lname, jos_customers.customer_email,
	                     jos_departments.department_name,
	                     jos_products.product_name
					FROM `jos_jobs` as j
		
				    LEFT JOIN `jos_jobs_groups` as g
					   ON g.group_id = j.group_id
		
					LEFT JOIN `jos_customers`
					   ON jos_customers.customer_id = g.customer_id
		
					LEFT JOIN `jos_customers_group`
					   ON jos_customers_group.group_id = jos_customers.group_id

					LEFT JOIN `jos_departments`
					   ON jos_departments.department_id = j.department_id
			
					LEFT JOIN `jos_products`
					   ON jos_products.product_ref = j.job_product

                    LEFT JOIN `cms_users`
					   ON cms_users.user_id = j.user_id

					WHERE j.job_status = "In Production" AND j.department_id != 0 AND jos_departments.department_name = "Sales"
                    ORDER BY jos_departments.department_name, j.job_date DESC;';



$sales_result = mysql_query($sales_sql);


if(mysql_num_rows($delivery_result) > 0) {
    
    //var_dump($result);
    
    $jobs_delivery_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $jobs_delivery_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>JO #</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Product</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Title</th> 
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th> 
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Quantity</th> 
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Due Date</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Department</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th> 
                            </tr>
                        </thead>";
    $jobs_delivery_html .= "<tbody>";

    
    while ($row = mysql_fetch_assoc($delivery_result)) {
         
        $job_date = date('d M Y', strtotime($row['job_date'])). '<br>'. $row['job_time'];
        $jo_ref = substr($row['job_date'], 0, 4). '-'.substr($row['job_date'], 5, 2).'-'.str_pad($row['job_id'], 5, '0', STR_PAD_LEFT).'-'.substr($row['user_fname'], 0, 1).substr($row['user_lname'], 0, 1);
        $customer = $row['group_company']. ' - '.$row['customer_fname'].' '.$row['customer_lname'];
        $due_date = ($row['job_due_date'] == '0000-00-00')? 'TBC' : date('d M Y', strtotime($row['job_due_date'])). '<br>'. $row['job_due_time'];
       
        $jobs_delivery_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$jo_ref."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$job_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['product_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['job_reference']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$customer."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".number_format($row['job_paper_quantity'], 0, '.', ',')."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$due_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['department_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/jobs/progress?id=".$row['job_id']."'>View</a></td>    
						 </tr>"; 
    }
    
    $jobs_delivery_html .= "</tbody></table>";
    
   // echo $jobs_delivery_html;
    
   
}

if(mysql_num_rows($sales_result) > 0) {

    //var_dump($result);

    $jobs_sales_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $jobs_sales_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>JO #</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Product</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Title</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Quantity</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Due Date</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Department</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th>
                            </tr>
                        </thead>";
    $jobs_sales_html .= "<tbody>";


    while ($row = mysql_fetch_assoc($sales_result)) {
         
        $job_date = date('d M Y', strtotime($row['job_date'])). '<br>'. $row['job_time'];
        $jo_ref = substr($row['job_date'], 0, 4). '-'.substr($row['job_date'], 5, 2).'-'.str_pad($row['job_id'], 5, '0', STR_PAD_LEFT).'-'.substr($row['user_fname'], 0, 1).substr($row['user_lname'], 0, 1);
        $customer = $row['group_company']. ' - '.$row['customer_fname'].' '.$row['customer_lname'];
        $due_date = ($row['job_due_date'] == '0000-00-00')? 'TBC' : date('d M Y', strtotime($row['job_due_date'])). '<br>'. $row['job_due_time'];
         
        $jobs_sales_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$jo_ref."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$job_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['product_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['job_reference']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$customer."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".number_format($row['job_paper_quantity'], 0, '.', ',')."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$due_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['department_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/jobs/progress?id=".$row['job_id']."'>View</a></td>
						 </tr>";
    }

    $jobs_sales_html .= "</tbody></table>";

    //echo $jobs_sales_html;

   

}


$users_sql = 'SELECT CONCAT(u.user_fname," ", u.user_lname) AS user, u.user_email, pr.role_name FROM `cms_users` as u LEFT JOIN `cms_priv_roles` as pr ON u.role_id = pr.role_id;';
$users_result = mysql_query($users_sql);


$users = array();

while ($row = mysql_fetch_assoc($users_result)) {
      
    $users[] = $row;

}



foreach ($users as $user){
    
    if($user['role_name'] == 'Sales' && isset($user['user_email'])){
    
        $email = trim($user['user_email']);
    
        $content = "<p>You have new job orders in your department:</p><br>".$jobs_sales_html;
    
        send_email($email, $content);
    
    
    }
    
}

foreach ($users as $user){

    if($user['role_name'] == 'Delivery' && isset($user['user_email'])){

        $email = trim($user['user_email']);
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            continue;
        }

        $content = "<p>You have new job orders in your department:</p><br>".$jobs_delivery_html;

        send_email($email, $content);

    }
     

}


/* echo '<pre>';
print_r($users);
echo '<pre>'; */

function send_email($email, $content){
    
    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
    
    require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');
    
    $postmark = new Postmark\Mail($postmarkApiKey);
    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
    $postmark->subject('Identity App: New Job Orders Notice');
    $postmark->addTo($email);
    
    $msg_body = $content;
    
    $postmark->messageHTML($msg_body);
    
    echo 'Sending email to: '.$email.'<br>';
    
    /* if($postmark->send()){
        //echo "Email sent";
    }  */
    

}

