<?php


require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");

$grn_items = array();
$grns = array();
$today = date('d M Y');

$year = "2020";
$m = "12";



$month = date('F', strtotime($year.'-'.$m.'-01'));




$grn_sql = "SELECT grn.*,SUM(li.item_unit_price * gi.grn_item_qty) as grn_value,
            SUM(IF(lpo.lpo_tax = 'Taxable', (li.item_unit_price * gi.grn_item_qty) * 0.18, 0)) as tax,
           lpo.lpo_supplier, s.supplier_id, s.supplier_fname, s.supplier_lname, s.supplier_company,
					 lpo.lpo_currency
				FROM jos_grn grn
				LEFT JOIN jos_grn_items as gi
					 ON grn.grn_id = gi.grn_id
					 LEFT JOIN jos_lpo_items as li
							ON li.item_id = gi.lpo_item_id
			  LEFT JOIN jos_lpo as lpo
					 ON lpo.lpo_id = grn.lpo_id
				LEFT JOIN jos_suppliers as s
					 ON s.supplier_id = lpo.supplier_id
				WHERE MONTH(grn_date) = '$m' AND YEAR(grn_date) = '$year' GROUP BY grn.grn_id";

$result_grn = mysql_query($grn_sql);

if(mysql_num_rows($result_grn) > 0) {

  $total_grn = 0;
  $total_tax = 0;
	while ($row = mysql_fetch_array($result_grn)) {

	   $grns[] = $row;
     $total_grn += $row['grn_value'];
     $total_tax += $row['tax'];
	}


	$grn_items_sql = "SELECT gi.*, grn.*, js.units, li.item_unit_price, gi.grn_item_qty, li.item_qty_per_pack,
														li.item_description, li.item_general_notes
													FROM jos_grn_items as gi
													LEFT JOIN jos_grn as grn
													  ON grn.grn_id = gi.grn_id
													LEFT JOIN jos_lpo_items as li
														 ON li.item_id = gi.lpo_item_id

													LEFT JOIN jos_stock as js
														 ON js.stock_id = li.stock_id

													WHERE MONTH(grn_date) = '$m' AND YEAR(grn_date) = '$year' GROUP BY grn.grn_id";

	$result_items = mysql_query($grn_items_sql);
	while ($row = mysql_fetch_array($result_items)) {
	   $grn_items[] = $row;
	}


	// Create List of GRN with items
	foreach ($grns as $key => $value) {

		$grns[$key]['items'] = search_key_value($grn_items, 'grn_id', $value['grn_id']);

	}


	// Create HTML email content
	$grn_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$grn_html .= "<thead>
													<tr>
															<th width='15%' style='padding:3px;' bgcolor='#ccc'>ID</th>
															<th width='15%' style='padding:3px 4px;' bgcolor='#ccc'>LPO ID</th>
															<th width='40%' style='padding:3px 4px;' bgcolor='#ccc'>Supplier</th>
															<th width='30%' style='padding:3px 4px;' bgcolor='#ccc'>GRN Value</th>
													</tr>
											</thead>";
	$grn_html .= "<tbody>";

  if(count($grns) > 0){

    foreach ($grns as $key => $value) {


              $ref_yy = substr($value['grn_date'], 0, 4);
        	    $ref_no = 'GRN-'.$ref_yy . '-' . leading_zero($value['grn_id'], 5);

  						$supplier = $value['supplier_company'];


  						if($row['lpo_currency'] == 'USD'){
                  $grn_value = number_format($value['grn_value'], 2);
  						}else{
  							$grn_value = number_format($value['grn_value'], 0);
  						}

              $lpo_currency = $value['lpo_currency'];

  						$grn_value = $grn_value." ".$lpo_currency;

  						$grn_html .= "<tr><td colspan='4'>
  									 <table width='100%'>
                     <tr>
                        <td colspan='4'>&nbsp;</td>
                     </tr>
  										 <tr>
  								    <td width='15%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$ref_no."</td>
  								    <td width='15%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$value['lpo_id']."</td>
  								    <td  width='40%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$supplier."</td>
  										<td  width='30%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>".$grn_value."</td>
  								     </tr>
  										";

  				$grn_html .= "<tr><td colspan='4'>
  					 <table width='100%'>
  						 <tr>
  							 <th>Item ID</th>
  							 <th>Description</th>
  							 <th>Quantity</th>
  							 <th>Unit Rate</th>
  							 <th>Price</th>
  						 </tr>";
          if(count($value['items']) > 0){

            foreach ($value['items'] as $item) {

    					if($row['lpo_currency'] == 'USD'){

    					    $item_price = number_format($item['item_unit_price'], 2);
    							$item_total_price = number_format($item['item_unit_price'] * $item['grn_item_qty'], 2);

    					}else{

    					    $item_price = number_format($item['item_unit_price'], 0);
    							$item_total_price = number_format($item['item_unit_price'] * $item['grn_item_qty'], 0);

    					}



    					 $grn_html .= "<tr>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['grn_item_id']."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['item_description']."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item['grn_item_qty']."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item_price."</td>
    					 <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item_total_price."</td>
    						</tr>";


    				}


          }else{

            $grn_html .= "<tr>
            <td colspan='4'><p>No records found</p></td>

             </tr>";
          }


  				$grn_html .= "</table></td></tr></table></td></tr>";
  	}




  }else{
    $grn_html .= "<tr>
    <td colspan='4'><p>No records found</p></td>

     </tr>";
  }

  $grn_html .= "<tr>
  <td colspan='4'>&nbsp;</td>

   </tr><tr>
   <td colspan='4'>&nbsp;</td>

    </tr>";

    $grn_html .= "<tr>
    <td align='left'><strong>Total GRN Value</strong></td><td colspan='3' align='left'>".number_format($total_grn, 0)." TZS</td>

     </tr><tr>
     <td align='left'><strong>Total VAT Value</strong></td><td colspan='3' align='left'>".number_format($total_tax, 0)." TZS</td>
      </tr>";



  $grn_html .= "</tbody></table>";


  $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';


  require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');


  $postmark = new Postmark\Mail($postmarkApiKey);
  $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
  $postmark->subject("Identity App: GRN Report for $month $year");
  $postmark->addTo('hasnain@identitytz.com');
  $postmark->addTo('kazim@identitytz.com');
  $postmark->addTo('accounts@identitytz.com');
  $postmark->addTo('FC@identitytz.com');
  // $postmark->addTo('beecraq@gmail.com');

  $msg_body = "<p>The following is a list of GRN records for $month $year:</p><br>".$grn_html;

  // print_r($msg_body);
  // exit;

  $postmark->messageHTML($msg_body);

 if($postmark->send()){
     echo "Email sent $m";
  }

}








function search_key_value($array, $key, $value)
{
		$results = array();

		if (is_array($array)) {
				if (isset($array[$key]) && $array[$key] == $value) {
						$results[] = $array;
				}

				foreach ($array as $subarray) {
						$results = array_merge($results, search_key_value($subarray, $key, $value));
				}
		}

		return $results;
}
