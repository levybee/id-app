<?php

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';

require_once( __DIR__."/../configs/variables.php");
require_once( __DIR__."/../configs/functions.php");

require($root_dir."vendor/autoload.php"); // Ensure PHPMailer is included
// require_once(__DIR__.'/../modules/job_schedule/print.class.php');



$schedule_list_sql = "SELECT s.*,
d.department_name FROM `jos_schedule` as s
LEFT JOIN `jos_departments` as d
ON d.department_id = s.department_id
WHERE s.schedule_date <= CURDATE()
AND s.shift = 'Day'
AND s.status = 'Approved'";


$result = mysql_query($schedule_list_sql);
$schedule_ids = [];
$cronDate = date('Y-m-d H:i:s');
$rows = mysql_num_rows($result);

echo "[Run Date $cronDate] $rows Records found..\n\n";

if(mysql_num_rows($result) > 0) {



    $scheduleHtmlDesign = "";
    $scheduleHtml = "";
    while ($row = mysql_fetch_assoc($result)) {


      if($row['department_id'] == 2){

          $scheduleDate = date('d/m/Y', strtotime($row['schedule_date']));

          $scheduleHtmlDesign .= "<table>
                          <tr>
                           <td><strong>Schedule Date: </strong></td>
                           <td>$scheduleDate</td>
                         </tr>
                        </table>";

          $schedule_items_sql = "SELECT si.*,
          @diff:=ABS( UNIX_TIMESTAMP(si.start_time) - UNIX_TIMESTAMP(si.stop_time) ) ,
          CAST(@days := IF(@diff/86400 >= 1, floor(@diff / 86400 ),0) AS SIGNED) as days,
          CAST(@hours := IF(@diff/3600 >= 1, floor((@diff:=@diff-@days*86400) / 3600),0) AS SIGNED) as hours,
          CAST(@minutes := IF(@diff/60 >= 1, floor((@diff:=@diff-@hours*3600) / 60),0) AS SIGNED) as minutes,
          j.job_id,p.printer_name,p.printer_id,
                            CONCAT(j.job_id, ': ', cg.group_company, ' - ', IF(jqi.stock_id > 0, stck.stock_name, j.job_reference)) as job_info,
                            GROUP_CONCAT(se.employee_id) as employees_str,
                            GROUP_CONCAT(CONCAT(e.first_name, ' ', e.last_name, ' (', LEFT(e.type , 1) , ')' )) as employees

                            FROM `jos_schedule_items` as si
                            LEFT JOIN `jos_schedule_employees` as se
                            ON se.si_id = si.si_id
                            LEFT JOIN `jos_employees` as e
                            ON e.id = se.employee_id
                            LEFT JOIN jos_printers p
                            ON p.printer_id = si.printer_id
                            LEFT JOIN jos_jobs as j
                            ON j.job_id = si.job_id
                            LEFT JOIN `jos_quotes_items` as jqi
                  					ON jqi.item_id = j.item_id
                            LEFT JOIN `jos_stock` as stck
                            ON stck.stock_id = jqi.stock_id
                            LEFT JOIN `jos_jobs_groups` as g
                            ON g.group_id = j.group_id
                            LEFT JOIN `jos_customers` as c
                            ON c.customer_id = g.customer_id
                            LEFT JOIN `jos_customers_group` as cg
                            ON cg.group_id = c.group_id
                            LEFT JOIN `jos_products` jp
                            ON jp.product_ref = j.job_product
                            WHERE si.schedule_id = {$row['schedule_id']} GROUP BY si.si_id ORDER BY p.printer_name ASC";

          $schedule_items = smartsql($schedule_items_sql);

          // Group by Printer ID
          $scheduleByPrinter = [];
          foreach ($schedule_items as $key => $value) {
            $scheduleByPrinter[$value['printer_id']][] = $value;
          }

          foreach ($scheduleByPrinter as $printer_id => $items) {

            $scheduleHtmlDesign .= "<table>
                              <tr>
                               <td><strong>Machine: </strong></td>
                               <td>{$items[0]['printer_name']}</td>
                             </tr>
                            </table>";

                      $scheduleHtmlDesign .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                    <tr>
                                        <th width='40' style='padding:3px;' bgcolor='#ccc'>#</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Job</th>
                                        <th style='padding:3px;' bgcolor='#ccc'>Quantity</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Employees</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Task</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Status</th>
                                    </tr>";

                foreach ($items as $k => $item) {

                  $start_time = "-";
                  if($item['start_time']){
                      $time = date('H:i:s' , strtotime($item['start_time']));
                      $start_time = date('g:i a', strtotime($time));
                  }

                  $stopHtml = "</div>";
                  if($item['stop_time']){
                      $time = date('H:i:s' , strtotime($item['stop_time']));
                      $stop_time = date('g:i a', strtotime($time));
                      $stopHtml = " / <strong>Stop</strong> $stop_time </div>";
                  }

                  $startStopHtml = "<div><strong>Start</strong> $start_time $stopHtml";

                  $machineTimeHtml = "";
                  if($item['start_time'] && $item['stop_time']){
                   $machineTimeHtml = "<div><strong>Total Machine Time:</strong> {$item['hours']} Hrs {$item['minutes']} Mins</div>";
                  }

                  $notesHtml = "";
                  if($item['comments']){
                    $notesHtml = "<div><strong>Notes:</strong> {$item['comments']}</div>";
                  }
                  $counter = $k + 1;
                  $scheduleHtmlDesign .= "<tr>
                  <td style='padding:3px 4px; border-bottom:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>{$counter}</td>
                  <td style='padding:3px 4px; border-bottom:1px solid #ccc; text-align:left;' bgcolor='#fcfcfc'>{$item['job_info']}</td>
                  <td style='padding:3px 4px; border-bottom:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>{$item['expected_qty']}</td>
                  <td style='padding:3px 4px; border-bottom:1px solid #ccc; text-align:left;' bgcolor='#fcfcfc'>{$item['employees']}</td>
                  <td style='padding:3px 4px; border-bottom:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>{$item['task']}</td>
                  <td style='padding:3px 4px; border-bottom:1px solid #ccc; text-align:left;' bgcolor='#fcfcfc'>
                       $startStopHtml
                       $machineTimeHtml
                      <div><strong>Qty Done: </strong><span>{$item['final_qty']}</div>
                      $notesHtml
                    </td>
                    </tr>";
                  // code...
                }

                $scheduleHtmlDesign .= "</table>";
                $scheduleHtmlDesign .= "<br><br>";

          }

        }else{ // All departments

          $schedule_ids[] =  $row['schedule_id'];

           $scheduleDate = date('d/m/Y', strtotime($row['schedule_date']));

          $scheduleHtml .= "<table>
                          <tr>
                           <td style='font-size: 16px; color:#f3731a;'><strong>Department: </strong></td>
                           <td style='font-size: 16px; color:#f3731a;'>{$row['department_name']}</td>
                         </tr>
                          <tr>
                           <td><strong>Schedule Date: </strong></td>
                           <td>$scheduleDate</td>
                         </tr>
                        </table>";

          $schedule_items_sql = "SELECT si.*,
          @diff:=ABS( UNIX_TIMESTAMP(si.start_time) - UNIX_TIMESTAMP(si.stop_time) ) ,
          CAST(@days := IF(@diff/86400 >= 1, floor(@diff / 86400 ),0) AS SIGNED) as days,
          CAST(@hours := IF(@diff/3600 >= 1, floor((@diff:=@diff-@days*86400) / 3600),0) AS SIGNED) as hours,
          CAST(@minutes := IF(@diff/60 >= 1, floor((@diff:=@diff-@hours*3600) / 60),0) AS SIGNED) as minutes,
          j.job_id,p.printer_name,p.printer_id,
                            CONCAT(j.job_id, ': ', cg.group_company, ' - ', IF(jqi.stock_id > 0, stck.stock_name, j.job_reference)) as job_info,
                            GROUP_CONCAT(se.employee_id) as employees_str,
                            GROUP_CONCAT(CONCAT(e.first_name, ' ', e.last_name, ' (', LEFT(e.type , 1) , ')' )) as employees

                            FROM `jos_schedule_items` as si
                            LEFT JOIN `jos_schedule_employees` as se
                            ON se.si_id = si.si_id
                            LEFT JOIN `jos_employees` as e
                            ON e.id = se.employee_id
                            LEFT JOIN jos_printers p
                            ON p.printer_id = si.printer_id
                            LEFT JOIN jos_jobs as j
                            ON j.job_id = si.job_id
                            LEFT JOIN `jos_quotes_items` as jqi
                  					ON jqi.item_id = j.item_id
                            LEFT JOIN `jos_stock` as stck
                            ON stck.stock_id = jqi.stock_id
                            LEFT JOIN `jos_jobs_groups` as g
                            ON g.group_id = j.group_id
                            LEFT JOIN `jos_customers` as c
                            ON c.customer_id = g.customer_id
                            LEFT JOIN `jos_customers_group` as cg
                            ON cg.group_id = c.group_id
                            LEFT JOIN `jos_products` jp
                            ON jp.product_ref = j.job_product
                            WHERE si.schedule_id = {$row['schedule_id']} GROUP BY si.si_id ORDER BY p.printer_name ASC";

          $schedule_items = smartsql($schedule_items_sql);

          // Group by Printer ID
          $scheduleByPrinter2 = [];
          foreach ($schedule_items as $key => $value) {
            $scheduleByPrinter2[$value['printer_id']][] = $value;
          }

          foreach ($scheduleByPrinter2 as $printer_id => $items) {

            $scheduleHtml .= "<table>
                              <tr>
                               <td><strong>Machine: </strong></td>
                               <td>{$items[0]['printer_name']}</td>
                             </tr>

                            </table>";

                      $scheduleHtml .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>
                                    <tr>
                                        <th width='40' style='padding:3px;' bgcolor='#ccc'>#</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Job</th>
                                        <th style='padding:3px;' bgcolor='#ccc'>Quantity</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Employees</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Task</th>
                                        <th width='20%' style='padding:3px;' bgcolor='#ccc'>Status</th>
                                    </tr>";

                foreach ($items as $k => $item) {

                  $start_time = "-";
                  if($item['start_time']){
                      $time = date('H:i:s' , strtotime($item['start_time']));
                      $start_time = date('g:i a', strtotime($time));
                  }

                  $stopHtml = "</div>";
                  if($item['stop_time']){
                      $time = date('H:i:s' , strtotime($item['stop_time']));
                      $stop_time = date('g:i a', strtotime($time));
                      $stopHtml = " / <strong>Stop</strong> $stop_time </div>";
                  }

                  $startStopHtml = "<div><strong>Start</strong> $start_time $stopHtml";

                  $machineTimeHtml = "";
                  if($item['start_time'] && $item['stop_time']){
                   $machineTimeHtml = "<div><strong>Total Machine Time:</strong> {$item['hours']} Hrs {$item['minutes']} Mins</div>";
                  }

                  $notesHtml = "";
                  if($item['comments']){
                    $notesHtml = "<div><strong>Notes:</strong> {$item['comments']}</div>";
                  }
                  $counter = $k + 1;
                  $scheduleHtml .= "<tr>
                    <td style='padding:3px 4px; border-bottom:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>{$counter}</td>
                    <td style='padding:3px 4px; border-bottom:1px solid #ccc; text-align:left;' bgcolor='#fcfcfc'>{$item['job_info']}</td>
                    <td style='padding:3px 4px; border-bottom:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>{$item['expected_qty']}</td>
                    <td style='padding:3px 4px; border-bottom:1px solid #ccc; text-align:left;' bgcolor='#fcfcfc'>{$item['employees']}</td>
                    <td style='padding:3px 4px; border-bottom:1px solid #ccc;' bgcolor='#fcfcfc' align='center'>{$item['task']}</td>
                    <td style='padding:3px 4px; border-bottom:1px solid #ccc; text-align:left;' bgcolor='#fcfcfc'>
                       $startStopHtml
                       $machineTimeHtml
                      <div><strong>Qty Done: </strong><span>{$item['final_qty']}</div>
                      $notesHtml
                    </td>
                    </tr>";
                  // code...
                }

                $scheduleHtml .= "</table>";
                $scheduleHtml .= "<br><br>";

          }


        }

    }

    // print_r($schedule_ids);
    // exit;
    //   echo $scheduleHtml;
    //     exit;



		// Close schedules
		$close_sql = "UPDATE jos_schedule SET status = 'Closed'
		WHERE schedule_date <= CURDATE() AND shift = 'Day' AND status = 'Approved';";

		echo "Closing..\n\n";
		 $close_query = mysql_query($close_sql);
      // $scheduleHtmlDesign = '';

		if(mysql_affected_rows() > 0) {

			echo mysql_num_rows($result)." schedules were closed, continuing processing..\n\n";

		}else{
			echo "None closed";
		}


	  $today = date('d M Y');

    if($scheduleHtmlDesign){

      $mail = new PHPMailer(true);

    	// Server settings
    	$mail->isSMTP();
    	$mail->Host = SMTP_HOST;  // Replace with your SMTP server
    	$mail->SMTPAuth = true;
    	$mail->Username = SMTP_USERNAME; // SMTP username
    	$mail->Password = SMTP_PASSWORD; // SMTP password
    	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    	$mail->Port = 587; // Usually 587 for TLS
    	$mail->isHTML(true);

      $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
      $mail->Subject = "Identity App: Closed Job Schedule [Design]  - Day Shift";

    //  $mail->addAddress('beecraq@gmail.com');
     $mail->addAddress('kazim@identitytz.com');
     $mail->addAddress('designer@identitytz.com');

    //   $mail->addAddress('hasnain@identitytz.com');
    //   $mail->addAddress('accounts@identitytz.com');
    //   $mail->addAddress('admin@identitytz.com');
     // $mail->addAddress('sachin@identitytz.com');

     $msg_body = "<p> Below are Job Schedules closed today ($today) for the Design department (Day Shift) </p><br><br>".$scheduleHtmlDesign;

       // echo $msg_body;
       // exit;
      $mail->Body = $msg_body;

     if($mail->send()){
          echo "Email sent design\n\n";
      }else{
       echo "something went wrong";
     }

    }


    if($schedule_ids){

      $ids = implode(',', $schedule_ids);
      echo "Schedule IDs: $ids..\n\n";

      $mail = new PHPMailer(true);

    	// Server settings
    	$mail->isSMTP();
    	$mail->Host = SMTP_HOST;  // Replace with your SMTP server
    	$mail->SMTPAuth = true;
    	$mail->Username = SMTP_USERNAME; // SMTP username
    	$mail->Password = SMTP_PASSWORD; // SMTP password
    	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    	$mail->Port = 587; // Usually 587 for TLS
    	$mail->isHTML(true);

      $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
      $mail->Subject = "Identity App: Production Report - Day Shift - $today";

    //  $mail->addAddress('beecraq@gmail.com');
      $mail->addAddress('kazim@identitytz.com');
      $mail->addAddress('hasnain@identitytz.com');
     // $mail->addAddress('gm@identitytz.com');
      $mail->addAddress('hripl@identitytz.com');
      $mail->addAddress('rama@identitytz.com');
      $mail->addAddress('pm@identitytz.com');
      $mail->addAddress('ganesh@identitytz.com');

    //  $mail->addAddress('designer@identitytz.com');
     //  $mail->addAddress('accounts@identitytz.com');
      // $mail->addAddress('admin@identitytz.com');
      // $mail->addAddress('sachin@identitytz.com');


     $msg_body = "<p> Attached is Production Report for ($today)  - Day Shift.</p><br><br>".$scheduleHtml;

        // echo $msg_body;
        // exit;

      $mail->Body = $msg_body;

    //   $pdfFiles = [];
    //   $send_email = true;
    //   foreach($schedule_ids as $uid){
    //     include($root_dir.'modules/job_schedule/print.php');
    //     if(file_exists($schedule_path)){
    //       //     echo $schedule_path."\n";
    //     //  unlink($schedule_path);
    //     //  var_dump(file_exists($schedule_path));
    //     //  exit;
    //       $pdfFiles[] = $schedule_path;
    //      // $postmark->addAttachment($schedule_path);
    //     }

    //   }

    //   require_once($root_dir.'modules/pdf_classes/fpdf.php');
    //   require_once($root_dir.'modules/pdf_classes/fpdi/fpdi.php');
    //
    // //   print_r($pdfFiles);
    // //   exit;
    //
    //   $pdf  = new FPDI();
    //   foreach($pdfFiles as $file){
    //     $pagecount = $pdf->setSourceFile($file);
    //     for($i=0; $i < $pagecount; $i++){
    //       $tpl = $pdf->importPage($i + 1, '/MediaBox');
    //       $pdf->AddPage();
    //       $pdf->useTemplate($tpl);
    //     }
    //   }
    //
    //   $filename = "Job-Schedule-Report-".date('d-m-Y').".pdf";
    //   $attachment = $root_dir.'tmp/'. $filename;
    //   $pdf->Output($attachment, 'F');

        // $random = '?rand=' . date('U');
        // header("Location: /tmp/$filename$random");
        // exit;

     // $mail->addAttachment($attachment);

     if($mail->send()){
          echo "Email sent report.\n\n";
          //  unlink($attachment);
      }else{
       echo "something went wrong.\n\n";
     }

    }else{
      echo "No Schedules IDs to send..\n";
    }

}
