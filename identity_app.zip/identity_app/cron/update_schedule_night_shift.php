<?php

header("Content-Type: text/plain");

$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for updating night shift schedule.\n\n";

require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");
require(__DIR__."/../modules/attendance_schedule/functions.php");

$shift_id = 2;
$status = update_schedule_for_casuals($shift_id);



if($status){
  echo "Schedule updated successfully for shift_id: $shift_id";
}else{
  echo "No records updated for shift_id: $shift_id";
}

@mysql_close();

?>
