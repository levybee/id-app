<?php

require( __DIR__."/../configs/variables.php");



$schedule_list_sql = "SELECT * FROM `jos_vehicle_schedule`
WHERE schedule_date <= NOW()
AND status = 'Open'";


$result = mysql_query($schedule_list_sql);

if(mysql_num_rows($result) > 0) {

  echo "Records found..\n\n";

		// Close schedules
		$close_sql = "UPDATE jos_vehicle_schedule SET status = 'Closed'
		WHERE schedule_date <= NOW() AND status = 'Open';";

		echo "Closing..\n\n";
		$close_query = mysql_query($close_sql);

		if(mysql_affected_rows() > 0) {

			echo mysql_num_rows($result)." schedules were closed..\n\n";

		}else{
			echo "None closed";
		}

		exit;


}
