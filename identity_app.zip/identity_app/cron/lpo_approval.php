<?php

require("/home/identity/public_html/app/configs/variables.php");

$approval_sql = 'SELECT l.lpo_id, l.lpo_date, l.lpo_attention, l.lpo_status, l.lpo_supplier, l.lpo_destination,
					   s.supplier_id, s.supplier_fname, s.supplier_lname, s.supplier_company, s.supplier_email,
					   u.user_fname, u.user_lname
					FROM `jos_lpo` as l
			
					LEFT JOIN `jos_suppliers` as s
					   ON s.supplier_id = l.supplier_id

					LEFT JOIN `cms_users` as u
					   ON u.user_id = l.user_id

					WHERE l.lpo_status  = "Pending"
                    ORDER BY l.lpo_date DESC;';


$lpo_qry = mysql_query($approval_sql) or die(mysql_error());



if(mysql_num_rows($lpo_qry) > 0) {

    $lpo_list = array();

    while($lpo_data = mysql_fetch_array($lpo_qry, MYSQL_ASSOC)) {
        	
        // Loop to get items
        // $lpo_items_qry = mysql_query('SELECT `item_product` FROM `jos_lpo_items` WHERE `lpo_id` = \'' . $lpo_data['lpo_id'] . '\';');
        $lpo_items_qry = mysql_query('SELECT `item_id` FROM `jos_lpo_items` WHERE `lpo_id` = \'' . $lpo_data['lpo_id'] . '\';');
        	
        if($lpo_items_qry) {

            $items_num = mysql_num_rows($lpo_items_qry);


        } else {

            $items_num = 0;
            $items_text = '---';

        }
        	
        // Temporary Array
        $lpo_temp = array (
            'lpo_info' => $lpo_data,
            'lpo_items_num' => $items_num,
            'lpo_items_desc' => $items_text
        );
        	
        $lpo_list[] = $lpo_temp;

    }
    
    foreach ($lpo_list as $k => $v){
         
        if($v['lpo_info']['supplier_id'] == 0){
             
            $supplier_info = explode(',' , $v['lpo_info']['lpo_supplier']);
            $lpo_list[$k]['lpo_info']['supplier'] =  $supplier_info[0];
        }
    }
    
    
    $lpos_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $lpos_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>Ref #</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Supplier</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Destination</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Items #</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th>
                            </tr>
                        </thead>";
    $lpos_html .= "<tbody>";
    
    
    foreach ($lpo_list as $row) {
         
        $lpo_date = date('d M Y', strtotime($row['lpo_info']['lpo_date']));
        $lpo_ref = 'LPO-'.substr($row['lpo_info']['lpo_date'], 0, 4).'-'.str_pad($row['lpo_info']['lpo_id'], 4, '0', STR_PAD_LEFT);
        $supplier = ($row['lpo_info']['supplier_id'] == 0 || $row['lpo_info']['supplier_id'] == '')? $row['lpo_info']['supplier']: $row['lpo_info']['supplier_company'].' - '.$row['lpo_info']['supplier_fname']. ' ' .$row['lpo_info']['supplier_lname'];
         
        $lpos_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$lpo_ref."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$lpo_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$supplier."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['lpo_info']['lpo_destination']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['lpo_items_num']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/lpo/approve/?id=".$row['lpo_info']['lpo_id']."'>Approve</a></td>
						 </tr>";
    }
    
    $lpos_html .= "</tbody></table>";
    
   // echo $lpos_html;
    
    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
     
    
    require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');
    
    
    $postmark = new Postmark\Mail($postmarkApiKey);
    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
    $postmark->subject('Identity App: Requisitions Approval Notice');
    $postmark->addTo('hasnain@identitytz.com');
   // $postmark->addTo('kazim@identitytz.com');
   // $postmark->addTo('gm@identitytz.com');
    
    $msg_body = "<p>The following LPOs require approval:</p><br>".$lpos_html;
    
    $postmark->messageHTML($msg_body);
    
     if($postmark->send()){
     // echo "Email sent";
     } 
    
    
    

}
