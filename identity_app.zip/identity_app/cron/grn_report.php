<?php

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

$local = false;
$cron = true;

if($local){
    $doc_root = $_SERVER['DOCUMENT_ROOT'];
}else{
    $doc_root = '/home/identity/public_html/app';
}

require("$doc_root/configs/variables.php");
require("$doc_root/configs/functions.php");
require ("$doc_root/modules/configurations.php");
require("$doc_root/vendor/autoload.php"); // Ensure PHPMailer available

// Helper: fetch GRNs for given lpo_tax value ('Exempt' or 'Taxable')
function fetch_grns_by_tax($taxType) {
    $grns = [];
    $total_grn = 0;
    $total_tax = 0;

    $taxCond = "AND lpo.lpo_tax = '" . mysql_real_escape_string($taxType) . "'";

    $grn_sql = "SELECT grn.*,
                       SUM(IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) * gi.grn_item_qty) as grn_value,
                       CONCAT(u.user_fname,' ', u.user_lname) AS user,
                       SUM(IF(lpo.lpo_tax = 'Taxable', (IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) * gi.grn_item_qty) * 0.18, 0)) as tax,
                       lpo.lpo_supplier, s.supplier_id, s.supplier_fname, s.supplier_lname, s.supplier_company, dp.department_name,
                       lpo.lpo_currency
                FROM jos_grn grn
                LEFT JOIN jos_grn_items as gi ON grn.grn_id = gi.grn_id
                LEFT JOIN jos_lpo_items as li ON li.item_id = gi.lpo_item_id
                LEFT JOIN jos_lpo as lpo ON lpo.lpo_id = grn.lpo_id
                LEFT JOIN jos_jobs j ON j.job_id = lpo.job_id
                LEFT JOIN jos_departments dp ON dp.department_id = j.department_id
                LEFT JOIN cms_users as u ON u.user_id = grn.user_id
                LEFT JOIN jos_suppliers as s ON s.supplier_id = lpo.supplier_id
                WHERE grn_date = CURDATE() AND  grn.status != 'Cancelled' $taxCond
                GROUP BY grn.grn_id";

    $res = mysql_query($grn_sql);
    if (!$res) { return ['grns'=>[], 'total_grn'=>0, 'total_tax'=>0]; }

    while ($row = mysql_fetch_assoc($res)) {
        $grns[] = $row;
        $total_grn += floatval($row['grn_value']);
        $total_tax += floatval($row['tax']);
    }

    // fetch items for these GRNs
    $grn_items = [];
    if (count($grns) > 0) {
        $ids = implode(',', array_map('intval', array_column($grns, 'grn_id')));
        $grn_items_sql = "SELECT gi.*, grn.grn_date, js.units, COALESCE(js.category, cat.category_name) as category_name,
                                 IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) as item_unit_price,
                                 gi.grn_item_qty, li.item_qty_per_pack, li.item_description, li.item_general_notes,li.asset_category, li.asset_id
                          FROM jos_grn_items as gi
                          LEFT JOIN jos_grn as grn ON grn.grn_id = gi.grn_id
                          LEFT JOIN jos_lpo_items as li ON li.item_id = gi.lpo_item_id
                          LEFT JOIN jos_lpo as lpo ON lpo.lpo_id = li.lpo_id
                          LEFT JOIN jos_stock as js ON js.stock_id = li.stock_id
                          LEFT JOIN jos_categories as cat ON cat.category_id = li.category_id
                          WHERE gi.grn_id IN ($ids)";
        $res_items = mysql_query($grn_items_sql);
        while ($r = mysql_fetch_assoc($res_items)) {
            $grn_items[] = $r;
        }
    }

    // attach items to grns
    foreach ($grns as $k => $g) {
        $grns[$k]['items'] = [];
        if (!empty($grn_items)) {
            foreach ($grn_items as $it) {
                if ($it['grn_id'] == $g['grn_id']) {
                    $grns[$k]['items'][] = $it;
                }
            }
        }
    }

    return ['grns' => $grns, 'total_grn' => $total_grn, 'total_tax' => $total_tax];
}

// Prepare report
$today = date('d M Y');
//$today = date('d M Y', strtotime('2026-08-27'));
$cronDate = date('Y-m-d H:i:s');

// Fetch Exempt and Taxable groups
$exempt = fetch_grns_by_tax('Exempt');
$taxable = fetch_grns_by_tax('Taxable');

$total_rows = count($exempt['grns']) + count($taxable['grns']);
echo "[Run Date $cronDate] $total_rows Records found..\n\n";

// Collect attachments from closed grns across both sets
$attachments = [];
foreach (array_merge($exempt['grns'], $taxable['grns']) as $row) {
    if ($row['status'] == 'Closed' && !empty($row['attachment_path'])) {
        if(array_search($row['attachment_path'], $attachments) === false){
            $attachments[] =  $row['attachment_path'];
        }
    }
}

// Build HTML sections
function build_section_html($title, $data) {
    $html = "<h3 style='font-family:Arial,Helvetica,sans-serif;'>$title</h3>";
    if (count($data['grns']) == 0) {
        $html .= "<p>No records found</p>";
        return $html;
    }

     $html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";

    // Added main table headers
    $html .= "<thead>
                                                    <tr>
                                                            <th width='10%' style='padding:3px;' bgcolor='#ccc'>ID</th>
                                                            <th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Invoice No</th>
                                                            <th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>LPO ID</th>
                                                            <th width='35%' style='padding:3px 4px;' bgcolor='#ccc'>Supplier</th>
                                                            <th width='15%' style='padding:3px 4px;' bgcolor='#ccc'>Issued By</th>
                                                            <th width='20%' style='padding:3px 4px;' bgcolor='#ccc'>GRN Value</th>
                                                    </tr>
                                            </thead>";
    foreach ($data['grns'] as $value) {
        $ref_yy = substr($value['grn_date'], 0, 4);
        $prefix = ($title == 'E-GRN (Exempt)') ? 'E-' : 'GRN-';
        $ref_no = $prefix . $ref_yy . '-' . leading_zero($value['grn_id'], 5);
        $supplier = $value['supplier_company'] ?? $value['lpo_supplier'];
        $grn_value = number_format($value['grn_value'], 0) . " TZS" ;
        
        $html .= "<tr><td colspan='6'>
                    <table width='100%'>
                      <tr>
                        <td width='10%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>{$ref_no}</td>
                        <td width='10%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>{$value['invoice_no']}</td>
                        <td width='10%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>{$value['lpo_id']}</td>
                        <td  width='35%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>{$supplier}</td>
                        <td width='15%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>{$value['user']}</td>
                        <td  width='20%' style='padding:3px 4px;' bgcolor='#d2cece' align='center'>{$grn_value}</td>
                      </tr>";

        $html .= "<tr><td colspan='6'><table width='100%'>
                   <tr>
                     <th>Item ID</th>
                     <th>Description</th>
                     <th>Category</th>
                     <th>Quantity</th>
                     <th>Unit Rate</th>
                     <th>Price</th>
                   </tr>";

        if (!empty($value['items'])) {
            foreach ($value['items'] as $item) {
                $category_name = $item['asset_category'] ? $item['asset_category'] : $item['category_name'];
                $item_price = number_format($item['item_unit_price'], 0);
                $item_total_price = number_format($item['item_unit_price'] * $item['grn_item_qty'], 0);
                $html .= "<tr>
                            <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$item['grn_item_id']}</td>
                            <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$item['item_description']}</td>
                            <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$category_name}</td>
                            <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$item['grn_item_qty']}</td>
                            <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$item_price}</td>
                            <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$item_total_price}</td>
                          </tr>";
            }
        } else {
            $html .= "<tr><td colspan='6'><p>No records found</p></td></tr>";
        }

        $html .= "</table></td></tr>";
    }

    // Totals for section
    $html .= "<tr><td colspan='6'>&nbsp;</td></tr>";
	if( $data['total_tax'] > 0 ) {
    $html .= "<tr><td align='left' colspan='2'><strong>Total GRN Value</strong></td><td colspan='2'  align='left'>".number_format($data['total_grn'], 0)." TZS</td></tr>";
    $html .= "<tr><td align='left' colspan='2'><strong>Total VAT Value</strong></td><td colspan='2'  align='left'>".number_format($data['total_tax'], 0)." TZS</td></tr>";
	}
	$grandTotal = $data['total_grn'] + $data['total_tax'];
    $html .= "<tr><td align='left' colspan='2'><strong>Grand Total</strong></td><td colspan='2'  align='left'>".number_format($grandTotal, 0)." TZS</td></tr>";
 
	$html .= "</table><br>";

    return $html;
}

$section_exempt_html = build_section_html('E-GRN (Exempt)', $exempt);
$section_taxable_html = build_section_html('GRN (Taxable)', $taxable);

// Build full email body
$grn_html = "<div style='font-family:Arial,Helvetica,sans-serif;'>";
$grn_html .= "<p>The following is a list of GRN records for today $today:</p><br>";
$grn_html .= $section_taxable_html;
$grn_html .= "<hr style='margin:20px 0;'>";
$grn_html .= $section_exempt_html;
$grn_html .= "</div>";


// Send email
$mail = new PHPMailer(true);

// Server settings
$mail->isSMTP();
$mail->Host = SMTP_HOST;  // Replace with your SMTP server
$mail->SMTPAuth = true;
$mail->Username = SMTP_USERNAME; // SMTP username
$mail->Password = SMTP_PASSWORD; // SMTP password
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587; // Usually 587 for TLS
$mail->isHTML(true);

$mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
$mail->Subject = "Identity App: GRN Report for $today";
$mail->addAddress('hasnain@identitytz.com');
$mail->addAddress('kazim@identitytz.com');
$mail->addAddress('accountsipl@identitytz.com');
$mail->addAddress('store@identitytz.com');
$mail->addAddress('procurement@identitytz.com');

// $mail->addAddress('beecraq@gmail.com');

// echo $grn_html;
// exit;

$mail->Body = $grn_html;

if(!empty($attachments)){
    foreach($attachments as $attch){
        $filepath = "$doc_root/{$config['attachment_dir']}$attch";
        if (file_exists($filepath)) {
            $mail->addAttachment($filepath);
        }
    }
}

if($mail->send()){
    echo "Email sent\n";
} else {
    echo "Email failed\n";
}

@mysql_close();


// Original helper retained
function search_key_value($array, $key, $value)
{
        $results = array();

        if (is_array($array)) {
                if (isset($array[$key]) && $array[$key] == $value) {
                        $results[] = $array;
                }

                foreach ($array as $subarray) {
                        $results = array_merge($results, search_key_value($subarray, $key, $value));
                }
        }

        return $results;
}
?>