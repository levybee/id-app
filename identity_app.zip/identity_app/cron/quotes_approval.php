<?php

require("/home/identity/public_html/app/configs/variables.php");

$approval_sql = "SELECT q. * , count( jos_quotes_items.quote_id ) AS quote_items_num, jos_customers_group.group_company, jos_customers.customer_id, jos_customers.customer_fname, jos_customers.customer_lname, jos_customers.customer_email
                    FROM `jos_quotes` AS q
                    LEFT JOIN `jos_quotes_items` ON jos_quotes_items.quote_id = q.quote_id
                    LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                    LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                    WHERE q.quote_status = 'Confirmed'
                    GROUP BY q.quote_id
                    ORDER BY q.quote_date DESC";

$result = mysql_query($approval_sql);

if(mysql_num_rows($result) > 0) {
    
    //var_dump($result);
    
    $quotes_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $quotes_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>ID</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Quote Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>No of Items</th> 
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th> 
                            </tr>
                        </thead>";
    $quotes_html .= "<tbody>";

    
    while ($row = mysql_fetch_assoc($result)) {
        
        $customer = ($row['customer_id'] == 0)? $row['quote_customer'] : $row['group_company']." - ". $row['customer_fname']." ".$row['customer_lname'];
        
        $date = date('d M Y', strtotime($row['quote_date']));
        
        $quotes_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['quote_id']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$customer."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['quote_items_num']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>Approve</a></td>    
						</tr>";

    }
    
    $quotes_html .= "</tbody></table>";
    
    //echo $quotes_html;
    
    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
     
    
    require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');
    
    
    $postmark = new Postmark\Mail($postmarkApiKey);
    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
    $postmark->subject('Identity App: Quotes Approval Notice');
    $postmark->addTo('hasnain@identitytz.com');
    $postmark->addTo('kazim@identitytz.com');
    $postmark->addTo('anthony@identitytz.com');
    
    $msg_body = "<p>The following quotes have been confirmed and have to be approved:</p><br>".$quotes_html;
    
    $postmark->messageHTML($msg_body);
    
    if($postmark->send()){
       // echo "Email sent";
    }
    
    // Load PHPMailer
    /*require("../configs/class.phpmailer.php");
    
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Host = "mail.identity.co.tz";
    $mail->SMTPAuth = true;
    $mail->Username = 'smtp@identity.co.tz';
    $mail->Password = 'smtppassword';
    
    $mail->From="info@identitytz.com";
    $mail->FromName="app.identitytz.com";
    $mail->Sender="info@identitytz.com";
    
    $mail->IsHTML(true);
    $mail->Subject = "Quotes Approval in Identity Job Order System";
    $mail->Body = "<p>The following quotes have been confirmed and have to be approved:</p>".$quotes_html;
    
    // Fetch 'quotes - approve' task_id
    $task_sql = "SELECT task_id FROM `cms_priv_tasks` WHERE task_section = 'quotes' AND task_action = 'approve'";
    $task_query = mysql_query($task_sql);
    $task_id = mysql_result($task_query, 0, 'task_id');
  
    
    // Loop through cms users and check if they have privilege to approve quotes
     $users_sql = "SELECT user_fname, user_lname, role_id FROM `cms_users` WHERE user_status = 'Active'";
    $users_query = mysql_query($users_sql);
    
    if(mysql_num_rows($users_query) > 0) {
        
        while ($user_row = mysql_fetch_assoc($users_result)) {
            
            $check_priv_sql = "SELECT * FROM `cms_priv_roles_tasks` WHERE role_id = '".$user_row['role_id']."' AND task_id = '".$task_id."'";
            $check_priv_query = mysql_query($check_priv_sql);
            
            if(mysql_num_rows($check_priv_query) == 1){// User has privilege send email
                
                $mail->AddAddress("email@example.com");
                
                if($mail->Send()) {
                
                    // Do something
                }
                     
            }
            
            // Clear sent email address
            $mail->ClearAddresses();
            
        }
          
    } */
    
}

