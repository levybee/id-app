<?php

/** Snapshot live WIP using the existing WIP calculation tables. Call once per month-end. */

header("Content-Type: text/plain");

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';

require_once( __DIR__."/../configs/variables.php");
require_once( __DIR__."/../configs/functions.php");

$cronDate = date('Y-m-d H:i:s');

$date=date('Y-m-d');
$date="2026-09-30";
$count=mmr_snapshot_wip($date);
echo "WIP snapshot {$date}: {$count} jobs\n";

function mmr_snapshot_wip($snapshotDate) {
    $date=$snapshotDate;
    $sql="SELECT j.job_id,j.department_id,d.department_name,
        IFNULL(stckQry.stock_value,0)*(1-IFNULL((invQry.qty_invoiced/j.job_paper_quantity)*100,0)/100) wip_value,
        IFNULL(stckQry.stock_qty,0) wip_qty
        FROM jos_jobs j
        LEFT JOIN jos_departments d ON d.department_id=j.department_id
        LEFT JOIN (SELECT qc.job_id,SUM(ii.item_quantity) qty_invoiced FROM jos_invoice_items ii LEFT JOIN jos_qc qc ON qc.id=ii.qc_id GROUP BY qc.job_id) invQry ON invQry.job_id=j.job_id
        LEFT JOIN (SELECT r.job_id,SUM(js.unit_price) stock_value,SUM(ri.quantity) stock_qty
            FROM jos_requisition_is jis
            LEFT JOIN jos_requisition_isi risi ON jis.ris_id=risi.ris_id
            LEFT JOIN jos_requisition_items ri ON ri.ri_id=risi.ri_id
            LEFT JOIN jos_stock js ON js.stock_id=ri.stock_id
            LEFT JOIN jos_requisition r ON r.requisition_id=ri.requisition_id
            WHERE jis.status='Issued' GROUP BY r.job_id) stckQry ON stckQry.job_id=j.job_id
        WHERE j.job_status='In Production'";
    $rows=smartsql($sql); $count=0;

    foreach((array)$rows as $r){
        $job=(int)$r['job_id'];
        mysql_query("INSERT INTO jos_finance_wip_snapshots (snapshot_date,job_id,department_id,department_name,wip_qty,wip_value)
            VALUES('$date',$job,".(int)$r['department_id'].",'".$r['department_name']."',".$r['wip_qty'].",".$r['wip_value'].")
            ON DUPLICATE KEY UPDATE department_id=VALUES(department_id),department_name=VALUES(department_name),wip_qty=VALUES(wip_qty),wip_value=VALUES(wip_value)");
        $count++;
    }
    return $count;
}

@mysql_close();
