<?php

// 0 	20 	* 	* 	1-6

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");


$th_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$th_html .= "<thead>
                        <tr>
                            <th width='110' style='padding:3px;' bgcolor='#ccc'>Type</th>
					                  <th style='padding:3px 4px;' bgcolor='#ccc'>Time</th>
					                  <th style='padding:3px 4px;' bgcolor='#ccc'>Client/Job/Quote</th>
                            <th style='padding:3px 4px;' bgcolor='#ccc'>Remarks</th>
                        </tr>
                    </thead>";
$th_html .= "<tbody>";

$users_sql = "SELECT user_id, CONCAT(user_fname, ' ', user_lname) as user, COALESCE(user_location, 'IPL1') as user_location 
FROM cms_users u
LEFT JOIN `cms_priv_roles` r ON r.role_id = u.role_id
WHERE r.role_name LIKE '%Sales%' AND exclude_sales_reports = 0 AND user_status = 'Active' ORDER BY user_location ASC, user_fname ASC, user_lname ASC";
$users_qry = mysql_query($users_sql);

$today = date('d M Y');
// $today = date('d M Y', strtotime('-1 day'));
 $date_sql = "DATE(NOW())";
//$date_sql = "'2026-03-18'";

$report_html = "";
echo "-- found ". mysqli_num_rows($users_qry)." users looping..\n";

// Group users by location
$users_by_location = array();
while ($user_row = mysql_fetch_assoc($users_qry)) {
    $location = $user_row['user_location'];
    if (!isset($users_by_location[$location])) {
        $users_by_location[$location] = array();
    }
    $users_by_location[$location][] = $user_row;
}

// Define location order (IPL1 first, then IPL2)
$location_order = array('IPL1', 'IPL2');
$ordered_locations = array();
foreach ($location_order as $loc) {
    if (isset($users_by_location[$loc])) {
        $ordered_locations[$loc] = $users_by_location[$loc];
    }
}
// Add any other locations that weren't in the predefined order
foreach ($users_by_location as $loc => $users) {
    if (!isset($ordered_locations[$loc])) {
        $ordered_locations[$loc] = $users;
    }
}

// Process reports by location
foreach ($ordered_locations as $location => $location_users) {
    $report_html .= "<h2 style='margin-top: 20px; border-bottom: 2px solid #333; padding-bottom: 10px;'>" . htmlspecialchars($location) . "</h2>";
    
    foreach ($location_users as $user_row) {

      $user_id = $user_row['user_id'];

      $search_ext_sr = " WHERE DATE(sr.date_created) = $date_sql AND sr.user_id = '$user_id' ";
      $search_ext_vp = " WHERE vp.vp_date = CURRENT_DATE AND vp.user_id = '$user_id' ";
      $search_ext_jb = " WHERE jb.user_id = '$user_id' AND DATE(jb.date_created) = $date_sql ";
      $search_ext_q = " WHERE q.user_id = '$user_id' AND DATE(q.quote_date) = $date_sql ";
      // $search_ext_q = " WHERE q.user_id IN (SELECT user_id
      //                         FROM jos_sales_report
      //                         WHERE DATE(date_created) = $date_sql) AND DATE(q.quote_date) = $date_sql AND q.user_id = '$user_id' ";

      // $search_ext_jb = " WHERE jb.user_id IN (SELECT user_id
      //                               FROM jos_sales_report
      //        


      $report_sql = "SELECT * FROM (SELECT
        sr.id,
        sr.report_type,
        sr.collection_amount,
        sr.payment_expected_date,
        sr.remarks,
        sr.date_created,
        g.group_company,
        j.job_id,
        j.job_date,
        j.job_reference,
        NULL AS quote_id,
        NULL AS quote_date,
        NULL AS quote_reference,
        NULL as jb_id,
        NULL as jb_reference,
        NULL as jb_group_company,
        CONCAT( u.user_fname, ' ', u.user_lname) as username

      FROM
          jos_sales_report sr
      LEFT JOIN jos_customers_group g ON
          g.group_id = sr.group_id
      LEFT JOIN jos_jobs AS j
      ON
          j.job_id = sr.job_id
      LEFT JOIN cms_users u ON
          u.user_id = sr.user_id
          $search_ext_sr
      UNION
          (
          SELECT NULL AS
          id,
          'Quotes Issued' AS report_type,
          NULL as collection_amount,
          NULL as payment_expected_date,
          NULL AS remarks,
          q.date_created,
          NULL AS group_company,
          NULL AS job_id,
          NULL AS job_date,
          NULL AS job_reference,
          q.quote_id,
          q.quote_date,
          qg.group_company AS quote_reference,
          NULL as jb_id,
          NULL as jb_reference,
          NULL as jb_group_company,
          CONCAT( u.user_fname, ' ', u.user_lname) as username
          FROM
              jos_quotes q
          LEFT JOIN jos_customers c ON
              c.customer_id = q.customer_id
          LEFT JOIN jos_customers_group qg ON
              qg.group_id = c.group_id
          LEFT JOIN cms_users u ON
              u.user_id = q.user_id
          $search_ext_q)
          UNION (

            SELECT NULL AS id,
                  'Jobs Issued' AS report_type,
                  NULL as collection_amount,
                  NULL as payment_expected_date,
                  NULL AS remarks,
                  jb.date_created,
                  NULL AS group_company,
                  NULL AS job_id,
                  NULL AS job_date,
                  NULL AS job_reference,
                  NULL quote_id,
                  NULL quote_date,
                  NULL AS quote_reference,
                  jb.job_id as jb_id,
                  jb.job_reference as jb_reference,
                  cgj.group_company as jb_group_company,
                  CONCAT(u.user_fname, ' ', u.user_lname) AS username


              FROM
                  jos_jobs as jb
                  LEFT JOIN `jos_jobs_groups` as g
                  ON g.group_id = jb.group_id
                  LEFT JOIN `jos_customers` as c
                  ON c.customer_id = g.customer_id
                  LEFT JOIN `jos_customers_group` as cgj
                  ON cgj.group_id = c.group_id
              LEFT JOIN cms_users u ON
                  u.user_id = jb.user_id
              $search_ext_jb
          )

          UNION (

            SELECT NULL AS id,
                  'Visit Plan' AS report_type,
                  NULL as collection_amount,
                  NULL as payment_expected_date,
                  CONCAT(vp.remarks, ' - ', vp.visit_location) AS remarks,
                  CONCAT(vp.vp_date, ' ', vp.vp_time) AS date_created,
                  IF(vp.group_id > 0, g.group_company, vp.client_name) AS group_company,
                  NULL AS job_id,
                  NULL AS job_date,
                  NULL AS job_reference,
                  NULL AS quote_id,
        NULL AS quote_date,
        NULL AS quote_reference,
        NULL as jb_id,
        NULL as jb_reference,
        NULL as jb_group_company,
        CONCAT( u.user_fname, ' ', u.user_lname) as username
    FROM  jos_sales_visitplan vp
    LEFT JOIN jos_customers_group g
    ON g.group_id = vp.group_id
LEFT JOIN cms_users u ON u.user_id = vp.user_id
              $search_ext_vp
          )


        ) a ORDER BY report_type, date_created ASC";

          // echo $report_sql;
          // exit;

        $report_result = mysql_query($report_sql);


        $report_html .= "<h3>".$user_row['user']."</h3>";
        $report_html .= $th_html;

        $bg_color1 = '#fcfcfc';
           $bg_color2 = '#e5e5e5';
           $row_color = $bg_color1;

         if(mysql_num_rows($report_result) > 0) {



           while ($row = mysql_fetch_assoc($report_result)) {

               $time = "";
               if($row['date_created']){
                 $time = date('H:i:s', strtotime($row['date_created']));
               }

               $q_ref_no = "";
               if($row['quote_id']){
                 $ref_yy = substr($row['quote_date'], 0, 4);
                 $ref_mm = substr($row['quote_date'], 5, 2);
                 $q_ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
               }

               $j_ref_no = "";
               if($row['job_id']){
                 $ref_yy = substr($row['job_date'], 0, 4);
                 $ref_mm = substr($row['job_date'], 5, 2);
                 $j_ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['job_id'], 5);
               }

               $info = "";

               if($row['report_type'] == 'Clients Visited' || $row['report_type'] == 'Collections'){
                  $info = $row['group_company'];
               }

               $collection_amount = "";
               $payment_expected_date = "";
               if($row['report_type'] == 'Collections'){
                 $collection_amount = ($row['collection_amount'] > 0)? number_format($row['collection_amount']) : '';
                 $payment_expected_date = ($row['payment_expected_date'])? date('d/m/Y', strtotime($row['payment_expected_date'])) : '';
               }

               if($row['report_type'] == 'Jobs Follow Up'){
                  $info = $j_ref_no.": {$row['job_reference']}";
               }

               if($row['report_type'] == 'Quotes Issued'){
                  $info = $q_ref_no.": {$row['quote_reference']}";
               }

               if($row['report_type'] == 'Jobs Issued'){
                  $info = "{$row['jb_id']}: {$row['jb_reference']} - {$row['jb_group_company']}";
               }

               $collectionHtml = '';
               if($collection_amount){
                 $collectionHtml .= "<br><strong>Collection Amount:</strong> $collection_amount";
                 $collectionHtml .= "<br><strong>Expected Payment Date:</strong> $payment_expected_date";
               }


               $report_html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['report_type']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$time</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$info $collectionHtml</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color'>{$row['remarks']}</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }




         }else{
           echo "-- no records for user #$user_id - [{$user_row['user']}]\n";
           $report_html .= "<tr>
                            <td colspan='4' style='padding:3px 4px;' bgcolor='$row_color'>No records found</td>
                       </tr>";
         }

         $report_html .= "</tbody></table><br><br>";

    }
}


  $msg_body = "<p>Sales Report per user for the date $today</p><br>";
  $msg_body .= $report_html;

    //   echo $msg_body;
    //   exit;
    require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included

     $mail = new PHPMailer(true);

     // Server settings
     $mail->isSMTP();
     $mail->Host = SMTP_HOST;  // Replace with your SMTP server
     $mail->SMTPAuth = true;
     $mail->Username = SMTP_USERNAME; // SMTP username
     $mail->Password = SMTP_PASSWORD; // SMTP password
     $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
     $mail->Port = 587; // Usually 587 for TLS
     $mail->isHTML(true);

     $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
     $mail->Subject = 'Identity App: User Sales Report Daily Notice';

     $mail->addAddress('hasnain@identitytz.com');
     $mail->addAddress('kazim@identitytz.com');
     $mail->addAddress('hr@identitytz.com');
    // $mail->addAddress('floor@identitytz.com');
     // $mail->addAddress('collections@identitytz.com');
    // $mail->addAddress('reception@identitytz.com');
     // $mail->addAddress('beecraq@gmail.com');

    //  echo $msg_body;
    //  exit;

    $mail->Body = $msg_body;

    if($mail->send()){
        echo "Email sent";
    }
