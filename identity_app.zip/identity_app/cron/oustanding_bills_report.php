<?php

// 30 	9 	* 	* 	1,5

// ini_set('display_errors', 1);
// error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included

$HOME_DIR = '/home/identity/public_html/app/';
include_once($HOME_DIR.'modules/bills/print.class.php');

$bill_items = array();
$bills = array();
$today = date('d M Y');

$bill_sql = "SELECT jb.*, ji.invoice_currency,
    IF(ji.tax = 'Taxable',
         SUM(ii.item_quantity * ii.item_price) + (SUM(ii.item_quantity * ii.item_price) * (IF(ji.vat > 0, (ji.vat / 100), 0))),
         SUM(ii.item_quantity * ii.item_price)) as bill_amount,

         IFNULL((SELECT
             SUM(ri.item_amount)

         FROM
             jos_receipt_items ri

         		LEFT JOIN jos_receipts r
             ON r.receipt_id = ri.receipt_id

         WHERE
             ri.quote_invoice_id = ji.invoice_id AND r.receipt_type = 'Invoice' AND r.status = 'Valid'
         GROUP BY
             ri.quote_invoice_id
         ) , 0) AS amount_received,

       cg.group_company,cg.group_id, cg.notification_email,ji.invoice_id,ji.invoice_date,jg.job_lpo_other,
       GROUP_CONCAT(cu.customer_fname,' ',cu.customer_lname) as customer_name,
       cu.customer_email, sales_u.user_email,
       cg.credit_terms,
        DATEDIFF(NOW(), ji.invoice_date) as age_diff,
        (IF(cg.credit_terms > 0 AND (DATEDIFF(NOW(), ji.invoice_date)) > cg.credit_terms, (DATEDIFF(NOW(), ji.invoice_date)) - cg.credit_terms, '-')) as overage
    FROM jos_bills as jb

    LEFT JOIN jos_invoices as ji
       ON  ji.invoice_id = jb.invoice_id

    LEFT JOIN jos_invoice_items as ii
        ON ji.invoice_id = ii.invoice_id

    LEFT JOIN jos_customers as cu
       ON cu.customer_id = ji.customer_id

    LEFT JOIN jos_customers_group as cg
       ON cg.group_id = cu.group_id

       LEFT JOIN jos_qc AS qc
ON qc.id = ii.qc_id

LEFT JOIN jos_jobs AS j
ON qc.job_id = j.job_id

     LEFT JOIN jos_jobs_groups as jg
       ON jg.group_id = j.group_id

      LEFT JOIN cms_users  as u
         ON u.user_id = jb.user_id

      LEFT JOIN cms_users as sales_u
      ON sales_u.user_id = cg.salesperson_user_id

         WHERE jb.status = 'Pending' AND ji.invoice_status != 'Cancelled'
         AND cg.outstanding_report  != 'No'

      GROUP BY ji.invoice_id ORDER BY  jb.id ASC";

$result_bill = mysql_query($bill_sql);

$cronDate = date('Y-m-d H:i:s');
$rows = mysql_num_rows($result_bill);

echo "[Run Date $cronDate] $rows Records found..\n\n";

if(mysql_num_rows($result_bill) > 0) {



  // Generate reprt company wise
  $report = array();
  while ($row = mysql_fetch_assoc($result_bill)) {

    $report[$row['group_id']][] = $row;

  }

	   //print_r($report);
	   //exit;


  $counter=0;

  foreach ($report as $grp_id => $grp_array) {

      $counter++;

    // Create HTML email content
  	$bill_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
  	$bill_html .= "<thead>
  													<tr>
                                <th width='15%' style='padding:3px 4px;' bgcolor='#ccc'>Bill Date</th>
  															<th width='10%' style='padding:3px;' bgcolor='#ccc'>Invoice No</th>
                                <th width='10%' style='padding:3px;' bgcolor='#ccc'>LPO No</th>
  															<th width='10%' style='padding:3px 4px;' bgcolor='#ccc'>Amount (TZS)</th>
                                <th width='30%' style='padding:3px 4px;' bgcolor='#ccc'>Days Overdue</th>
  													</tr>
  											</thead>";
  	$bill_html .= "<tbody>";

    $bg_color1 = '#fcfcfc';
    $bg_color2 = '#e5e5e5';
    $row_color = $bg_color1;
    $company_name = $grp_array[0]['group_company'];
    $customer_name = (isset($grp_array[0]['customer_name']))? $grp_array[0]['customer_name'] : 'Sir/Madam';
    $customer_email = trim($grp_array[0]['notification_email'])? trim($grp_array[0]['notification_email']) : trim($grp_array[0]['customer_email']);
    $emails = explode(",",$customer_email);
    
    $user_email = trim($grp_array[0]['user_email']);
    $total = 0;


    foreach ($grp_array as $row) {

        $bill_amount = $row['bill_amount'] - $row['amount_received'];
        if($bill_amount == 0) continue;
        $date = date('d M Y', strtotime($row['date_created']));
        $total += $bill_amount;
        $amount = number_format($bill_amount, 2);

        $bill_html .= "<tr>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['invoice_id']}</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['job_lpo_other']}</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$amount</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['overage']}</td>
             </tr>";

        if($row_color == $bg_color1){
          $row_color = $bg_color2;
        }elseif($row_color == $bg_color2){
          $row_color = $bg_color1;
        }
    }

    if($total == 0 || !($row['overage'] >= 1)) continue; // If outstanding is zero dont send statement
    
     echo "Preparing report for group [$grp_id - $company_name]..\n\n";

    $subtotal = $total;
    $total = number_format($total, 2);

    $bill_html .= "<tr>
            <td style='padding:3px 4px;' bgcolor='$row_color' align='right' colspan='3'><strong>Sub Total</strong></td>
            <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><strong>$total</strong></td>
            <td style='padding:3px 4px;' bgcolor='$row_color'></td>
         </tr>";

   // Get On Account values
   $on_acc_sql = "SELECT r.receipt_id, r.receipt_date, r.on_account
                 FROM jos_receipts r
                 LEFT JOIN jos_customers c
                 ON c.customer_id = r.customer_id
                 WHERE c.group_id = '$grp_id' AND r.on_account > 0 AND r.status = 'Valid'";
   $on_acc_items = smartsql($on_acc_sql);

   $on_account_total = 0;
   if(count($on_acc_items) > 0){
     foreach ($on_acc_items as $k => $oc_v) {
       $on_account_total += $oc_v['on_account'];
     }

     if($on_account_total > $subtotal){
         $net_total =  number_format($on_account_total - $subtotal, 2);
     }else{
        $net_total =  number_format($subtotal - $on_account_total, 2);
     }




     foreach ($on_acc_items as $k => $v) {

       $acc_date = date('d/m/Y', strtotime($v['receipt_date']));
       $on_account = number_format($v['on_account'], 2);

       $bill_html .= "<tr>
               <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$acc_date</td>
               <td style='padding:3px 4px;' bgcolor='$row_color'></td>
               <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>On Account</td>
               <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>($on_account)</td>
               <td style='padding:3px 4px;' bgcolor='$row_color'></td>
            </tr>";

     }

     $bill_html .= "<tr>
             <td style='padding:3px 4px;' bgcolor='$row_color'></td>
             <td style='padding:3px 4px;' bgcolor='$row_color'></td>
             <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><strong>Net Amount</strong></td>
             <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><strong>($net_total)</strong></td>
             <td style='padding:3px 4px;' bgcolor='$row_color'></td>
          </tr>";


   }


    $bill_html .= "</tbody></table>";


    // if($customer_email == 'mwasi.makenge@cbm.org') continue;

    // if (!filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
    //     continue;
    // }
    

   //  $customer_email = 'beecraq@gmail.com';

    if($emails){
    

      $subject = "Outstanding Due for Payment - $company_name - as of $today";

      $mail = new PHPMailer(true);

      // Server settings
      $mail->isSMTP();
      $mail->Host = SMTP_HOST;  // Replace with your SMTP server
      $mail->SMTPAuth = true;
      $mail->Username = SMTP_USERNAME; // SMTP username
      $mail->Password = SMTP_PASSWORD; // SMTP password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
      $mail->Port = 587; // Usually 587 for TLS
      $mail->isHTML(true);

      $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
      $mail->Subject = $subject;
      $mail->addReplyTo('collections@identitytz.com');
      // $mail->addAddress('beecraq@gmail.com');
      // $mail->addAddress('hasnain@identitytz.com');
     // $mail->addAddress('kazim@identitytz.com');
      // $mail->addAddress('accounts@identitytz.com');
       $mail->addAddress('vijay@identitytz.com');
       $mail->addAddress('collections@identitytz.com');
       foreach($emails as $e){
         if(filter_var($e, FILTER_VALIDATE_EMAIL)){
           $mail->addAddress($e);
         }
       }

     //  $mail->addAddress('beecraq@gmail.com');

       if($user_email){
           $mail->addAddress($user_email);
       }


      $msg_body = "Dear $company_name";
      $msg_body .= "<p>The following is an oustanding statement for your company [$company_name] from Identity Promotions Ltd:</p><br>".$bill_html;
      $msg_body .= "<br><p>We appreciate your business and timely payment according to the agreed terms. Do not hesitate to contact us for any queries related to the above at collections@identitytz.com</p>";
      $msg_body .= "<br><p>Accounts Department</p>";
      $msg_body .= "<p>Identity Promotions Ltd</p>";

      $mail->Body = $msg_body;

      // Attachment
      $send_email = 1;
      $uid = $grp_id;


      $file_path = '';
      include($HOME_DIR.'modules/bills/print.output.php');

      if($file_path) {

          $mail->addAttachment($file_path);
          //unlink($file_path);
      }

    //   echo $msg_body;
    //   exit;

     if($mail->send()){
         echo "Email sent to ".$customer_email." \n";
         // exit;
      }

     // if($counter > 3){ echo "enough"; exit; }

    }

  }

  echo "Done..\n";

}else{
  echo "No records found..\n";
}
