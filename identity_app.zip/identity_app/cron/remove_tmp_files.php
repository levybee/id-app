<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

header("Content-Type: text/plain");
$cronDate = date('Y-m-d H:i:s');
echo "[Run Date $cronDate] Deleting pdf files..\n\n";

$tmp_path = __DIR__ . "/../tmp/";
//var_dump(file_exists($tmp_path));
//echo $tmp_path;
//exit;

//chmod_r($tmp_path); no need for this, only parent folder has to be 0777
$del = array_map('unlink', glob( "$tmp_path*.pdf"));
var_dump($del);


function chmod_r($path) {
    $dir = new DirectoryIterator($path);
    foreach ($dir as $item) {
        chmod($item->getPathname(), 0777);
        if ($item->isDir() && !$item->isDot()) {
            chmod_r($item->getPathname());
        }
    }
}
