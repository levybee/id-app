<?php

use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included


$head_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$head_html .= "<thead>
                      <tr>
                          <th width='110' style='padding:3px;' bgcolor='#ccc'>Ref #</th>
                      <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
                      <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
                      <th style='padding:3px 4px;' bgcolor='#ccc'>Receipt Amount (TZS)</th>
                      <th style='padding:3px 4px;' bgcolor='#ccc'>Commission (TZS)</th>
                      </tr>
                    </thead>";
$head_html .= "<tbody>";

$users_sql = "SELECT user_id,CONCAT(user_fname, ' ', user_lname) as user FROM cms_users WHERE (role_id = 5 OR role_id = 20) AND exclude_sales_reports = 0 AND user_status = 'Active'";
$users_qry = mysql_query($users_sql);

while ($user_row = mysql_fetch_assoc($users_qry)) {

      $user_name = $user_row['user'];
      $user_id = $user_row['user_id'];
      $user_email = $user_row['user_email'];

      $receipt = "SELECT
        r.receipt_id,
        r.receipt_date,
        cg.group_company,
        r.receipt_amount,
        q.quote_id,
        ii.invoice_id,
        u.user_id,
        u.user_fname,
        u.user_lname,
          (CASE
    		     WHEN cg.commission_structure = 'Key Account' THEN (r.receipt_amount * 0.001)
    		     WHEN cg.commission_structure = 'Standard' THEN (r.receipt_amount * 0.002)
    				 WHEN cg.commission_structure = 'Bulk' THEN (r.receipt_amount * 0.0006)
    				 ELSE NULL END) as commission_amount

    FROM
        jos_receipts r
    LEFT JOIN jos_receipt_items AS ri
    ON
        r.receipt_id = ri.receipt_id
    LEFT JOIN jos_invoice_items ii ON

        ii.invoice_id = ri.quote_invoice_id
    LEFT JOIN jos_dn_items dni ON
        dni.dn_item_id = ii.dn_item_id
    LEFT JOIN jos_jobs jb ON
        jb.job_id = dni.job_id
    LEFT JOIN jos_quotes_items qi ON
        qi.item_id = jb.item_id
        -- First join for qi.quote_id
        LEFT JOIN jos_quotes q1
            ON q1.quote_id = qi.quote_id
        -- Second join for ri.quote_invoice_id when receipt_type = 'Quote'
        LEFT JOIN jos_quotes q2
            ON q2.quote_id = ri.quote_invoice_id
            AND r.receipt_type = 'Quote'
        -- Coalesce to pick the first non-null quote_id
        LEFT JOIN jos_quotes q
            ON q.quote_id = COALESCE(q1.quote_id, q2.quote_id)
    LEFT JOIN cms_users u ON
        u.user_id = q.user_id
    LEFT JOIN jos_customers AS cu
    ON cu.customer_id = r.customer_id
    LEFT JOIN jos_customers_group AS cg
    ON cg.group_id = cu.group_id

      WHERE r.status = 'Valid' AND r.receipt_amount > 0
      AND DATEDIFF(NOW(),r.receipt_date) <= 7 AND q.user_id = $user_id

      GROUP BY r.receipt_id ORDER BY r.receipt_date DESC";

        $receipt_qry = mysql_query($receipt);


         if(mysql_num_rows($receipt_qry) > 0) {

           $total_value = 0;

           $receipt_html = "";
           $receipt_html .= $head_html;

           $bg_color1 = '#fcfcfc';
           $bg_color2 = '#e5e5e5';
           $row_color = $bg_color1;
           while ($row = mysql_fetch_assoc($receipt_qry)) {


               $date = date('d M Y', strtotime($row['receipt_date']));
               $ref_yy = substr($row['receipt_date'], 0, 4);
               $ref_mm = substr($row['receipt_date'], 5, 2);
               $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['receipt_id'], 5);
               $customer = $row['group_company'];
               $value = number_format($row['receipt_amount'], 2);
               $commission = ($row['commission_amount'] > 0)? number_format($row['commission_amount'], 2) : '-';
               $total_value += $row['receipt_amount'];
               $total_commission += $row['commission_amount'];


               $receipt_html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='http://app.identitytz.com/receipts/view/?id=".$row['receipt_id']."'>$ref_no</a></td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$customer</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$value</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$commission</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }
           $total = number_format($total_value, 2);
           $receipt_html .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' colspan='3' align='right'><strong>TOTAL</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' align='center'>$total</td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' align='center'>$total_commission</td>
                                     </tr>";
           $receipt_html .= "</tbody></table>";


         }

         //echo $msg_body;
         $msg_body = "<p>Performance Report [$user_name]: Receipts Weekly.</p><br>";
         $msg_body .= $receipt_html;


        //   echo $msg_body;
        //   exit;

        $mail = new PHPMailer(true);

        // Server settings
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;  // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME; // SMTP username
        $mail->Password = SMTP_PASSWORD; // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587; // Usually 587 for TLS
        $mail->isHTML(true);

        $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
        $mail->Subject = "Identity App: Performance Report [$user_name] - Receipts Weekly Notice";

        $mail->addAddress('hasnain@identitytz.com');
        // $mail->addAddress('kazim@identitytz.com');
        // $mail->addAddress('hr@identitytz.com');
        $mail->addAddress($user_email);

        // $mail->addAddress('beecraq@gmail.com');

        $mail->Body = $msg_body;

        if($mail->send()){
            echo "Email sent ";
        }

}
