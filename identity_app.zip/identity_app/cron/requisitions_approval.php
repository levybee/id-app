<?php

require("/home/identity/public_html/app/configs/variables.php");

$approval_sql = 'SELECT r.*, js.units, js.stock_name, js.stock_qty, 
	                    jd.department_name, j.job_reference, cg.group_company
						FROM `jos_requisitions` as r
                	    LEFT JOIN `jos_stock` as js
                          ON js.stock_id = r.stock_id
	                    LEFT JOIN `jos_jobs` as j
	                      ON j.job_id = r.job_id
                        LEFT JOIN `jos_departments` as jd
                          ON jd.department_id = j.department_id
	                    LEFT JOIN `jos_jobs_groups` as g
					     ON g.group_id = j.group_id
	                   LEFT JOIN `jos_customers` as c
					     ON c.customer_id = g.customer_id
			
					   LEFT JOIN `jos_customers_group` as cg
					     ON cg.group_id = c.group_id
                       WHERE r.status = "Draft"
						ORDER BY r.requisition_date DESC;';



$result = mysql_query($approval_sql);

if(mysql_num_rows($result) > 0) {
    
    //var_dump($result);
    
    $requisitions_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $requisitions_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>ID</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Requisition Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Item</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Job Reference</th> 
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Department</th> 
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Required Qty</th> 
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Qty in Stock</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th> 
                            </tr>
                        </thead>";
    $requisitions_html .= "<tbody>";

    
    while ($row = mysql_fetch_assoc($result)) {
         
        $date = date('d M Y', strtotime($row['requisition_date']));
        $remarks = ($row['remarks'] == '')? '': ' - '.$row['remarks'];
        $item = ($row['stock_id'] == 0)? $row['item_description'].$remarks:$row['stock_name'].$remarks;
        $department = (isset($row['department_name']))? $row['department_name']: ' - ';
        $job_reference = ($row['job_id'] != 0)? $row['job_id'].': '.$row['job_reference'].' - '.$row['group_company']:' - ';
        
        $requisitions_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['requisition_id']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$job_reference."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$department."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['quantity']." ".$row['units']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['stock_qty']." ".$row['units']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/requisitions/?actn=approve&id=".$row['requisition_id']."'>Approve</a></td>    
						 </tr>";

    }
    
    $requisitions_html .= "</tbody></table>";
    
   // echo $requisitions_html;
    
    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
     
    
    require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');
    
    
    $postmark = new Postmark\Mail($postmarkApiKey);
    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
    $postmark->subject('Identity App: Requisitions Approval Notice');
    $postmark->addTo('hasnain@identitytz.com');
   // $postmark->addTo('kazim@identitytz.com');
   // $postmark->addTo('gm@identitytz.com');
    
    $msg_body = "<p>The following requisitions require approval:</p><br>".$requisitions_html;
    
    $postmark->messageHTML($msg_body);
    
   if($postmark->send()){
       // echo "Email sent";
    }
    
    
}

