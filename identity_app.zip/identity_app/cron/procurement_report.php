<?php
// This report will be sent at 5pm daily and on Saturdays at 1pm

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");

$qcs = array();
$today = date('d M Y');
$sql_date = date('Y-m-d');

$bg_color1 = '#fcfcfc';
$bg_color2 = '#e5e5e5';
$row_color = $bg_color1;

// Pending Stock Refill
$stock_refill_sql = "SELECT
    r.*, CONCAT(u.user_fname, ' ', u.user_lname) AS user,
    js.units,
    js.stock_name,
    js.stock_qty,
    (r.quantity - r.issued_qty) AS balance_qty,
    jd.department_name,
    j.job_reference,
    cg.group_company,
    (
    SELECT
        SUM(lpoi.item_qty)
    FROM
        jos_lpo lpo
    LEFT JOIN jos_lpo_items lpoi ON
        lpoi.lpo_id = lpo.lpo_id
    WHERE
        lpoi.stock_id = js.stock_id AND lpo.lpo_status IN ('Pending', 'Approved')
    GROUP BY
        lpo.lpo_id
    LIMIT 1
) AS qty_ordered,(
    SELECT
        lpo.lpo_id
    FROM
        jos_lpo lpo
    LEFT JOIN jos_lpo_items lpoi ON
        lpoi.lpo_id = lpo.lpo_id
    WHERE
        lpoi.stock_id = js.stock_id AND lpo.lpo_status IN('Pending', 'Approved')
    GROUP BY
        lpo.lpo_id
    LIMIT 1
) AS lpo
FROM
    `jos_requisitions` AS r
LEFT JOIN `jos_stock` AS js
ON
    js.stock_id = r.stock_id
LEFT JOIN `jos_jobs` AS j
ON
    j.job_id = r.job_id
LEFT JOIN `jos_departments` AS jd
ON
    jd.department_id = j.department_id
LEFT JOIN `jos_jobs_groups` AS g
ON
    g.group_id = j.group_id
LEFT JOIN `jos_customers` AS c
ON
    c.customer_id = g.customer_id
LEFT JOIN `jos_customers_group` AS cg
ON
    cg.group_id = c.group_id
LEFT JOIN `cms_users` AS u
ON
    u.user_id = r.user_id
LEFT JOIN `cms_users` AS ua
ON
    ua.user_id = r.approval_user_id
WHERE r.requisition_for = 'Stock Refill'
AND  date(r.requisition_date) = '$sql_date'
AND r.status IN  ('Draft', 'Approved')
ORDER BY r.requisition_id DESC";

$result_stock_refill = mysql_query($stock_refill_sql);


$stock_refill_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$stock_refill_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>Requisition ID</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Item</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Required Qty</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Qty Ordered</th>
                              <th style='padding:3px;' bgcolor='#ccc'>User</th>
													</tr>
											</thead>";
	$stock_refill_html .= "<tbody>";

if(mysqli_num_rows($result_stock_refill) > 0) {

	// Create HTML email content
  while ($row = mysql_fetch_assoc($result_stock_refill)) {
     // $date_required = date('d/m/Y', strtotime($row['date_required']));
			$item = ($row['stock_id'] > 0)? $row['stock_name'] : $row['item_description'] ;
			$qty_ordered = "";
      if($row['qty_ordered'] > 0){
        $qty_ordered = $row['qty_ordered']." ".$row['units'];
				if($row['lpo']){
					$qty_ordered .= " <br/>(LPO #{$row['lpo']})";
				}

			}

      $stock_refill_html .= "<tr>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='https://app.identitytz.com/requisitions?id={$row['requisition_id']}'>{$row['requisition_id']}</a></td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$item</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['quantity']} {$row['units']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$qty_ordered</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['user']."</td>
           </tr>";

      if($row_color == $bg_color1){
        $row_color = $bg_color2;
      }elseif($row_color == $bg_color2){
        $row_color = $bg_color1;
      }
  }


}else{

  $stock_refill_html .= "<tr>
              <td colspan='5' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No pending stock refill records found</td>
           </tr>";

}

$stock_refill_html .= "</tbody></table>";


// Collection After COB
$cob_sql = "SELECT
    l.lpo_id,
    l.lpo_date,
    l.date_created,
    l.lpo_attention,
    l.lpo_status,
    l.lpo_supplier,
    l.lpo_destination,
    l.comments,
    s.supplier_id,
    s.supplier_fname,
    s.supplier_lname,
    s.supplier_company,
    l.payment_type,
    l.cob,
		CONCAT(u.user_fname, ' ', u.user_lname) AS user
FROM
    `jos_lpo` AS l
LEFT JOIN `jos_suppliers` AS s
ON
    s.supplier_id = l.supplier_id
LEFT JOIN `cms_users` AS u
ON u.user_id = l.user_id
WHERE date(l.lpo_date) = '$sql_date'
AND l.cob = '1'
GROUP BY
    l.lpo_id
ORDER BY l.lpo_date
DESC, l.lpo_id DESC";

$result_cob = mysql_query($cob_sql);


$cob_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$cob_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>LPO ID</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Supplier</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Payment Type</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Destination</th>
															<th style='padding:3px;' bgcolor='#ccc'>Comments</th>
                              <th style='padding:3px;' bgcolor='#ccc'>User</th>
													</tr>
											</thead>";
	$cob_html .= "<tbody>";

if(mysqli_num_rows($result_cob) > 0) {

  while ($row = mysql_fetch_assoc($result_cob)) {

			$date = date('d/m/Y', strtotime($row['date_created']));
			$time = date('H:i:s', strtotime($row['date_created']));
			$lpo_date = "$date <br>($time)";
			$supplier = ($row['supplier_id'] > 0)? $row['supplier_company'] : $row['supplier'] ;

      $cob_html .= "<tr>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='https://app.identitytz.com/lpo/print?uid={$row['lpo_id']}'>{$row['lpo_id']}</a></td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$supplier</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['payment_type']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['lpo_destination']."</td>
							<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['comments']."</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['user']."</td>
           </tr>";

      if($row_color == $bg_color1){
        $row_color = $bg_color2;
      }elseif($row_color == $bg_color2){
        $row_color = $bg_color1;
      }
  }



}else{

  $cob_html .= "<tr>
              <td colspan='6' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No LPOs for Collection After COB found</td>
           </tr>";

}

$cob_html .= "</tbody></table>";



// Cash Purchases Pending
$cash_sql = "SELECT
    l.lpo_id,
    l.lpo_date,
    l.date_created,
    l.lpo_attention,
    l.lpo_status,
    l.lpo_supplier,
    l.lpo_destination,
    l.comments,
    s.supplier_id,
    s.supplier_fname,
    s.supplier_lname,
    s.supplier_company,
    l.payment_type,
    l.cob,
		CONCAT(u.user_fname, ' ', u.user_lname) AS user
FROM
    `jos_lpo` AS l
LEFT JOIN `jos_suppliers` AS s
ON
    s.supplier_id = l.supplier_id
LEFT JOIN `cms_users` AS u
ON u.user_id = l.user_id
WHERE date(l.lpo_date) = '$sql_date'
/* AND l.payment_type = 'Cash' */
AND l.lpo_status IN ('Pending')
GROUP BY
    l.lpo_id
ORDER BY l.lpo_date
DESC, l.lpo_id DESC";

$result_cash = mysql_query($cash_sql);


$cash_lpo_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$cash_lpo_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>LPO ID</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Supplier</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Destination</th>
															<th style='padding:3px;' bgcolor='#ccc'>Comments</th>
                              <th style='padding:3px;' bgcolor='#ccc'>User</th>
													</tr>
											</thead>";
	$cash_lpo_html .= "<tbody>";

if(mysqli_num_rows($result_cash) > 0) {

	// Create HTML email content
  while ($row = mysql_fetch_assoc($result_cash)) {

		$date = date('d/m/Y', strtotime($row['date_created']));
		$time = date('H:i:s', strtotime($row['date_created']));
		$lpo_date = "$date <br>($time)";
		$supplier = ($row['supplier_id'] > 0)? $row['supplier_company'] : $row['supplier'] ;

		$cash_lpo_html .= "<tr>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='https://app.identitytz.com/lpo/print?uid={$row['lpo_id']}'>{$row['lpo_id']}</a></td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$supplier</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['lpo_destination']."</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['comments']."</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['user']."</td>
				 </tr>";

      if($row_color == $bg_color1){
        $row_color = $bg_color2;
      }elseif($row_color == $bg_color2){
        $row_color = $bg_color1;
      }
  }



}else{

  $cash_lpo_html .= "<tr>
              <td colspan='5' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No Pending LPOs found</td>
           </tr>";

}

$cash_lpo_html .= "</tbody></table>";




// Approved LPOs
$approved_lpo_sql = "SELECT
    l.lpo_id,
    l.lpo_date,
    l.date_created,
    l.lpo_attention,
    l.lpo_status,
    l.lpo_supplier,
    l.lpo_destination,
    l.comments,
    s.supplier_id,
    s.supplier_fname,
    s.supplier_lname,
    s.supplier_company,
    l.payment_type,
    l.cob,
		CONCAT(u.user_fname, ' ', u.user_lname) AS user
FROM
    `jos_lpo` AS l
LEFT JOIN `jos_suppliers` AS s
ON
    s.supplier_id = l.supplier_id
LEFT JOIN `cms_users` AS u
ON u.user_id = l.user_id
WHERE date(l.lpo_date) = '$sql_date'
/* AND l.payment_type = 'Cash' */
AND l.lpo_status IN ('Approved')
GROUP BY
    l.lpo_id
ORDER BY l.lpo_date
DESC, l.lpo_id DESC";

$approved_result = mysql_query($approved_lpo_sql);


$approved_lpo_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$approved_lpo_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>LPO ID</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Supplier</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Destination</th>
															<th style='padding:3px;' bgcolor='#ccc'>Comments</th>
                              <th style='padding:3px;' bgcolor='#ccc'>User</th>
													</tr>
											</thead>";
	$approved_lpo_html .= "<tbody>";

if(mysqli_num_rows($approved_result) > 0) {

	// Create HTML email content
  while ($row = mysql_fetch_assoc($approved_result)) {

		$date = date('d/m/Y', strtotime($row['date_created']));
		$time = date('H:i:s', strtotime($row['date_created']));
		$lpo_date = "$date <br>($time)";
		$supplier = ($row['supplier_id'] > 0)? $row['supplier_company'] : $row['supplier'] ;

		$approved_lpo_html .= "<tr>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='https://app.identitytz.com/lpo/print?uid={$row['lpo_id']}'>{$row['lpo_id']}</a></td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$supplier</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['lpo_destination']."</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['comments']."</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['user']."</td>
				 </tr>";

      if($row_color == $bg_color1){
        $row_color = $bg_color2;
      }elseif($row_color == $bg_color2){
        $row_color = $bg_color1;
      }
  }



}else{

  $approved_lpo_html .= "<tr>
              <td colspan='5' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No Approved LPOs found</td>
           </tr>";

}

$approved_lpo_html .= "</tbody></table>";


// Open LPOs
$open_lpo_sql = "SELECT
    l.lpo_id,
    l.lpo_date,
    l.date_created,
    l.lpo_attention,
    l.lpo_status,
    l.lpo_supplier,
    l.lpo_destination,
    l.comments,
    s.supplier_id,
    s.supplier_fname,
    s.supplier_lname,
    s.supplier_company,
    l.payment_type,
    l.cob,
		CONCAT(u.user_fname, ' ', u.user_lname) AS user
FROM
    `jos_lpo` AS l
LEFT JOIN `jos_suppliers` AS s
ON
    s.supplier_id = l.supplier_id
LEFT JOIN `cms_users` AS u
ON u.user_id = l.user_id
WHERE l.lpo_status IN ('Approved','Pending')
GROUP BY
    l.lpo_id
ORDER BY l.lpo_date
DESC, l.lpo_id DESC";

$open_result = mysql_query($open_lpo_sql);


$open_lpo_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$open_lpo_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>LPO ID</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Date</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Supplier</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Destination</th>
															<th style='padding:3px;' bgcolor='#ccc'>Comments</th>
                              <th style='padding:3px;' bgcolor='#ccc'>User</th>
													</tr>
											</thead>";
	$open_lpo_html .= "<tbody>";

if(mysqli_num_rows($open_result) > 0) {

	// Create HTML email content
  while ($row = mysql_fetch_assoc($open_result)) {

		$date = date('d/m/Y', strtotime($row['date_created']));
    $delivery_date = isset($row['lpo_delivery_date'])? date('d/m/Y', strtotime($row['lpo_delivery_date'])) : '-' ;
	//	$time = date('H:i:s', strtotime($row['date_created']));
		$lpo_date = "$date <br>($time)";
		$supplier = ($row['supplier_id'] > 0)? $row['supplier_company'] : $row['supplier'] ;

		$open_lpo_html .= "<tr>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='https://app.identitytz.com/lpo/print?uid={$row['lpo_id']}'>{$row['lpo_id']}</a></td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
            <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$supplier</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['lpo_destination']."</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['comments']."</td>
						<td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['user']."</td>
				 </tr>";

      if($row_color == $bg_color1){
        $row_color = $bg_color2;
      }elseif($row_color == $bg_color2){
        $row_color = $bg_color1;
      }
  }



}else{

  $open_lpo_html .= "<tr>
              <td colspan='5' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No Approved LPOs found</td>
           </tr>";

}

$open_lpo_html .= "</tbody></table>";

  $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
  require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');

  $postmark = new Postmark\Mail($postmarkApiKey);
  $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
  $postmark->subject("Identity App: Procurement Report for $today");
 //   $postmark->addTo('hasnain@identitytz.com');
//   $postmark->addTo('controller@identitytz.com');
  $postmark->addTo('procurement@identitytz.com');
  $postmark->addTo('kazim@identitytz.com');
  $postmark->addTo('operations@identitytz.com');
  // $postmark->addTo('beecraq@gmail.com');

  $msg_body = "<p><strong>Stock Refills Pending:</strong></p>".$stock_refill_html;
 // $msg_body .= "<br><p><strong>Goods to be Received After COB:</strong></p>".$cob_html;
  $msg_body .= "<br><p><strong>LPOs Pending Approval:</strong></p>".$cash_lpo_html;
  $msg_body .= "<br><p><strong>Approved LPOs:</strong></p>".$approved_lpo_html;
  $msg_body .= "<br><p><strong>Open LPOs:</strong></p>".$open_lpo_html;

//   echo $msg_body;
//   exit;
  $postmark->messageHTML($msg_body);

 if($postmark->send()){
     echo "Email sent";
  }
