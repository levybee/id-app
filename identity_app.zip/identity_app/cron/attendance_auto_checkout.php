<?php

/* Autometed email that sends list of employees not checked out after 6:05pm
*/

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';

require_once( __DIR__."/../configs/variables.php");
require_once( __DIR__."/../configs/functions.php");
require_once( __DIR__."/../modules/attendance_schedule/functions.php");

$ATTACHMENTS_DIR = $_SERVER['DOCUMENT_ROOT'] . '/uploads/attachments/';

$date = date('Y-m-d');
$shift_id = 1;
$order = 'je.first_name, je.last_name ASC';
$params['schedule_date']= $date;
$params['shift_id']=$shift_id;
$params['order'] = $order;
$params['employee_status'] = 'Active';
$params['no_time_out'] = 1;
$params['overtime_checked'] = 0;
$params['not_department_id'] = [2,1];
$params['status'] = array('Present','Late');

// $params['debug'] = 1;
$schedule_data = fetch_schedule($params);
$rows = is_array($schedule_data) ? count($schedule_data) : 0;
$cronDate = date('Y-m-d H:i:s');
echo "[Run Date $cronDate] $rows Records found..\n\n";
if($rows == 0){
  exit;
}

exit;


$report_array = array();
$employee_ids = [];

if(count($schedule_data) > 0) {
    $count=0;
    // foreach($schedule_data as $k => $row){

    //     $count++;
    //     $report_array[] = array(

    //         'id' => $count,
    //         'employee_name' => $row['employee_name'],
    //         'type' => $row['type'],
    //         'department_name' => $row['department_name'],
    //         'time_in' => $row['time_in'],
    //         'status' => $row['status'],
    //     );

    // }


    // $today = date('d M Y');

    // $filename = "Employees-Not-Checked-Out-$date-".time().".csv";
    // $filepath = $ATTACHMENTS_DIR.$filename;



    // $file = fopen($filepath, 'w');
    // fputcsv($file, array('#','EMPLOYEE NAME','TYPE','DEPARTMENT','TIME IN','STATUS'));
    // foreach ($report_array as $line) {
    //     fputcsv($file, ($line));
    // }

    // fclose($file);


    $html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
            $html .= "<thead>
                                <tr>
                                <th width='50' style='padding:3px;' bgcolor='#ccc'>#</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>EMPLOYEE NAME</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>TYPE</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>DEPARTMENT</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>STATUS</th>
                                </tr>
                     </thead>";
            $html .= "<tbody>";

           $bg_color1 = '#fcfcfc';
           $bg_color2 = '#e5e5e5';
           $row_color = $bg_color1;

           foreach($schedule_data as $k => $row){
               $schedule_ids[] = $row['id'];
               $count++;

               $html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$count</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['employee_name']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['type']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['department_name']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['status']}</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }

           $html .= "</tbody></table>";


         $today = date('d M Y');
         $msg_body = "<p>The following is a report of employees that are not on overtime and have not checked out. They have been automatically checked out $today - Day</p><br>";
         $msg_body .= $html;


         if(!empty($schedule_ids)){

           $time_out = date('H:i:s');
           $user_id = '162';
           $timestamp = date('Y-m-d H:i:s');
           $schedule_ids = implode(',', $schedule_ids);

           $update_sql = "UPDATE jos_attendance_schedule
                          SET time_out = '$time_out',
                          checked_out_user_id = '$user_id',
                          date_updated = '$timestamp'
                          WHERE id IN ($schedule_ids)";

            $update_qry = mysql_query($update_sql);
         }

          // echo $msg_body;
          // exit;

    require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Employees Checked Out";
    // $mail->addAddress('hasnain@identitytz.com');
   //  $mail->addAddress('gm@identitytz.com');
    // $mail->addAddress('hr@identitytz.com');
     $mail->addAddress('kazim@identitytz.com');
    // $mail->addAddress('beecraq@gmail.com');

    // $mail->addAddress('Admin@identitytz.com');
    // $mail->addAddress('nabila@identitytz.com');
    // $mail->addAddress('procurement@identitytz.com');


   // $msg_body = "<p>Attached is a report for employees that have not checked out $today - Day</p><br>";

    $mail->Body = $msg_body;
   // $postmark->addAttachment($filepath);

    if($mail->send()){
        echo "Email sent";
    } else {
        echo "Sending failed.";
    }

}
