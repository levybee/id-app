<?php

use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included

$between = " (DATE_FORMAT(CURDATE() - INTERVAL 1 MONTH,'%Y-%m-01')) AND (LAST_DAY(NOW() - INTERVAL 1 MONTH)) ";
// $between = " '2022-08-01' AND '2022-08-31' ";

$head_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$head_html .= "<thead>
                      <tr>
                          <th width='110' style='padding:3px;' bgcolor='#ccc'>Ref #</th>
                      <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
                      <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
                      <th style='padding:3px 4px;' bgcolor='#ccc'>Value (TZS)</th>
                      </tr>
                    </thead>";
$head_html .= "<tbody>";

$users_sql = "SELECT user_id,CONCAT(user_fname, ' ', user_lname) as user, user_email FROM cms_users WHERE role_name LIKE '%Sales%' AND exclude_sales_reports = 0 AND user_status = 'Active' AND role_status = 'Active' ORDER BY user_fname ASC";
$users_qry = mysql_query($users_sql);

while ($user_row = mysql_fetch_assoc($users_qry)) {

      $user_name = $user_row['user'];
      $user_id = $user_row['user_id'];
      $user_email = $user_row['user_email'];

      $bs = "SELECT
        ji.invoice_id,
        ji.invoice_currency,
        ji.invoice_date,
        ji.invoice_status,
        IF(
            ji.tax = 'Taxable',
            SUM(
                ii.item_quantity * ii.item_price
            ) +(
                SUM(
                    ii.item_quantity * ii.item_price
                ) * 0.18
            ),
            SUM(
                ii.item_quantity * ii.item_price
            )
        ) AS invoice_value,
        cg.group_company,
    		u.user_fname, u.user_lname

    FROM
        jos_invoices AS ji
    LEFT JOIN jos_invoice_items AS ii
    ON
        ji.invoice_id = ii.invoice_id
    LEFT JOIN jos_customers AS cu
    ON
        (
            cu.customer_id = ji.customer_id
        )
    LEFT JOIN jos_customers_group AS cg
    ON
        cg.group_id = cu.group_id

    	 LEFT JOIN jos_delivery_notes dn
    	 ON FIND_IN_SET(dn.dn_id, ji.dn_id) = 1

    	 LEFT JOIN jos_jobs j
    	 ON dn.job_id = j.job_id

       LEFT JOIN jos_quotes_items jqi ON j.item_id = jqi.item_id
       LEFT JOIN jos_quotes q ON jqi.quote_id = q.quote_id
       LEFT JOIN cms_users u ON u.user_id = q.user_id

      WHERE (ji.invoice_date between  $between) AND q.user_id = $user_id

      GROUP BY ji.invoice_id ORDER BY ji.invoice_date DESC, ji.invoice_id DESC";

        $bs_result = mysql_query($bs);


         if(mysql_num_rows($bs_result) > 0) {

           $total_value = 0;

           $bs_html = "";
           $bs_html .= $head_html;

           $bg_color1 = '#fcfcfc';
           $bg_color2 = '#e5e5e5';
           $row_color = $bg_color1;
           while ($row = mysql_fetch_assoc($bs_result)) {


               $date = date('d M Y', strtotime($row['invoice_date']));
               $ref_yy = substr($row['invoice_date'], 0, 4);
               $ref_no = 'TI/' . $ref_yy . '/' . leading_zero($row['invoice_id'], 5);
               $customer = $row['group_company'];
               $total_value += $row['invoice_value'];
               $value = number_format($row['invoice_value'], 2);


               $bs_html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='http://app.identitytz.com/invoices/view?uid=".$row['invoice_id']."'>$ref_no</a></td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$customer</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$value</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }
           $total = number_format($total_value, 2);
           $bs_html .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' colspan='3' align='right'><strong>TOTAL</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' align='center'>$total</td>
                                     </tr>";
           $bs_html .= "</tbody></table>";


         }

         //echo $msg_body;
         $msg_body = "<p>Performance Report [$user_name]: Billed Sales Monthly.</p><br>";
         $msg_body .= $bs_html;

           $mail = new PHPMailer(true);

           // Server settings
           $mail->isSMTP();
           $mail->Host = SMTP_HOST;  // Replace with your SMTP server
           $mail->SMTPAuth = true;
           $mail->Username = SMTP_USERNAME; // SMTP username
           $mail->Password = SMTP_PASSWORD; // SMTP password
           $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
           $mail->Port = 587; // Usually 587 for TLS
           $mail->isHTML(true);

           $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
           $mail->Subject = "Identity App: Performance Report [$user_name] - Billed Sales Monthly Notice";

           $mail->addAddress('hasnain@identitytz.com');
           // $mail->addAddress('kazim@identitytz.com');
           // $mail->addAddress('hr@identitytz.com');
           $mail->addAddress($user_email);

           // $mail->addAddress('beecraq@gmail.com');

           $mail->Body = $msg_body;

           if($mail->send()){
               echo "Email sent ";
           }

}
