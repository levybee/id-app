<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header("Content-Type: text/plain");

$local = false;
$cron = true;

require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");
require (__DIR__."/../modules/configurations.php");
require (__DIR__."/../modules/petty_cash/functions.php");
require (__DIR__."/../modules/ledger_accounts/functions.php");

$date_from = date('Y-m-d').' 00:00:00';
$date_to = date('Y-m-d').' 11:59:59';
//   $date_from = '2026-04-23 00:00:00';
//   $date_to = '2026-04-23 11:59:59';


// $log_list_sql = "SELECT pc.amount,CONCAT(u.user_fname,' ', u.user_lname) AS user, pc.attachment, pc.date_created,
// 									 pc.reference, pc.status, pc.remarks, CONCAT(je.first_name,' ', je.last_name) AS employee_name,
// 									 jexp.expense_name, lpo.lpo_id
// 					FROM `jos_petty_cash` as pc
// 					LEFT JOIN jos_expenses as jexp
// 					ON jexp.expense_id = pc.expense_id
// 					LEFT JOIN `cms_users` as u
// 						ON pc.user_id = u.user_id
// 					LEFT JOIN jos_employees as je
// 						ON je.id = pc.employee_id
// 						LEFT JOIN `jos_lpo` as lpo
// 						ON lpo.lpo_id = pc.lpo_id
// 					 WHERE (pc.date_created >= '$date_from' OR pc.date_updated >= '$date_from') AND (pc.status='Issued' OR pc.status='Closed')";


$log_list_sql = "SELECT pc.id,pc.amount, CONCAT(u.user_fname,' ', u.user_lname) AS user, pc.date_created,
						pc.status, pc.remarks, CONCAT(je.first_name,' ', je.last_name) AS employee_name,
						pc.attachment, pc.approval_attachment, jexp.expense_name, lpo.lpo_id
					FROM `jos_petty_cash` as pc
					LEFT JOIN jos_expenses as jexp
					ON jexp.expense_id = pc.expense_id
					LEFT JOIN `cms_users` as u
						ON pc.user_id = u.user_id
					LEFT JOIN jos_employees as je
						ON je.id = pc.employee_id
						LEFT JOIN `jos_lpo` as lpo
						ON lpo.lpo_id = pc.lpo_id
					 WHERE (pc.date_created >= '$date_from' OR pc.date_updated >= '$date_from') AND pc.status IN ('Pending','Approved','Issued','Closed')";

$result = mysql_query($log_list_sql);
$attachments = [];

$cronDate = date('Y-m-d H:i:s');
$rows = mysql_num_rows($result);
echo "[Run Date $cronDate] $rows Records found..\n\n";

if(mysqli_num_rows($result) > 0) {

  echo "Records found..\n\n";
	$aprroved_amount_sql = "SELECT SUM(IF(status = 'Approved', amount,0)) AS 'approved' FROM jos_petty_cash";

	$aprroved_amount_qry = mysql_query($aprroved_amount_sql);
	$aprroved_amount = mysql_fetch_array($aprroved_amount_qry, MYSQL_ASSOC)['approved'];


	$cash_entries = getPettyCashLogs([
	    'start_date' => $date_from,
	    'end_date' => $date_to
	]);	


   $cash_balance = $cash_entries['closing_balance'];
   $cash_required = $aprroved_amount - $cash_balance + 3000000;

   $opening_balance = 0;
	if(isset($cash_entries['opening_balance'])){
		$opening_balance = $cash_entries['opening_balance'];
	}
	 
  echo "Approved: $aprroved_amount\n\n";
	echo "Balance: $cash_balance\n\n";
	echo "Required: $cash_required\n\n";

	


    $pcv_html = "<table class='table table-bordered table-striped' style='border-collapse: collapse; width: 100%;'>";
    $pcv_html .= "<thead style='background-color: #f5f5f5;'>";
    $pcv_html .= "<tr>";
    $pcv_html .= "<th style='padding: 8px; text-align: center;'>Date</th>";
    $pcv_html .= "<th style='padding: 8px; text-align: center;'>PCV#</th>";
	$pcv_html .= "<th style='padding: 8px; text-align: center;'>LPO/Contract</th>";
	$pcv_html .= "<th style='padding: 8px; text-align: center;'>Payee</th>";
    $pcv_html .= "<th style='padding: 8px;'>Description</th>";
    $pcv_html .= "<th style='padding: 8px; text-align: right;'>Debit</th>";
    $pcv_html .= "<th style='padding: 8px; text-align: right;'>Credit</th>";
    $pcv_html .= "</tr>";
    $pcv_html .= "</thead>";
    $pcv_html .= "<tbody>";

    $today = date('d M Y');

    $total_debit = 0;
    $total_credit = 0;
	$row_index = 0;

    foreach($cash_entries['entries'] as $entry){
		$debit_amount = number_format($entry['debit'], 2, '.', ',');
		$credit_amount = number_format($entry['credit'], 2, '.', ',');
		$descr = $entry['remarks'];
		// Remove 'Petty Cash #XXXXX - ' prefix from description
		$descr = $entry['description'];
		if($entry['entry_type'] != 'Petty Cash' && $entry['entry_type'] != ''){
			$descr .= " ({$entry['entry_type']})";
		}

		$date = date('d/m/Y', strtotime($entry['entry_date']));
		$pcv_ref = ($entry['link_id'] > 0) ? "<a title='View Petty Cash' target='_blank' href='https://app.identitytz.com/petty_cash?filter=1&pc_id={$entry['link_id']}'>{$entry['reference']}</a>" : $entry['reference'];
        
		$payeeLink = '-';
		if($entry['lpo_id']){
			$payeeLink = "<a title='View LPO' target='_blank' href='https://app.identitytz.com/lpo/approve/?id={$entry['lpo_id']}'>LPO #{$entry['lpo_id']}</a>";
		}

		if($entry['contractor_id'] > 0){
			$payeeLink = "<a title='View Contractor' target='_blank' href='https://app.identitytz.com/casual_contractors/view?id={$entry['contractor_id']}'>Contractor #{$entry['contractor_id']}</a>";
		}
        
		$payee = $entry['payee']? $entry['payee'] : $entry['employee_name'];

		$row_bg = ($row_index % 2 == 0) ? '#ffffff' : '#f7f7f7';
		$row_index++;
		$pcv_html .= "<tr style='background-color: $row_bg;'>";
		$pcv_html .= "<td style='padding: 8px; text-align: center;'>$date</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: center;'>$pcv_ref</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: center;'>$payeeLink</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: center;'>$payee</td>";
		$pcv_html .= "<td style='padding: 8px;'>$descr</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: right;'>".($entry['debit'] > 0 ? $debit_amount : '')."</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: right;'>".($entry['credit'] > 0 ? $credit_amount : '')."</td>";
		$pcv_html .= "</tr>";

	}

	// Add totals row
	if(count($cash_entries['entries']) > 0){
		$pcv_html .= "<tr style='background-color: #f9f9f9; font-weight: bold;'>";
		$pcv_html .= "<td colspan='5' style='padding: 8px; text-align: right;'>Total (TZS)</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: right;'>".number_format($cash_entries['total_debit'], 2, '.', ',')."</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: right;'>".number_format($cash_entries['total_credit'], 2, '.', ',')."</td>";
		$pcv_html .= "</tr>";
		$pcv_html .= "<tr style='background-color: #f5f5f5; font-weight: bold;'>";
		$pcv_html .= "<td colspan='5' style='padding: 8px; text-align: right;'>Closing Balance</td>";
		$pcv_html .= "<td style='padding: 8px; text-align: right;' colspan='2'>".number_format($cash_entries['closing_balance'], 2, '.', ',')."</td>";
		$pcv_html .= "</tr>";
	}

	// Attachments
    while ($row = mysql_fetch_assoc($result)) {

		if($row['status'] == 'Closed' && !empty($row['attachment'])){

		  //  echo "Attchment found {$row['attachment']}..\n";

			// GRN Attachment check
			$grnAttched = false;
			$grnCheckSql = "SELECT grn_id FROM jos_grn WHERE attachment_path LIKE '%{$row['attachment']}%'";
			$grnResult = mysql_query($grnCheckSql);
			if(mysqli_num_rows($grnResult) > 0){
				$grnAttched = true;
			}

			if(array_search($row['attachment'], $attachments) === false && $grnAttched == false){
				$attachments[] =  $row['attachment'];
				echo "Attchment added {$row['attachment']}..\n";
			}else{
			 // echo "Attchment removed {$row['attachment']}..\n";
			}
		 

		}elseif(!empty($row['approval_attachment'])){
			$attachments[] =  $row['approval_attachment'];
		}

    }

    $pcv_html .= "</tbody>";
    $pcv_html .= "</table>";

    // echo $pcv_html;
	// 	exit;


		require(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);

		// Server settings
    $mail->isSMTP();
		$mail->Host = SMTP_HOST;  // Replace with your SMTP server
		$mail->SMTPAuth = true;
		$mail->Username = SMTP_USERNAME; // SMTP username
		$mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = 'Identity App: Todays Petty Cash Log';
    $mail->addAddress('hasnain@identitytz.com');
    $mail->addAddress('kazim@identitytz.com');
    $mail->addAddress('accountsipl@identitytz.com');
    $mail->addAddress('vijay@identitytz.com');
//   	$mail->addAddress('accounts@identitytz.com');
//   	$mail->addAddress('admin@identitytz.com');
  	
		$mail->addAddress('beecraq@gmail.com');
    $tmrw = date('d M Y', strtotime('+1 day'));
    $cash_required = number_format(floatval($cash_required));
    $closing_balance = number_format(floatval($cash_balance));
    $opening_balance = number_format(floatval($opening_balance));
	
		$msg_body = "<p>Cash requirement for tomorrow ($tmrw) : $cash_required TZS </p>";
		$msg_body .= "<p>The following are cash logs for today ($today) :</p><br>".$pcv_html;
		// $msg_body .= $pcv_html2;

         

    $mail->Body = $msg_body;

	// Attachemnt on Closed PCVs
	if(!empty($attachments)){

		foreach($attachments as $attch){
			$filepath = "$doc_root/{$config['attachment_dir']}$attch";
			if(file_exists($filepath)){
              $mail->addAttachment($filepath);
			}
		}
	}else{
	  echo "No Attchments \n";
	}
	
// 	 print_r($attachments);
// 		  echo $msg_body;
// 		  exit;

   if($mail->send()){
        echo "Email sent";
    }else{
		echo "something went wrong";
	}


}else{
    echo 'no records found';
}
@mysql_close();
