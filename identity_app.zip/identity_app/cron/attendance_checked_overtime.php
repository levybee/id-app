<?php

/* Autometed email that sends list of employees allowed overtime - 4pm
*/

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';

require_once( __DIR__."/../configs/variables.php");
require_once( __DIR__."/../configs/functions.php");
require_once( __DIR__."/../modules/attendance_schedule/functions.php");

$date = date('Y-m-d');
$shift_id = 1;
$order = 'je.first_name, je.last_name ASC';
$params['schedule_date']= $date;
$params['shift_id']=$shift_id;
$params['order'] = $order;
$params['employee_status'] = 'Active';
$params['overtime_checked'] = 1;

// $params['debug'] = 1;

$schedule_data = fetch_schedule($params);
$rows = is_array($schedule_data) ? count($schedule_data) : 0;
$cronDate = date('Y-m-d H:i:s');
echo "[Run Date $cronDate] $rows Records found..\n\n";
if($rows == 0){
  exit;
}

$report_array = array();

if(count($schedule_data) > 0) {


   // Group per Location
   $perLocationData = [];
   foreach ($schedule_data as $key => $value) {
     $perLocationData[$value['employee_location']][] = $value;
   }

   $html = '';
   foreach ($perLocationData as $location => $data) {

     $count=0;

     $departments = [];
     $html .= "<br><p style'font-size:16px;'><strong>{$location}</strong></p>";

     foreach ($data as $key => $value) {
       $departments[$value['department_name']][] = $value;
     }

     foreach ($departments as $department => $schData) {

       $html .= "<br><p><strong>{$department}</strong></p>";

       $html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
               $html .= "<thead>
                                   <tr>
                                   <th width='50' style='padding:3px;' bgcolor='#ccc'>#</th>
                                   <th style='padding:3px 4px;' bgcolor='#ccc'>EMPLOYEE NAME</th>
                                   <th style='padding:3px 4px;' bgcolor='#ccc'>TYPE</th>
                                   <th style='padding:3px 4px;' bgcolor='#ccc'>STATUS</th>
                                   </tr>
                        </thead>";
               $html .= "<tbody>";

              $bg_color1 = '#fcfcfc';
              $bg_color2 = '#e5e5e5';
              $row_color = $bg_color1;

              foreach($schData as $k => $row){

                  $count++;

                  $html .= "<tr>
                         <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$count</td>
                         <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['employee_name']}</td>
                         <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['type']}</td>
                         <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['status']}</td>
                     </tr>";

                     if($row_color == $bg_color1){
                       $row_color = $bg_color2;
                     }elseif($row_color == $bg_color2){
                       $row_color = $bg_color1;
                     }

              }

              $html .= "</tbody></table>";

      }

    }


         $today = date('d M Y');
         $msg_body = "<p>The following is a report of employees that are allowed to stay overtime $today - Day</p><br>";
         $msg_body .= $html;

// echo $msg_body;
// exit;

    require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;  // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME; // SMTP username
    $mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = "Identity App: Employees Allowed Overtime";

     $mail->addAddress('hasnain@identitytz.com');
    // $mail->addAddress('gm@identitytz.com');
    // $mail->addAddress('hr@identitytz.com');
     $mail->addAddress('kazim@identitytz.com');
    // $mail->addAddress('pm@identitytz.com');
    // $mail->addAddress('nabila@identitytz.com');
    // $mail->addAddress('procurement@identitytz.com');
    // $mail->addAddress('beecraq@gmail.com');

   // $msg_body = "<p>Attached is a report for employees that have not checked out $today - Day</p><br>";

    $mail->Body = $msg_body;
   // $postmark->addAttachment($filepath);

    if($mail->send()){
        echo "Email sent\n\n";
    } else {
        echo "Sending failed.\n\n";
    }

}
