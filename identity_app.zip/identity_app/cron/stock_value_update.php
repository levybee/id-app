<?php
// used to run: 0 	8,10,12,14,16,18 	* 	* 	1-6
header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for stock value update.\n";

require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");


$data = array();
// Quotes
$lpo_sql = "SELECT s.* , lpoi.item_unit_price, lpoi.lpo_currency, lpoi.lpo_id FROM `jos_stock` as s
            LEFT JOIN
            ( SELECT t1.*
              FROM ( SELECT po.lpo_date, poi.stock_id, po.lpo_currency,
                IF(po.lpo_currency = 'USD', poi.item_unit_price * po.exch_rate, poi.item_unit_price) as item_unit_price,
                poi.item_id, po.lpo_id
                FROM jos_lpo_items poi LEFT JOIN jos_lpo po ON po.lpo_id = poi.lpo_id
                WHERE poi.stock_id != 0 ) t1 INNER JOIN ( SELECT MAX(po.lpo_date) as max_date, poi.stock_id
                FROM jos_lpo_items poi LEFT JOIN jos_lpo po ON po.lpo_id = poi.lpo_id WHERE poi.stock_id != 0
                GROUP BY poi.stock_id ) t2 ON t1.stock_id = t2.stock_id
                AND t1.lpo_date = t2.max_date ) AS lpoi ON s.stock_id = lpoi.stock_id
                GROUP BY s.stock_id";


$result = mysql_query($lpo_sql);

if(mysql_num_rows($result) > 0) {

  echo "Found data working on it..\n";

    while ($row = mysql_fetch_assoc($result)) {

      if($row['item_unit_price'] > 0){

          $currency = 'TZS'; //$row['lpo_currency']

        $data[] = array(
    		 	      'stock_id' => $row['stock_id'],
    		 	      'unit_price' => $row['item_unit_price'],
    			      'currency' => $currency,
                      'update_lpo_id' => $row['lpo_id']
    			   );

      }

    }

    echo "Update data array built, working on our magic function...\n";

    // print_r($data);
    // exit;

    $table = 'jos_stock';
    $key = 'stock_id';
    $update_columns = array('unit_price','currency', 'update_lpo_id');
    $no_affected_rows = lev_batch_update($table, $data, $key, $update_columns);
    @mysql_close();

    echo "All done $no_affected_rows rows updated.\n\n";



}
