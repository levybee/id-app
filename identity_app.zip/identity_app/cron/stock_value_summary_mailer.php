<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for stock value summary.\n";

$local = true;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require($root_dir."configs/variables.php");
require($root_dir."configs/functions.php");

$ATTACHMENTS_DIR = $root_dir . '/tmp/';

//$month = date("m", strtotime("first day of previous month"));
$month = date('m');
$year = date('Y');
$report_sql = "SELECT SUM(svs.opening_value) as opening_value,
                  SUM(svs.closing_value) as closing_value,
                  s.category
                  FROM `jos_stock_value_summary` svs
                  LEFT JOIN jos_stock s
                  ON s.stock_id = svs.stock_id
                            WHERE MONTH(svs.date_created) = $month
                            AND YEAR(svs.date_created) = $year
                            GROUP BY s.category
                            ORDER BY s.category ASC";


$result = mysql_query($report_sql);

$report_array = array();

if(mysql_num_rows($result) > 0) {


    $current_cat = "";
    $previous_cat = "";

    $categories = [];
    $categories['General'] = array('Administration','General Production','Parts');
    $categories['Stationary'] = array('Stationary RM','Stationary FG');
    $categories['Promo'] = array('T-Shirt','Promotional','Embroidery','Screen Printing Consumables');
    $categories['Signage'] = array('Signage','Building Material');
    $categories['Wide Format'] = array('Wide Format');
    $categories['Offset'] = array('Offset Consumables','Offset Paper','Digital Printing');
    $categories['Flexo'] = array('Flexo');

    $lineCats = array('Administration','General Production','Parts','Offset Consumables','Offset Paper','Digital Printing','Stationary RM','Stationary FG','T-Shirt','Promotional','Embroidery','Screen Printing Consumables','Signage','Building Material','Wide Format','Flexo');


    while ($row = mysql_fetch_assoc($result)) {

         if(!$row['category']){
            echo "Cat null ID: {$row['stock_id']}\n";
        }

      $main_cat = '';
      foreach($categories as $cat_name => $catArray){
        if(array_search($row['category'], $catArray) !== false){
          $main_cat = $cat_name;
          break;
        }


      }

      if($main_cat){
        $report_array[] = array(
            'category' => $row['category'],
            'opening_value' => $row['opening_value'],
            'closing_value' => $row['closing_value'],
            'main_category' => $main_cat,
        );
      }



    }


    $reportSumamry = [];
    foreach($report_array as $k => $val){
      $reportSumamry[$val['main_category']][] = $val;
    }

    // Calc totals
    foreach($reportSumamry as $key => $arr){
      $total_opening = 0;
      $total_closing = 0;
      foreach($arr as $k => $v){
        $total_opening += $v['opening_value'];
        $total_closing += $v['closing_value'];
      }

      $reportSumamry[$key][0]['total_opening'] = $total_opening;
      $reportSumamry[$key][0]['total_closing'] = $total_closing;

    }

    // print_r($reportSumamry);
    // exit;

    $date = date('d-m-Y');
    $dateSum =    date("F Y", strtotime("first day of previous month"));
   // $dateSum =  date('F Y');

    // $stock_sql = "SELECT * FROM jos_stock s WHERE s.category IN ('Signage') ORDER BY s.stock_name ASC";

    // $stock_result = mysql_query($stock_sql);
    // $stockfilename = "Stock-Value-Signage-$date.csv";
    // $stockfilepath = $ATTACHMENTS_DIR.$stockfilename;

    // $file = fopen($stockfilepath, 'w');
    // fputcsv($file, array('Stock ID','Stock Name','Qty','Unit Price','Value'));
    // $totalValue = 0;
    // while ($row = mysql_fetch_assoc($stock_result)) {
    //     $value = $row['stock_qty'] * $row['unit_price'];
    //     fputcsv($file, array("{$row['stock_id']}","{$row['stock_name']}","{$row['stock_qty']}","{$row['unit_price']}","{$value}"));
    //     $totalValue += $value;
    // }

    // fputcsv($file, array("","","","",""));
    // fputcsv($file, array("","","","",$totalValue));
    // fclose($file);


    $filename = "Stock-Value-Summary-$date.csv";
    $filepath = $ATTACHMENTS_DIR.$filename;

    $file = fopen($filepath, 'w');
    fputcsv($file, array('Category','Opening','Closing'));
    foreach($reportSumamry as $k => $arr){

      if(isset($k)){

        foreach ($arr as $line) {
          fputcsv($file, array("{$line['category']}","{$line['opening_value']}","{$line['closing_value']}"));
        }
        fputcsv($file, array("{$k} Total","{$arr[0]['total_opening']}","{$arr[0]['total_closing']}"));
        fputcsv($file, array("","",""));

      }

    }

    fclose($file);

    require($root_dir . 'vendor/autoload.php'); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);


    try{

      // $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';
      //
      // require_once($root_dir .'libs/Postmark/class.postmark.php');
      //

      //
      // $postmark = new Postmark\Mail($postmarkApiKey);
      // $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
      // $postmark->subject("Identity App: Stock Value Summary - $dateSum");
      // $postmark->addTo('hasnain@identitytz.com');
      //  $postmark->addTo('Admin@identitytz.com');
      // // $postmark->addTo('nabila@identitytz.com');
      // $postmark->addTo('kazim@identitytz.com');
      // $postmark->addTo('gm@identitytz.com');
      //  $postmark->addTo('procurement@identitytz.com');
     //  $postmark->addTo('accounts2@identitytz.com');
    // $postmark->addTo('beecraq@gmail.com');

     //  $msg_body = "<p>Attached is a Stock Value Report for $dateSum.</p><br>";
     //
     //  // echo $filepath;
     //  // exit;
     //
     //  $postmark->messageHTML($msg_body);
     //  $postmark->addAttachment($filepath);
     // // $postmark->addAttachment($stockfilepath);
     //
     // foreach($lineCats as $cat){
     //
     //    $stock_sql = "SELECT * FROM jos_stock s WHERE s.category IN ('$cat') ORDER BY s.stock_name ASC";
     //
     //    $stock_result = mysql_query($stock_sql);
     //    $catName = str_replace(' ', '', $cat);
     //    $stockfilename = "Stock-Value-$catName-$date.csv";
     //    $stockfilepath = $ATTACHMENTS_DIR.$stockfilename;
     //
     //    $file = fopen($stockfilepath, 'w');
     //    fputcsv($file, array('Stock Name','Qty','Unit Price','Value'));
     //    $totalValue = 0;
     //    while ($row = mysql_fetch_assoc($stock_result)) {
     //        $value = $row['stock_qty'] * $row['unit_price'];
     //        fputcsv($file, array("{$row['stock_name']}","{$row['stock_qty']}","{$row['unit_price']}","{$value}"));
     //        $totalValue += $value;
     //    }
     //
     //    fputcsv($file, array("","","",""));
     //    fputcsv($file, array("","","",$totalValue));
     //    fclose($file);
     //
     //    $postmark->addAttachment($stockfilepath);
     //
     //  }
     //
     //
     //  if($postmark->send()){
     //      echo "Email sent";
     //  } else {
     //      echo "Sending failed.";
     //  }

     $filename = "Stock-Value-Summary-$date.csv";
     $filepath = $ATTACHMENTS_DIR.$filename;

     // Server settings
     $mail->isSMTP();
     $mail->Host = 'mail.identity.co.tz';  // Replace with your SMTP server
     $mail->SMTPAuth = true;
     $mail->Username = 'smtp@identity.co.tz'; // SMTP username
     $mail->Password = 'RXSRV_0@u7r3'; // SMTP password
     $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
     $mail->Port = 587; // Usually 587 for TLS

     // Sender & Recipients
     $mail->setFrom('smtp@identity.co.tz', 'Identity Promotions Ltd');
     // $mail->addAddress('hasnain@identitytz.com');
     // $mail->addAddress('admin@identitytz.com');
     // $mail->addAddress('kazim@identitytz.com');
     // $mail->addAddress('gm@identitytz.com');
     // $mail->addAddress('procurement@identitytz.com');
     $mail->addAddress('beecraq@gmail.com');

     // Email Content
     $mail->isHTML(true);
     $mail->Subject = "Identity App: Stock Value Summary - $dateSum";
     $mail->Body    = "<p>Attached is a Stock Value Report for $dateSum.</p><br>";

     // Attachments
     $mail->addAttachment($filepath); // Attach Stock Value Summary

     foreach ($lineCats as $cat) {
         $stock_sql = "SELECT * FROM jos_stock s WHERE s.category IN ('$cat') ORDER BY s.stock_name ASC";
         $stock_result = mysql_query($stock_sql);
         $catName = str_replace(' ', '', $cat);
         $stockfilename = "Stock-Value-$catName-$date.csv";
         $stockfilepath = $ATTACHMENTS_DIR . $stockfilename;

         $file = fopen($stockfilepath, 'w');
         fputcsv($file, ['Stock Name', 'Qty', 'Unit Price', 'Value']);
         $totalValue = 0;

         while ($row = mysql_fetch_assoc($stock_result)) {
             $value = $row['stock_qty'] * $row['unit_price'];
             fputcsv($file, [$row['stock_name'], $row['stock_qty'], $row['unit_price'], $value]);
             $totalValue += $value;
         }

         fputcsv($file, ["", "", "", ""]);
         fputcsv($file, ["", "", "", $totalValue]);
         fclose($file);

         $mail->addAttachment($stockfilepath);
     }

     // Send Email
     if ($mail->send()) {
         echo "Email sent";
     } else {
         echo "Sending failed.";
     }

    } catch (Exception $e) {
        echo "Error: " . $mail->ErrorInfo;
    }



}
