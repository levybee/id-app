<?php

use PHPMailer\PHPMailer\PHPMailer;

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require_once("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included


$qi_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
$qi_html .= "<thead>
                        <tr>
                            <th width='110' style='padding:3px;' bgcolor='#ccc'>Ref #</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
              <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
              <th style='padding:3px 4px;' bgcolor='#ccc'>No of Items</th>
					    <th style='padding:3px 4px;' bgcolor='#ccc'>Quote Value (TZS)</th>
                        </tr>
                    </thead>";
$qi_html .= "<tbody>";

$users_sql = "SELECT user_id,CONCAT(user_fname, ' ', user_lname) as user FROM cms_users WHERE (role_id = 5 OR role_id = 20) AND exclude_sales_reports = 0 AND user_status = 'Active'";
$users_qry = mysql_query($users_sql);

while ($user_row = mysql_fetch_assoc($users_qry)) {

      $user_name = $user_row['user'];
      $user_id = $user_row['user_id'];
      $user_email = $user_row['user_email'];

      $quotes_issued = "SELECT
                        q.quote_id,
                        q.quote_date,
                        q.quote_status,
                        cg.group_company,
                        cms_users.user_fname,
                        cms_users.user_lname,
                        COUNT(qi.item_id) AS quote_items_num,
                        SUM(
                            qi.item_quantity_1 * qi.item_price_1
                        ) AS quote_value
                    FROM
                        jos_quotes AS q
                    LEFT JOIN jos_quotes_items qi ON
                        qi.quote_id = q.quote_id
                    LEFT JOIN jos_customers jc ON jc.customer_id = q.customer_id
                    LEFT JOIN jos_customers_group cg ON cg.group_id = jc.group_id
                    LEFT JOIN cms_users ON cms_users.user_id = q.user_id
                    WHERE DATEDIFF(NOW(),q.quote_date) <= 7 AND q.user_id = $user_id

                    GROUP BY
                        q.quote_id
                    ORDER BY
                        q.quote_date
                    DESC
                        ,
                        q.quote_id
                    DESC";

        $quotes_result = mysql_query($quotes_issued);


         if(mysql_num_rows($quotes_result) > 0) {

           $total_value = 0;

           $quotes_issued_html = "";
           $quotes_issued_html .= $qi_html;

           $bg_color1 = '#fcfcfc';
           $bg_color2 = '#e5e5e5';
           $row_color = $bg_color1;
           while ($row = mysql_fetch_assoc($quotes_result)) {


               $date = date('d M Y', strtotime($row['quote_date']));
               $ref_yy = substr($row['quote_date'], 0, 4);
               $ref_mm = substr($row['quote_date'], 5, 2);
               $ref_no = $ref_yy . '-' . $ref_mm . '-' . leading_zero($row['quote_id'], 5);
               $customer = $row['group_company'];
               $total_value += $row['quote_value'];
               $value = number_format($row['quote_value'], 2);


               $quotes_issued_html .= "<tr>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>$ref_no</a></td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$customer</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['quote_items_num']}</td>
                      <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$value</td>
                  </tr>";

                  if($row_color == $bg_color1){
                    $row_color = $bg_color2;
                  }elseif($row_color == $bg_color2){
                    $row_color = $bg_color1;
                  }

           }
           $total = number_format($total_value, 2);
           $quotes_issued_html .= "<tr><td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' colspan='4' align='right'><strong>TOTAL</strong></td>
                                         <td style='padding:3px 4px; border-top:1px solid #ccc;' bgcolor='$row_color' align='center'>$total</td>
                                     </tr>";
           $quotes_issued_html .= "</tbody></table>";


         }

         //echo $msg_body;
         $msg_body = "<p>Performance Report [$user_name]: Quotes Issued Weekly.</p><br>";
         $msg_body .= $quotes_issued_html;

           $mail = new PHPMailer(true);

           // Server settings
           $mail->isSMTP();
           $mail->Host = SMTP_HOST;  // Replace with your SMTP server
           $mail->SMTPAuth = true;
           $mail->Username = SMTP_USERNAME; // SMTP username
           $mail->Password = SMTP_PASSWORD; // SMTP password
           $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
           $mail->Port = 587; // Usually 587 for TLS
           $mail->isHTML(true);

           $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
           $mail->Subject = 'Identity App: Performance Report - Quotes Issued Weekly Notice';

           $mail->addAddress('hasnain@identitytz.com');
           // $mail->addAddress('kazim@identitytz.com');
           // $mail->addAddress('hr@identitytz.com');
           $mail->addAddress($user_email);

           // $mail->addAddress('beecraq@gmail.com');

          $mail->Body = $msg_body;

           if($mail->send()){
              // echo "Email sent";
           }

}
