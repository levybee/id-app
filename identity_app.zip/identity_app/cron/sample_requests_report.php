<?php

// ini_set('display_errors', 1);
// error_reporting(E_ALL);
// Sends email report daily showing only the list of Open Sample Requests
header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for open sample requests.\n";
echo "Fetching data..\n";

$local = false;
$appUrl = $local? 'http://idlocal.lev/' : 'https://app.identitytz.com/';

require(__DIR__."/../configs/variables.php");
require(__DIR__."/../configs/functions.php");
require(__DIR__."/../configs/email.php");
require(__DIR__."/../modules/requisition/functions.php");

$params = [];
$params['sample'] = 1;
$params['requisition_status'] = ['Draft','Approved','Complete'];
$params['limit'] = 'LIMIT 20'; // to avoid overload
$params['order'] = 'r.date_created  DESC';
$data = get_requisitions($params);

echo "Found ".count($data)." open sample requests.\n";
if(count($data) > 0){

    $bg_color1 = '#fcfcfc';
    $bg_color2 = '#e5e5e5';
    $row_color = $bg_color1;

        $html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
        $html .= "<thead>
                                                <tr>
                                                    <th style='padding:3px 4px;' bgcolor='#ccc'>ID</th>
                                                    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
                                                    <th style='padding:3px 4px;' bgcolor='#ccc'>Duration</th>
                                                    <th style='padding:3px 4px;' bgcolor='#ccc'>Job</th>
                                                    <th style='padding:3px 4px;' bgcolor='#ccc'>Department</th>
                                                    <th style='padding:3px 4px;' bgcolor='#ccc'>Status</th>
                                                    <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                                                </tr>
                                    </thead>";
    $html .= "<tbody>";

    foreach ($data as $row){

        $req_link = "<a target='_blank' href='https://app.identitytz.com/requisitions?id={$row['requisition_id']}'>".str_pad($row['requisition_id'], 5, '0', STR_PAD_LEFT)."</a>";
        $date = date('d/m/Y', strtotime($row['date_created']));
        $time = date('H:i:s', strtotime($row['date_created']));
        $job_ref = '-';
        if($row['job_id']){
            $job_ref = "{$row['job_id']}:{$row['job_reference']} - {$row['group_company']}";
        }

        $dept = ($row['department_name']) ? $row['department_name'] : '-';
        $dept .= '<br>' . $row['requisition_location'];

        $status_html = "<span>{$row['requisition_status']}</span>";
        if($row['requisition_status'] == 'Approved' && $row['approval_user_id'] > 0){
            $approval_date = date('d M Y', strtotime($row['approval_date']));
            $approval_time = date('H:i:s', strtotime($row['approval_date']));
           // $status_html .= "<br><i>by {$row['approval_user']}</i><br><i>on {$approval_date} ({$approval_time})</i>";
        }

        // Duration: if complete use date_updated - date_created, else use now - date_created
        // Display hours when < 24h, otherwise show days
        $duration_display = '';
        if(!empty($row['date_created'])){
            $start = strtotime($row['date_created']);
            if(!empty($row['date_updated']) && $row['requisition_status'] == 'Complete'){
                $end = strtotime($row['date_updated']);
            } else {
                $end = time();
            }
            $seconds = max(0, $end - $start);
            if($seconds < 86400){
                // show hours, round to nearest hour but at least 1
                $hours = max(1, (int) round($seconds / 3600));
                $duration_display = $hours . ' ' . ($hours == 1 ? 'hr' : 'hrs');
            } else {
                $days = (int) floor($seconds / 86400);
                $duration_display = $days . ' ' . ($days == 1 ? 'day' : 'days');
            }
        }

        $html .= "<tr>
                    <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$req_link}</td>
                    <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$date}<br>({$time})</td>
                    <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$duration_display}</td>
                    <td style='padding:3px 4px;' bgcolor='$row_color' align='left'>{$job_ref}</td>
                    <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$dept}</td>
                    <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$status_html}</td>
                    <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['user']}</td>
                  </tr>";

        // Items subtable (only sample items are included by params)
                $html .= "<tr><td colspan='7' style='padding:0 !important;'>";
                $html .= "<table width='100%' class='inner' style='border-collapse:collapse;'>";
                $html .= "<tr>
                                        <th style='padding:3px 6px;' bgcolor='#eee'>Item</th>
                                        <th style='padding:3px 6px;' bgcolor='#eee'>Image</th>
                                        <th style='padding:3px 6px;' bgcolor='#eee'>Required Qty</th>
                                        <th style='padding:3px 6px;' bgcolor='#eee'>Issued Qty</th>
                                        <th style='padding:3px 6px;' bgcolor='#eee'>Balance Qty</th>
                                        <th style='padding:3px 6px;' bgcolor='#eee'>Qty in Stock</th>
                                        <th style='padding:3px 6px;' bgcolor='#eee'>Qty Ordered</th>
                                    </tr>";

        if(isset($row['items']) && count($row['items']) > 0){
            foreach ($row['items'] as $item){
                $item_name = $item['stock_name'];
                // if($item['sample'] && isset($item['sample_image']) && $item['sample_image']){
                //     $img = basename($item['sample_image']);
                //     $item_name .= " <br><i>Sample: <a target='_blank' href='https://app.identitytz.com/{$item['sample_image']}'>{$img}</a></i>";
                // }

                $required = $item['quantity'] . ' ' . $item['units'];
                $issued = ($item['issued_qty'] > 0) ? $item['issued_qty'] . ' ' . $item['units'] : '-';
                $balance = $item['balance_qty'] . ' ' . $item['units'];
                $stock_qty = $item['stock_qty'] . ' ' . $item['units'];
                $qty_ordered = '-';
                if($item['qty_ordered'] > 0){
                    $qty_ordered = $item['qty_ordered'] . ' ' . $item['units'];
                    // if($item['lpo']){
                    //     $qty_ordered .= "<br>(LPO #{$item['lpo']})";
                    // }
                }

                                $sample_td = '-';
                                if($item['sample'] && !empty($item['sample_image'])){
                                        $img_url = $appUrl . ltrim($item['sample_image'], '/');
                                        $sample_td = "<a target='_blank' href='{$img_url}'><img src='{$img_url}' style='height:40px; max-width:80px; border:1px solid #ddd;'></a>";
                                }

                                $html .= "<tr>
                                                        <td style='padding:3px 6px;' bgcolor='$row_color'>{$item_name}</td>
                                                        <td style='padding:3px 6px;' bgcolor='$row_color' align='center'>{$sample_td}</td>
                                                        <td style='padding:3px 6px;' bgcolor='$row_color' align='center'>{$required}</td>
                                                        <td style='padding:3px 6px;' bgcolor='$row_color' align='center'>{$issued}</td>
                                                        <td style='padding:3px 6px;' bgcolor='$row_color' align='center'>{$balance}</td>
                                                        <td style='padding:3px 6px;' bgcolor='$row_color' align='center'>{$stock_qty}</td>
                                                        <td style='padding:3px 6px;' bgcolor='$row_color' align='center'>{$qty_ordered}</td>
                                                    </tr>";

                // toggle row color
                $row_color = ($row_color == $bg_color1) ? $bg_color2 : $bg_color1;
            }
        } else {
            $html .= "<tr><td colspan='7' style='padding:3px 6px;' bgcolor='$row_color' align='center'>No items found</td></tr>";
        }

        $html .= "</table>";
        $html .= "</td></tr>";

        // separator row to show clear separation between requisitions
        $html .= "<tr><td colspan='7' style='padding:1px 0 !important; background:#ccc;'></td></tr>";

        // reset row color for next requisition header
        $row_color = $bg_color1;
    }

    $html .= "</tbody></table>";

    $today = date('d M Y');
    $msg_body = "<p>The following are open sample requisition requests today -  $today</p><br>";
    $msg_body .= $html;

    $subject = "Identity App: Open Sample Requests - $today";

    $msg_body .= "<p>--------------</p>";
    $msg_body .= "<p>This email was generated by Identity App (https://app.identitytz.com)</p>";

   // $email_to = ['hasnain@identitytz.com','kazim@identitytz.com','accounts2@identitytz.com','procurement@identitytz.com'];
    $email_to = ['beecraq@gmail.com'];
    $params  = [
      'subject' => $subject,
      'email_to' => $email_to,
      'body' => $msg_body
    ];

    echo $msg_body; exit;

    $sent = send_email($params);

    if($sent){
        echo "Email sent\n";
    } else {
        echo "Sending failed: ";
        var_export($sent);
        echo "\n";
    }

} else {
    echo "No records found.\n";
}
