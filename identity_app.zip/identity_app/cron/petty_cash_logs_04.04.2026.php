<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header("Content-Type: text/plain");

$local = false;
$cron = true;

if($local){
	$doc_root = $_SERVER['DOCUMENT_ROOT'];
}else{
	$doc_root = '/home/identity/public_html/app';
}


require("$doc_root/configs/variables.php");
require("$doc_root/configs/functions.php");
require ("$doc_root/modules/configurations.php");
require ("$doc_root/modules/ledger_accounts/functions.php");

$date_from = date('Y-m-d').' 00:00:00';
$date_to = date('Y-m-d').' 11:59:59';
//  $date_from = '202-03-26 00:00:00';
//   $date_to = '2026-03-26 11:59:59';


// $log_list_sql = "SELECT pc.amount,CONCAT(u.user_fname,' ', u.user_lname) AS user, pc.attachment, pc.date_created,
// 									 pc.reference, pc.status, pc.remarks, CONCAT(je.first_name,' ', je.last_name) AS employee_name,
// 									 jexp.expense_name, lpo.lpo_id
// 					FROM `jos_petty_cash` as pc
// 					LEFT JOIN jos_expenses as jexp
// 					ON jexp.expense_id = pc.expense_id
// 					LEFT JOIN `cms_users` as u
// 						ON pc.user_id = u.user_id
// 					LEFT JOIN jos_employees as je
// 						ON je.id = pc.employee_id
// 						LEFT JOIN `jos_lpo` as lpo
// 						ON lpo.lpo_id = pc.lpo_id
// 					 WHERE (pc.date_created >= '$date_from' OR pc.date_updated >= '$date_from') AND (pc.status='Issued' OR pc.status='Closed')";


$log_list_sql = "SELECT pc.id,pc.amount, CONCAT(u.user_fname,' ', u.user_lname) AS user, pc.date_created,
										pc.status, pc.remarks, CONCAT(je.first_name,' ', je.last_name) AS employee_name,
									 jexp.expense_name, lpo.lpo_id
					FROM `jos_petty_cash` as pc
					LEFT JOIN jos_expenses as jexp
					ON jexp.expense_id = pc.expense_id
					LEFT JOIN `cms_users` as u
						ON pc.user_id = u.user_id
					LEFT JOIN jos_employees as je
						ON je.id = pc.employee_id
						LEFT JOIN `jos_lpo` as lpo
						ON lpo.lpo_id = pc.lpo_id
					 WHERE (pc.date_created >= '$date_from' OR pc.date_updated >= '$date_from') AND pc.status IN ('Pending','Approved','Issued')";

$result = mysql_query($log_list_sql);
$attachments = [];

$cronDate = date('Y-m-d H:i:s');
$rows = mysql_num_rows($result);
echo "[Run Date $cronDate] $rows Records found..\n\n";

if(mysqli_num_rows($result) > 0) {

  echo "Records found..\n\n";
	$aprroved_amount_sql = "SELECT SUM(IF(status = 'Approved', amount,0)) AS 'approved' FROM jos_petty_cash";

	$aprroved_amount_qry = mysql_query($aprroved_amount_sql);
	$aprroved_amount = mysql_fetch_array($aprroved_amount_qry, MYSQL_ASSOC)['approved'];

   $account = get_ledger_accounts(['account_id' => 12]);
   $cash_balance = $account[0]['balance'];

	$cash_required = $aprroved_amount - $cash_balance + 3000000;


	// Get Opening Balance
	$obDate = date('Y-m-d', strtotime('-1 day'));
	$obSql = "SELECT * FROM `jos_account_transactions` WHERE `account_id` = 12 AND date(date_created) = '$obDate' ORDER BY id DESC LIMIT 1;";
    $obData = smartsql($obSql);
	$opening_balance = 0;
	if(isset($obData[0])){
		$opening_balance = $obData[0]['account_balance'];
	}


  echo "Approved: $aprroved_amount\n\n";
	echo "Balance: $cash_balance\n\n";
	echo "Required: $cash_required\n\n";


    $pcv_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $pcv_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>Reference</th>
																<th style='padding:3px 4px;' bgcolor='#ccc'>Status</th>
														    <th style='padding:3px 4px;' bgcolor='#ccc'>Expense Type</th>
														    <th style='padding:3px 4px;' bgcolor='#ccc'>Remarks</th>
					                      <th style='padding:3px 4px;' bgcolor='#ccc'>Amount</th>
					                      <th style='padding:3px 4px;' bgcolor='#ccc'>Issued To</th>
																<th style='padding:3px 4px;' bgcolor='#ccc'>LPO</th>
					                      <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
                            </tr>
                        </thead>";
    $pcv_html .= "<tbody>";

    $today = date('d M Y');

    while ($row = mysql_fetch_assoc($result)) {

        $date = date('d M Y h:i:s', strtotime($row['date_created']));
        $payee = ($row['employee_name'] == '')? '-': $row['employee_name'];
        $amount = number_format($row['amount']);
      //  $account_amount = number_format($row['account_amount']);

		if($row['status'] == 'Closed' && $row['attachment']){

		    echo "Attchment found {$row['attachment']}..\n";

			// GRN Attachment check
			$grnAttched = false;
			$grnCheckSql = "SELECT grn_id FROM jos_grn WHERE attachment_path LIKE '%{$row['attachment']}%'";
			$grnResult = mysql_query($grnCheckSql);
			if(mysqli_num_rows($grnResult) > 0){
				$grnAttched = true;
			}

			if(array_search($row['attachment'], $attachments) === false && $grnAttched == false){
				$attachments[] =  $row['attachment'];
			}else{
			  echo "Attchment removed {$row['attachment']}..\n";
			}



		}

        $pcv_html .= "<tr>

						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['reference']."</td>
								<td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['status']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['expense_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['remarks']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$amount TZS</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$payee</td>
								<td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$row['lpo_id']}</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['user']."</td>

						 </tr>";

    }

    $pcv_html .= "</tbody></table>";

    // echo $pcv_html;
		// exit;

		// $result2 = mysql_query($log_list_sql2);

		// $pcv_html2 = "<br><p>Approved cash log:</p>";

		// if(mysql_num_rows($result2) > 0) {

		// 	$pcv_html2 .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	    // $pcv_html2 .= "<thead>
	    //                         <tr>
	    //                             <th width='40' style='padding:3px;' bgcolor='#ccc'>#</th>
		// 													    <th style='padding:3px 4px;' bgcolor='#ccc'>Expense Type</th>
		// 													    <th style='padding:3px 4px;' bgcolor='#ccc'>Remarks</th>
		// 				                      <th style='padding:3px 4px;' bgcolor='#ccc'>Amount</th>
		// 															<th style='padding:3px 4px;' bgcolor='#ccc'>LPO</th>
		// 				                      <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
	    //                         </tr>
	    //                     </thead>";
	    // $pcv_html2 .= "<tbody>";

		// 	while ($row = mysql_fetch_assoc($result2)) {

	    //     $amount = number_format($row['amount']);
	    //   //  $account_amount = number_format($row['account_amount']);

	    //     $pcv_html2 .= "<tr>

		// 					    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['id']."</td>
		// 					    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['expense_name']."</td>
		// 					    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['remarks']."</td>
		// 					    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$amount TZS</td>
		// 							<td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>{$row['lpo_id']}</td>
		// 					    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['user']."</td>

		// 					 </tr>";

	    // }

		// }else{
		// 	$pcv_html2 .= "No records found";
		// }


		require($doc_root . '/vendor/autoload.php'); // Ensure PHPMailer is included

    $mail = new PHPMailer(true);

		// Server settings
    $mail->isSMTP();
		$mail->Host = SMTP_HOST;  // Replace with your SMTP server
		$mail->SMTPAuth = true;
		$mail->Username = SMTP_USERNAME; // SMTP username
		$mail->Password = SMTP_PASSWORD; // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587; // Usually 587 for TLS
    $mail->isHTML(true);

    $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
    $mail->Subject = 'Identity App: Todays Petty Cash Log';
    $mail->addAddress('hasnain@identitytz.com');
    $mail->addAddress('kazim@identitytz.com');
    $mail->addAddress('accountsipl@identitytz.com');
    $mail->addAddress('vijay@identitytz.com');
//   	$mail->addAddress('accounts@identitytz.com');
//   	$mail->addAddress('admin@identitytz.com');
  	
	//	$mail->addAddress('beecraq@gmail.com');
    $tmrw = date('d M Y', strtotime('+1 day'));
    $cash_required = number_format(floatval($cash_required));
    $closing_balance = number_format(floatval($cash_balance));
    $opening_balance = number_format(floatval($opening_balance));
	$msg_body = "<p>Opening Balace : $opening_balance TZS </p>";
    $msg_body .= "<p>Closing Balace : $closing_balance TZS </p>";
		$msg_body .= "<p>Cash requirement for tomorrow ($tmrw) : $cash_required TZS </p>";
		$msg_body .= "<p>The following is list of Unclosed PCVs for today ($today) :</p><br>".$pcv_html;
		// $msg_body .= $pcv_html2;

		  //echo $msg_body;
		  //print_r($attachments);
		  //exit;

    $mail->Body = $msg_body;

	// Attachemnt on Closed PCVs
	if(!empty($attachments)){

		foreach($attachments as $attch){
			$filepath = "$doc_root/{$config['attachment_dir']}$attch";
			$mail->addAttachment($filepath);
		}
	}else{
	  echo "No Attchments \n";
	}

   if($mail->send()){
        echo "Email sent";
    }else{
		echo "something went wrong";
	}


}else{
    echo 'no records found';
}
@mysql_close();
