<?php

require("/home/identity/public_html/app/configs/variables.php");
// require("/home/identity/public_html/app/modules/configurations.php");
$ATTACHMENTS_DIR = $_SERVER['DOCUMENT_ROOT'] . '/uploads/attachments/';



$min_stock_sql = "SELECT *  FROM `jos_stock`
                            WHERE stock_qty < stock_min_qty
                            ORDER BY stock_name ASC";

$result = mysql_query($min_stock_sql);

$report_array = array();

if(mysql_num_rows($result) > 0) {


    $report_html = "<table width='100%' border='0' cellspacing='0' cellpadding='10px'>";
    $report_html .= "<thead>
                            <tr>
                                <th width='40' bgcolor='#ccc'>ID</th>
							    <th  bgcolor='#ccc'>Stock Name</th>
							    <th  bgcolor='#ccc'>Category</th>
							    <th  bgcolor='#ccc'>Quantity</th>
                                <th  bgcolor='#ccc'>Min Stock Level</th>
                            </tr>
                        </thead>";
    $report_html .= "<tbody>";

    $current_cat = "";
    $previous_cat = "";

    while ($row = mysql_fetch_assoc($result)) {


        $current_cat = $row['category'];

        if($previous_cat != $current_cat){

            $report_html .= "<tr>
						    <td bgcolor='#fcfcfc'>&nbsp;</td>
						    <td bgcolor='#fcfcfc'>&nbsp;</td>
						    <td bgcolor='#fcfcfc'>&nbsp;</td>
						    <td bgcolor='#fcfcfc'>&nbsp;</td>
						    <td bgcolor='#fcfcfc'>&nbsp;</td>
						</tr>";

        }

        $report_html .= "<tr>
						    <td style='border-bottom:1px solid #f2f2f2'  bgcolor='#fcfcfc' align='center'>".$row['stock_id']."</td>
						    <td style='border-bottom:1px solid #f2f2f2' bgcolor='#fcfcfc' align='center'>".$row['stock_name']."</td>
						    <td style='border-bottom:1px solid #f2f2f2' bgcolor='#fcfcfc' align='center'>".$row['category']."</td>
						    <td style='border-bottom:1px solid #f2f2f2' bgcolor='#fcfcfc' align='center'>".$row['stock_qty'].$row['units']."</td>
						    <td style='border-bottom:1px solid #f2f2f2' bgcolor='#fcfcfc' align='center'>".$row['stock_min_qty'].$row['units']."</td>
						</tr>";

        $report_array[] = array(

            'stock_id' => $row['stock_id'],
            'stock_name' => $row['stock_name'],
            'category' => $row['category'],
            'stock_qty' => $row['stock_qty'].$row['units'],
            'stock_min_qty' => $row['stock_min_qty'].$row['units']
        );

        $previous_cat = $current_cat;

    }

    $report_html .= "</tbody></table>";
    $date = date('d-m-Y');
    $today = date('d M Y');

    // print_r($report_array);
    // exit;

    // echo $report_html;
    $filename = "Stock-Reorder-Notice-$date-".time().".csv";
    $filepath = $ATTACHMENTS_DIR.$filename;

  

    $file = fopen($filepath, 'w');
    fputcsv($file, array('ID','Stock Name','Category','Qunatity','Min Stock Level'));
    foreach ($report_array as $line) {
        fputcsv($file, ($line));
    }
    fclose($file);

    $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';

    require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');

    $postmark = new Postmark\Mail($postmarkApiKey);
    $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
    $postmark->subject('Identity App: Stock Reorder Notice');
    $postmark->addTo('beecraq@gmail.com');


    $msg_body = "<p>Attached is a report for stock items that are below the minimum reorder level for $today:</p><br>";

    $postmark->messageHTML($msg_body);
    $postmark->addAttachment($filepath);

    if($postmark->send()){
        echo "Email sent";
    } else {
        echo "Sending failed.";
    }

    @unlink($filepath);

}
