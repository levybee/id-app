<?php
// This report will be sent at  on Fridays at 1pm

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

// Start
$cronRun = date('Y-m-d H:i:s');
echo "Cron Run[$cronRun]:\n";
echo "Starting automation for approved LPOs.\n";

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';
require($root_dir."configs/variables.php");
require($root_dir."configs/functions.php");

$ATTACHMENTS_DIR = $root_dir . '/tmp/';

$qcs = array();
$today = date('d M Y');
$sql_date = date('Y-m-d');

// Approved LPOs
$approved_lpo_sql = "SELECT
    l.lpo_id,
    l.lpo_date,
    l.date_created,
    l.lpo_attention,
    l.lpo_status,
    l.lpo_supplier,
    l.lpo_destination,
    l.comments,
    s.supplier_id,
    s.supplier_fname,
    s.supplier_lname,
    s.supplier_company,
    l.payment_type,
    l.cob,
		CONCAT(u.user_fname, ' ', u.user_lname) AS user
FROM
    `jos_lpo` AS l
LEFT JOIN `jos_suppliers` AS s
ON
    s.supplier_id = l.supplier_id
LEFT JOIN `cms_users` AS u
ON u.user_id = l.user_id
WHERE l.lpo_status IN ('Approved')
GROUP BY
    l.lpo_id
ORDER BY l.lpo_date
DESC, l.lpo_id DESC";

$approved_result = mysql_query($approved_lpo_sql);

if(mysqli_num_rows($approved_result) > 0) {

  echo "Found ".mysqli_num_rows($approved_result)." LPOs.\n";

	$filename = "Approved-LPO-$sql_date.csv";
  $filepath = $ATTACHMENTS_DIR.$filename;

    $file = fopen($filepath, 'w');
    fputcsv($file, array('LPO ID','Date','Supplier','Destination','Comments','User'));

  while ($row = mysql_fetch_assoc($approved_result)) {

		$date = date('d/m/Y', strtotime($row['date_created']));
		$time = date('H:i:s', strtotime($row['date_created']));
		$lpo_date = "$date <br>($time)";
		$supplier = ($row['supplier_id'] > 0)? $row['supplier_company'] : $row['supplier'] ;


      fputcsv($file, array("{$row['lpo_id']}","$date","$supplier","{$row['lpo_destination']}","{$row['comments']}","{$row['user']}"));

      // PCV/Transfer
      $pc_list_sql = "SELECT 'pcv' as pc_type, pc.reference, pc.date_created, itmAmt.items_amount, pc.remarks, pc.status
		FROM jos_petty_cash as pc
	LEFT JOIN (SELECT pci.pc_id, pci.lpo_id, SUM(pci.amount) as items_amount
			   FROM  jos_pettycash_items as pci
			   LEFT JOIN jos_petty_cash pc
			   ON pc.id = pci.pc_id
			   GROUP BY pci.lpo_id) as itmAmt
			   ON itmAmt.pc_id = pc.id
			   WHERE itmAmt.lpo_id = {$row['lpo_id']}

			   UNION

			   (SELECT 'transfer' as pc_type, pc.reference, pc.date_created, itmAmt.items_amount, pc.remarks, pc.status
			   FROM jos_petty_cash_mobile as pc
	LEFT JOIN (SELECT pci.pcm_id, pci.lpo_id, SUM(pci.amount) as items_amount
			   FROM  jos_pettycash_mobile_items as pci
			   LEFT JOIN jos_petty_cash_mobile pc
			   ON pc.id = pci.pcm_id
			   GROUP BY pci.lpo_id) as itmAmt
			   ON itmAmt.pcm_id = pc.id
			   WHERE itmAmt.lpo_id = {$row['lpo_id']})";

  $pc_list = smartsql($pc_list_sql);
  $line = array("","","","","");
  if(isset($pc_list[0])){

    fputcsv($file, $line);
    foreach($pc_list as $pc){
      fputcsv($file, ["Reference","Date","Amount","Remarks","Status"]);
      $pc_date = date('d/m/Y', strtotime($pc['date_created']));
      $amount = number_format($pc['items_amount'], 2);
      $ref = ($pc['pc_type'] == 'pcv')? "PCV {$pc['reference']}" : "Transfer {$pc['reference']}";
      fputcsv($file, array("$ref","$pc_date","$amount","{$pc['remarks']}","{$pc['status']}"));

    }

  }

  fputcsv($file, $line);
  fputcsv($file, $line);


  }


  require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

  $mail = new PHPMailer(true);

  // Server settings
  $mail->isSMTP();
  $mail->Host = SMTP_HOST;  // Replace with your SMTP server
  $mail->SMTPAuth = true;
  $mail->Username = SMTP_USERNAME; // SMTP username
  $mail->Password = SMTP_PASSWORD; // SMTP password
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587; // Usually 587 for TLS
  $mail->isHTML(true);

  $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
  $mail->Subject = "Identity App: Approved LPOs";
  $mail->addAddress('hasnain@identitytz.com');
 // $mail->addAddress('controller@identitytz.com');
 // $mail->addAddress('procurement@identitytz.com');
//  $mail->addAddress('kazim@identitytz.com');
// $mail->addAddress('operations@identitytz.com');
  // $mail->addAddress('beecraq@gmail.com');

  $msg_body = "<p>Attached report of Approved LPOs.</p><br>";

//   echo $msg_body;
//   exit;
  $mail->Body = $msg_body;
  $mail->addAttachment($filepath);

 if($mail->send()){
     echo "Email sent";
  }


}else{
  echo "No records found.\n";
}
