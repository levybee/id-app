<?php

// ini_set('display_errors', 1);
// error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;

header("Content-Type: text/plain");

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");

$grn_items = array();
$grns = array();
$today = date('d M Y');
$to_date = date('Y-m-d', strtotime('last day of previous month'));

$date_arr = explode('-', $to_date);
$m = $date_arr[1];
$y = $date_arr[0];
$from_date = "$y-$m-01";

$month = date('F', strtotime($from_date));
$month_from = date('d F Y', strtotime($from_date));
$month_to = date('d F Y', strtotime($to_date));


$grn_sql = "SELECT grn.*,SUM(IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) * gi.grn_item_qty) as grn_value,
            SUM(IF(lpo.lpo_tax = 'Taxable',
              (IF(lpo.lpo_currency = 'USD', li.item_unit_price * lpo.exch_rate, li.item_unit_price) * gi.grn_item_qty) * 0.18, 0)) as tax,
           lpo.lpo_supplier, s.supplier_id, s.supplier_fname, s.supplier_lname, s.supplier_company,
					 lpo.lpo_currency
				FROM jos_grn grn
				LEFT JOIN jos_grn_items as gi
					 ON grn.grn_id = gi.grn_id
					 LEFT JOIN jos_lpo_items as li
							ON li.item_id = gi.lpo_item_id
			  LEFT JOIN jos_lpo as lpo
					 ON lpo.lpo_id = grn.lpo_id
				LEFT JOIN jos_suppliers as s
					 ON s.supplier_id = lpo.supplier_id
				WHERE grn_date >= '$from_date' AND grn_date <= '$to_date' GROUP BY grn.grn_id";

$result_grn = mysql_query($grn_sql);

$cronDate = date('Y-m-d H:i:s');
$rows = mysql_num_rows($result_grn);
echo "[Run Date $cronDate] $rows Records found..\n\n";

if($rows > 0) {

    echo  "Creating HTML email content\n";

  $total_grn = 0;
  $total_tax = 0;
	while ($row = mysql_fetch_array($result_grn)) {

	   $grns[] = $row;
     $total_grn += $row['grn_value'];
     $total_tax += $row['tax'];
	}



	$grn_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$grn_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>ID</th>
															<th style='padding:3px 4px;' bgcolor='#ccc'>LPO ID</th>
															<th style='padding:3px 4px;' bgcolor='#ccc'>Supplier</th>
                              <th style='padding:3px 4px;' bgcolor='#ccc'>Tax</th>
															<th style='padding:3px 4px;' bgcolor='#ccc'>GRN Value</th>
													</tr>
											</thead>";
	$grn_html .= "<tbody>";

  if(count($grns) > 0){

    foreach ($grns as $key => $value) {


              $ref_yy = substr($value['grn_date'], 0, 4);
        	    $ref_no = 'GRN-'.$ref_yy . '-' . leading_zero($value['grn_id'], 5);

  						$supplier = $value['supplier_company'];



  							$grn_value = number_format($value['grn_value'], 0);
                $tax = number_format($value['tax'], 0);


              $lpo_currency = 'TZS';

  						$grn_value = $grn_value." ".$lpo_currency;
              $tax = $tax." ".$lpo_currency;

  						$grn_html .= "<tr>
  								    <td style='padding:3px 4px;'  align='center'>".$ref_no."</td>
  								    <td style='padding:3px 4px;'  align='center'>".$value['lpo_id']."</td>
  								    <td style='padding:3px 4px;'  align='center'>".$supplier."</td>
  										<td style='padding:3px 4px;'  align='center'>".$tax."</td>
                      <td style='padding:3px 4px;'  align='center'>".$grn_value."</td>
  								     </tr>
  										";



  	}


  }else{
    $grn_html .= "<tr>
    <td colspan='4'><p>No records found</p></td>

     </tr>";
  }

  $grn_html .= "</tbody></table>";

  $grn_html .= "<tr>
  <td colspan='4'>&nbsp;</td>

   </tr><tr>
   <td colspan='4'>&nbsp;</td>

    </tr>";

    $grn_html .= "<tr>
    <td align='left'><strong>Total GRN Value</strong></td><td colspan='3' align='left'>".number_format($total_grn, 0)."TZS</td>

     </tr><tr>
     <td align='left'><strong>Total VAT Value</strong></td><td colspan='3' align='left'>".number_format($total_tax, 0)." TZS</td>
      </tr>";



  $grn_html .= "</tbody></table>";

  require("/home/identity/public_html/app/vendor/autoload.php"); // Ensure PHPMailer is included


  $mail = new PHPMailer(true);

  // Server settings
  $mail->isSMTP();
  $mail->Host = SMTP_HOST;  // Replace with your SMTP server
  $mail->SMTPAuth = true;
  $mail->Username = SMTP_USERNAME; // SMTP username
  $mail->Password = SMTP_PASSWORD; // SMTP password
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
  $mail->Port = 587; // Usually 587 for TLS
  $mail->isHTML(true);

  $mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
  $mail->Subject = "Identity App: GRN Report for $month";

  $mail->addAddress('hasnain@identitytz.com');
  $mail->addAddress('kazim@identitytz.com');
  $mail->addAddress('accountsipl@identitytz.com');
  $mail->addAddress('store@identitytz.com');
  $mail->addAddress('procurement@identitytz.com');
 // $postmark->addTo('FC@identitytz.com');
//  $postmark->addTo('beecraq@gmail.com');

  $msg_body = "<p>The following is a list of GRN records from $month_from to $month_to:</p><br>".$grn_html;

//   print_r($msg_body);
//   exit;

$mail->Body = $msg_body;

 if($mail->send()){
     echo "Email sent";
  }

}else{

   echo "No records found";
}
