<?php

require("/home/identity/public_html/app/configs/variables.php");

$quotes_msg_html = '';
$jobs_msg_html = '';
$lpo_msg_html = '';
$requisitions_msg_html = '';


// Quotes
$approval_sql = "SELECT q. * , count( jos_quotes_items.quote_id ) AS quote_items_num, jos_customers_group.group_company, jos_customers.customer_id, jos_customers.customer_fname, jos_customers.customer_lname, jos_customers.customer_email
                    FROM `jos_quotes` AS q
                    LEFT JOIN `jos_quotes_items` ON jos_quotes_items.quote_id = q.quote_id
                    LEFT JOIN `jos_customers` ON jos_customers.customer_id = q.customer_id
                    LEFT JOIN `jos_customers_group` ON jos_customers_group.group_id = jos_customers.group_id
                    WHERE q.quote_status = 'Confirmed'
                    GROUP BY q.quote_id
                    ORDER BY q.quote_date DESC";

$result = mysql_query($approval_sql);

if(mysql_num_rows($result) > 0) {

    //var_dump($result);

    $quotes_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
    $quotes_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>ID</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Quote Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>No of Items</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th>
                            </tr>
                        </thead>";
    $quotes_html .= "<tbody>";


    while ($row = mysql_fetch_assoc($result)) {

        $customer = ($row['customer_id'] == 0)? $row['quote_customer'] : $row['group_company']." - ". $row['customer_fname']." ".$row['customer_lname'];

        $date = date('d M Y', strtotime($row['quote_date']));

        $quotes_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['quote_id']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$customer."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['quote_items_num']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/quotes/view/?id=".$row['quote_id']."'>Approve</a></td>
						</tr>";

    }

    $quotes_html .= "</tbody></table>";

    //echo $quotes_html;

    //$quotes_subject = "Identity App: Quotes Approval Notice";
    $quotes_msg_txt = "The following quotes have been confirmed and have to be approved:";

    $quotes_msg_html = "<p>$quotes_msg_txt</p><br>$quotes_html<br><br><br>";

   // send_approval_email($quotes_subject, $quotes_msg_txt, $quotes_html);
}


    // Jobs

    $jobs_approval_sql = 'SELECT j.group_id, j.job_id, j.job_date, j.job_time, j.job_due_date, j.job_due_time, j.job_status, j.job_reference, j.job_product, j.job_paper_quantity, j.job_color, j.job_color_other, j.job_invoice_no,
						 jos_customers_group.group_company, cms_users.user_fname, cms_users.user_lname,
						 jos_customers.customer_fname, jos_customers.customer_lname, jos_customers.customer_email,
	                     jos_departments.department_name,
	                     jos_products.product_name
					FROM `jos_jobs` as j

				    LEFT JOIN `jos_jobs_groups` as g
					   ON g.group_id = j.group_id

					LEFT JOIN `jos_customers`
					   ON jos_customers.customer_id = g.customer_id

					LEFT JOIN `jos_customers_group`
					   ON jos_customers_group.group_id = jos_customers.group_id

					LEFT JOIN `jos_departments`
					   ON jos_departments.department_id = j.department_id

					LEFT JOIN `jos_products`
					   ON jos_products.product_ref = j.job_product
                    LEFT JOIN `cms_users`
					   ON cms_users.user_id = j.user_id

					WHERE j.job_status = "Pending"
                    ORDER BY j.job_date DESC;';



    $jobs_result = mysql_query($jobs_approval_sql);


    if(mysql_num_rows($jobs_result) > 0) {

        //var_dump($result);

        $jobs_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
        $jobs_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>JO #</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Product</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Title</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Customer</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Quantity</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Due Date</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Department</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th>
                            </tr>
                        </thead>";
        $jobs_html .= "<tbody>";


        while ($row = mysql_fetch_assoc($jobs_result)) {

            $job_date = date('d M Y', strtotime($row['job_date'])). '<br>'. $row['job_time'];
            $jo_ref = substr($row['job_date'], 0, 4). '-'.substr($row['job_date'], 5, 2).'-'.str_pad($row['job_id'], 5, '0', STR_PAD_LEFT).'-'.substr($row['user_fname'], 0, 1).substr($row['user_lname'], 0, 1);
            $customer = $row['group_company']. ' - '.$row['customer_fname'].' '.$row['customer_lname'];
            $due_date = ($row['job_due_date'] == '0000-00-00')? 'TBC' : date('d M Y', strtotime($row['job_due_date'])). '<br>'. $row['job_due_time'];

            $jobs_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$jo_ref."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$job_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['product_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['job_reference']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$customer."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".number_format($row['job_paper_quantity'], 0, '.', ',')."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$due_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['department_name']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/jobs/progress?id=".$row['job_id']."'>Approve</a></td>
						 </tr>";
        }

        $jobs_html .= "</tbody></table>";

        //$jobs_subject = "Identity App: Jobs Approval Notice";
        $jobs_msg_txt = "The following jobs orders require approval:";

        //send_approval_email($jobs_subject, $jobs_msg_txt, $jobs_html);

        $jobs_msg_html = "<p>$jobs_msg_txt</p><br>$jobs_html<br><br><br>";



    }



    // LPO
    $lpo_approval_sql = 'SELECT l.lpo_id, l.lpo_date, l.lpo_attention, l.lpo_status, l.lpo_supplier, l.lpo_destination,
					   s.supplier_id, s.supplier_fname, s.supplier_lname, s.supplier_company, s.supplier_email,
					   u.user_fname, u.user_lname
					FROM `jos_lpo` as l

					LEFT JOIN `jos_suppliers` as s
					   ON s.supplier_id = l.supplier_id

					LEFT JOIN `cms_users` as u
					   ON u.user_id = l.user_id

					WHERE l.lpo_status  = "Pending"
                    ORDER BY l.lpo_date DESC;';


    $lpo_qry = mysql_query($lpo_approval_sql) or die(mysql_error());



    if(mysql_num_rows($lpo_qry) > 0) {

        $lpo_list = array();

        while($lpo_data = mysql_fetch_array($lpo_qry, MYSQL_ASSOC)) {

            // Loop to get items
            // $lpo_items_qry = mysql_query('SELECT `item_product` FROM `jos_lpo_items` WHERE `lpo_id` = \'' . $lpo_data['lpo_id'] . '\';');
            $lpo_items_qry = mysql_query('SELECT `item_id` FROM `jos_lpo_items` WHERE `lpo_id` = \'' . $lpo_data['lpo_id'] . '\';');

            if($lpo_items_qry) {

                $items_num = mysql_num_rows($lpo_items_qry);


            } else {

                $items_num = 0;
                $items_text = '---';

            }

            // Temporary Array
            $lpo_temp = array (
                'lpo_info' => $lpo_data,
                'lpo_items_num' => $items_num,
                'lpo_items_desc' => $items_text
            );

            $lpo_list[] = $lpo_temp;

        }

        foreach ($lpo_list as $k => $v){

            if($v['lpo_info']['supplier_id'] == 0){

                $supplier_info = explode(',' , $v['lpo_info']['lpo_supplier']);
                $lpo_list[$k]['lpo_info']['supplier'] =  $supplier_info[0];
            }
        }


        $lpos_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
        $lpos_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>Ref #</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Supplier</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Destination</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Items #</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th>
                            </tr>
                        </thead>";
        $lpos_html .= "<tbody>";


        foreach ($lpo_list as $row) {

            $lpo_date = date('d M Y', strtotime($row['lpo_info']['lpo_date']));
            $lpo_ref = 'LPO-'.substr($row['lpo_info']['lpo_date'], 0, 4).'-'.str_pad($row['lpo_info']['lpo_id'], 4, '0', STR_PAD_LEFT);
            $supplier = ($row['lpo_info']['supplier_id'] == 0 || $row['lpo_info']['supplier_id'] == '')? $row['lpo_info']['supplier']: $row['lpo_info']['supplier_company'].' - '.$row['lpo_info']['supplier_fname']. ' ' .$row['lpo_info']['supplier_lname'];

            $lpos_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$lpo_ref."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$lpo_date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$supplier."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['lpo_info']['lpo_destination']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['lpo_items_num']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/lpo/approve/?id=".$row['lpo_info']['lpo_id']."'>Approve</a></td>
						 </tr>";
        }

        $lpos_html .= "</tbody></table>";

        // echo $lpos_html;

        //$lpos_subject = "Identity App: Requisitions Approval Notice";
        $lpos_msg_txt = "The following LPOs require approval:";

        //send_approval_email($jobs_subject, $jobs_msg_txt, $lpos_html);

        $lpo_msg_html = "<p>$lpos_msg_txt</p><br>$lpos_html<br><br><br>";


    }


    // Requisitions

    $requisitions_approval_sql = 'SELECT r.*, js.units, js.stock_name, js.stock_qty,
	                    jd.department_name, j.job_reference, cg.group_company
						FROM `jos_requisitions` as r
                	    LEFT JOIN `jos_stock` as js
                          ON js.stock_id = r.stock_id
	                    LEFT JOIN `jos_jobs` as j
	                      ON j.job_id = r.job_id
                        LEFT JOIN `jos_departments` as jd
                          ON jd.department_id = j.department_id
	                    LEFT JOIN `jos_jobs_groups` as g
					     ON g.group_id = j.group_id
	                   LEFT JOIN `jos_customers` as c
					     ON c.customer_id = g.customer_id

					   LEFT JOIN `jos_customers_group` as cg
					     ON cg.group_id = c.group_id
                       WHERE r.status = "Draft"
						ORDER BY r.requisition_date DESC;';



    $requisitions_result = mysql_query($requisitions_approval_sql);

    if(mysql_num_rows($requisitions_result) > 0) {

        //var_dump($result);

        $requisitions_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
        $requisitions_html .= "<thead>
                            <tr>
                                <th width='40' style='padding:3px;' bgcolor='#ccc'>ID</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Requisition Date</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Item</th>
							    <th style='padding:3px 4px;' bgcolor='#ccc'>Job Reference</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Department</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Required Qty</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>Qty in Stock</th>
                                <th style='padding:3px 4px;' bgcolor='#ccc'>&nbsp;</th>
                            </tr>
                        </thead>";
        $requisitions_html .= "<tbody>";


        while ($row = mysql_fetch_assoc($requisitions_result)) {

            $date = date('d M Y', strtotime($row['requisition_date']));
            $remarks = ($row['remarks'] == '')? '': ' - '.$row['remarks'];
            $item = ($row['stock_id'] == 0)? $row['item_description'].$remarks:$row['stock_name'].$remarks;
            $department = (isset($row['department_name']))? $row['department_name']: ' - ';
            $job_reference = ($row['job_id'] != 0)? $row['job_id'].': '.$row['job_reference'].' - '.$row['group_company']:' - ';

            $requisitions_html .= "<tr>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['requisition_id']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$date."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$item."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$job_reference."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$department."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['quantity']." ".$row['units']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['stock_qty']." ".$row['units']."</td>
						    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'><a target='_blank' href='http://app.identitytz.com/requisitions/?actn=approve&id=".$row['requisition_id']."'>Approve</a></td>
						 </tr>";

        }

        $requisitions_html .= "</tbody></table>";

        // echo $requisitions_html;

        //$requisitions_subject = "Identity App: Requisitions Approval Notice";
        $requisitions_msg_txt = "The following requisitions require approval:";

        //send_approval_email($requisitions_subject, $requisitions_msg_txt, $requisitions_html);

        $requisitions_msg_html = "<p>$requisitions_msg_txt</p><br>$requisitions_html";

    }

    $pcv_list_sql = "SELECT pc.id,pc.amount, CONCAT(u.user_fname,' ', u.user_lname) AS user,
    									  pc.status, pc.remarks, CONCAT(je.first_name,' ', je.last_name) AS employee_name,
    									 jexp.expense_name
    					FROM `jos_petty_cash` as pc
    					LEFT JOIN jos_expenses as jexp
    					ON jexp.expense_id = pc.expense_id
    					LEFT JOIN `cms_users` as u
    						ON pc.user_id = u.user_id
    					LEFT JOIN jos_employees as je
    						ON je.id = pc.employee_id
    					 WHERE pc.status='Pending'";

    $pcv_result = mysql_query($pcv_list_sql);

    $pcv_html = "<br><p>Pending cash approvals:</p>";

		if(mysql_num_rows($pcv_result) > 0) {

			$pcv_html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	    $pcv_html .= "<thead>
	                            <tr>
	                                <th width='40' style='padding:3px;' bgcolor='#ccc'>#</th>
															    <th style='padding:3px 4px;' bgcolor='#ccc'>Expense Type</th>
															    <th style='padding:3px 4px;' bgcolor='#ccc'>Remarks</th>
						                      <th style='padding:3px 4px;' bgcolor='#ccc'>Amount</th>
						                      <th style='padding:3px 4px;' bgcolor='#ccc'>User</th>
	                            </tr>
	                        </thead>";
	    $pcv_html .= "<tbody>";

			while ($row = mysql_fetch_assoc($pcv_result)) {

	        $amount = number_format($row['amount']);
	        $account_amount = number_format($row['account_amount']);

	        $pcv_html .= "<tr>

							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['id']."</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['expense_name']."</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['remarks']."</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>$amount TZS</td>
							    <td style='padding:3px 4px;' bgcolor='#fcfcfc' align='center'>".$row['user']."</td>

							 </tr>";

	    }

		}else{
			$pcv_html .= "No records found";
		}


    $subject = "Identity App: Approvals Notice";
    $msg_html = $quotes_msg_html.$jobs_msg_html.$lpo_msg_html.$requisitions_msg_html.$pcv_html;

    // echo $msg_html;
    // exit;

    send_approval_email($subject, $msg_html);

    function send_approval_email($subject, $msg_html){


        $postmarkApiKey = '223c8e12-4faa-4c65-8354-3d9be6648829';


        require_once('/home/identity/public_html/app/libs/Postmark/class.postmark.php');


        $postmark = new Postmark\Mail($postmarkApiKey);
        $postmark->from('identity@rahisisha.com', 'Identity Promotions Ltd');
        $postmark->subject($subject);
        $postmark->addTo('hasnain@identitytz.com');
       // $postmark->addTo('kazim@identitytz.com');
        $postmark->addTo('anthony@identitytz.com');

        $msg_body = $msg_html;

        $postmark->messageHTML($msg_body);

        //echo "Sending '$subject' email<br>";

        if($postmark->send()){
            // echo "Email sent";
        }


    }
