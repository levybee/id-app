<?php

use PHPMailer\PHPMailer\PHPMailer;

// ini_set('display_errors', 1);
// error_reporting(E_ALL);

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");

// 0 	18 	* 	* 	1-6 	php -q /home/identity/public_html/app/cron/qc_invoices_report.php

$qcs = array();
$today = date('d M Y');
$sql_date = date('Y-m-d');
// $sql_date = '2026-04-04';

$bg_color1 = '#fcfcfc';
$bg_color2 = '#e5e5e5';
$row_color = $bg_color1;


// QCs Issued
$qc_sql = "SELECT
qc.*, CONCAT(je.first_name, ' ', je.last_name) AS employee_name, je.employee_location,
CONCAT(u.user_fname, ' ', u.user_lname) AS user,
CONCAT(u2.user_fname, ' ', u2.user_lname) AS sales_user,
qc.balance AS balance_qty,
IF(stck.stock_id > 0,  stck.stock_name, j.job_reference) as job_reference,
cg.group_company, j.job_paper_quantity, d.department_name
FROM
`jos_qc` AS qc
LEFT JOIN jos_employees AS je
ON je.id = qc.given_by_employee_id
LEFT JOIN `jos_jobs` AS j
ON j.job_id = qc.job_id


LEFT JOIN `jos_products` as jp
			      ON j.job_product = jp.product_ref
LEFT JOIN `jos_quotes_items` as jqi
					   ON jqi.item_id = j.item_id

           LEFT JOIN `jos_stock` as stck
           ON stck.stock_id = jqi.stock_id
           
           LEFT JOIN jos_quotes AS jq
ON jq.quote_id = jqi.quote_id
LEFT JOIN cms_users AS u2
ON u2.user_id = jq.user_id

LEFT JOIN `jos_jobs_groups` AS g
ON g.group_id = j.group_id
LEFT JOIN `jos_customers` AS c
ON c.customer_id = g.customer_id
LEFT JOIN `jos_customers_group` AS cg
ON cg.group_id = c.group_id
LEFT JOIN `jos_departments` d ON
d.department_id = qc.department_id
LEFT JOIN `cms_users` AS u
ON u.user_id = qc.checked_by_user_id
WHERE date(qc.date_created) = '$sql_date'
ORDER BY qc.id
DESC";


$result_qc = mysql_query($qc_sql);


$qc_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$qc_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>ID</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Job Reference</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Production Qty</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Balance</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Sales User</th> 
													</tr>
											</thead>";
	$qc_html .= "<tbody>";
	
	

$qcIPL1 = [];
$qcIPL2 = [];
if(mysqli_num_rows($result_qc) > 0) {


	while ($row = mysql_fetch_assoc($result_qc)) {
		if($row['employee_location']  == 'IPL1'){
			$qcIPL1[] = $row;
		}
		if($row['employee_location']  == 'IPL2'){
			$qcIPL2[] = $row;
		}
	}

	// Create HTML email content
	$htmlIPL1 = '<h4>IPL 1</h4>';
	$htmlIPL2 = '<h4>IPL 2</h4>';
	$htmlBodyIPL1 = '';
	$htmlBodyIPL2 = '';

	if(count($qcIPL1) > 0){


		foreach($qcIPL1 as $k => $row){

	      $job_ref = ($row['job_id'] > 0)? $row['job_id'].": ".$row['job_reference']." - ".$row['group_company'] : '-';

	      $htmlBodyIPL1 .= "<tr>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['id']}</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$job_ref</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['quantity'], 2)."</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['balance_qty'], 2)."</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['sales_user']."</td>
	           </tr>";

	      if($row_color == $bg_color1){
	        $row_color = $bg_color2;
	      }elseif($row_color == $bg_color2){
	        $row_color = $bg_color1;
	      }
	  }


	}


	if(count($qcIPL2) > 0){


		foreach($qcIPL2 as $k => $row){

	      $job_ref = ($row['job_id'] > 0)? $row['job_id'].": ".$row['job_reference']." - ".$row['group_company'] : '-';

	      $htmlBodyIPL2 .= "<tr>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['id']}</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$job_ref</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['quantity'], 2)."</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['balance_qty'], 2)."</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['sales_user']."</td>
	           </tr>";

	      if($row_color == $bg_color1){
	        $row_color = $bg_color2;
	      }elseif($row_color == $bg_color2){
	        $row_color = $bg_color1;
	      }
	  }


	}

	$htmlIPL1 .= $qc_html.$htmlBodyIPL1;
	$htmlIPL1 .= "</tbody></table>";

	$htmlIPL2 .= "<br/><br/>".$qc_html.$htmlBodyIPL2;
	$htmlIPL2 .= "</tbody></table>";

	$qc_html = $htmlIPL1.$htmlIPL2;

}else{

  $qc_html .= "<tr>
              <td colspan='6' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No QC records found</td>
           </tr>";

					 $qc_html .= "</tbody></table>";

}



// Uninvoiced QCs
$qc_uninvoiced_sql = "SELECT
qc.*, CONCAT(je.first_name, ' ', je.last_name) AS employee_name, je.employee_location,
CONCAT(u.user_fname, ' ', u.user_lname) AS user,
CONCAT(u2.user_fname, ' ', u2.user_lname) AS sales_user,
qc.balance AS balance_qty,
IF(stck.stock_id > 0,  stck.stock_name, j.job_reference) as job_reference,
cg.group_company, j.job_paper_quantity, d.department_name
FROM
`jos_qc` AS qc
LEFT JOIN jos_employees AS je
ON je.id = qc.given_by_employee_id
LEFT JOIN `jos_jobs` AS j
ON j.job_id = qc.job_id

LEFT JOIN `jos_products` as jp
			      ON j.job_product = jp.product_ref
LEFT JOIN `jos_quotes_items` as jqi
					   ON jqi.item_id = j.item_id

           LEFT JOIN `jos_stock` as stck
           ON stck.stock_id = jqi.stock_id
           
           LEFT JOIN jos_quotes AS jq
ON jq.quote_id = jqi.quote_id
LEFT JOIN cms_users AS u2
ON u2.user_id = jq.user_id

LEFT JOIN `jos_jobs_groups` AS g
ON g.group_id = j.group_id
LEFT JOIN `jos_customers` AS c
ON c.customer_id = g.customer_id
LEFT JOIN `jos_customers_group` AS cg
ON cg.group_id = c.group_id
LEFT JOIN `jos_departments` d ON
d.department_id = qc.department_id
LEFT JOIN `cms_users` AS u
ON u.user_id = qc.checked_by_user_id
WHERE
    (
        qc.id NOT IN(
        SELECT
            ii.qc_id
        FROM
            jos_invoice_items ii
        LEFT JOIN jos_invoices i ON
            i.invoice_id = ii.invoice_id
        WHERE
            i.invoice_status != 'Cancelled' AND ii.qc_id IS NOT NULL
    ) AND qc.delivered IS NULL
    ) AND qc.type = 'Normal' AND c.customer_id != '62'
GROUP BY qc.id
ORDER BY u2.user_fname, u2.user_lname ASC";

$result_uninvoiced_qc = mysql_query($qc_uninvoiced_sql);


// echo $qc_uninvoiced_sql;
// exit;


$qc_uninvoiced_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$qc_uninvoiced_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>ID</th>
															<th style='padding:3px;' bgcolor='#ccc'>Date</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Job Reference</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Production Qty</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Balance</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Sales User</th>
													</tr>
											</thead>";
	$qc_uninvoiced_html .= "<tbody>";

$uninvoicedQC = [];
if(mysqli_num_rows($result_uninvoiced_qc) > 0) {


	while ($row = mysql_fetch_assoc($result_uninvoiced_qc)) {
		$sales_user = $row['sales_user'];
		if (!isset($uninvoicedQC[$sales_user])) {
			$uninvoicedQC[$sales_user] = [];
		}
		$uninvoicedQC[$sales_user][] = $row;
	}

	// Create HTML email content
	$row_color = $bg_color1;

	if(count($uninvoicedQC) > 0){


		foreach($uninvoicedQC as $sales_user => $rows){

			foreach($rows as $row){

	      $job_ref = ($row['job_id'] > 0)? $row['job_id'].": ".$row['job_reference']." - ".$row['group_company'] : '-';
	      $date = date('d/m/Y', strtotime($row['date_created']));

	      $qc_uninvoiced_html .= "<tr>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['id']}</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$job_ref</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['quantity'], 2)."</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['balance_qty'], 2)."</td>
	              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['sales_user']."</td>
	           </tr>";

	      if($row_color == $bg_color1){
	        $row_color = $bg_color2;
	      }elseif($row_color == $bg_color2){
	        $row_color = $bg_color1;
	      }
	  }


	}


}else{

  $qc_uninvoiced_html .= "<tr>
              <td colspan='5' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No QC records found</td>
           </tr>";
}

$qc_uninvoiced_html .= "</tbody></table>";

}



// Invoices Issued
$invoices_sql = "SELECT
    ji.invoice_id,
    ji.invoice_currency,
    ji.invoice_date,
    ji.invoice_status,
    ji.attachment,
    CONCAT(u2.user_fname, ' ', u2.user_lname) AS sales_user,
    CONCAT(u.user_fname, ' ', u.user_lname) AS user,
    IF(
        ji.tax = 'Taxable',
        SUM(
            ii.item_quantity * ii.item_price
        ) +(
            SUM(
                ii.item_quantity * ii.item_price
            ) * 0.18
        ),
        SUM(
            ii.item_quantity * ii.item_price
        )
    ) AS invoice_value,
    cg.group_company,
    ji.vfd_status
FROM
    `jos_invoices` AS ji
LEFT JOIN `jos_invoice_items` AS ii
ON
    ji.invoice_id = ii.invoice_id
LEFT JOIN `jos_customers` AS cu
ON cu.customer_id = ji.customer_id
LEFT JOIN `jos_customers_group` AS cg
ON cg.group_id = cu.group_id
LEFT JOIN `cms_users` AS u
ON u.user_id = ji.user_id

LEFT JOIN `jos_qc` AS qc
ON qc.id = ii.qc_id
LEFT JOIN `jos_jobs` AS j
ON j.job_id = qc.job_id
LEFT JOIN jos_quotes_items AS jqi
ON jqi.item_id = j.item_id
LEFT JOIN jos_quotes AS jq
ON jq.quote_id = jqi.quote_id
LEFT JOIN cms_users AS u2
ON u2.user_id = jq.user_id

WHERE ji.invoice_status = 'Issued'
AND date(ji.invoice_date) = '$sql_date'
GROUP BY
    ji.invoice_id
ORDER BY
    invoice_date DESC,
    invoice_id DESC";

$result_invoice = mysql_query($invoices_sql);


$invoices_html = "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
	$invoices_html .= "<thead>
													<tr>
															<th style='padding:3px;' bgcolor='#ccc'>ID</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Company</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Value</th>
                              <th style='padding:3px;' bgcolor='#ccc'>Sales User</th>
													</tr>
											</thead>";
	$invoices_html .= "<tbody>";

if(mysqli_num_rows($result_invoice) > 0) {

	// print_r($invoices);
	// exit;

	// Create HTML email content
  while ($row = mysql_fetch_assoc($result_invoice)) {

      $invoices_html .= "<tr>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['invoice_id']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['group_company']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['invoice_value'], 2)." {$row['invoice_currency']}</td>
              <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".$row['sales_user']."</td>
           </tr>";

      if($row_color == $bg_color1){
        $row_color = $bg_color2;
      }elseif($row_color == $bg_color2){
        $row_color = $bg_color1;
      }
  }



}else{

  $invoices_html .= "<tr>
              <td colspan='6' style='padding:3px 4px;' bgcolor='$row_color' align='center'>No records found</td>
           </tr>";

}

$invoices_html .= "</tbody></table>";



// Invoices Unclosed
$invoices_unclosed_sql = "SELECT
    ji.invoice_id,
    ji.invoice_currency,
    ji.invoice_date,
    ji.invoice_status,
    ji.attachment,
    CONCAT(u.user_fname, ' ', u.user_lname) AS user,
    CONCAT(u2.user_fname, ' ', u2.user_lname) AS sales_user,
    IF(
        ji.tax = 'Taxable',
        SUM(
            ii.item_quantity * ii.item_price
        ) +(
            SUM(
                ii.item_quantity * ii.item_price
            ) * 0.18
        ),
        SUM(
            ii.item_quantity * ii.item_price
        )
    ) AS invoice_value,
    cg.group_company,
    ji.vfd_status
FROM
    `jos_invoices` AS ji
LEFT JOIN `jos_invoice_items` AS ii
ON
    ji.invoice_id = ii.invoice_id
LEFT JOIN `jos_customers` AS cu
ON cu.customer_id = ji.customer_id
LEFT JOIN `jos_customers_group` AS cg
ON cg.group_id = cu.group_id
LEFT JOIN `cms_users` AS u
ON u.user_id = ji.user_id

LEFT JOIN `jos_qc` AS qc
ON qc.id = ii.qc_id
LEFT JOIN `jos_jobs` AS j
ON j.job_id = qc.job_id
LEFT JOIN jos_quotes_items AS jqi
ON jqi.item_id = j.item_id
LEFT JOIN jos_quotes AS jq
ON jq.quote_id = jqi.quote_id
LEFT JOIN cms_users AS u2
ON u2.user_id = jq.user_id

WHERE ji.invoice_status IN ('Issued','Draft','Approved')
GROUP BY
    ji.invoice_id
ORDER BY
    u2.user_fname, u2.user_lname ASC";

$result_invoice_unclosed = mysql_query($invoices_unclosed_sql);


$unclosedInvoices = [];
if(mysqli_num_rows($result_invoice_unclosed) > 0) {

	while ($row = mysql_fetch_assoc($result_invoice_unclosed)) {
		$sales_user = $row['sales_user'];
		if (!isset($unclosedInvoices[$sales_user])) {
			$unclosedInvoices[$sales_user] = [];
		}
		$unclosedInvoices[$sales_user][] = $row;
	}
}

// Now create grouped HTML
$grouped_html = '';
$all_sales_users = array_unique(array_merge(array_keys($uninvoicedQC), array_keys($unclosedInvoices)));
sort($all_sales_users);

foreach ($all_sales_users as $sales_user) {
    $grouped_html .= "<h3>$sales_user</h3>";
    
    // Uninvoiced QC
    if (isset($uninvoicedQC[$sales_user]) && count($uninvoicedQC[$sales_user]) > 0) {
        $grouped_html .= "<h4>Uninvoiced QC</h4>";
        $grouped_html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
        $grouped_html .= "<thead>
            <tr>
                <th style='padding:3px;' bgcolor='#ccc'>ID</th>
                <th style='padding:3px;' bgcolor='#ccc'>Date</th>
                <th style='padding:3px;' bgcolor='#ccc'>Job Reference</th>
                <th style='padding:3px;' bgcolor='#ccc'>Production Qty</th>
                <th style='padding:3px;' bgcolor='#ccc'>Balance</th>
            </tr>
        </thead>";
        $grouped_html .= "<tbody>";
        $row_color = $bg_color1;
        foreach ($uninvoicedQC[$sales_user] as $row) {
            $job_ref = ($row['job_id'] > 0)? $row['job_id'].": ".$row['job_reference']." - ".$row['group_company'] : '-';
            $date = date('d/m/Y', strtotime($row['date_created']));
            $grouped_html .= "<tr>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['id']}</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$job_ref</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['quantity'], 2)."</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['balance_qty'], 2)."</td>
            </tr>";
            $row_color = ($row_color == $bg_color1) ? $bg_color2 : $bg_color1;
        }
        $grouped_html .= "</tbody></table>";
    }
    
    // Unclosed Invoices
    if (isset($unclosedInvoices[$sales_user]) && count($unclosedInvoices[$sales_user]) > 0) {
        $grouped_html .= "<h4>Unclosed Invoice</h4>";
        $grouped_html .= "<table width='100%' border='0' cellspacing='0' cellpadding='0'>";
        $grouped_html .= "<thead>
            <tr>
                <th style='padding:3px;' bgcolor='#ccc'>ID</th>
                <th style='padding:3px;' bgcolor='#ccc'>Date</th>
                <th style='padding:3px;' bgcolor='#ccc'>Company</th>
                <th style='padding:3px;' bgcolor='#ccc'>Value</th>
            </tr>
        </thead>";
        $grouped_html .= "<tbody>";
        $row_color = $bg_color1;
        foreach ($unclosedInvoices[$sales_user] as $row) {
            $date = date('d/m/Y', strtotime($row['invoice_date']));
            $grouped_html .= "<tr>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['invoice_id']}</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>$date</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>{$row['group_company']}</td>
                <td style='padding:3px 4px;' bgcolor='$row_color' align='center'>".number_format($row['invoice_value'], 2)." {$row['invoice_currency']}</td>
            </tr>";
            $row_color = ($row_color == $bg_color1) ? $bg_color2 : $bg_color1;
        }
        $grouped_html .= "</tbody></table>";
    }
}


	require_once(__DIR__."/../vendor/autoload.php"); // Ensure PHPMailer is included

	$mail = new PHPMailer(true);

	// Server settings
	$mail->isSMTP();
	$mail->Host = SMTP_HOST;  // Replace with your SMTP server
	$mail->SMTPAuth = true;
	$mail->Username = SMTP_USERNAME; // SMTP username
	$mail->Password = SMTP_PASSWORD; // SMTP password
	$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
	$mail->Port = 587; // Usually 587 for TLS
	$mail->isHTML(true);

	$mail->setFrom('info@identitytz.com', 'Identity Promotions Ltd');
	$mail->Subject = "Identity App: QC And Invoice Report for $today";

  $mail->addAddress('hasnain@identitytz.com');
  $mail->addAddress('kazim@identitytz.com');
  $mail->addAddress('accountsipl@identitytz.com');
  $mail->addAddress('salesipl@identitytz.com');
  $mail->addAddress('ops@identitytz.com');
 // $mail->addAddress('collections@identitytz.com');
 // $mail->addAddress('FC@identitytz.com');
 //$mail->addAddress('beecraq@gmail.com');



  $msg_body = "<p><strong>QCs Issued:</strong></p>".$qc_html;
  $msg_body .= "<br><p><strong>Invoices Issued:</strong></p>".$invoices_html;
  $msg_body .= "<br><p><strong>Uninvoiced QC and Unclosed Invoices:</strong></p>".$grouped_html;

//   print_r($msg_body);
//   exit;

  $mail->Body = $msg_body;

 if($mail->send()){
     echo "Email sent";
  }