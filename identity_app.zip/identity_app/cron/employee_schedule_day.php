<?php

require("/home/identity/public_html/app/configs/variables.php");
require("/home/identity/public_html/app/configs/functions.php");
require("/home/identity/public_html/app/configs/functions.cms.php");
require("/home/identity/public_html/app/modules/attendance_schedule/functions.php");

$today = date('Y-m-d');
$shift_id = 1;
  
// Check if chedule for the the day exists
$params['schedule_date']=$today; 
$params['shift_id']=$shift_id;
$schedule_data = fetch_schedule($params);

 if(is_array($schedule_data) && count($schedule_data) > 0){
   echo "Schedule was already created";
   exit;
 }

$records = create_schedule($shift_id);

echo "$records created";

?>
