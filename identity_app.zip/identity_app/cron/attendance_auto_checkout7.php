<?php

/* Autometed email that sends list of employees not checked out after 6:05pm
*/

header("Content-Type: text/plain");

$local = false;
$root_dir = ($local)? $_SERVER['DOCUMENT_ROOT'].'/' : '/home/identity/public_html/app/';

require_once( __DIR__."/../configs/variables.php");
require_once( __DIR__."/../configs/functions.php");
require_once( __DIR__."/../modules/attendance_schedule/functions.php");

$ATTACHMENTS_DIR = $_SERVER['DOCUMENT_ROOT'] . '/uploads/attachments/';

$date = date('Y-m-d', strtotime('-1 day'));
$shift_id = 2;
$order = 'je.first_name, je.last_name ASC';
$params['schedule_date']= $date;
$params['shift_id']=$shift_id;
$params['order'] = $order;
$params['employee_status'] = 'Active';
$params['no_time_out'] = 1;
$params['status'] = array('Present','Late');

// $params['debug'] = 1;
$schedule_data = fetch_schedule($params);
$rows = is_array($schedule_data) ? count($schedule_data) : 0;
$cronDate = date('Y-m-d H:i:s');
echo "[Run Date $cronDate] $rows Records found..\n\n";
if($rows == 0){
  exit;
}

$report_array = array();
$employee_ids = [];


if(count($schedule_data) > 0) {
    $count=0;

           foreach($schedule_data as $k => $row){
               $schedule_ids[] = $row['id'];
               $count++;
           }

         if(!empty($schedule_ids)){

           $time_out = date('H:i:s');
           $user_id = '162';
           $timestamp = date('Y-m-d H:i:s');
           $schedule_ids = implode(',', $schedule_ids);

           $update_sql = "UPDATE jos_attendance_schedule
                          SET time_out = '$time_out',
                          checked_out_user_id = '$user_id',
                          date_updated = '$timestamp'
                          WHERE id IN ($schedule_ids)";

            $update_qry = mysql_query($update_sql);
         }

}
