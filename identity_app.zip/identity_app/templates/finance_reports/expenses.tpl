{if $privileges.finance_reports.sales}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Finance Reports</a></li>
     <li class="active"><a href="">Expenses</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Expenses Report</h2>
</div>


 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


                <div class="col-md-12" style="margin-bottom:10px;">
                     <div class="col-md-6">
          <a href="#search" class="btn btn-default no-print" onclick="toggleSearch('search'); return false;">Search</a> <a href="/finance_reports/expenses" class="btn btn-default no-print">Clear</a>
            </div>
            <div class="col-md-6 text-right">
                 <form class="form-inline no-print" method="post" action="/finance_reports/expenses{if $search_str}search=1{$search_str}{/if}">
                    <input type="hidden" name="export" value="excel" >
                    <button name="submit" type="submit" class="btn btn-default">Excel Export</button>
                </form>
                </div>
            {include file="$section/e-search.tpl"}
		</div>
        <div class="panel panel-default">

            <div class="panel-heading">
                 <!-- <h3 class="panel-title">bills Table</h3> -->

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline no-print" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <label> Displaying {$resultsCount}</label>
                             
                         </div>
                         <div class="form-group" style="padding-left: 10px;">
                          <a href="#" onclick="window.print(); return false;">
                                  <img src="/images/print.png" alt="Prints"  title="Print" width="32" height="32" border="0" />
                             </a>
                         </div>
                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">
                    <div class="table-responsive">
                        <table class="table table-striped">

    <thead style="background-color: #f5f5f5;">
        <tr>
            <th width="50">#</th>
            <th>Expense</th>
            <th class="text-right" width="20%">Amount (TZS)</th>
        </tr>
    </thead>

    <tbody>

        {foreach from=$report_data key=department_key item=department name=departments}

            {* Department Header *}
            <tr style="background-color: #e9ecef; font-weight: bold; border-top: 2px solid #999;">

                <td>
                    {$smarty.foreach.departments.iteration}
                </td>

                <td style="color: #333; font-size: 14px;">
                   {$department.department_name}
                </td>

                <td class="text-right" style="color: #333; font-size: 14px;">
                    {$department.department_total|number_format:2:".":","}
                </td>

            </tr>


            {* Expenses within Department *}
            {foreach from=$department.expenses key=expense_key item=expense}

                <tr style="background-color: #ffffff; font-weight: bold;">

                    <td></td>

                    <td style="padding-left: 25px;">
                        {$expense.expense_name}
                    </td>

                    <td class="text-right">
                        {$expense.total|number_format:2:".":","}
                    </td>

                </tr>


                {* Individual expense items *}
                {foreach from=$expense.items item=row}

                    <tr style="background-color: #fafafa;">

                        <td></td>

                        <td colspan="1" style="padding-left: 50px;">

                            {if $row.source_type == 'Petty Cash'}

                                {$row.entry_date|date_format:"%d/%m/%Y"}

                                <a
                                    class="plain-link"
                                    title="{$row.description}"
                                    href="/petty_cash?filter=1&pc_id={$row.id}"
                                    target="_blank"
                                >
                                    {$row.description|truncate:130:"...":true}
                                </a>

                            {elseif $row.source_type == 'Bank Transfer'}

                                {$row.entry_date|date_format:"%d/%m/%Y"}

                                <a
                                    class="plain-link"
                                    title="{$row.description}"
                                    href="/petty_cash_mobile/list?filter=1&pc_id={$row.id}"
                                    target="_blank"
                                >
                                    {$row.description|truncate:130:"...":true}
                                </a>

                            {else}

                                {$row.entry_date|date_format:"%d/%m/%Y"}
                                {$row.description|truncate:130:"...":true}

                            {/if}

                        </td>

                        <td class="text-right">
                            {$row.amount|number_format:2:".":","}
                        </td>

                    </tr>

                {/foreach}

            {/foreach}


            {* Department Total *}
            {* <tr style="
                background-color: #f5f5f5;
                font-weight: bold;
                border-bottom: 1px solid #ccc;
            ">

                <td colspan="2" class="text-right">
                    {$department.department_name} TOTAL
                </td>

                <td class="text-right">
                    {$department.department_total|number_format:2:".":","}
                </td>

            </tr> *}

        {/foreach}


        {* Grand Total *}
        {if $report_data|@count > 0}

            <tr style="
                background-color: #f9f9f9;
                font-weight: bold;
                font-size: 15px;
                border-top: 2px solid #333;
                border-bottom: 2px solid #333;
            ">

                <td colspan="2" class="text-right">
                    GRAND TOTAL
                </td>

                <td class="text-right" style="font-size: 15px;">
                    <strong>
                        {$grand_total|number_format:2:".":","}
                    </strong>
                </td>

            </tr>

        {/if}

    </tbody>

</table>
                    </div>
                </div>
        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
  </div>

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
