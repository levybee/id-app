


<div id="search" class="panel panel-default" style="margin-top:15px;">

  <div class="panel-body">
     <form id="form2" name="form2" class="form-inline"  method="post" action="/finance_reports/expenses?search=1{if $search_str}{$search_str}{/if}">
    
       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Expense</label>
       <select name="expense_id" class="form-control select">
        <option value="0">All Expenses</option>
        {foreach $expense_categories as $cat}
            <option value="{$cat.expense_id}" {if $smarty.post.expense_id == $cat.expense_id}selected{/if}>
                {$cat.expense_name}
            </option>
        {/foreach}
    </select>
      </div> 

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Department</label>
       <select name="department" class="form-control select">
        <option value="">All Departments</option>
        {foreach $departments as $dept}
            <option value="{$dept}" {if $smarty.post.department == $dept || $smarty.get.department == $dept}selected{/if}>
                {$dept}
            </option>
        {/foreach}
    </select>
      </div> 



      <div class="form-group"  style="margin:0 15px 10px 0;">
      <label for="to_date">Date From</label>
       <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="from_date"  value="{if $smarty.post.from_date}{$smarty.post.from_date|date_format:'%Y-%m-%d'}{else}{$from_date}{/if}" >
     </div>

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Date To</label>
        <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="to_date"  value="{if $smarty.post.to_date}{$smarty.post.to_date|date_format:'%Y-%m-%d'}{else}{$to_date}{/if}" >
      </div>
       <div class="form-group" style="margin-top:10px;">
         <input type="hidden" name="debug" value="{$smarty.get.s_debug}" >
         <button type="submit" class="btn btn-primary">Go</button>
       </div>

  </form>

  </div>

  </div>
