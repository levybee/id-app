


<div id="search" class="panel panel-default" style="margin-top:15px;">

  <div class="panel-body">
     <form id="form2" name="form2" class="form-inline"  method="post" action="/finance_reports/purchase_expense?search=1{if $search_str}{$search_str}{/if}">
    
       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Category</label>
       <select name="category" class="form-control select">
        <option value="0">All Categories</option>
        {foreach $stock_categories as $cat}
            <option value="{$cat}" {if $smarty.post.category == $cat || $smarty.get.category == $cat}selected{/if}>
                {$cat}
            </option>
        {/foreach}
    </select>
      </div> 

      <div class="form-group"  style="margin:0 15px 10px 0;">
      <label for="to_date">Date From</label>
       <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="from_date"  value="{if $smarty.post.from_date}{$smarty.post.from_date|date_format:'%Y-%m-%d'}{else}{$from_date}{/if}" >
     </div>

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Date To</label>
        <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="to_date"  value="{if $smarty.post.to_date}{$smarty.post.to_date|date_format:'%Y-%m-%d'}{else}{$to_date}{/if}" >
      </div>
       <div class="form-group" style="margin-top:10px;">
         <input type="hidden" name="debug" value="{$smarty.get.s_debug}" >
         <button type="submit" class="btn btn-primary">Go</button>
       </div>

  </form>

  </div>

  </div>
