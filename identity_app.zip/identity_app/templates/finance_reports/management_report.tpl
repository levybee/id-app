{if $privileges.finance_reports.management_report}

<ul class="breadcrumb">
    <li><a href="/">Home</a></li>
    <li><a href="#">Finance Reports</a></li>
    <li class="active"><a href="">MGT Report</a></li>
</ul>

<div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>MGT Report - {$report_month_name}</h2>
</div>

<div class="page-content-wrap">
    <div class="row">
        <div class="col-md-12">
            {if $message}
            <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                {$message}
            </div>
            {/if}

           
            <div class="col-sm-6"> <a href="#search" class="btn btn-default no-print" onclick="toggleSearch('search'); return false;">Search</a></div>
            <div class="col-sm-6 text-right">  <a href="/finance_reports/management_report?month_date={$month_date}&export=excel" class="btn btn-info no-print">Excel Export</a></div>
             <div class="col-md-12" style="margin-bottom:10px;">
                {include file="$section/mmr-search.tpl"}
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-body text-center">
                            <div class="text-muted">Revenue</div>
                            <h3>{$management_report.totals.revenue|number_format:2:".":","}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-body text-center">
                            <div class="text-muted">Gross Profit</div>
                            <h3>{$management_report.totals.gross_profit|number_format:2:".":","}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-body text-center">
                            <div class="text-muted">Operating Expenses</div>
                            <h3>{$management_report.totals.operating_expenses|number_format:2:".":","}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel panel-default">
                        <div class="panel-body text-center">
                            <div class="text-muted">Net Profit / (Loss)</div>
                            <h3>{$management_report.totals.net_profit|number_format:2:".":","}</h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <ul class="panel-controls panel-controls-title">
                        <li><strong>Departmental P&amp;L - TZS</strong></li>
                    </ul>
                </div>
                <div class="panel-body panel-body-table">
                    <div class="table-responsive">
                           <style>
    .mmr-blank-row td {
        height: 12px;
        padding-top: 2px;
        padding-bottom: 2px;
        border-top: 0;
        border-bottom: 0;
        background: transparent;
    }
</style>

<table class="table table-striped table-bordered">
                            <thead style="background-color:#f5f5f5;">
                                <tr>
                                    <th>Particulars</th>
                                    {foreach from=$management_report.departments item=department}<th class="text-right">{$department}</th>{/foreach}
                                    <th class="text-right">Total</th>
                                    <th class="text-right">Budget</th>
                                    <th class="text-right">Variance %</th>
                                </tr>
                            </thead>
                            <tbody>
                                {foreach from=$management_report.lines item=line}
                                    <tr
                                        {if $line.line_type == 'blank'}
                                            class="mmr-blank-row"
                                        {elseif $line.section == 'section_header'}
                                            style="font-weight:bold;background-color:#e9ecef;border-top:2px solid #999;"
                                        {elseif $line.section == 'revenue_total' || $line.section == 'cogs_total' || $line.section == 'gross_profit' || $line.section == 'operating_total' || $line.section == 'net_profit'}
                                            style="font-weight:bold;border-top:2px solid #999;"
                                        {elseif $line.bold}
                                            style="font-weight:bold;"
                                        {/if}>
                                        <td>
                                            {$line.name}
                                             {* {if $line.line_type == 'expense' && $line.expense_id_label && $smarty.session.user_data[0].user_id == '24'}
                                                <small class="text-muted">[ID{$line.expense_id_label}]</small>
                                            {/if} *}
                                        </td>
                                        {foreach from=$management_report.departments item=department}
                                        <td class="text-right">
                                            {if $line.line_type == 'percentage'}
                                                {$line.values[$department]|number_format:2:".":","}%
                                            {elseif $line.line_type != 'section_header' && $line.line_type != 'blank'}
                                                {if $line.bank_transfer_pc_id}
                                                    {if {$line.values[$department] > 0}}
                                                        <a target="_blank" href="/petty_cash_mobile/list?filter=1&amp;pc_id={$line.bank_transfer_pc_id}">{$line.values[$department]|number_format:2:".":","}</a>
                                                    {else}
                                                        {$line.values[$department]|number_format:2:".":","}
                                                    {/if}
                                                {elseif $line.name == 'Departmental Purchases'}
                                                     {* Use source purchase categories, not the normalized MMR department label. *}
                                                    {if $department == 'Offset'}
                                                        {assign var='purchase_categories' value='Offset Paper,Offset Consumables,Digital Printing,Digital Offset,Offset - Press,Offset - Finishing'}
                                                    {elseif $department == 'Promotional'}
                                                        {assign var='purchase_categories' value='Promo,Promotion,T-Shirt,Promotional'}
                                                    {elseif $department == 'Wide Format'}
                                                        {assign var='purchase_categories' value='WideFormat,WF - Finishing,WF - Printing,Wide Format'}
                                                    {elseif $department == 'Stationary'}
                                                        {assign var='purchase_categories' value='Stationary RM,Stationary FG,Stationary'}
                                                    {else}
                                                        {assign var='purchase_categories' value=$department}
                                                    {/if}
                                                    <a target="_blank" href="/finance_reports/purchase_expense?from_date={$management_report.from_date|escape:'url'}&amp;to_date={$management_report.to_date|escape:'url'}&amp;category={$purchase_categories|escape:'url'}">{$line.values[$department]|number_format:2:".":","}</a>
                                                {elseif $line.name == 'Departmental Direct Expenses'}
                                                    {assign var=direct_expense_ids_started value=0}
                                                    <a target="_blank" href="/finance_reports/expenses?from_date={$management_report.from_date}&amp;to_date={$management_report.to_date}&amp;department={$department|escape:'url'}&amp;expense_id={foreach from=$management_report.schedules.expense_lines item=direct_expense_line}{if $direct_expense_line.report_section == 'direct'}{foreach from=$direct_expense_line.expense_ids item=direct_expense_id}{if $direct_expense_ids_started},{/if}{$direct_expense_id}{assign var=direct_expense_ids_started value=1}{/foreach}{/if}{/foreach}">{$line.values[$department]|number_format:2:".":","}</a>
                                                {elseif $line.line_type == 'expense' && $line.report_section == 'indirect' && $line.expense_ids}
                                                    <a target="_blank" href="/finance_reports/expenses?from_date={$management_report.from_date}&amp;to_date={$management_report.to_date}&amp;expense_id={foreach from=$line.expense_ids item=expense_id name=expense_id_loop}{if !$smarty.foreach.expense_id_loop.first},{/if}{$expense_id}{/foreach}">{$line.values[$department]|number_format:2:".":","}</a>
                                                {else}

                                                 {$line.values[$department]|number_format:2:".":","}
                                                    {* {if $line.line_type == 'expense' && $line.report_section == 'salary'}
                                                       <pre>{$management_report.schedules|@print_r}</pre>
                                                    {/if} *}
                                                {/if}
                                            {/if}
                                        </td>
                                        {/foreach}
                                        <td class="text-right">
                                            {if $line.line_type == 'percentage'}
                                                <strong>{$line.total|number_format:2:".":","}%</strong>
                                            {elseif $line.line_type != 'section_header' && $line.line_type != 'blank'}
                                                <strong>{$line.total|number_format:2:".":","}</strong>
                                            {/if}
                                        </td>
                                        <td class="text-right">
                                            {if $line.line_type != 'section_header' && $line.line_type != 'percentage' && $line.line_type != 'blank' && $line.budget_total}
                                                {$line.budget_total|number_format:2:".":","}
                                            {/if}
                                        </td>
                                        <td class="text-right">
                                            {if $line.line_type != 'section_header' && $line.line_type != 'percentage' && $line.line_type != 'blank' && $line.variance_total !== null}
                                                {$line.variance_total|number_format:2:".":","}%
                                            {/if}
                                        </td>
                                    </tr>
                                {/foreach}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            {* <div class="panel panel-default">
                <div class="panel-heading"><strong>Supporting Schedules</strong></div>
                <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#mmr-sales" data-toggle="tab">Taxable Sales</a></li>
                        <li><a href="#mmr-exempt" data-toggle="tab">Exempt Sales</a></li>
                        <li><a href="#mmr-purchases" data-toggle="tab">Purchases</a></li>
                        <li><a href="#mmr-expenses" data-toggle="tab">Expenses</a></li>
                        <li><a href="#mmr-stock" data-toggle="tab">Stock</a></li>
                        <li><a href="#mmr-wip" data-toggle="tab">WIP</a></li>
                        <li><a href="#mmr-payroll" data-toggle="tab">Payroll</a></li>
                    </ul>
                    <div class="tab-content" style="padding-top:15px;">
                        <div class="tab-pane active" id="mmr-sales">
                            <table class="table table-striped table-bordered"><thead><tr><th>Date</th><th>Invoice</th><th>Customer</th><th>Department</th><th class="text-right">Amount</th></tr></thead><tbody>
                            {foreach from=$management_report.schedules.taxable_sales item=row}<tr><td>{$row.date|date_format:"%d/%m/%Y"}</td><td><a class="plain-link" href="/invoices/view?uid={$row.reference}" target="_blank">Invoice #{$row.reference}</a></td><td>{$row.customer}</td><td>{$row.department}</td><td class="text-right">{$row.amount|number_format:2:".":","}</td></tr>{foreachelse}<tr><td colspan="5" class="text-center">No records found.</td></tr>{/foreach}
                            </tbody></table>
                        </div>
                        <div class="tab-pane" id="mmr-exempt">
                            <table class="table table-striped table-bordered"><thead><tr><th>Date</th><th>Quote</th><th>Customer</th><th>Department</th><th class="text-right">Amount</th></tr></thead><tbody>
                            {foreach from=$management_report.schedules.exempt_sales item=row}<tr><td>{$row.date|date_format:"%d/%m/%Y"}</td><td>{$row.reference}</td><td>{$row.customer}</td><td>{$row.department}</td><td class="text-right">{$row.amount|number_format:2:".":","}</td></tr>{foreachelse}<tr><td colspan="5" class="text-center">No records found.</td></tr>{/foreach}
                            </tbody></table>
                        </div>
                        <div class="tab-pane" id="mmr-purchases">
                            <table class="table table-striped table-bordered"><thead><tr><th>Date</th><th>GRN</th><th>Description</th><th>Department</th><th class="text-right">Amount</th></tr></thead><tbody>
                            {foreach from=$management_report.schedules.purchases item=row}<tr><td>{$row.date|date_format:"%d/%m/%Y"}</td><td>{$row.reference}</td><td>{$row.description}</td><td>{$row.department}</td><td class="text-right">{$row.amount|number_format:2:".":","}</td></tr>{foreachelse}<tr><td colspan="5" class="text-center">No records found.</td></tr>{/foreach}
                            </tbody></table>
                        </div>
                        <div class="tab-pane" id="mmr-expenses">
                            <table class="table table-striped table-bordered"><thead><tr><th>Date</th><th>Reference</th><th>Type</th><th>Description</th><th>Department</th><th class="text-right">Amount</th></tr></thead><tbody>
                            {foreach from=$management_report.schedules.expenses item=row}<tr><td>{$row.entry_date|date_format:"%d/%m/%Y"}</td><td>{$row.reference}</td><td>{$row.source_type}</td><td>{$row.description|truncate:120:"...":true}</td><td>{$row.department}</td><td class="text-right">{$row.amount|number_format:2:".":","}</td></tr>{foreachelse}<tr><td colspan="6" class="text-center">No records found.</td></tr>{/foreach}
                            </tbody></table>
                        </div>
                        <div class="tab-pane" id="mmr-stock">
                            <table class="table table-striped table-bordered"><thead><tr><th>Category</th><th>Main Category</th><th class="text-right">Opening</th><th class="text-right">Closing</th></tr></thead><tbody>
                            {foreach from=$management_report.schedules.stock item=row}<tr><td>{$row.category}</td><td>{$row.main_category}</td><td class="text-right">{$row.opening_value|number_format:2:".":","}</td><td class="text-right">{$row.closing_value|number_format:2:".":","}</td></tr>{foreachelse}<tr><td colspan="4" class="text-center">No records found.</td></tr>{/foreach}
                            </tbody></table>
                        </div>
                        <div class="tab-pane" id="mmr-wip">
                            {if !$management_report.wip_available}<div class="alert alert-warning">WIP snapshots are not configured yet. The P&amp;L will show zero WIP until month-end WIP snapshots are available.</div>{/if}
                            <table class="table table-striped table-bordered"><thead><tr><th>Snapshot Date</th><th>Department</th><th class="text-right">WIP Value</th></tr></thead><tbody>
                            {foreach from=$management_report.schedules.wip item=row}<tr><td>{$row.snapshot_date|date_format:"%d/%m/%Y"}</td><td>{$row.department}</td><td class="text-right">{$row.wip_value|number_format:2:".":","}</td></tr>{foreachelse}<tr><td colspan="3" class="text-center">No WIP snapshot records found.</td></tr>{/foreach}
                            </tbody></table>
                        </div>
                        <div class="tab-pane" id="mmr-payroll">
                            {if !$management_report.payroll_available}<div class="alert alert-warning">No processed/approved payroll was found for this month.</div>{/if}
                            <table class="table table-striped table-bordered"><thead><tr><th>Employee</th><th>Department</th><th class="text-right">Salary A</th><th class="text-right">Cash-B</th></tr></thead><tbody>
                            {foreach from=$management_report.schedules.payroll item=row}<tr><td>{$row.employee_name}</td><td>{$row.department_name}</td><td class="text-right">{$row.salary_a|number_format:2:".":","}</td><td class="text-right">{$row.salary_b|number_format:2:".":","}</td></tr>{foreachelse}<tr><td colspan="4" class="text-center">No records found.</td></tr>{/foreach}
                            </tbody></table>
                        </div>
                    </div>
                </div>
            </div> *}

            {* <div class="alert alert-info">
                <strong>Report notes:</strong> Targets, monthly budgets, shared-expense allocations, statutory rates and WIP snapshots are configuration/data driven. Confirm client-approved rates and historical WIP snapshots before using the report for final management accounts.
            </div> *}
        </div>
    </div>
</div>

{else}
<div class="row"><div class="col-md-12"><div class="panel panel-default"><div class="alert alert-danger">You are not authorized to view this section</div></div></div></div>
{/if}
