 <!-- PAGE PLUGINS -->
        <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>

{literal}

<script type="text/javascript">
  


</script>
{/literal}


<!-- END PAGE PLUGINS -->
