{if $privileges.bills.list}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Outstanding</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Outstanding List</h2>
</div>


 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">

            <a href="/bills/summary" class="btn btn-default">Summary</a>
            <br><br>

          <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/bills/list?page=1" class="btn btn-default">Clear</a>  | Filter By Status: <a href="/bills/list?page=1{if $search_str}&{$search_str}{/if}" class="btn {if !$smarty.get.fby_param}btn-success{/if} btn-flat btn-rad">All</a>


            <a href="/bills/list?page=1&filter=1&fby=status&fby_param=Pending{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Pending'}btn-success{else}btn-default{/if}">Pending</a>

            <a href="/bills/list?page=1&filter=1&fby=status&fby_param=Paid{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Paid'}btn-success{else}btn-default{/if}">Paid</a>

            <a href="/bills/list?page=1&filter=1&fby=status&fby_param=Cancelled{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled</a>

            {include file='search/mini.bill.tpl'}
		</div>
        <div class="panel panel-default">

            <div class="panel-heading">
                 <!-- <h3 class="panel-title">bills Table</h3> -->

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/bills/list{if $search_str}?search=1&{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/bills/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">
             <form method="post" action="">
               <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">

                    <table class="table pad-5 table-bordered table-striped table-actions">
                        <thead>
                            <tr>

                                {* {if $smarty.get.fby_param eq 'Pending'}<th width="20" class="text-center"><input type="checkbox" id="check_all_confirmed"/></th>{/if} *}
              							    <th class="text-center">Date</th>
              							    <th class="text-center">Company</th>
                                <th class="text-center">Invoice No</th>
                                <th class="text-center">LPO No</th>
              							    <th class="text-center">Days Overdue</th>
              							    <th width="135" class="text-center">Amount</th>
                                <th width="135" class="text-center">Total</th>
              							    <th class="text-center">Status</th>
              							    <th width="120" class="text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=bill_list loop=$bill_list}
						  <tr>

						    {* <td class="text-center">{$start+$smarty.section.bill_list.rownum}</td> *}
						    {* {if $smarty.get.fby_param eq 'Pending'}<td class="text-center"><input type="checkbox" name="Pendings_check[]" class="confirmed_check" value="{$bill_list[bill_list].bill_id}" /></td>{/if} *}

						    <td>{$bill_list[bill_list].date_created|date_format:"%d/%m/%Y"}</td>
						    <td>{$bill_list[bill_list].group_company}</td>
                <td class="text-center">
                  <a title="View PDF" href="/invoices/print?uid={$bill_list[bill_list].invoice_id}"  alt="View PDF" target = "_blank">
                  TI/{$bill_list[bill_list].invoice_date|substr:0:4}/{$bill_list[bill_list].invoice_id}
                  </a>
                </td>
                <td>{$bill_list[bill_list].job_lpo_other}</td>
                {* <td class="text-center">{if $bill_list[bill_list].lpo_id}<a title="View LPO" href="#" onclick="popupPDF('lpo', {if $bill_list[bill_list].lpo_id}{$bill_list[bill_list].lpo_id}{else}0{/if});" >{$bill_list[bill_list].lpo_id}</a>{else}-{/if}</td> *}
                <td class="text-center" {if $bill_list[bill_list].overage gt 0}style="color:red;"{/if}>{$bill_list[bill_list].overage}</td>
						    <td class="text-right">{$bill_list[bill_list].bill_amount|number_format:2:".":","} {$bill_list[bill_list].invoice_currency}</td>
                <td class="text-right">{if $bill_list[bill_list].total}{$bill_list[bill_list].total|number_format:2:".":","} {$bill_list[bill_list].invoice_currency}{/if}</td>
                <td class="text-center {if $bill_list[bill_list].status eq 'Pending'}text-danger{elseif $bill_list[bill_list].status eq 'Cancelled'}text-default{else}text-success{/if}">{$bill_list[bill_list].status}</td>
                {* <td class="text-center">{$bill_list[bill_list].user_fname} {$bill_list[bill_list].user_lname}</td> *}
						    {if !$smarty.get.print}
						    <td class="text-center">
                <a class="btn btn-default btn-rounded btn-condensed btn-sm"  title="View PDF" href="/bills/print?grp_id={$bill_list[bill_list].group_id}"  alt="View PDF" target = "_blank"><span class="fa fa-file-pdf-o"></span></a>
                {if $bill_list[bill_list].status eq 'Paid'}
                <a class="btn btn-default btn-rounded btn-condensed btn-sm" title="View Receipt" target="_blank" href="/receipts/view/?id={$bill_list[bill_list].receipt_id}"  alt="View Receipt" ><span class="fa fa-paste"></span></a>
                {/if}
                {if $privileges.bills.ledger}
                <a class="btn btn-default btn-rounded btn-condensed btn-sm"  title="View Ledger" href="/bills/legder?group_id={$bill_list[bill_list].group_id}"  alt="View Ledger" target = "_blank"><span class="fa fa-adjust"></span></a>
                {/if}

              {*  <a href="#"
                data-item-id="{$bill_list[bill_list].id}"
                data-ref="TI/{$bill_list[bill_list].invoice_date|substr:0:4}/{$bill_list[bill_list].invoice_id}"
                class="btn btn-danger btn-rounded btn-condensed btn-sm cancel_item" title="Cancel" >
                  <span class="fa fa-times"></span>
                </a> *}

                {* {if $bill_list[bill_list].status eq 'Pending'}
                <a class="btn btn-success btn-rounded btn-condensed btn-sm" title="Pay Bill" href="/bills/list?act=pay&id={$bill_list[bill_list].id}" onclick="confirmAction('[Pay Bill] Are you sure?', this.href); return false;"> <span class="fa fa-thumbs-up"></span> </a>
                {/if} *}


                </td>
						    {/if}


						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="8"><div align="center">No records found.</td>
						  </tr>
						 {/section}
                        </tbody>
                    </table>

                </div>
              </form>

            </div>
             <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form"  method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/bills/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/bills/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>

                 </ul>
            </div>

        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

<!-- NEW COMPANY MODAL -->
  <div class="modal" id="cancelModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-sm">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_cancel_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead"><span class="item_name"></span></h4>
              </div>
              <form id="cancel_form" name="cancel_form" method="post" action="/bills/list" class="form-horizontal" enctype="multipart/form-data">
	              <div class="modal-body">
	                 <div id="cancel_response"></div>


			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			                 <div class="panel-body form-group">
			                   <div class="row">

									   <div class="form-group">
									    <label class="col-md-12">Notes</label>
									    <div class="col-md-12">
									    <textarea id="notes" name="notes" class="form-control" rows="4"></textarea>
									    </div>
									  </div>

                    <div class="form-group">
                     <label class="col-md-12">Attachment</label>
                     <div class="col-md-12">
                     <input name="attachment" type="file" id="attachment" class="form-control" />
                     </div>

                     </div>
                   </div>

			                   </div>


			                 </div>

			             </div>

                   <div class="modal-footer">
                       <input type="hidden" name="item_id" value="" >
                       <input type="hidden" name="cancel" value="1" >
                       <input type="submit" name="cancel_submit" class="btn btn-primary item_submit" value="Submit">
                       <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                     </div>

	              </div>

              </form>

          </div>
      </div>
  </div>

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
