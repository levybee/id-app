<div id="search" class="panel panel-default" style="margin-top:15px; display:none;">
    <div class="panel-body">
        <form id="form2" name="form2" class="form-inline" method="get" action="/finance_reports/management_report">
            <div class="form-group" style="margin:0 15px 10px 0;">
                <label for="month">Report Month</label>
                <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="month_date"  value="{if $smarty.post.month_date}{$smarty.post.month_date|date_format:'%Y-%m-%d'}{else}{/if}" >
            </div>
            <div class="form-group" style="margin-top:10px;">
                <button type="submit" class="btn btn-primary">Go</button>
            </div>
        </form>
    </div>
</div>
