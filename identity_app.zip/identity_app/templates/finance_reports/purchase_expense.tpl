{if $privileges.finance_reports.purchase_expenses}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb no-print">
     <li><a href="/">Home</a></li>
     <li><a href="#">Finance Reports</a></li>
     <li class="active"><a href="">Purchase Expense</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Purchase Expense</h2>
</div>


 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">
        <div class="col-md-6">
          <a href="#search" class="btn btn-default no-print" onclick="toggleSearch('search'); return false;">Search</a> <a href="/finance_reports/purchase_expense" class="btn btn-default no-print">Clear</a>
            </div>
            <div class="col-md-6 text-right">
                 <form class="form-inline no-print" method="post" action="/finance_reports/purchase_expense{if $search_str}?search=1{$search_str}{/if}">
                    <input type="hidden" name="export" value="excel" >
                    <button name="submit" type="submit" class="btn btn-default">Excel Export</button>
                </form>
                </div>
            {include file="$section/pe-search.tpl"}
		</div>
        <div class="panel panel-default">

            <div class="panel-heading">
                 <!-- <h3 class="panel-title">bills Table</h3> -->

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline no-print" role="form" method="post">
                                <div class="form-group">
                                    <label>Displaying {$resultsCount}</label>
                                </div>
                                 <div class="form-group" style="padding-left: 10px;">
                          <a href="#" onclick="window.print(); return false;">
                                  <img src="/images/print.png" alt="Prints"  title="Print" width="32" height="32" border="0" />
                             </a>
                         </div>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead style="background-color: #f5f5f5;">
                                <tr>
                                    <th width="50">#</th>
                                    <th>Category</th>
                                    <th class="text-right" width="20%">Total (TZS)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {foreach from=$report_data key=k item=cat}
                                <tr style="background-color: #ffffff; font-weight: bold; border-top: 2px solid #ddd;">
                                    <td>{$k+1}</td>
                                    <td>{$cat.category}</td>
                                    <td class="text-right">{$cat.total|number_format:2:".":","}</td>
                                </tr>
                                {foreach from=$cat.items item=row}
                                <tr style="background-color: #fafafa;">
                                    <td colspan="2" style="padding-left: 40px;">
                                     {$row.entry_date|date_format:"%d/%m/%Y"}   <a title="View" href="/grn/list?search=1&grn_id={$row.grn_id}" target="_blank" class="plain-link">{$row.description}</a> 
                                    </td>
                                    <td class="text-right">{$row.amount|number_format:2:'.':','}</td>
                                </tr>
                                {/foreach}
                                {/foreach}
                                {if $report_data|@count > 0}
                                <tr style="background-color: #f9f9f9; font-weight: bold; font-size: 15px; border-top: 2px solid #333; border-bottom: 2px solid #333;">
                                    <td colspan="2" class="text-right">GRAND TOTAL</td>
                                    <td class="text-right" style="font-size: 15px;"><strong>{$grand_total|number_format:2:".":","}</strong></td>
                                </tr>
                                {/if}
                            </tbody>
                        </table>
                    </div>
                </div>
        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
  </div>

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
