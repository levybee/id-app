<!-- START PAGE SIDEBAR -->
<div class="page-sidebar">
<!-- START X-NAVIGATION -->
<ul class="x-navigation">

    <li class="xn-logo">
        <a class="hidden-md hidden-lg" href="/"><img src="/img/logo-lr.png" alt="Identity Promotions" /></a>
        <a href="#" class="x-navigation-control"></a>
    </li>

    <li class="xn-profile">
        <a href="/" class="profile-mini">
            {* <img src="/assets/images/users/{if $user_data[0].user_image}{$user_data[0].user_image}{else}no-image.jpg{/if}" alt="{$user_data[0].user_fname} {$user_data[0].user_lname}"/> *}
            <img src="/img/logo-small.png" alt="Identity Promotions" style="border: 0px;" />
        </a>
        <div class="profile" style="padding: 15px 0px;">
            <a  class="hidden-sm hidden-xs" href="/">
                <img src="/img/logo-new.png" alt="Identity Promotions" style="width: 75%;" />
            </a>
            {*
            <div class="profile-image">
                <img src="/assets/images/users/{if $user_data[0].user_image}{$user_data[0].user_image}{else}no-image.jpg{/if}" alt="{$user_data[0].user_fname} {$user_data[0].user_lname}"/>
            </div>
            <div class="profile-data">
                <div class="profile-data-name">{$user_data[0].user_fname} {$user_data[0].user_lname}</div>
                <!-- <div class="profile-data-title">Web Developer/Designer</div> -->
            </div>
            <div class="profile-controls">
                <!-- <a href="pages-profile.html" class="profile-control-left"><span class="fa fa-info"></span></a>
                <a href="pages-messages.html" class="profile-control-right"><span class="fa fa-envelope"></span></a> -->
            </div>
            *}
        </div>
    </li>
    {* <li class="xn-title">Navigation</li> *}
    <li class="xn-openable" {if $section eq 'main' || $menu_default eq 'pendings/list'}class="active"{/if}>
        <a href="/main"><span class="fa fa-dashboard"></span> <span class="xn-text">Dashboard</span></a>
        <ul>
            <li {if $section eq 'main'}class="active"{/if}><a href="/main">Main</a></li>
            {if $privileges.pending_approvals.list}
            <li {if $menu_default eq 'pendings/list'}class="active"{/if}><a href="/pendings/list">Pending Approvals</a></li>
            {/if}
        </ul>
    </li>
    <li class="xn-openable" {if $menu_default eq 'attendance_schedule/list'}class="active"{/if}><a href="#"><span class="fa fa-clock-o"></span>Time Attendance</a>

        <ul>
            <li {if $menu_default eq 'attendance_schedule/register' && $smarty.get.shift_id eq '1' }class="active"{/if}><a href="/attendance_schedule/register?shift_id=1">Register - Day</a></li>
            <li {if $menu_default eq 'attendance_schedule/register' && $smarty.get.shift_id eq '2'}class="active"{/if}><a href="/attendance_schedule/register?shift_id=2">Register - Night</a></li>
            <li {if $menu_default eq 'attendance_schedule/list'}class="active"{/if}><a href="/attendance_schedule/list">Attendance List</a></li>
            <li {if $menu_default eq 'attendance_schedule/reports'}class="active"{/if}><a href="/attendance_schedule/reports">Attendance Reports</a></li>
            <li {if $menu_default eq 'attendance_shifts/list'}class="active"{/if}><a href="/attendance_shifts/list">Shifts</a></li>
            <li {if $menu_default eq 'attendance_schedule/holidays'}class="active"{/if}><a href="/attendance_schedule/holidays">Holidays</a></li>
        </ul>

    </li>
    <li class="xn-openable">
        <a href="#"><span class="fa fa-gavel"></span> <span class="xn-text">Maintenance</span></a>

        <ul>
            <li  {if $menu_default eq 'news/list'}class="active"{/if}><a href="/repair_ticket/list"></span> Repair Tickets</a></li>
            <li {if $menu_default eq 'news/add'}class="active"{/if}><a href="/repair_ticket/add">Add Repair Ticket</a></li>
        </ul>
    </li>
    <li class="xn-openable">
        <a href="#"><span class="fa fa-cogs"></span><span class="xn-text">System Settings</span></a>

        <ul>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-hdd-o"></span>Backup</a>
                <ul>
                    <li {if $menu_default eq 'backup/new'}class="active"{/if}><a href="/backup/new"><span class="fa fa-hdd-o"></span>Generate</a></li>
                    <li {if $menu_default eq 'backup/list'}class="active"{/if}><a href="/backup/list"><span class="fa fa-download"></span>View/Download</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-wrench"></span> Configurations</a>
                <ul>
                    <li {if $menu_default eq 'config/add'}class="active"{/if}><a href="/config/add"><span class="fa fa-wrench"></span>New</a></li>
                    <li {if $menu_default eq 'config/list'}class="active"{/if}><a href="/config/list"><span class="fa fa-list "></span>List</a></li>
                </ul>
            </li>
        </ul>
    </li>
    <li class="xn-openable">
        <a href="#"><span class="fa fa-cog"></span><span class="xn-text">General Settings</span></a>

        <ul>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-industry"></span>Industries</a>
                <ul>
                    <li {if $menu_default eq 'industries/add'}class="active"{/if}><a href="/industries/add"><span class="fa fa-industry"></span>New</a></li>
                    <li {if $menu_default eq 'industries/list'}class="active"{/if}><a href="/industries/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-file"></span>Product Items</a>
                <ul>
                    <li {if $menu_default eq 'products/add'}class="active"{/if}><a href="/products/add"><span class="fa fa-file"></span>New</a></li>
                    <li {if $menu_default eq 'products/list'}class="active"{/if}><a href="/products/list"><span class="fa fa-list "></span>List</a></li>
                </ul>
            </li>

            <li class="xn-openable">
                <a href="#"><span class="fa fa-files-o"></span>Paper Types</a>
                <ul>
                    <li {if $menu_default eq 'papers/add'}class="active"{/if}><a href="/papers/add"><span class="fa fa-files-o"></span>New Papers</a></li>
                    <li {if $menu_default eq 'papers/list'}class="active"{/if}><a href="/papers/list"><span class="fa fa-list"></span>List Papers</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-arrows-h"></span>Paper Sizes</a>
                <ul>
                    <li {if $menu_default eq 'sizes/add'}class="active"{/if}><a href="/sizes/add"><span class="fa fa-arrows-h"></span>New</a></li>
                    <li {if $menu_default eq 'sizes/list'}class="active"{/if}><a href="/sizes/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-chevron-circle-up"></span>Paper Weights</a>
                <ul>
                    <li {if $menu_default eq 'weights/add'}class="active"{/if}><a href="/weights/add"><span class="fa fa-chevron-circle-up"></span>New</a></li>
                    <li {if $menu_default eq 'weights/list'}class="active"{/if}><a href="/weights/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-file-text"></span>Print Colours</a>
                <ul>
                    <li {if $menu_default eq 'print/add'}class="active"{/if}><a href="/print/add"><span class="fa fa-file-text"></span>New</a></li>
                    <li {if $menu_default eq 'print/list'}class="active"{/if}><a href="/print/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-clipboard"></span>Finishing</a>
                <ul>
                    <li {if $menu_default eq 'finishing/add'}class="active"{/if}><a href="/finishing/add"><span class="fa fa-clipboard"></span>New</a></li>
                    <li {if $menu_default eq 'finishing/list'}class="active"{/if}><a href="/finishing/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-print"></span>Machines</a>
                <ul>
                    <li {if $menu_default eq 'printers/add'}class="active"{/if}><a href="/printers/add"><span class="fa fa-print"></span>New</a></li>
                    <li {if $menu_default eq 'printers/list'}class="active"{/if}><a href="/printers/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-file-text"></span>Materials</a>
                <ul>
                    <li {if $menu_default eq 'materials/add'}class="active"{/if}><a href="/materials/add"><span class="fa fa-file-text"></span>New</a></li>
                    <li {if $menu_default eq 'materials/list'}class="active"{/if}><a href="/materials/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
             <li class="xn-openable">
                <a href="#"><span class="fa fa-file-powerpoint-o"></span>Print Processes</a>
                <ul>
                    <li {if $menu_default eq 'print_processes/add'}class="active"{/if}><a href="/print_processes/add"><span class="fa fa-file-powerpoint-o"></span>New</a></li>
                    <li {if $menu_default eq 'print_processes/list'}class="active"{/if}><a href="/print_processes/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-credit-card"></span>Payment Terms</a>
                <ul>
                    <li {if $menu_default eq 'payments/add'}class="active"{/if}><a href="/payments/add"><span class="fa fa-credit-card"></span>New</a></li>
                    <li {if $menu_default eq 'payments/list'}class="active"{/if}><a href="/payments/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
            <li class="xn-openable">
                <a href="#"><span class="fa fa-sitemap"></span>Departments</a>
                <ul>
                    <li {if $menu_default eq 'departments/add'}class="active"{/if}><a href="/departments/add"><span class="fa fa-sitemap"></span>New</a></li>
                    <li {if $menu_default eq 'departments/list'}class="active"{/if}><a href="/departments/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
             <li class="xn-openable">
                <a href="#"><span class="fa fa-file-text"></span>Expenses</a>
                <ul>
                    <li {if $menu_default eq 'expenses/add'}class="active"{/if}><a href="/expenses/add"><span class="fa fa-file-text"></span>New</a></li>
                    <li {if $menu_default eq 'expenses/list'}class="active"{/if}><a href="/expenses/list"><span class="fa fa-list"></span>List</a></li>
                </ul>
            </li>
        </ul>
    </li>
    <li class="xn-openable">
        <a href="#"><span class="fa fa-key"></span><span class="xn-text">Access Control</span></a>
        <ul>
          <li class="xn-openable">
           <a href="#"><span class="fa fa-play-circle"></span>Roles</a>
           <ul>
               <li {if $menu_default eq 'roles/add'}class="active"{/if}><a href="/roles/add"><span class="fa fa-play-circle"></span>Add Role</a></li>
               <li {if $menu_default eq 'roles/list'}class="active"{/if}><a href="/roles/list"><span class="fa fa-list"></span>List Roles</a></li>
           </ul>
       </li>
       <li class="xn-openable">
          <a href="#"><span class="fa fa-user"></span>Users</a>
          <ul>
              <li {if $menu_default eq 'users/add'}class="active"{/if}><a href="/users/add"><span class="fa fa-user-plus"></span>Add User</a></li>
              <li {if $menu_default eq 'users/list'}class="active"{/if}><a href="/users/list"><span class="fa fa-list"></span>List Users</a></li>
          </ul>
      </li>
        </ul>
    </li>

     <li class="xn-openable">
        <a href="#"><span class="fa fa-server"></span><span class="xn-text">Job Order System</span></a>
        <ul>
          <li class="xn-openable">
           <a href="#"><span class="fa fa-building"></span>Companies</a>
           <ul>
               <li {if $menu_default eq 'customers_group/add'}class="active"{/if}><a href="/customers_group/add"><span class="fa fa-building"></span>Add Company</a></li>
               <li {if $menu_default eq 'customers_group/tin_vrn'}class="active"{/if}><a href="/customers_group/tin_vrn"><span class="fa fa-building"></span>Add TIN/VRN</a></li>
               <li {if $menu_default eq 'customers_group/list'}class="active"{/if}><a href="/customers_group/list"><span class="fa fa-list"></span>List Companies</a></li>
           </ul>
       </li>
       <li class="xn-openable">
          <a href="#"><span class="fa fa-sticky-note-o"></span>Notes</a>
          <ul>
              <li {if $menu_default eq 'notes/add'}class="active"{/if}><a href="/notes/add"><span class="fa fa-sticky-note-o"></span>Add Note</a></li>
              <li {if $menu_default eq 'notes/list'}class="active"{/if}><a href="/notes/list"><span class="fa fa-list"></span>List Notes</a></li>
          </ul>
      </li>
      <li class="xn-openable">
          <a href="#"><span class="fa fa-briefcase"></span>Customers</a>
          <ul>
              <li {if $menu_default eq 'customers/add'}class="active"{/if}><a href="/customers/add"><span class="fa fa-briefcase"></span>Add Customer</a></li>
              <li {if $menu_default eq 'customers/list'}class="active"{/if}><a href="/customers/list"><span class="fa fa-list"></span>List Customers</a></li>
              <li {if $menu_default eq 'customers/mail'}class="active"{/if}><a href="/customers/mail"><span class="fa fa-envelope"></span>Export for Mailing</a></li>
          </ul>
      </li>
      <li class="xn-openable">
          <a href="#"><span class="fa fa-credit-card"></span>Sales</a>
          <ul>
              {* <li {if $menu_default eq 'quotes/add'}class="active"{/if}><a href="/quotes/add"><span class="fa fa-file-text"></span>Add Quote</a></li> *}
              <li {if $menu_default eq 'quotes/list'}class="active"{/if}><a href="/quotes/list"><span class="fa fa-file-text"></span>Quotes</a></li>
              <li {if $menu_default eq 'my_reports/list'}class="active"{/if}><a href="/my_reports/list"><span class="fa fa-bar-chart"></span>My Reports</a></li>
              <li {if $menu_default eq 'performance/list'}class="active"{/if}><a href="/performance_reports/list"><span class="fa fa-line-chart"></span>Performance</a></li>
              <li {if $menu_default eq 'visit_plan/list'}class="active"{/if}><a href="/visit_plan/list"><span class="fa fa-list-ol"></span>Visit Plan</a></li>
          </ul>
      </li>
      <li class="xn-openable">
          <a href="#"><span class="fa fa-check-square"></span>Job Orders</a>
          <ul>
              <!-- <li {if $menu_default eq 'jobs/add'}class="active"{/if}><a href="/jobs/add"><span class="fa fa-check-square"></span>New Job</a></li> -->
              <li {if $menu_default eq 'jobs/list'}class="active"{/if}><a href="/jobs/list"><span class="fa fa-list"></span>List Jobs</a></li>
              <li {if $menu_default eq 'job_schedule/list'}class="active"{/if}><a href="/job_schedule/list"><span class="fa fa-list"></span>Jobs Schedule</a></li>
              <li {if $menu_default eq 'jobs/closed'}class="active"{/if}><a href="/jobs/closed"><span class="fa fa-list"></span>Closed Jobs</a></li>
              <li {if $menu_default eq 'jobs/delivery_planner'}class="active"{/if}><a href="/jobs/delivery_planner"><span class="fa fa-list"></span>Job Planner</a></li>

          </ul>
      </li>
      <li {if $menu_default eq 'reports/index'}class="active"{/if}>
          <a href="/reports"><span class="fa fa-bar-chart"></span>Reports</a>
       </li>
       <li {if $menu_default eq 'project_checklist/list'}class="active"{/if}>
          <a href="/project_checklist/list"><span class="fa fa-list"></span>Handover Checklist</a>
       </li>
     </ul>
    </li>
    <li class="xn-openable">
       <a href="#"><span class="fa fa-barcode"></span>Inventory</a>
       <ul>
           <li class="xn-openable"><a href="#">LPO</a>
             <ul>
               <li {if $menu_default eq 'lpo/index' || $menu_default eq 'lpo/receive' || $menu_default eq 'lpo/approve'}class="active"{/if}><a href="/lpo">LPO List</a></li>
                <li {if $menu_default eq 'lpo/add' || $menu_default eq 'lpo/edit' }class="active"{/if}><a href="/lpo/add">New LPO</a></li>
             </ul>

           </li>
           <li class="xn-openable"><a href="#">GRN</a>
             <ul>
               <li {if $menu_default eq 'grn/list'}class="active"{/if}><a href="/grn/list">GRN List</a></li>
                <li {if $menu_default eq 'grn/add'}class="active"{/if}><a href="/grn/add">New GRN</a></li>
                <li {if $menu_default eq 'grn/outstanding'}class="active"{/if}><a href="/grn/outstanding">Outstanding GRNs</a></li>
             </ul>

           </li>
           {* <li class="xn-openable"><a href="#">Requisitions</a>
             <ul>
               <li {if $menu_default eq 'requisitions/index'}class="active"{/if}><a href="/requisitions">Requisitions List</a></li>
                <li {if $menu_default eq 'requisitions/add' || $menu_default eq 'requisitions/edit' }class="active"{/if}><a href="/requisitions/add">New Requisition</a></li>
             </ul>

           </li> *}
           <li class="xn-openable"><a href="#">Requisitions</a>
             <ul>
               <li {if $menu_default eq 'requisition/list'}class="active"{/if}><a href="/requisition/list">Requisitions List</a></li>
                <li {if $menu_default eq 'requisition/add' || $menu_default eq 'requisition/edit' }class="active"{/if}><a href="/requisition/add">New Requisition</a></li>
                <li {if $menu_default eq 'requisition/issued_stock'}class="active"{/if}><a href="/requisition/issued_stock">Issued Stock</a></li>
                <li {if $menu_default eq 'requisition/stock_value'}class="active"{/if}><a href="/requisition/stock_value">Stock Value Report</a></li>
             </ul>
           </li>
           <li class="xn-openable"><a href="#">Stock</a>
             <ul>
               <li {if $menu_default eq 'stock/list' || $menu_default eq 'sale_pricing/add'}class="active"{/if}><a href="/stock">Stock List</a></li>
               <li {if $menu_default eq 'stock/add' || $menu_default eq 'stock/edit'}class="active"{/if}><a href="/stock/add">Add Stock</a></li>
                {* <li {if $menu_default eq 'sale_pricing/list' || $menu_default eq 'sale_pricing/edit' || $menu_default eq 'sale_pricing/add'}class="active"{/if}><a href="/sale_pricing/list">Sale Pricing</a></li> *}
               <li {if $menu_default eq 'stock/reconciliation'}class="active"{/if}><a href="/stock/reconciliation">Reconciliation</a></li>
               {* <li {if $menu_default eq 'requisitions/issued_stock'}class="active"{/if}><a href="/requisitions/issued_stock">Issued Stock</a></li> *}
               <li {if $menu_default eq 'stock/log'}class="active"{/if}><a href="/stock/log">Log Book</a></li>
               {* <li {if $menu_default eq 'requisitions/stock_value'}class="active"{/if}><a href="/requisitions/stock_value">Stock Value Report</a></li> *}
               <li {if $menu_default eq 'stock/reconciliation_report'}class="active"{/if}><a href="/stock/reconciliation_report">Reconciliation Report</a></li>
               <li {if $menu_default eq 'stock/reconciliation_pending'}class="active"{/if}><a href="/stock/reconciliation_pending">Reconciliation Pending</a></li>

             </ul>
           </li>
            <li class="xn-openable"><a href="#"></span>Suppliers</a>
              <ul>
                <li {if $menu_default eq 'suppliers/list' }class="active"{/if}><a href="/suppliers">Suppliers List</a></li>
                <li {if $menu_default eq 'suppliers/add' || $menu_default eq 'suppliers/edit'}class="active"{/if}><a href="/suppliers/add">Add Suppliers</a></li>
             </ul>
            </li>
            <li class="xn-openable"><a href="#"></span>Casual Contractors</a>
              <ul>
                <li {if $menu_default eq 'casual_contractors/list' }class="active"{/if}><a href="/casual_contractors/list">Contractors</a></li>
                <li {if $menu_default eq 'contractor_templates/list' || $menu_default eq 'contractor_templates/add'}class="active"{/if}><a href="/contractor_templates/list">Contractor Templates</a></li>
             </ul>
            </li>
            <li class="xn-openable"><a href="#">GMR</a>
              <ul>
                <li {if $menu_default eq 'gmr/list'}class="active"{/if}><a href="/gmr/list">GMR List</a></li>
                 <li {if $menu_default eq 'gmr/add'}class="active"{/if}><a href="/gmr/add">New GMR</a></li>
              </ul>

            </li>
       </ul>
   </li>
    <li class="xn-openable">
        <a href="#"><span class="fa fa-money"></span><span class="xn-text">Billing</span></a>
        <ul>
           <li class="xn-openable" {if $menu_default eq 'deliveries/list'}class="active"{/if}><a href="#"><span class="fa fa-sticky-note"></span>Delivery Notes</a>

               <ul>
                   <li {if $menu_default eq 'deliveries/list' }class="active"{/if}><a href="/deliveries/list">Delivery List</a></li>
                   <li {if $menu_default eq 'deliveries/add' || $menu_default eq 'deliveries/edit'}class="active"{/if}><a href="/deliveries/add">New Delivery</a></li>
               </ul>

           </li>

           <li class='xn-openable' {if $menu_default eq 'invoices/list'}class="active"{/if}><a href="#"><span class="fa fa-paste"></span>Invoices</a>

               <ul>
                   <li {if $menu_default eq 'invoices/list' }class="active"{/if}><a href="/invoices/list">Invoices List</a></li>
                   <li {if $menu_default eq 'invoices/add' || $menu_default eq 'invoices/edit'}class="active"{/if}><a href="/invoices/add">New Invoice</a></li>
                   <li {if $menu_default eq 'invoices/reports' }class="active"{/if}><a href="/invoices/reports">Reports</a></li>
               </ul>

           </li>

           <li class='xn-openable' {if $menu_default eq 'receipts/list'}class="active"{/if}><a href="#"><span class="fa fa-paste"></span>Receipts</a>

               <ul>
                   <li {if $menu_default eq 'receipts/list' }class="active"{/if}><a href="/receipts/list">Receipts List</a></li>
                   <li {if $menu_default eq 'receipts/add' || $menu_default eq 'receipts/edit'}class="active"{/if}><a href="/receipts/add">New Receipt</a></li>
                   <li {if $menu_default eq 'receipts/exempt' }class="active"{/if}><a href="/receipts/exempt">Exempt Receipts</a></li>
                   {* <li {if $menu_default eq 'receipts/exempt_float' }class="active"{/if}><a href="/receipts/exempt_float">Exempt Float</a></li> *}
               </ul>

           </li>
           <li class='xn-openable' {if $menu_default eq 'bills/list'}class="active"{/if}><a href="#"><span class="fa fa-money"></span>Outstanding</a>

               <ul>
                   <li {if $menu_default eq 'receipts/list' }class="active"{/if}><a href="/bills/list">List</a></li>
                   <li {if $menu_default eq 'bills/summary'}class="active"{/if}><a href="/bills/summary">Summary</a></li>
               </ul>

           </li>
           {* <li  {if $menu_default eq 'quotes_outstanding/list'}class="active"{/if}><a href="/quotes_outstanding/list"></span>Exempt Outstanding</a></li> *}
            <li  {if $menu_default eq 'exempt_outstanding/list'}class="active"{/if}><a href="/exempt_outstanding/list"></span>Exempt Outstanding - DN</a></li>
           <li  {if $menu_default eq 'credit_notes/list'}class="active"{/if}><a href="/credit_notes/list"></span>Credit Notes</a></li>

        </ul>
    </li>

    <li class="xn-openable">
        <a href="#"><span class="fa fa-money"></span> <span class="xn-text">Finance</span></a>
        <ul>
            <li  {if $menu_default eq 'finance_reports/management_report'}class="active"{/if}><a href="/finance_reports/management_report">MGT Report</a></li>
            <li {if $menu_default eq 'sales_targets/add' || $menu_default eq 'sales_targets/edit' || $menu_default eq 'sales_targets/list'}class="active"{/if}><a href="/sales_targets/list">Sales Targets</a></li>
            <li {if $menu_default eq 'expense_budgets/add' || $menu_default eq 'expense_budgets/edit' || $menu_default eq 'expense_budgets/list'}class="active"{/if}><a href="/expense_budgets/list">Expense  Budgets</a></li>
        </ul>
    </li>

    <li class="xn-openable">
        <a href="#"><span class="fa fa-users"></span><span class="xn-text">HR</span></a>
        <ul>
           <li class="xn-openable" {if $menu_default eq 'employees/list'}class="active"{/if}><a href="#">Employees</a>

               <ul>
                   <li {if $menu_default eq 'employees/list' }class="active"{/if}><a href="/employees/list">Employees List</a></li>
                   <li {if $menu_default eq 'employees/add' || $menu_default eq 'employees/edit'}class="active"{/if}><a href="/employees/add">New Employee</a></li>
               </ul>

           </li>
           <li class="xn-openable" {if $menu_default eq 'contracts/list'}class="active"{/if}><a href="#">Contracts</a>
               <ul>
                   <li {if $menu_default eq 'contracts/list' }class="active"{/if}><a href="/contracts/list">List</a></li>
                   <li {if $menu_default eq 'contract_templates/list' || $menu_default eq 'contract_templates/edit'}class="active"{/if}><a href="/contract_templates/list">Templates</a></li>
               </ul>
           </li>
           <li class="xn-openable" {if $menu_default eq 'employee_notice/list'}class="active"{/if}><a href="#">Employee Notice</a>
               <ul>
                   <li {if $menu_default eq 'employee_notice/list' }class="active"{/if}><a href="/employee_notice/list">List</a></li>
                   <li {if $menu_default eq 'notice_templates/list' || $menu_default eq 'notice_templates/edit'}class="active"{/if}><a href="/notice_templates/list">Templates</a></li>
                   <li {if $menu_default eq 'employee_remarks/list' }class="active"{/if}><a href="/employee_remarks/list">Remarks</a></li>
               </ul>
           </li>
        <li {if $menu_default eq 'payroll/list' }class="active"{/if}><a href="/payroll/list">Payroll</a></li>
        <li {if $menu_default eq 'leaves/list' }class="active"{/if}><a href="/leaves/list">Leaves</a></li>
        <li {if $menu_default eq 'advances/list' }class="active"{/if}><a href="/advances/list">Advances</a></li>
        <li {if $menu_default eq 'damage_report/list' }class="active"{/if}><a href="/damage_report/list">Damage Report</a></li>
        <li {if $menu_default eq 'loans/list' }class="active"{/if}><a href="/loans/list">Loans</a></li>

        </ul>
    </li>

    <li class="xn-openable">
        <a href="#"><span class="fa fa-money"></span> <span class="xn-text">Petty Cash</span></a>
        <ul>
            <li  {if $menu_default eq 'petty_cash/list'}class="active"{/if}><a href="/petty_cash/list">List Petty Cash</a></li>
            <li {if $menu_default eq 'petty_cash/add'}class="active"{/if}><a href="/petty_cash/add">Add Petty Cash</a></li>
            <li {if $menu_default eq 'petty_cash/log'}class="active"{/if}><a href="/petty_cash/log">Cash Log</a></li>
        </ul>
    </li>

    <li class="xn-openable">
        <a href="#"><span class="fa fa-money"></span> <span class="xn-text">Bank Transfer</span></a>

        <ul>
            <li  {if $menu_default eq 'petty_cash_mobile/list'}class="active"{/if}><a href="/petty_cash_mobile/list">List Bank Transfers</a></li>
            <li {if $menu_default eq 'petty_cash_mobile/add'}class="active"{/if}><a href="/petty_cash_mobile/add">Add Bank Transfer</a></li>
            {* <li {if $menu_default eq 'petty_cash_mobile/log'}class="active"{/if}><a href="/petty_cash_mobile/log">Bank Transfer Log</a></li> *}
        </ul>
    </li>

    <li class="xn-openable">
        <a href="#"><span class="fa fa-money"></span> <span class="xn-text">Exempt Cash</span></a>
        <ul>
            <li {if $menu_default eq 'exemptcash/list' }class="active"{/if}><a href="/exemptcash/list">List Exempt Cash</a></li>
            <li {if $menu_default eq 'exemptcash/add'}class="active"{/if}><a href="/exemptcash/add">Add Payout</a></li>
        </ul>
    </li>

    <li class="xn-openable">
       <a href="#"><span class="fa fa-truck"></span>Logistics</a>
       <ul>
           <li class="xn-openable"><a href="#"><span class="fa fa-truck"></span> Vehicles</a>
             <ul>
               <li {if $menu_default eq 'vehicles/index' || $menu_default eq 'vehicles/list'}class="active"{/if}><a href="/vehicles">Vehicles List</a></li>
                <li {if $menu_default eq 'vehicles/add' || $menu_default eq 'vehicles/edit' }class="active"{/if}><a href="/vehicles/add">New Vehicle</a></li>
             </ul>

           </li>
           <li class="xn-openable"><a href="#"><span class="fa fa-list"></span> Vehicle Schedule</a>
             <ul>
               <li {if $menu_default eq 'vehicle_schedule/list'}class="active"{/if}><a href="/vehicle_schedule/list">Vehicle Schedule List</a></li>
                <li {if $menu_default eq 'vehicle_schedule/add'}class="active"{/if}><a href="/vehicle_schedule/add">New Vehicle Schedule</a></li>
                <li {if $menu_default eq 'vehicle_schedule/consumption_report'}class="active"{/if}><a href="/vehicle_schedule/consumption_report">Consumption Report</a></li>
             </ul>

           </li>

       </ul>
   </li>

   <li class="xn-openable">
       <a href="#"><span class="fa fa-briefcase"></span> <span class="xn-text">Asset Management</span></a>

       <ul>
           <li  {if $menu_default eq 'assets/list'}class="active"{/if}><a href="/assets/list">Assets</a></li>
           <li {if $menu_default eq 'assets/reconciliation'}class="active"{/if}><a href="/assets/reconciliation">Reconciliation</a></li>
           <li {if $menu_default eq 'electronics/list'}class="active"{/if}><a href="/electronics/list">Electronic Equipment</a></li>
           <li {if $menu_default eq 'furniture/list'}class="active"{/if}><a href="/furniture/list">Furniture and Fixtures</a></li>
       </ul>
   </li>

    <li class="xn-openable">
        <a href="#"><span class="fa fa-wrench"></span> <span class="xn-text">Tools & Equipments</span></a>

        <ul>
            <li  {if $menu_default eq 'tools/list'}class="active"{/if}><a href="/tools/list">List Tools</a></li>
            <li {if $menu_default eq 'loaned_tools/list'}class="active"{/if}><a href="/loaned_tools/list">Loaned Tools</a></li>
        </ul>
    </li>



</ul>
<!-- END X-NAVIGATION -->



</div>
<!-- END PAGE SIDEBAR -->
