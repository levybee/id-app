{if $privileges.config.edit || $privileges.config.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/config/list">Configurations</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Configurations</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
             
        {if !$hide_form}     
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Config</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">
                      
                     
                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Configuration</label>
                         <div class="col-md-6 col-xs-12">                                            
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                 <input type="text" name="config_name" value="{if $smarty.post.config_name}{$smarty.post.config_name}{elseif $edit_config[0].config_name}{$edit_config[0].config_name}{/if}" class="form-control"/>
                             </div>                                            
                             
                         </div>
                     </div>
                     
                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Value</label>
                         <div class="col-md-6 col-xs-12">                                            
                             <textarea name="config_value" class="form-control" rows="12">{if $smarty.post.config_value}{$smarty.post.config_value}{elseif $edit_config[0].config_value}{$edit_config[0].config_value}{/if}</textarea>
                             
                         </div>
                     </div>
                     
                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>                                    
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Config</button>
                 </div>
             </div>
            </form>                                                
            {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 

{/if}