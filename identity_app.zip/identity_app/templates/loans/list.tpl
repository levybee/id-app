{if $privileges.loans.list}



<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Loans</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Loans List</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">


           <a href="/loans/add" class="btn btn-default">Add Loan</a>


      <br><br>

      {* Filter By Status: <a href="/loans/list?page=1" class="btn {if !$smarty.get.type}btn-success{/if} btn-flat btn-rad">All</a>

      <a href="/loans/list?page=1&filter=1&type=Routine Service" class="btn {if $smarty.get.type eq 'Routine Service'}btn-success{else}btn-default{/if}">Routine Service</a>

      <a href="/loans/list?page=1&filter=1&type=New Problem" class="btn {if $smarty.get.type eq 'New Problem'}btn-success{else}btn-default{/if}">New Problem</a>
       <br><br> *}
       <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a>
        {include file="$section/search.tpl"}
        </div>

        <div class="panel panel-default">

            <div class="panel-heading">
                 <h3 class="panel-title">Loans Table</h3>
                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/loans/list?{if $search_str}&{$search_str}&page={$page-1}{else}&page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/loans/list?{if $search_str}&{$search_str}&page={$page+1}{else}&page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                          {* if $role_data[0].role_is_admin eq 'Yes'}
        					         <a href="/loans/list?popup=1&print=1&page=*" onClick="popupURL(this.href, 'ticketList', 800, 500); return false;">
        					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
        					                </a>
        					        {/if *}

                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="80" class="text-center">#</th>
                                <th class="text-center">Date Applied</th>
                                <th class="text-center">Employee</th>
                                <th class="text-center">Deduction Installment</th>
                                <th class="text-center">Deduction Amount</th>
                                <th class="text-center">Loan Total</th>
                                <th class="text-center">Created By</th>
                                <th class="text-center">Confirmed By</th>
                                <th class="text-center">Status</th>
							                {if !$smarty.get.print}  <th class="text-center">Action</th> {/if}
                            </tr>
                        </thead>
                        <tbody>
                           {section name=loan_list loop=$loan_list}
                            <tr>

                                <td class="text-center">{$loan_list[loan_list].id}</td>
                                <td class="text-center">{$loan_list[loan_list].date_applied|date_format:"%d %b %Y"}</td>
                                <td class="text-center"> {$loan_list[loan_list].employee}</td>
                                <td class="text-center">{$loan_list[loan_list].no_of_months} Months</td>
                                <td class="text-center">{$loan_list[loan_list].deduction_amount} TZS</td>
                                <td class="text-center">{$loan_list[loan_list].total_loan} TZS</td>
                                <td class="text-center">{$loan_list[loan_list].user}</td>
                                <td class="text-center">{$loan_list[loan_list].confirmed_user}</td>
                                <td class="text-center">
                                    <span class="{if $loan_list[loan_list].loan_status eq 'Pending'}text-info{elseif $loan_list[loan_list].loan_status eq 'Confirmed'}text-success{else}text-default{/if}">{$loan_list[loan_list].loan_status}</span>
                                </td>

                                {if !$smarty.get.print}
                                <td style="padding:10px!important;" class="text-center">
                                  {if $loan_list[loan_list].loan_status eq 'Pending'}
                                    <a href="/loans/list?actn=confirm&id={$loan_list[loan_list].id}" class="btn btn-success btn-rounded btn-condensed btn-sm" title="Confirm" onclick="confirmAction('[Confirm Loan] Are you sure?', this.href); return false;" ><span class="fa fa-check"></span></a>
                                  {/if}
                                  {if $loan_list[loan_list].loan_status eq 'Pending' || $loan_list[loan_list].loan_status eq 'Confirmed'}
                                  <a title="edit" href="/loans/edit?id={$loan_list[loan_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>
                                  {/if}
                                </td>
                                {/if}
                            </tr>
                            {sectionelse}
                            <tr>
                                <td colspan="10">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
