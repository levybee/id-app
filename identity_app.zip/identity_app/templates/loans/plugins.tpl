<!-- PAGE PLUGINS -->
       <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
       <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>




{literal}

<script type="text/javascript">

$(document).ready(function(){
  var page_action =  '{/literal}{$action}{literal}';

  if(page_action == 'edit'){
    var employee_id = '{/literal}{$edit_loan[0].employee_id}{literal}';
    var employee = '{/literal}{$edit_loan[0].employee}{literal}';

    if(employee_id){
      var job_option = new Option(employee , employee_id, true, true);
      $("#employee_id").append(job_option).trigger('change');
    }

  }

$("#employee_id").select2({
   placeholder: "Type to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/employees.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       //console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 var no_of_months = $('#no_of_months').val();
 var deduction_amount = $('#deduction_amount').val();
 deduction_total(no_of_months, deduction_amount);

 $("#no_of_months").on("blur", function () {
    var deduction_amount = $('#deduction_amount').val();
    deduction_total($(this).val(), deduction_amount);
 });

 $("#deduction_amount").on("blur", function () {
    var no_of_months = $('#no_of_months').val();
    deduction_total(no_of_months, $(this).val());
 });

 function deduction_total(no_of_months, deduction_amount){

   if($.isNumeric(no_of_months) && $.isNumeric(deduction_amount)){
     var total = no_of_months * deduction_amount;
     total = addCommas(total)
     $('.deduction_total').text(total +' TZS');
   }else{
     $('.deduction_total').text('');
   }
 }

 function addCommas(nStr) {
     nStr += '';
     var x = nStr.split('.');
     var x1 = x[0];
     var x2 = x.length > 1 ? '.' + x[1] : '';
     var rgx = /(\d+)(\d{3})/;
     while (rgx.test(x1)) {
         x1 = x1.replace(rgx, '$1' + ',' + '$2');
     }
     return x1 + x2;
 }


 });

</script>
{/literal}


<!-- END PAGE PLUGINS -->
