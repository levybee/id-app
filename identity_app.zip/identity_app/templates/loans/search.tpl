


<div id="search" class="panel panel-default" style="{if !$smarty.get.filter}display: none;{/if} margin-top:15px;">

  <div class="panel-body">
     <form id="form2" name="form2" class="form-inline"  method="post" action="/loans/list?filter=1{if $search_str}{$search_str}{/if}">

       <div class="form-group" style="margin:0 15px 10px 0;">
       <label >Employee:</label><br>
       <select id="employee_id" name="employee_id" style="display:block; width:180px;" {if $smarty.post.employee_id}value="{$smarty.post.employee_id}"{/if}  class="form-control">
       </select>

       </div>

      <div class="form-group"  style="margin:0 15px 10px 0;">
      <label for="to_date">Date From:</label>
       <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_from"  value="{if $smarty.post.date_from}{$smarty.post.date_from|date_format:'%Y-%m-%d'}{else}{/if}" >

     </div>

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Date To:</label>
        <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_to"  value="{if $smarty.post.date_to}{$smarty.post.date_to|date_format:'%Y-%m-%d'}{else}{/if}" >

      </div>

       <div class="form-group" style="margin-top:10px;">
         <input type="hidden" name="debug" value="{$smarty.get.s_debug}" >
         <button type="submit" class="btn btn-primary">Go</button>
       </div>

  </form>

  </div>

  </div>
