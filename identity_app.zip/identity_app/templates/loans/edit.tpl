{if $privileges.loans.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/loans/list">Loans</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{if $action eq 'add'}New{else}Edit{/if} Loan</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

         {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                      <h3 class="panel-title"><strong>Loan</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>

                 <div class="panel-body form-group">
                   <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">Date Applied</label>
                     <div class="col-md-6 col-xs-12">
                       <div class="input-group">
                           <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                           <input name="date_applied" type="text" class="form-control datepicker" value="{if $smarty.post.date_applied}{$smarty.post.date_applied}{else}{$edit_loan[0].date_applied}{/if}" readonly="readonly" required>
                       </div>
                     </div>
                   </div>
                   <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">Employee</label>
                     <div class="col-md-6 col-xs-12">
                       <select id="employee_id" name="employee_id" style="width:100%;" {if $smarty.post.employee_id}value="{$smarty.post.employee_id}"{/if}  class="form-control">
                       </select>
                     </div>
                   </div>

                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Deduction Installment (Months)</label>
                    <div class="col-md-6 col-xs-12">
                        <input name="no_of_months" id="no_of_months" type="number" value="{if $smarty.post.no_of_months}{$smarty.post.no_of_months}{else}{$edit_loan[0].no_of_months}{/if}" class="form-control" required />
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Deduction Amount</label>
                    <div class="col-md-6 col-xs-12">
                        <input name="deduction_amount" id="deduction_amount" placeholder="TZS" value="{if $smarty.post.deduction_amount}{$smarty.post.deduction_amount}{else}{$edit_loan[0].deduction_amount}{/if}" class="form-control" required />
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Total</label>
                    <div class="col-md-6 col-xs-12">
                        <p class="form-control-static deduction_total"></p>
                    </div>
                </div>

                {* <div class="form-group">
                     <label class="col-md-3 control-label">Remarks</label>
                     <div class="col-md-6">
                       <textarea name="remarks"  class="form-control" rows='4'>{if $smarty.post.remarks}{$smarty.post.remarks}{else}{$edit_loan[0].remarks}{/if}</textarea>
                     </div>
                </div> *}



                {if $action eq 'edits'}
                  <div class="form-group">
                      <label class="col-md-3 col-xs-12 control-label">Status</label>
                      <div class="col-md-6 col-xs-12">
                          <select name="status" class="form-control select">
                               <option value="Pending" {if $edit_loan[0].status eq 'Pending'}selected{/if}>Pending</option>
                               <option value="Confirmed" {if $edit_loan[0].status eq 'Confirmed'}selected{/if}>Confirmed</option>
                               <option value="Closed" {if $edit_loan[0].status eq 'Closed'}selected{/if}>Closed</option>
                               <option value="Cancelled" {if $edit_loan[0].status eq 'Cancelled'}selected{/if}>Cancelled</option>
                          </select>

                      </div>
                  </div>
              {/if}

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{if $action eq 'add'}Add{else}Edit{/if} Loan</button>
                 </div>
             </div>
             </form>


            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->


{/if}
