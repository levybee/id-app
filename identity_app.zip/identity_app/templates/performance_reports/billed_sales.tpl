
<div class="panel panel-default">

    <div class="panel-heading">
         <h3 class="panel-title">Report Table</h3>
          <ul class="panel-controls panel-controls-title">
             <li>

             {* <form class="form-inline" role="form" method="post">
                 <div class="form-group">
                   </div>
                 <div class="form-group">
                     <a href="/my_reports/list?{if $search_str}&{$search_str}&page={$page-1}{else}&page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/my_reports?task=list{if $search_str}&{$search_str}&page={$page+1}{else}&page={$page+1}{/if}">Next Page &gt;</a>

                     <label>| Displaying {$resultsCount}</label>
                 </div>
                 <div class="form-group">

                   <select name="page" id="page" class="form-control">
                       {section name=pagination loop=$numPages}

                         <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                       {sectionelse}

                         <option value="1" selected>Page 1</option>


                       {/section}

                        </select>
                               </div>
                               <button name="submit" type="submit" class="btn btn-danger">Go</button>
                           </form> *}
                           </li>

                       </ul>
                  </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              <th>Ref #</th>
            							    <th>Date</th>
            							    <th>Customer</th>
                              <th class="text-center">Value (TZS)</th>
            							    <th class="text-center">User</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=invoice_list loop=$invoice_list}
                            <tr>
                              <td><a title="View" target="_blank" href="/invoices/view?uid={$invoice_list[invoice_list].invoice_id}">TI/{$invoice_list[invoice_list].invoice_date|substr:0:4}/{$invoice_list[invoice_list].invoice_id}</a></td>
                             <td>{$invoice_list[invoice_list].invoice_date|date_format:"%d %B %Y"}</td>
                             <td>{$invoice_list[invoice_list].group_company}</td>
                              <td class="text-center">{$invoice_list[invoice_list].invoice_value|number_format:2:".":","}</td>
                             <td class="text-center">{$invoice_list[invoice_list].user_fname} {$invoice_list[invoice_list].user_lname}</td>
                            </tr>
                            {sectionelse}
                            <tr>

                                <td colspan="5">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                           <tr>
                             <td colspan="3" class="text-right"><strong>Total</strong></td><td class="text-center"><strong>{$total_invoice_value|number_format:2:".":","}</strong></td>
                             <td></td>
                           </tr>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
