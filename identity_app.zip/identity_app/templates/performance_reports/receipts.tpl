
<div class="panel panel-default">

    <div class="panel-heading">
         <h3 class="panel-title">Report Table</h3>
          <ul class="panel-controls panel-controls-title">
             <li>

             {* <form class="form-inline" role="form" method="post">
                 <div class="form-group">
                   </div>
                 <div class="form-group">
                     <a href="/my_reports/list?{if $search_str}&{$search_str}&page={$page-1}{else}&page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/my_reports?task=list{if $search_str}&{$search_str}&page={$page+1}{else}&page={$page+1}{/if}">Next Page &gt;</a>

                     <label>| Displaying {$resultsCount}</label>
                 </div>
                 <div class="form-group">

                   <select name="page" id="page" class="form-control">
                       {section name=pagination loop=$numPages}

                         <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                       {sectionelse}

                         <option value="1" selected>Page 1</option>


                       {/section}

                        </select>
                               </div>
                               <button name="submit" type="submit" class="btn btn-danger">Go</button>
                           </form> *}
                           </li>

                       </ul>
                  </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              <th>Ref #</th>

            							    <th>Customer</th>
                              <th class="text-center">Receipt Amount (TZS)</th>
                              <th class="text-center">Commission (TZS)</th>
            							    <th>User</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=receipt_list loop=$receipt_list}
                            <tr>
                              <td><a title="View Receipt" href="/receipts/view/?id={$receipt_list[receipt_list].receipt_id}"  alt="View Receipt">{$receipt_list[receipt_list].receipt_date|substr:0:4}-{$receipt_list[receipt_list].receipt_date|substr:5:2}-{$receipt_list[receipt_list].receipt_id|leading_zero:5}</a></td>

                             <td>{$receipt_list[receipt_list].group_company}</td>
                             <td class="text-right">{$receipt_list[receipt_list].receipt_amount|number_format:2:".":","}</td>
                             <td class="text-right">{if $receipt_list[receipt_list].commission_amount}{$receipt_list[receipt_list].commission_amount|number_format:2:".":","}{/if}</td>
                             <td class="text-center">{$receipt_list[receipt_list].user_fname} {$receipt_list[receipt_list].user_lname}</td>
                            </tr>
                            {sectionelse}
                            <tr>

                                <td colspan="5">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                           <tr>
                             <td colspan="2" class="text-right"><strong>Total</strong></td><td class="text-right"><strong>{$total_receipt_value|number_format:2:".":","}</strong></td>
                             <td class="text-right">{if $commision_total gt 0}<strong>{$commision_total|number_format:2:".":","}</strong>{/if}</td>
                             <td></td>
                           </tr>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
