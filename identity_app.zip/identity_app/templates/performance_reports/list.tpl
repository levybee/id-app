{if $privileges.performance_reports.list}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Performance Reports</a></li>
     {if $report_type}<li class="active"><a href="">{$report_type}</a></li>{/if}
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Performance Reports{if $report_type}: {$report_type}{/if}</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
         {/if}
     <div class="col-md-12" style="margin-bottom:10px;">

      <div id="search" class="panel panel-default" style="margin-top:15px;">

      <div class="panel-body">
         <form id="performance_form" name="performance_form" class="form-inline"  method="post" action="/performance_reports/list?{if $search_str}{$search_str}{/if}">

           <div class="form-group" style="margin-right:15px;">
           <label>Report Type</label><br>
           <select name="report_type" style="display:block; width:160px;"   class="form-control">
           <option value="">Select..</option>
             <option value="Quotes Issued" {if $smarty.post.report_type eq 'Quotes Issued'}selected{/if}>Quotes Issued</option>
             <option value="Sales In Production" {if $smarty.post.report_type eq 'Sales In Production'}selected{/if}>Sales In Production</option>
             <option value="Billed Sales" {if $smarty.post.report_type eq 'Billed Sales'}selected{/if}>Billed Sales</option>
             <option value="Exempt Sales" {if $smarty.post.report_type eq 'Exempt Sales'}selected{/if}>Exempt Sales</option>
             <option value="Receipts" {if $smarty.post.report_type eq 'Receipts'}selected{/if}>Receipts</option>
           </select>

           </div>
           <div class="form-group" style="margin-right:15px;">
           <label>Sales Person</label><br>
           <select name="user_id" style="display:block; width:160px;"   class="form-control select2">
           <option value="" {if !$smarty.post.user_id}selected{/if}>All</option>
           {section name=users loop=$cms_users}
             <option value="{$cms_users[users].user_id}" {if $smarty.post.user_id eq '{$cms_users[users].user_id}'}selected{/if}>{$cms_users[users].user_fname} {$cms_users[users].user_lname}</option>
           {/section}
           </select>

           </div>

          <div class="form-group" style="margin-right:15px;">
           <label for="from_date" >Date From:</label>
            <input  type="text" style="display:block;"  name="date_from"  class="form-control datepicker" value="{if $smarty.post.date_from}{$smarty.post.date_from|date_format:'%Y-%m-%d'}{else}{/if}" >
          </div>

           <div class="form-group"  style="margin-right:15px;">
           <label for="to_date">Date To:</label>
            <input type="text" class="form-control datepicker" style="display:block;"  name="date_to"  value="{if $smarty.post.date_to}{$smarty.post.date_to|date_format:'%Y-%m-%d'}{else}{/if}" >

          </div>

           <div class="form-group" style="margin-top:20px;">
             <input type="hidden" name="debug" value="{$smarty.get.post_debug}" >
             <button type="submit" class="btn btn-primary">Go</button>
           </div>


      </form>

      </div>
      </div>

     </div>


            {if $report_type eq 'Quotes Issued'}
            {include file='performance_reports/quotes_issued.tpl'}
            {/if}
            {if $report_type eq 'Billed Sales'}
            {include file='performance_reports/billed_sales.tpl'}
            {/if}
            {if $report_type eq 'Sales In Production'}
            {include file='performance_reports/sales_in_production.tpl'}
            {/if}
            {if $report_type eq 'Receipts'}
            {include file='performance_reports/receipts.tpl'}
            {/if}
            {if $report_type eq 'Exempt Sales'}
            {include file='performance_reports/exempt_sales.tpl'}
            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
