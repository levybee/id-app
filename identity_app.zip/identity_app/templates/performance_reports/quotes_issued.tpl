
<div class="panel panel-default">

    <div class="panel-heading">
         <h3 class="panel-title">Report Table</h3>
          <ul class="panel-controls panel-controls-title">
             <li>

             {* <form class="form-inline" role="form" method="post">
                 <div class="form-group">
                   </div>
                 <div class="form-group">
                     <a href="/my_reports/list?{if $search_str}&{$search_str}&page={$page-1}{else}&page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/my_reports?task=list{if $search_str}&{$search_str}&page={$page+1}{else}&page={$page+1}{/if}">Next Page &gt;</a>

                     <label>| Displaying {$resultsCount}</label>
                 </div>
                 <div class="form-group">

                   <select name="page" id="page" class="form-control">
                       {section name=pagination loop=$numPages}

                         <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                       {sectionelse}

                         <option value="1" selected>Page 1</option>


                       {/section}

                        </select>
                               </div>
                               <button name="submit" type="submit" class="btn btn-danger">Go</button>
                           </form> *}
                           </li>

                       </ul>
                  </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              <th>Ref #</th>
                              <th>Date</th>
                              <th>Customer</th>
                              <th>Items #</th>
                              <th>Value (TZS)</th>
                              {* <th>Status</th> *}
                              <th>User</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=quote_list loop=$quote_list}
                            <tr>
                              <td><a title="View Quote" href="/quotes/view/?id={$quote_list[quote_list].quote_id}"  alt="View Quote">{$quote_list[quote_list].quote_date|substr:0:4}-{$quote_list[quote_list].quote_date|substr:5:2}-{$quote_list[quote_list].quote_id|leading_zero:5}</a></td>
                             <td>{$quote_list[quote_list].quote_date|date_format:"%d %B %Y"}</td>
                             <td>{if $quote_list[quote_list].customer_id eq 0}{$quote_list[quote_list].quote_customer}{else}{$quote_list[quote_list].group_company}{/if}</td>
                             <td class="text-center">{$quote_list[quote_list].quote_items_num}</td>
                              <td class="text-center">{$quote_list[quote_list].quote_value|number_format:2:".":","}</td>
                              {* <td>{$quote_list[quote_list].quote_status}</td> *}
                             <td>{$quote_list[quote_list].user_fname} {$quote_list[quote_list].user_lname}</td>
                            </tr>
                            {sectionelse}
                            <tr>

                                <td colspan="6">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                           <tr>
                             <td colspan="4" class="text-right"><strong>Total</strong></td><td class="text-center"><strong>{$total_quote_value|number_format:2:".":","}</strong></td>
                             <td></td>
                           </tr>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
