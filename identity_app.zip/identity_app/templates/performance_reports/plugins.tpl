 <!-- PAGE PLUGINS -->
        <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/js/jquery/jquery.livequery.min.js"></script>
        <script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>
        <!--  <script type="text/javascript" src="/js/plugins/smartwizard/jquery.smartWizard-2.0.min.js"></script>        
        <script type="text/javascript" src="/js/plugins/jquery-validation/jquery.validate.js"></script> -->
        
<!-- END PAGE PLUGINS --> 