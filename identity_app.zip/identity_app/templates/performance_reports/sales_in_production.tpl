
<div class="panel panel-default">

    <div class="panel-heading">
         <h3 class="panel-title">Report Table</h3>
          <ul class="panel-controls panel-controls-title">
             <li>

             {* <form class="form-inline" role="form" method="post">
                 <div class="form-group">
                   </div>
                 <div class="form-group">
                     <a href="/my_reports/list?{if $search_str}&{$search_str}&page={$page-1}{else}&page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/my_reports?task=list{if $search_str}&{$search_str}&page={$page+1}{else}&page={$page+1}{/if}">Next Page &gt;</a>

                     <label>| Displaying {$resultsCount}</label>
                 </div>
                 <div class="form-group">

                   <select name="page" id="page" class="form-control">
                       {section name=pagination loop=$numPages}

                         <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                       {sectionelse}

                         <option value="1" selected>Page 1</option>


                       {/section}

                        </select>
                               </div>
                               <button name="submit" type="submit" class="btn btn-danger">Go</button>
                           </form> *}
                           </li>

                       </ul>
                  </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              <th>Ref #</th>
            							    <th>Product</th>
            							    <th>Title</th>
            							    <th>Customer</th>
            							    <th>Quantity</th>
                              <th>Value (TZS)</th>
            							    <th>User</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=job_list loop=$job_list}
                            <tr>
                              <td><a title="View Progress" href="/jobs/progress?id={$job_list[job_list].job_id}">{$job_list[job_list].job_date|substr:0:4}-{$job_list[job_list].job_date|substr:5:2}-{$job_list[job_list].job_id|leading_zero:5}</a></td>
                             <td>{$job_list[job_list].product_name}</td>
             						     <td>{$job_list[job_list].job_reference}</td>
                             <td>{$job_list[job_list].group_company}</td>
                             <td>{$job_list[job_list].job_paper_quantity|thousand_sep}</td>
                              <td class="text-center">{$job_list[job_list].item_price_1|number_format:2:".":","}</td>
                             <td>{$job_list[job_list].user_fname} {$job_list[job_list].user_lname}</td>
                            </tr>
                            {sectionelse}
                            <tr>

                                <td colspan="7">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                           <tr>
                             <td colspan="5" class="text-right"><strong>Total</strong></td><td class="text-center"><strong>{$total_job_value|number_format:2:".":","}</strong></td>
                             <td></td>
                           </tr>
                        </tbody>
                    </table>
                </div>

            </div>

        </div>
