


<div id="search" class="panel panel-default" style="{if !$smarty.get.filter}display: none;{/if} margin-top:15px;">

  <div class="panel-body">
     <form id="form2" name="form2" class="form-inline"  method="post" action="/leaves/list?filter=1{if $search_str}{$search_str}{/if}">

       <div class="form-group" style="margin:0 15px 10px 0;">
       <label >Employee:</label><br>
       <select id="employee_id" name="employee_id" style="display:block; width:180px;" {if $smarty.post.employee_id}value="{$smarty.post.employee_id}"{/if}  class="form-control">
       </select>

       </div>

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label>Type:</label>
       <select name="leave_type" id="leave_type" class="form-control" style="display:block; width:180px;">
       <option value="">All</option> 
       <option value="Annual Leave"  {if $smarty.post.leave_type eq "Annual Leave" || $edit_leave[0].leave_type eq "Annual Leave"}selected{/if}>Annual Leave</option>
       <option value="Sick Leave"  {if $smarty.post.leave_type eq "Sick Leave" || $edit_leave[0].leave_type eq "Sick Leave"}selected{/if}>Sick Leave</option>
       <option value="Compassionate Leave"  {if $smarty.post.leave_type eq "Compassionate Leave" || $edit_leave[0].leave_type eq "Compassionate Leave"}selected{/if}>Compassionate Leave</option>
       <option value="Unpaid Leave"  {if $smarty.post.leave_type eq "Unpaid Leave" || $edit_leave[0].leave_type eq "Unpaid Leave"}selected{/if}>Unpaid Leave</option>
       <option value="Maternity Leave"  {if $smarty.post.leave_type eq "Maternity Leave" || $edit_leave[0].leave_type eq "Maternity Leave"}selected{/if}>Maternity Leave</option>
        </select>
      </div>

      <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="paper_id">Department</label>

       	<select name="department_id" id="department_id" class="form-control select">
          <option value="">Any</option>
          {section name=departments_list loop=$departments_list}
            <option value="{$departments_list[departments_list].department_id}" {if $edit_employee[0].department_id eq $departments_list[departments_list].department_id}selected{/if}>{$departments_list[departments_list].department_name}</option>
          {/section}


  	    </select>

      </div>

      <div class="form-group"  style="margin:0 15px 10px 0;">
      <label for="to_date">Date From:</label>
       <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_from"  value="{if $smarty.post.date_from}{$smarty.post.date_from|date_format:'%Y-%m-%d'}{else}{/if}" >

     </div>

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Date To:</label>
        <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_to"  value="{if $smarty.post.date_to}{$smarty.post.date_to|date_format:'%Y-%m-%d'}{else}{/if}" >

      </div>




       <div class="form-group" style="margin-top:10px;">
         <input type="hidden" name="debug" value="{$smarty.get.s_debug}" >
         <button type="submit" class="btn btn-primary">Go</button>
       </div>

  </form>

  </div>

  </div>
