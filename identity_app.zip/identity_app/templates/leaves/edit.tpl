{if $privileges.leaves.edit || $privileges.leaves.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/leaves/list">Leave</a></li>
     <li class="active"><a href="">{if $action eq 'add'}Request{else}Edit{/if}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{if $action eq 'add'}Request{else}Edit{/if} Leave</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

         {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     {* <h3 class="panel-title"><strong>Request</strong> Form</h3> *}
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">

                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Employee</label>
                    <div class="col-md-6 col-xs-12">
                        <select name="employee_id" id="employee_id"  class="form-control" style="width:100%;">
                         </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Leave Type</label>
                    <div class="col-md-6 col-xs-12">
                         <select name="leave_type" id="leave_type" class="form-control">
                         <option value="Annual Leave"  {if $smarty.post.leave_type eq "Annual Leave" || $edit_leave[0].leave_type eq "Annual Leave"}selected{/if}>Annual Leave</option>
                         <option value="Sick Leave"  {if $smarty.post.leave_type eq "Sick Leave" || $edit_leave[0].leave_type eq "Sick Leave"}selected{/if}>Sick Leave</option>
                         <option value="Compassionate Leave"  {if $smarty.post.leave_type eq "Compassionate Leave" || $edit_leave[0].leave_type eq "Compassionate Leave"}selected{/if}>Compassionate Leave</option>
                         <option value="Unpaid Leave"  {if $smarty.post.leave_type eq "Unpaid Leave" || $edit_leave[0].leave_type eq "Unpaid Leave"}selected{/if}>Unpaid Leave</option>
                         <option value="Maternity Leave"  {if $smarty.post.leave_type eq "Maternity Leave" || $edit_leave[0].leave_type eq "Maternity Leave"}selected{/if}>Maternity Leave</option>
                </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Start Date</label>
                    <div class="col-md-6 col-xs-12">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                            <input id="start_date" name="start_date" type="text" class="form-control datepicker" value="{if $edit_leave[0].start_date}{$edit_leave[0].start_date}{elseif $smarty.post.start_date}{$smarty.post.start_date}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" style="width:140px;" readonly="readonly">
                        </div>

                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">End Date</label>
                    <div class="col-md-6 col-xs-12">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                            <input id="end_date" name="end_date" type="text" class="form-control datepicker" value="{if $edit_leave[0].end_date}{$edit_leave[0].end_date}{elseif $smarty.post.end_date}{$smarty.post.end_date}{else}{/if}" style="width:140px;" readonly="readonly">
                        
                        </div>

                    </div>
                </div>
                 <!-- <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">Duration</label>
                     <div class="col-md-6 col-xs-12">
                         <p class="form-control-static duration">{$edit_leave[0].duration}</p>
                     </div>
                 </div> -->

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Leave</button>
                 </div>
             </div>
             </form>


            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
