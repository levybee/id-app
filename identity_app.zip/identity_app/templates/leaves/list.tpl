{if $privileges.leaves.list}
<script type="text/javascript" src="/js/quote.js"></script>

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Leaves</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Leaves</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">

             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">

         {if $privileges.leaves.add}

           <a href="/leaves/add" class="btn btn-default">New Leave Request</a>
           <br><br>
         {/if}

         <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/leaves/list?page=1" class="btn btn-default">Clear</a> | Filter By Status: <a href="/leaves/list?page=1" class="btn {if !$smarty.get.status }btn-success{/if} btn-flat btn-rad">All</a>

         <a href="/leaves/list?page=1&filter=1&status=Pending" class="btn {if $smarty.get.status  eq 'Pending'}btn-success{else}btn-default{/if}">Pending</a>

         <a href="/leaves/list?page=1&filter=1&status=Confirmed" class="btn {if $smarty.get.status  eq 'Confirmed'}btn-success{else}btn-default{/if}">Confirmed</a>

         {* <a href="/leaves/list?page=1&filter=1&status=Closed" class="btn {if $smarty.get.status  eq 'Closed'}btn-success{else}btn-default{/if}">Closed</a> *}

         <a href="/leaves/list?page=1&filter=1&status=Cancelled" class="btn {if $smarty.get.status  eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled</a>
         {include file="$section/search.tpl"}
      </div>

        <div class="panel panel-default">

            <div class="panel-heading">

              {if $smarty.get.status  eq 'Pendings'}
              <label for="approve_selected" name="approve_selected" class="btn btn-danger">
                Approve Selected
              </label>
              {/if}

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/leaves/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/leaves/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>

                 </ul>
            </div>




            <div class="panel-body panel-body-table">

                <form method="post" action="">
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">
                    <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              {if $smarty.get.status  eq 'Pendings'}
                                  <th width="40" class="text-center">
                                      <input type="checkbox" id="check_all_approved"/></th>
                              {/if}
                               <th class="text-center">#</th>
                               <th class="text-center">Employee</th>
              								 <th class="text-center">Type</th>
                               <th class="text-center">Start Date</th>
                               <th class="text-center">End Date</th>
              								 <th class="text-center">Duration</th>
                               <th class="text-center">Attachment</th>
                               <th class="text-center">Status</th>
              								 <th class="text-center">User</th>
              							   <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=leaves_list loop=$leaves_list}
						  <tr>
                {if $leaves_list[leaves_list].leave_status  eq 'Pendings' && $smarty.get.status  eq 'Pending'}<td class="text-center">
                    <input type="checkbox" name="approved_check[]" class="approved_check" value="{$leaves_list[leaves_list].id}" /></td>{/if}

						    <td class="text-center">{$leaves_list[leaves_list].id}</td>
                <td class="text-center">{$leaves_list[leaves_list].employee_name}</td>
                <td class="text-center">{$leaves_list[leaves_list].leave_type}</td>
						    <td class="text-center">{$leaves_list[leaves_list].start_date|date_format:"%d/%m/%Y"}</td>
                <td class="text-center">{$leaves_list[leaves_list].end_date|date_format:"%d/%m%Y"}</td>
                <td class="text-center">{$leaves_list[leaves_list].duration} days</td>
                <td class="text-center">
                <a href="/{$config.attachment_dir}{$leaves_list[leaves_list].attachment_path}" target = "_blank">{if $leaves_list[leaves_list].attachment_path}{$leaves_list[leaves_list].attachment_path}{else}-{/if}</a>
                </td>
                <td class="text-center">
                    <span class="{if $leaves_list[leaves_list].leave_status  eq 'Pending'}text-danger{elseif $leaves_list[leaves_list].leave_status  eq 'Closed'}text-info{elseif $leaves_list[leaves_list].leave_status  eq 'Cancelled'}text-default{else}text-success{/if}">{$leaves_list[leaves_list].leave_status}</span>
                    {if $leaves_list[leaves_list].leave_status  eq 'Approved'}by {$leaves_list[leaves_list].approval_user}{/if}
                </td>
						    <td class="text-center">{$leaves_list[leaves_list].user}</td>
						    <td class="text-center">
                   {if $leaves_list[leaves_list].leave_status  eq 'Confirmed'}
                     <a title="Attachment"
                     href="" class="btn btn-default btn-rounded btn-condensed btn-sm attach_btn"
                     data-id="{$leaves_list[leaves_list].id}"
                     data-employee="{$leaves_list[leaves_list].employee_name}"
                     data-attachment_path="{$leaves_list[leaves_list].attachment_path}"
                     ><span class="fa fa-paperclip"></span></a>
                   {/if}

                   {if $leaves_list[leaves_list].leave_status  eq 'Pending'}
                   {if $privileges.leaves.confirm}
                   <a href="/leaves/list?actn=confirm&id={$leaves_list[leaves_list].id}" class="btn btn-info btn-rounded btn-condensed btn-sm" title="Confirm" onclick="confirmAction('[Confirm Leave] Are you sure?', this.href); return false;" ><span class="fa fa-check-circle"></span></a>
                   {/if}

                   <a href="/leaves/list?actn=cancel&id={$leaves_list[leaves_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Cancel" onclick="confirmAction('[Cancel Leave] Are you sure?', this.href); return false;" ><span class="fa fa-times"></span></a>
                   {/if}
                   <a href="/leaves/edit/?id={$leaves_list[leaves_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
						    </td>
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="11">No records found.</td>
						  </tr>
						  {/section}
                        </tbody>
                    </table>

                </div>
                </form>


            </div>

     {if $smarty.get.dbg}
     {$privileges.leaves|@print_r}
     {/if}

        </div>

 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

<div class="modal" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="defModalHead">Attachment for <span class="item_name"></span></h4>
            </div>
            <form id="attachment_form" name="attachment_form" method="post" action="/leaves/list" class="form-horizontal" enctype="multipart/form-data">
              <div class="modal-body">
                 <div id="response"></div>


                 <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


                     <div class="panel-body form-group">
                       <div class="row">


                         <div class="form-group">
                             <label>Attachment</label>
                             <input name="attachment_file" type="file" id="attachment_file" class="form-control" style="width:50%;" />
                         </div>

                 </div>

              </div>
              <div class="modal-footer">
                  <input type="hidden" name="id" value="" >
                  <input type="hidden" name="attachment_path" value="" >
                  <input type="submit" name="item_submit" class="btn btn-primary" value="Submit">
                  <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                </div>
            </form>

        </div>
    </div>
</div>

{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
