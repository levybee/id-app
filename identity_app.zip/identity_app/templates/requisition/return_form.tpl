<!-- NEW COMPANY MODAL -->
  <div class="modal" id="returnModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-md">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead"></h4>
              </div>
              <form id="return_form" name="item_action_form" method="post" action="/requisition/list" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="returnResponse"></div>


			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			                 <div class="panel-body form-group">

                         <table class="table pad-10 table-striped return-items-table">
                             <thead>
                                 <tr>
                                   <th>ID</th>
                                   <th>Item</th>
                 							     <th>Issued Qty</th>
                                   <th>Return Qty</th>
                                 </tr>
                             </thead>
                             <tbody></tbody>
                            </table>
			                 </div>

			             </div>

	              </div>
	              <div class="modal-footer">
                    <input type="hidden" name="return" value="1" >
	                  <input type="submit" name="return_submit" class="btn btn-primary" value="Submit">
	                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
              </form>

          </div>
      </div>
  </div>
