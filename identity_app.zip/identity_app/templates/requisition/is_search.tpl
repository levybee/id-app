

<div id="search" class="panel panel-default">

<div class="panel-body">
   <form id="isForm" name="isForm" class="form-inline"  method="post" action="/requisition/issued_stock?filter=1{if $search_str}&{$search_str}{/if}">

    <div class="form-group" style="margin-right:15px;">
     <label for="from_date" >Date From:</label>
      <input  type="text" style="display:block;"  name="date_from"  class="form-control datepicker" value="{if $smarty.post.date_from}{$smarty.post.date_from|date_format:'%Y-%m-%d'}{else}{/if}" >
    </div>

     <div class="form-group"  style="margin-right:15px;">
     <label for="to_date">Date To:</label>
      <input type="text" class="form-control datepicker" style="display:block;"  name="date_to"  value="{if $smarty.post.date_to}{$smarty.post.date_to|date_format:'%Y-%m-%d'}{else}{/if}" >
    </div>

    <div class="form-group" style="margin:0 15px 0 0;">
    <label >Stock:</label><br>
     <select name="stock_id" id="stock_id"  class="form-control" style="width:200px;" ></select>
    </div>

    <input type="hidden" name="form_filter" value="1">

    <div class="form-group" style="margin-top:20px;">
      <button type="submit" class="btn btn-primary">Go</button>
    </div>
   </div>

</form>
</div>
</div>
