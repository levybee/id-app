{if $privileges.gmr.view}

    <!-- START BREADCRUMB -->

    <ul class="breadcrumb">

        <li><a href="/">Home</a></li>

        <li><a href="/gmr/list">GMR</a></li>

        <li class="active"> GMR #{$gmr.gmr_id}</li>

    </ul>


    <!-- END BREADCRUMB -->

    <div class="page-title">

        <h2>
            <span class="fa fa-arrow-circle-o-left"></span>GMR #{$gmr.gmr_id}
        </h2>

        <ul class="panel-controls fa panel-controls-title">
          {if $gmr.gmr_status == "Draft"}
              <li><a class="btn btn-default" title="Approve"
                     href="/gmr/view?id={$gmr.gmr_id}&actn=approve"
                     onclick="confirmAction('[Approve GMR] Are you sure?', this.href); return false;"><span
                              class="fa fa-check text-warning"></span>Approve</a>
              </li>
              <li>
                <a class="btn btn-default" title="Edit" href="/gmr/edit?id={$gmr.gmr_id}"><span class="fa fa-pencil text-success"></span><b>Edit</b></a>
              </li>
          {/if}
          {if $gmr.gmr_status == "Issued"}
          <li><a class="btn btn-default" title="Close"
                 href="/gmr/view?id={$gmr.gmr_id}&actn=close"
                 onclick="confirmAction('[Close GMR] Are you sure?', this.href); return false;"><span
                          class="fa fa-check-circle text-success"></span>Close</a>
          </li>
          {/if}

          {if $gmr.gmr_status == "Approved"}
          <li><a class="btn btn-default issueBtn" title="Issue"
                 href="#"
                 data-gmr_id="{$gmr.gmr_id}"
                 onclick="issueGmrModal({$gmr.gmr_id}); return false;"><span
                          class="fa fa-check-circle text-info"></span>Issue</a>
          </li>

          {/if}
          {if $gmr.gmr_status != "Approved" && $gmr.gmr_status != "Cancelled"}
          <li>
            <a class="btn btn-default" title="Print" target="_blank" href="/gmr/print?id={$gmr.gmr_id}"><span class="fa fa-file-pdf-o"></span><b>PDF</b></a>
          </li>
          {/if}

          {if $gmr.gmr_status == "Draft" || $gmr.gmr_status == "Approved"}
           <li><a class="btn btn-default" title="Cancel"
                   href="/gmr/view?id={$gmr.gmr_id}&actn=cancel"
                  onclick="confirmAction('[Cancel GMR] Are you sure?', this.href); return false;"><span
                           class="fa fa-times text-default"></span>Cancel</a>
           </li>
          {/if}

        </ul>

    </div>
    <!-- PAGE CONTENT WRAPPER -->



    <div class="page-content-wrap">

        <div class="row">

           <div class="col-md-12">
             {if $message || $msg}
                  <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                      {$message}
                      {$msg}
                  </div>
                  {/if}
           </div>
            <div class="col-md-3">


                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title">GMR Info</h3>
                    </div>

                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">

                          <table class="table pad-10 table-striped">
                            <tr>
                             <td colspan="2"><div><strong>Date</strong></div>
                                 <div>{$gmr.date_created|date_format:"%d/%m/%Y"}</div>
                             </td>
                           </tr>
                            <tr>
                             <td colspan="2">
                               <div class="row">
                                 <div class="col-sm-6" style="padding:0;">
                                   <div><strong>From</strong></div>
                                   <div>
                                   {if $gmr.movement_from == 'Supplier' && $gmr.supplier_from_name}
                                   {$gmr.supplier_from_name}
                                   {else}
                                   {$gmr.movement_from}
                                   {/if}
                                 </div>
                                 </div>
                                 <div class="col-sm-6" style="padding:0;">
                                   <div><strong>To</strong></div>
                                   <div>
                                   {if $gmr.movement_to == 'Supplier' && $gmr.supplier_name}
                                   {$gmr.supplier_name}
                                   {else}
                                   {$gmr.movement_to}
                                   {/if}
                                 </div>
                                 </div>
                               </div>

                             </td>
                           </tr>
                           {if $gmr.job_id}
                           <tr>
                            <td colspan="2"><div><strong>Job</strong></div>
                                <div> #{$gmr.job_id}: {$gmr.job_reference}</div>
                            </td>
                          </tr>
                           {/if}
                         {if $gmr.delivery_person}
                         <tr>
                            <td colspan="2"><div><strong>Delivery Person</strong></div>
                                <div>{$gmr.delivery_person}</div>
                            </td>
                          </tr>
                          {/if}
                          {if $gmr.checked_by}
                          <tr>
                             <td colspan="2"><div><strong>Checked By</strong></div>
                                 <div>{$gmr.checked_by}</div>
                             </td>
                           </tr>
                           {/if}
                          <tr>
                           <td colspan="2"><div><strong>Status</strong></div>
                               <div>{$gmr.gmr_status}</div>
                           </td>
                         </tr>
                        </table>

                      </div>

                    </div>

                </div>

            </div>

            <div class="col-md-9">

                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title">Items</h3>
                    </div>



                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">

                          <table class="table pad-10 table-bordered table-striped table-actions">
                          <thead>
                              <tr>
                                  <th width="40">#</th>
                                  <th>Item</th>
                                  <th>Quantity</th>
                              </tr>
                          </thead>
                          <tbody>
                             {section name=gmri loop=$items}
              						  <tr>
              						    <td class="text-center">{$smarty.section.gmri.rownum}</td>
                              <td>
                                <strong>{$items[gmri].type|@ucfirst}</strong>:
                                {if $items[gmri].type == 'job'}
                                <a title="View" target="_blank" href="/jobs/progress?id={$items[gmri].job_id}">#{$items[gmri].job_id}</a> - {$items[gmri].job_reference}
                                {if $items[gmri].material_type}
                                <br>  <strong>Material Type: </strong>{$items[gmri].material_type}
                                {/if}
                                {if $items[gmri].size}
                                 &nbsp;<strong>Size: </strong>{$items[gmri].size}
                                {/if}

                                {/if}
                                {if $items[gmri].type == 'stock'}
                                {$items[gmri].stock_name}
                                {/if}
                                {if $items[gmri].type == 'other'}
                                 <p>{$items[gmri].description}</p>
                                {/if}
                              </td>
                              <td>{$items[gmri].quantity}</td>
  						            </tr>
  						  {sectionelse}
  						  <tr>
  						    <td colspan="3">No items found.</td>
  						  </tr>
  						  {/section}
                     </tbody>

                          </table>

                        </div>

                    </div>


                </div>


    </div>

    </div>


    <!-- END PAGE CONTENT WRAPPER -->

    </div>



    <!-- END PAGE CONTENT -->


    </div>

  </div>

{include file='gmr/issue_modal.tpl'}

    <!-- END PAGE CONTAINER -->

    {else}



    <div class="row">



        <div class="col-md-12">



            <div class="panel panel-default">





                <div class="alert alert-danger" role="alert">



                    <button type="button" class="close" data-dismiss="alert">



                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>



                    </button>



                    You are not authorized to view this section



                </div>





            </div>







        </div>





    </div>




{/if}
