{if $privileges.requisitions.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Stock Value</a></li>
     <li class="active"><a href="">List</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Stock Value Report</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">

             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}



        <div class="col-md-12" style="margin-bottom:10px;">

          <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a>
          {if !$smarty.get.req}<a href="/requisition/stock_value?req=1" class="btn btn-default">Show Details</a>{/if}
          {if $smarty.get.req}<a href="/requisition/stock_value" class="btn btn-default">Hide Details</a>{/if}
           {include file="{$section}/sv_search.tpl"}
           <br>
           <br>

           <form class="form-inline" role="form" method="post" action="/requisition/stock_value{if $search_str}?search=1&{$search_str}{/if}" style="padding-left:5px;">
              <input type="hidden" name="export_csv" value="1" >
              <input type="hidden" name="debug" value="{$smarty.get.debug}" >
              <button name="submit" type="submit" class="btn btn-info pull-right">CSV Export</button>
          </form>
          <div class="clearfix"></div>
          <br>

        <div class="panel panel-default">

            <div class="panel-heading">


                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                           {*  <a href="/requisition/stock_value{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisition/stock_value{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a> *}

                             <label>Displaying {$resultsCount}</label>
                         </div>
                         {* <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button> *}


                     </form>
                     </li>
                     {* <li>

                      <form class="form-inline" role="form" method="post" action="/requisition/stock_value" style="padding-left:5px;">

                         <input type="hidden" name="export_csv" value="1" >
                         <button name="submit" type="submit" class="btn btn-success">CSV Export</button>

                     </form>
                     </li> *}

                 </ul>
            </div>




            <div class="panel-body panel-body-table">

                <form method="post" action="">
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">
                    <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="5%" class="text-center">#</th>
                								 <th width="10%" class="text-center">Job ID</th>
                								 <th width="20%" class="text-center">Product</th>
                                 <th width="20%" class="text-center">Title</th>
                                 <th width="15%" class="text-center">Customer</th>
                                 <th width="15%" class="text-center">Status</th>
                                 <th width="15%" class="text-center">Total (TZS)</th>

                            </tr>
                        </thead>
                        <tbody>
                           {section name=jobs_list loop=$jobs_list}
                           <tr>

                              <td colspan="7">

                               <table width="100%">

                                 <tr>
                                   <td width="5%" class="text-center">{$start+$smarty.section.jobs_list.rownum}</td>
                                   <td width="10%" class="text-center"><a target="_blank" href="/jobs/progress?id={$jobs_list[jobs_list].issued_stock[0].job_id}">{$jobs_list[jobs_list].issued_stock[0].job_date|substr:0:4}-{$jobs_list[jobs_list].issued_stock[0].job_date|substr:5:2}-{$jobs_list[jobs_list].issued_stock[0].job_id|leading_zero:5}</a></td>
                                   <td width="20%" class="text-center">{$jobs_list[jobs_list].issued_stock[0].product_name}</td>
                                   <td width="20%" class="text-center">{$jobs_list[jobs_list].issued_stock[0].job_reference}</td>
                                   <td width="15%" class="text-center">{$jobs_list[jobs_list].issued_stock[0].group_company}</td>
                                   <td width="15%" class="text-center">{$jobs_list[jobs_list].issued_stock[0].job_status}</td>
                                   <td width="15%" class="text-right">{$jobs_list[jobs_list].total|number_format:0:".":","}</td>
                                 </tr>
                                 <tr>
                                    <td colspan="7">&nbsp;</td>
                                 </tr>
                                 {if $smarty.get.req}
                                 <tr>
                                   <td colspan="7">
                                      <table width="100%">
                                        <tr>
                                          <th width="10%">GIN ID</td>
                                          <th>Stock Name</td>
                                          <th>Quantity</td>
                                          <th>Value (TZS)</td>
                                          <th>Sub Total (TZS)</td>
                                        </tr>
                                        {section name=req loop=$jobs_list[jobs_list].issued_stock}
                                        <tr>
                                          <td>{$jobs_list[jobs_list].issued_stock[req].ris_id}</td>
                                          <td>{$jobs_list[jobs_list].issued_stock[req].stock_name}</td>
                                          <td>{$jobs_list[jobs_list].issued_stock[req].issued_qty|number_format:2:".":""}</td>
                                          <td>{$jobs_list[jobs_list].issued_stock[req].unit_price|number_format:2:".":","}</td>
                                          <td>{$jobs_list[jobs_list].issued_stock[req].sub_total|number_format:2:".":","}</td>
                                        </tr>
                                        {/section}
                                        {* <tr>
                                           <td class='text-right' colspan="4"><strong>Total &nbsp;&nbsp;&nbsp;&nbsp;</strong></td>
                                           <td><strong>{$jobs_list[jobs_list].total|number_format:2:".":","} TZS</strong></td>
                                        </tr> *}
                                      </table>
                                   </td>
                                 </tr>
                                 {/if}
                               </table>

                              </td>

                           </tr>

              						  {sectionelse}
              						  <tr>
              						    <td colspan="7">No records found.</td>
              						  </tr>
              						{/section}
                          <tr>
                            <td colspan="6" class="text-right"><strong>Grand Total</strong></td><td class="text-right"><strong>{$grand_total|number_format:0:".":","} TZS</strong></td>
                          </tr>
                        </tbody>
                    </table>


                </div>
                </form>


            </div>
            <div class="panel-heading">


                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             {* <a href="/requisition/stock_value{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisition/stock_value{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a> *}

                             <label>Displaying {$resultsCount}</label>
                         </div>
                         {* <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>  *}


                     </form>
                     </li>


                 </ul>
            </div>



        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
