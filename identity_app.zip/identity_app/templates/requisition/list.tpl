{if $privileges.requisitions.list}

  <!-- START BREADCRUMB -->
   <ul class="breadcrumb">
       <li><a href="/">Home</a></li>
       <li><a href="/requisition/list">Requisitions</a></li>
       <li class="active"><a href="">{$action|capitalize}</a></li>
   </ul>
   <!-- END BREADCRUMB -->
   <div class="page-title">
      <h2><span class="fa fa-arrow-circle-o-left"></span>Requisitions</h2>
  </div>
   <!-- PAGE CONTENT WRAPPER -->
   <div class="page-content-wrap">

    <div class="row">
      <div class="col-md-12">
               {if $message || $msg}
               <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                   {$message}
                   {$msg}
               </div>
               {/if}


          <div class="col-md-12" style="margin-bottom:10px;">

           {if $privileges.requisitions.add}
             <a href="/requisition/add" class="btn btn-default">New Request</a>
             <br><br>
           {/if}
           {if !$smarty.get.print}
            Filter By Status: <a href="/requisition/list" class="btn {if !$smarty.get.filter}btn-success{/if} btn-flat btn-rad">All</a>
            <a href="/requisition/list?page=1&filter=1&status=Draft{if $search_str && !$smarty.get.status}{$search_str}{/if}" class="btn {if $smarty.get.status eq 'Draft' && !$smarty.get.type}btn-success{else}btn-default{/if}">Draft <span class="badge">{$status_nos.Draft}</span></a>
            <a href="/requisition/list?page=1&filter=1&status=Approved{if $search_str && !$smarty.get.status}{$search_str}{/if}" class="btn {if $smarty.get.status eq 'Approved' && !$smarty.get.type}btn-success{else}btn-default{/if}">Approved <span class="badge">{$status_nos.Approved}</span></a>
            <a href="/requisition/list?page=1&filter=1&status=Complete{if $search_str && !$smarty.get.status}{$search_str}{/if}" class="btn {if $smarty.get.status eq 'Complete' && !$smarty.get.type}btn-success{else}btn-default{/if}">
              Complete <span class="badge">{$status_nos.Complete}</span></a>
              <a href="/requisition/list?page=1&filter=1&status=Cancelled" class="btn {if $smarty.get.status eq 'Cancelled' && !$smarty.get.type}btn-success{else}btn-default{/if}">Cancelled</a>

            &nbsp;&nbsp;&nbsp;
            Filter By Location: <a href="/requisition/list?page=1&filter=1&location=IPL1" class="btn {if $smarty.get.location eq 'IPL1'}btn-success{else}btn-default{/if}">IPL1</a>
            <a href="/requisition/list?page=1&filter=1&location=IPL2" class="btn {if $smarty.get.location eq 'IPL2'}btn-success{else}btn-default{/if}">IPL2</a>

            <br><br>
            <h2>Stock Refill</h2>
            Filter By Type: <a href="/requisition/list?page=1&filter=type&type=Stock Refill{if $search_str && $smarty.get.filter != 'type'}{$search_str}{/if}" class="btn {if $smarty.get.type eq 'Stock Refill'}btn-success{else}btn-default{/if}">Stock Refill</a>
            {* <a href="/requisition/list?page=1&filter=type&non_refills=1{if $search_str && $smarty.get.filter != 'type'}{$search_str}{/if}" class="btn {if $smarty.get.non_refills}btn-success{else}btn-default{/if}">Non Stock Refill</a>
            <a href="/requisition/list?page=1&filter=type&incomplete_refills=1{if $search_str && $smarty.get.filter != 'type'}{$search_str}{/if}" class="btn {if $smarty.get.incomplete_refills}btn-success{else}btn-default{/if}">InComplete Stock Refill</a>
            <a href="/requisition/list?page=1&filter=type&complete_refills=1{if $search_str && $smarty.get.filter != 'type'}{$search_str}{/if}" class="btn {if $smarty.get.complete_refills}btn-success{else}btn-default{/if}">Completed Stock Refill</a> *}
            <a href="/requisition/list?page=1&filter=type&sample=1{if $search_str && $smarty.get.filter != 'type'}{$search_str}{/if}" class="btn {if $smarty.get.sample}btn-success{else}btn-default{/if}">Sample</a>
            <div style="margin-top:5px;"></div>
            Filter By Status: <a href="/requisition/list?page=1&filter=type&type=Stock Refill" class="btn {if !$smarty.get.filter}btn-success{/if} btn-flat btn-rad">All</a>
            <a href="/requisition/list?page=1&filter=1&status=Draft&type=Stock Refill{if $search_str && !$smarty.get.status}{$search_str}{/if}" class="btn {if $smarty.get.status eq 'Draft' && $smarty.get.type=='Stock Refill'}btn-success{else}btn-default{/if}">Draft <span class="badge">{$status_nos_rf.Draft}</span></a>
            <a href="/requisition/list?page=1&filter=1&status=Approved&type=Stock Refill{if $search_str && !$smarty.get.status}{$search_str}{/if}" class="btn {if $smarty.get.status eq 'Approved' && $smarty.get.type=='Stock Refill'}btn-success{else}btn-default{/if}">Approved <span class="badge">{$status_nos_rf.Approved}</span></a>
            <a href="/requisition/list?page=1&filter=1&status=Complete&type=Stock Refill{if $search_str && !$smarty.get.status}{$search_str}{/if}" class="btn {if $smarty.get.status eq 'Complete' && $smarty.get.type=='Stock Refill'}btn-success{else}btn-default{/if}">
              Complete <span class="badge">{$status_nos_rf.Complete}</span></a>
              <a href="/requisition/list?page=1&filter=1&status=Cancelled&type=Stock Refill" class="btn {if $smarty.get.status eq 'Cancelled' && $smarty.get.type=='Stock Refill'}btn-success{else}btn-default{/if}">Cancelled</a>
            {/if}
           <div id="refilResponse" style="margin-top:5px;"></div>
        </div>

          <div class="panel panel-default">

              <div class="panel-heading">

                {if $smarty.get.type eq 'Stock Refill' &&  $smarty.get.status != 'Draft'}
                <label for="create_lpos" name="create_lpos" class="btn btn-info" onclick="return confirm('Are you sure you want to create LPOs on selected items?')">
                  Create LPOs on Selected
                </label>
                {/if}

                {if $smarty.get.status eq 'Draft'}
                  <label for="cancel_selected" name="cancel_selected" class="btn btn-danger cancel_selected">
                    Cancel Selected
                  </label>
                  <label for="approve_selected" name="approve_selected" class="btn btn-warning" onclick="return confirm('Are you sure you want to approve selected items?')">
                    Approve Selected
                  </label>
                 {/if}

                 {if $smarty.get.status eq 'Draft' && $smarty.get.type == 'Stock Refill' && $privileges.requisitions.edit}
                 <input type="submit" name="edit_refils" form="requisition_form" value="Edit" class="btn btn-info" >
                 {/if}

                    <ul class="panel-controls panel-controls-title">
                       <li>

                       <form class="form-inline" role="form" method="post">
                           <div class="form-group">
                             </div>
                           <div class="form-group">
                               <a href="/requisition/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisition/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>
                               <label>| Displaying {$resultsCount}</label>
                           </div>
                           <div class="form-group">

                                   <select name="page" id="page" class="form-control">
                    {section name=pagination loop=$numPages}

                      <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                    {sectionelse}
                      <option value="1" selected>Page 1</option>
                    {/section}

                     </select>
                           </div>
                           <button name="submit" type="submit" class="btn btn-danger">Go</button>

                           {if $smarty.get.print}
                           <div class="form-group">
                             <a href="/requisition/list/?page=1&popup=1&print=1{if $search_str}{$search_str}{/if}" onClick="this.style.display = 'none'; window.print(); this.style.display = ''; return false;">
                        <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
                       </a>
                           </div>
                      {else}

                           <a href="/requisition/list?popup=1&print=1&page=1{if $search_str}{$search_str}{/if}" onClick="popupURL(this.href, 'RequisitionList', 800, 500); return false;">
                            <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
                           </a>
                       {/if}
                       </form>
                       </li>

                   </ul>
              </div>
              <div class="panel-body panel-body-table">

                <form id="requisition_form" method="post" action="">
                    {if $privileges.requisitions.approve}
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                    {/if}
                    <input type="submit" name="cancel_selected" id="cancel_selected" class="hidden" />
                    <input type="submit" name="create_lpos" id="create_lpos" class="hidden" />
                     {* <input type="submit" name="edit_refils" id="edit_refils" class="hidden" /> *}



                  <div class="table-responsive">

                      <table class="table pad-10 table-bordered table-striped table-actions">
                          <thead>
                              <tr>
                                {if $smarty.get.status eq 'Draft' || $smarty.get.type eq 'Stock Refill'}
                                  <th width="40" class="text-center">
                                    <input type="checkbox" id="check_all_confirmed"/>
                                  </th>
                                {/if}

                    <th width="40">ID</th>
  							    <th class="text-center">Date</th>
                    <th>Job Reference</th>
                    <th class="text-center">Department</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">User</th>
                    {if !$smarty.get.print}
   							     <th class="text-center" width="15%">Action</th>
                     {/if}
                              </tr>
                          </thead>
                          <tbody>
                             {section name=req_list loop=$requisition_list}
  						  <tr>

                    {if $requisition_list[req_list].requisition_status eq 'Draft' && $smarty.get.status eq 'Draft'}
                     <td class="text-center">
                      <input type="checkbox" name="confirmed_check[]" class="confirmed_check" value="{$requisition_list[req_list].requisition_id}" />
                    </td>
                    {/if}

                    {if $smarty.get.type eq 'Stock Refill' &&  $smarty.get.status != 'Draft'}
                      <td class="text-center">
                        <input type="checkbox" name="lpo_check[]" class="confirmed_check" value="{$requisition_list[req_list].requisition_id}" />
                      </td>
                    {/if}
  						    <td class="text-center">{$requisition_list[req_list].requisition_id|leading_zero:5}</td>
  						    <td class="text-center">
                  {$requisition_list[req_list].date_created|date_format:"%d/%m/%Y"}
                  <br>{$requisition_list[req_list].date_created|date_format:"%H:%M:%S"}
                </td>

                <td>
                  {if $requisition_list[req_list].job_id}<a style="text-decoration:none;" href="/jobs/progress?id={$requisition_list[req_list].job_id}" target="_blank">
                  {$requisition_list[req_list].job_id}: </a>{$requisition_list[req_list].job_reference} - {$requisition_list[req_list].group_company}{else}-{/if}
                  {if $requisition_list[req_list].requisition_remarks} <p style="width:30em; text-overflow: ellipsis; overflow:hidden; white-space: nowrap;"><a style="text-decoration:none;" href="#" title="{$requisition_list[req_list].requisition_remarks}">{$requisition_list[req_list].requisition_remarks}</a></p> {/if}
                </td>
  						    <td class="text-center">
                    {if $requisition_list[req_list].department_name}{$requisition_list[req_list].department_name}{else}-{/if}
                    <br>{$requisition_list[req_list].requisition_location}
                  </td>
                  <td class="text-center">
                  <span class="{if $requisition_list[req_list].requisition_status eq 'Draft'}text-danger{elseif $requisition_list[req_list].requisition_status eq 'Approved'}text-info{elseif $requisition_list[req_list].requisition_status eq 'Complete'}text-success{else}text-default{/if}">{$requisition_list[req_list].requisition_status}</span>
                  {if $requisition_list[req_list].requisition_status eq 'Approved' && $requisition_list[req_list].approval_user_id gt 0}
                  <br><i>by {$requisition_list[req_list].approval_user}</i>
                  <br><i>on {$requisition_list[req_list].approval_date|date_format:"%d %b %Y"}
                  <br>  ({$requisition_list[req_list].approval_date|date_format:"%H:%M:%S"})
                  </i>
                  {/if}
                  {if $requisition_list[req_list].cancel_remarks}
                  <br>
                  <i>{$requisition_list[req_list].cancel_remarks}</i>
                  {/if}

                  </td>
                  <td class="text-center">{$requisition_list[req_list].user}</td>
                  {if !$smarty.get.print}
  						    <td class="text-center">
                    {if $requisition_list[req_list].requisition_status eq 'Draft' && $privileges.requisitions.approve}
 						        <a href="/requisition/list?{if $smarty.get.type == 'Stock Refill'}filter=type&type=Stock Refill&{/if}actn=approve&id={$requisition_list[req_list].requisition_id}" class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Requisition] Are you sure?', this.href); return false;" ><span class="fa fa-check"></span></a>
 						        {/if}
                    {if $requisition_list[req_list].requisition_status eq 'Approved'}
                     <a href="" class="btn btn-info btn-rounded btn-condensed btn-sm issueBtn"
                     data-requisition_id="{$requisition_list[req_list].requisition_id}" title="Issue Items"><i class="fa fa-arrow-circle-right"></i></a>
 						        {/if}
                    {if $requisition_list[req_list].ris_id}
                     <a href="" class="btn btn-warning btn-rounded btn-condensed btn-sm returnBtn"
                     data-requisition_id="{$requisition_list[req_list].requisition_id}"
                     data-ris_id="{$requisition_list[req_list].ris_id}"
                     title="Return Items"><i class="fa fa-arrow-circle-left"></i></a>
 						        {/if}
                    {if $requisition_list[req_list].requisition_status eq 'Draft' || $requisition_list[req_list].requisition_status eq 'Approved'}
                     {if !$requisition_list[req_list].ris_id}
                     <a href="/requisition/edit?id={$requisition_list[req_list].requisition_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
                     <a class="btn btn-default btn-rounded btn-condensed btn-sm cancelReq"
                     data-requisition_id="{$requisition_list[req_list].requisition_id}"
                     title="Cancel Requisition" href="/requisition/list?actn=cancel&id={$requisition_list[req_list].requisition_id}"
                     onclick="return false;"><span class="fa fa-times"></span></a>
                     {/if}
                    {/if}
                    {* <a href="/requisitions/delete?id={$requisition_list[req_list].requisition_id}" class="btn btn-danger btn-rounded btn-condensed btn-sm" title="Delete" onclick="confirmAction('[Delete Requisition Item] Deleting will permanently remove the Requisition from the system. Are you sure?', this.href); return false;"><span class="fa fa-times"></span></a> *}
                  </td>
                  {/if}

  						  </tr>
                {assign var=items value=$requisition_list[req_list].items}
                <tr>
                  <td colspan="{if $smarty.get.status eq 'Draft' || $smarty.get.type eq 'Stock Refill'}8{else}7{/if}" style="padding:0 !important;">
                     <table width="100%" class="table pad-5 table-striped">
                       <tr>
        								 <th>Item</th>
        								 <th>Required Qty</th>
        								 <th>Issued Qty</th>
        								 <th>Balance Qty</th>
        								 <th>Qty in Stock</th>
                         <th>Qty Ordered</th>
                         <th width="13%"></th>
                       </tr>
                       {section name=items loop=$items}
                       <tr>
                        <td {if $items[items].type eq 'Stock Refill'}class="text-info"{/if}>{$items[items].stock_name}{if $items[items].type eq 'Stock Refill'} - Stock Refill {/if}
                         {if $items[items].item_description && $items[items].stock_id > 0} <p style="width:18em; text-overflow: ellipsis; overflow:hidden; white-space: nowrap;"><a style="text-decoration:none;" href="#" title="{$items[items].item_description}">{$items[items].item_description}</a></p> {/if}
                          {if $items[items].sample}
                          <i><b>Sample</b>: <a title="Sample Image" href="/{$items[items].sample_image}" target = "_blank">{$items[items].sample_image|regex_replace:"/^.*\//":""}</a></i>
                         {/if}
                        </td>
                        <td>
                          {if $smarty.get.type == 'Stock Refill' && $smarty.get.status == 'Draft'}
                          <input type="text" name="ri_qty[{$items[items].ri_id}]" value="{$items[items].quantity}" class="form-control" style="width:100px; display:inline;" > {$items[items].units}
                          {else}
                         {$items[items].quantity} {$items[items].units}
                         {/if}
                        </td>
                         <td>{if $items[items].issued_qty > 0}{$items[items].issued_qty} {$items[items].units}{else}-{/if}</td>
                         <td>{$items[items].balance_qty} {$items[items].units}</td>
                         <td>{$items[items].stock_qty} {$items[items].units}</td>
                         <td>
                           {if $items[items].qty_ordered > 0}
                          {$items[items].qty_ordered} {$items[items].units}
                          {if $items[items].lpo}<br><a title="View lpo" href="#" onclick="popupPDF('lpo', {$items[items].lpo});" >LPO #{$items[items].lpo}</a>{/if}
                          {else}
                           -
                          {/if}
                         </td>
                         <td>
                         {if $requisition_list[req_list].requisition_status eq 'Approved'}
                          <a href="" class="btn btn-info btn-rounded btn-condensed btn-sm issueBtn"
                          data-requisition_id="{$items[items].requisition_id}"
                          data-ri_id="{$items[items].ri_id}" title="Issue Item">
                          <i class="fa fa-arrow-circle-right"></i>
                          </a>
      						        {/if}
                         {* if $requisition_list[req_list].ris_id}
                          <a href="" class="btn btn-warning btn-rounded btn-condensed btn-sm returnBtn"
                          data-requisition_id="{$items[items].requisition_id}"
                          data-ris_id="{$items[items].ris_id}"
                          data-ri_id="{$items[items].ri_id}"
                          title="Return Item"><i class="fa fa-arrow-circle-left"></i></a>
      						        {/if *}
                          {if !$items[items].issued_qty && $requisition_list[req_list].requisition_status != 'Cancelled'}
                          <a class="btn btn-danger btn-rounded btn-condensed btn-sm"
                          title="Cancel Item" href="/requisition/list?actn=cancel-item&id={$items[items].ri_id}"
                          onclick="return confirm('Are you sure you want to cancel request item?')"><span class="fa fa-times"></span></a>
                          {/if}
                          {if  $items[items].issued_qty && $items[items].balance_qty > 0 && $requisition_list[req_list].requisition_status != 'Cancelled'}
                          <a class="btn btn-warning btn-rounded btn-condensed btn-sm"
                          title="Make full issued" href="/requisition/list?actn=adjust-item&id={$items[items].ri_id}"
                          onclick="return confirm('Are you sure you want to make item full issued?')"><span class="fa fa-check"></span></a>
                          {/if}
                         {if $items[items].stock_id > 0}<a href="/stock/log?filter=1&stock_id={$items[items].stock_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" target="_blank" title="View History"><span class="fa fa-history"></span></a>{/if}
                         </td>
                       </tr>

                        {sectionelse}
                        <tr>
                          <td colspan="5">No items found</td>
                        </tr>
                       {/section}


                     </table>
                  </td>
                </tr>
                <tr>
                  <td colspan="{if $smarty.get.status eq 'Draft' || $smarty.get.type eq 'Stock Refill'}8{else}7{/if}" style="padding:1px 0 !important; background:#ccc;"></td>
                </tr>
  						  {sectionelse}
  						  <tr>
  						    <td colspan="6"><div align="center">No records found.</td>
  						  </tr>
  						 {/section}
                          </tbody>
                        </table>

                    </div>
                    </form>


                </div>

                <div class="panel-heading">

                      <ul class="panel-controls panel-controls-title">
                         <li>

                         <form class="form-inline" role="form" method="post">



                             {if !$smarty.get.print}
                             <div class="form-group">
                               </div>
                             <div class="form-group">
                                 <a href="/requisition/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisition/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                                 <label>| Displaying {$resultsCount}</label>
                             </div>
                             <div class="form-group">

                                     <select name="page" id="page" class="form-control">
                      {section name=pagination loop=$numPages}

                        <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                      {sectionelse}

                        <option value="1" selected>Page 1</option>


                      {/section}

                       </select>

                             </div>
                             <button name="submit" type="submit" class="btn btn-danger">Go</button>
                        {/if}


                         </form>
                         </li>

                     </ul>
                </div>

         {if $smarty.get.dbg}
         {$privileges.requisitions|@print_r}
         {/if}

            </div>



            {include file="$section/item_form.tpl"}
            {include file="$section/return_form.tpl"}

        </div>
     </div>
    </div>
     <!-- END PAGE CONTENT WRAPPER -->
     </div>
      <!-- END PAGE CONTENT -->
    </div>
    <!-- END PAGE CONTAINER -->

      {include file="$section/cancel_form.tpl"}

    {else}
    <div class="row">
        <div class="col-md-12">


           <div class="alert alert-danger" role="alert">
    	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    	      You are not authorized to view this section
    	  </div>




    </div>

    </div>
    {/if}
