<div class="panel panel-default">

       <div class="panel-heading">
          <h3 class="panel-title">Requisition Info</h3>
	 </div>
	 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">
			  <tr>
			    <td colspan="2"><div><strong>Location</strong></div>
              {$smarty.session.requisition.requisition_location}
			    </td>
			  </tr>
        <tr>
           <td colspan="2"><div><strong>Job</strong></div>
             <div>{$smarty.session.requisition.job_reference}</div>
        </tr>
        {if $smarty.session.requisition.requisition_remarks}
        <tr>
           <td colspan="2"><div><strong>Remarks</strong></div>
             {$smarty.session.requisition.requisition_remarks}
        </tr>
        {/if}

             </table>

           </div>
       </div>


</div>
