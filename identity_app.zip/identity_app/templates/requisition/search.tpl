


<div id="search" class="panel panel-default" style="{if !$smarty.post.category_id}display: none;{/if} margin-top:15px;">

  <div class="panel-body">
     <form id="form2" name="form2" class="form-inline"  method="post" action="/casual_contractors/list?filter=1{if $search_str}{$search_str}{/if}">

       <div class="form-group" style="margin:0 15px 10px 0;">
       <label >From:</label><br>
       <select name="movement_from" id="movement_from"  class="form-control">
         <option value="">Please Select..</option>
         <option value="IPL1" {if $smarty.post.movement_from == 'IPL1'}selected{/if}>IPL1</option>
         <option value="IPL2" {if $smarty.post.movement_from == 'IPL2'}selected{/if}>IPL2</option>
         <option value="Magenta" {if $smarty.post.movement_from == 'Magenta'}selected{/if}>Magenta</option>
         <option value="Supplier" {if $smarty.post.movement_from == 'Supplier'}selected{/if}>Supplier</option>
       </select>
       </div>

       <div class="form-group" style="margin:0 15px 10px 0;">
       <label >To:</label><br>
       <select name="movement_to" id="movement_to"  class="form-control">
         <option value="">Please Select..</option>
         <option value="IPL1" {if $smarty.post.movement_to == 'IPL1'}selected{/if}>IPL1</option>
         <option value="IPL2" {if $smarty.post.movement_to == 'IPL2'}selected{/if}>IPL2</option>
         <option value="Magenta" {if $smarty.post.movement_from == 'Magenta'}selected{/if}>Magenta</option>
         <option value="Supplier" {if $smarty.post.movement_from == 'Supplier'}selected{/if}>Supplier</option>
       </select>
       </div>
       <div class="form-group" style="margin:0 15px 10px 0;">
       <label >Supplier:</label><br>
       <select name="supplier_id" id="supplier_id"  class="form-control select2" style="width:150px;">
       <option value="">Please Select</option>
       {section name=supplier_list loop=$supplier_list}
        <option value="{$supplier_list[supplier_list].supplier_id}" {if $form_data.supplier_id == $supplier_list[supplier_list].supplier_id || $smarty.post.supplier_id == $supplier_list[supplier_list].supplier_id}selected{/if}
        >{if $supplier_list[supplier_list].supplier_company}{$supplier_list[supplier_list].supplier_company} -{/if} {$supplier_list[supplier_list].supplier_fname} {$supplier_list[supplier_list].supplier_lname}</option>
       {/section}
       </select>
       </div>
       <div class="form-group" style="margin:0 15px 10px 0;">
       <label >Stock:</label><br>
        <select name="stock_id" id="stock_id"  class="form-control" style="width:100%;" ></select>
       </div>

       <div class="form-group" style="margin:0 15px 10px 0;">
       <label >Job:</label><br>
        <select name="job_id" id="job_id"  class="form-control" style="width:100%;" ></select>
       </div>
      <div class="form-group"  style="margin:0 15px 10px 0;">
      <label for="to_date">Date From:</label>
       <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_from"  value="{if $smarty.post.date_from}{$smarty.post.date_from|date_format:'%Y-%m-%d'}{else}{/if}" >
     </div>

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Date To:</label>
        <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_to"  value="{if $smarty.post.date_to}{$smarty.post.date_to|date_format:'%Y-%m-%d'}{else}{/if}" >
      </div>
       <div class="form-group" style="margin-top:10px;">
         <button type="submit" class="btn btn-primary">Go</button>
       </div>

  </form>

  </div>

  </div>
