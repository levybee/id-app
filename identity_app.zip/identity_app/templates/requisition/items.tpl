
<div id="summary" class="panel panel-default">

       <div class="panel-heading">
		        <h3 class="panel-title">Requisition Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">#</th>
                                <th width="15%">Type</th>
                                <th>Item</th>
                                <th width="10%">Quantity</th>
							                  <th width="120">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=ri loop=$smarty.session.requisition.items}
            						  <tr>
            						    <td class="text-center">{$smarty.section.ri.rownum}</td>
                            <td>{$smarty.session.requisition.items[ri].type}</td>
                            <td>
                              {if $smarty.session.requisition.items[ri].stock_id > 0}
                              {$smarty.session.requisition.items[ri].stock_id}:
                              {$smarty.session.requisition.items[ri].stock_name}
                              {/if}
                              {if $smarty.session.requisition.items[ri].item_description}
                               {$smarty.session.requisition.items[ri].item_description}
                              {/if}
                              {if $smarty.session.requisition.items[ri].sample_image}
                                <br/><b>Sample</b><i>: <a title="Sample Image" href="/{$smarty.session.requisition.items[ri].sample_image}" target = "_blank">{$smarty.session.requisition.items[ri].sample_image|regex_replace:"/^.*\//":""}</a></i>
                              {/if}
                            </td>
                            <td>{$smarty.session.requisition.items[ri].quantity}</td>
						              <td>

                  <a
                  href=""
                  title="Edit Item"
                  class="btn btn-default btn-rounded btn-condensed btn-sm edit_item"
                  data-ri_id="{$smarty.session.requisition.items[ri].ri_id}"
                  data-item_id="{$smarty.section.ri.rownum}"
                  data-type="{$smarty.session.requisition.items[ri].type}"
                  data-stock_id="{$smarty.session.requisition.items[ri].stock_id}"
                  data-stock_name="{$smarty.session.requisition.items[ri].stock_name}"
                  data-quantity="{$smarty.session.requisition.items[ri].quantity}"
                  data-item_description="{$smarty.session.requisition.items[ri].item_description}"
                  data-sample_image="{$smarty.session.requisition.items[ri].sample_image|regex_replace:'/^.*\//':''}"
                  ><span class="fa fa-pencil"></span>
                 </a>
                 <a title="Remove Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/requisition/{if $action eq 'add'}add?{else}edit?id={$smarty.get.id}&{/if}subtask=delete&subid={$smarty.section.ri.rownum}" onclick="confirmAction('[Delete Item]. Are you sure?', this.href); return false;"><span class="fa fa-times"></span></a>

                </td>
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="7">No items have been added for this Requisition.</td>
						  </tr>
						  {/section}
                   </tbody>
                    </table>

            </div>

  </div>

</div>
