{include file="requisition/items.tpl"}

{if !$form_hide}
<form id="ri-form" class="form-horizontal " method="post" action="/requisition/{$action}{if $action eq 'edit'}?id={$smarty.get.id}{/if}" enctype="multipart/form-data">
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Add Item</h3>
      </div>

      <div class="panel-body">
          <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                    <label class="col-md-3 control-label">Type</label>
                    <div class="col-md-9 col-xs-12">
                      <div class="col-md-4">
                        <label class="check"><input type="radio" name="type" id="normal" value="Normal" {if $formdata.type eq 'Normal'}checked="checked"{/if} /> Normal</label>
                     </div>
                      <div class="col-md-4">
                        <label class="check"><input type="radio" name="type" id="stock_refill" value="Stock Refill" {if $formdata.type eq 'Stock Refill'}checked="checked"{/if} /> Stock Refill</label>
                     </div>

                     <div class="col-md-4" style="padding:0;">
                        <label class="check"><input type="radio"  name="type" id="stock_return" value="Stock Return" {if $formdata.type eq 'Stock Return'}checked="checked"{/if} /> Stock Return</label>
                     </div>
                    </div>
                </div>
                <div class="form-group">
                   <label class="col-md-3 control-label">Item</label>
                   <div class="col-md-9">
                     <select name="stock_id" id="stock_id"  class="form-control" style="width:100%;"></select>
                     <input type="hidden" name="stock_name" id="stock_name" value="">
                   </div>
                </div>

                <div class="form-group">
                   <label class="col-md-3 control-label">Quantity</label>
                   <div class="col-md-9 col-xs-12">
                     <input name="quantity" type="text" id="quantity" value="{$formdata.quantity}" class="form-control" />
                   </div>
               </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                   <label class="col-md-3 control-label"></label>
                   <div class="col-md-9 col-xs-12">
                   </div>
               </div>
                {if $smarty.session.role_name eq 'Super Sales' || $smarty.session.role_name eq 'Sales - Remote Office' || $smarty.session.role_name eq 'Sales' || $smarty.session.role_name eq 'Administrator'}
                 <div class="form-group">
                <label class="col-md-4 col-xs-12 control-label">Sample?</label>
                    <div class="col-md-8 col-xs-12">
                            <label class="control-label"><input type="checkbox"  id="sample" name="sample" value="1" {if $formdata.sample eq '1'}checked{/if}></label>
                            <span class="sample_display"></span>
                    </div>
                </div>
                <div class="form-group sample_image" style="display:none;">
                  <label class="col-md-4 control-label">Sample Image </label>
                  <div class="col-md-8">
                     <input name="sample_image" type="file"  class="form-control" />
                  </div>
              </div>
               {/if}
                <div class="form-group">
                <label class="col-md-4 col-xs-12 control-label">Description</label>
                <div class="col-md-8 col-xs-12">
                  <textarea id="item_description" name="item_description" class="form-control" rows="3"></textarea>
                </div>
               </div>
              </div>

          </div>
     </div>
      <div class="panel-footer">
         <input type="hidden" name="item_debug"  value="{$smarty.get.item_debug}" />
         <input type="hidden" name="item_id"  value="" />
         <input type="hidden" name="ri_id"  value="" />
         <input type="hidden" name="next_step" id="next_step" value="three" />
         <input type="button" class="btn btn-default pull-right cancel" value="Cancel" style="display:none; margin-left:10px;" />
         <input type="submit" name="add_item" class="btn btn-primary pull-right" value="Add Item" />
      </div>
  </div>
  </form>
{/if}
