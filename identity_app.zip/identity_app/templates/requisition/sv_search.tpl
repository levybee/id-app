<div id="search" class="panel panel-default" style="display: none; margin-top:15px;">

<div class="panel-body">
   <form id="form2" name="form2" class="form-inline"  method="post" action="/requisitions/stock_value?filter=1{if $search_str}{$search_str}{/if}">


    <div class="form-group"  style="margin-right:15px;">
     <label for="job_id">Job ID</label>
      <input name="job_id" type="text" value="{if $smarty.post.job_id}{$smarty.post.job_id}{/if}" class="form-control" style="display:block;" />
    </div>

    <div class="form-group" style="margin-right:15px;">
     <label for="from_date" >Date From:</label>
      <input  type="text" style="display:block;"  name="date_start"  class="form-control datepicker" value="{if $smarty.post.date_start}{$smarty.post.date_start|date_format:'%Y-%m-%d'}{else}{/if}" >
    </div>



     <div class="form-group"  style="margin-right:15px;">
     <label for="to_date">Date To:</label>
      <input type="text" class="form-control datepicker" style="display:block;"  name="date_end"  value="{if $smarty.post.date_end}{$smarty.post.date_end|date_format:'%Y-%m-%d'}{else}{/if}" >

    </div>




     <div class="form-group" style="margin-top:20px;">
       <button type="submit" name="search2" class="btn btn-primary">Go</button>
     </div>


</form>


</div>



</div>
