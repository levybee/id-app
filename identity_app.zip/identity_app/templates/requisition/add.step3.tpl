<div class="panel panel-default">
	       <div class="panel-body">
	       {if !$error_message}
	         <h3>Save!</h3>
			   <p>You have successfully saved Rwquisition. <br /> </p>


	       {else}
	         <div class="alert alert-danger" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$error_message}
             </div>

	        {/if}

	       </div>

	     </div>
