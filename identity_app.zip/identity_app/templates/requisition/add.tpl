{if $privileges.requisitions.add}
	<ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/requisition/list">Requisitions</a></li>
     <li class="active"><a href="">{$action|capitalize} Requisitions</a></li>
	 </ul>
	 <!-- END BREADCRUMB -->
	 <div class="page-title">
	    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Requisition - Step {$step|capitalize}</h2>
	</div>


    <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
        {/if}

			<div class="col-md-12">
	     <div class="panel panel-default">
	       <div class="panel-body panel-body-table">

	          <table border="0" width="100%" cellpadding="5" cellspacing="0" id="progress_bar">
	          <thead>
	          <tr>
	            <th width="33%"  class="step {if $step eq 'one'}current{/if}" >Step 1</th>
	            <th width="33%"  class="step {if $step eq 'two'}current{/if}" >Step 2</th>
	            <th width="33%" class="step {if $step eq 'three'}current{/if}" >Step 3</th>
	          </tr>
	          </thead>
	          <tbody>
	            <tr>
		            <td class="progress_information">Prepare Requisition</td>
		            <td class="progress_information">Add Items</td>
		            <td class="progress_information">Save!</td>
	            </tr>

	           </tbody>
	         </table>
	       </div>

	     </div>

	   </div>
	   <div class="col-md-2">

	   {if $step eq 'two'}
		 {include file='requisition/info.tpl'}
		<div align="center" style="padding-bottom:15px;">
		 <form method="post" action="/requisition/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
		   <input type="hidden" name="next_step" value="three" />
			 <a class="btn btn-danger"  href="/requisition/{$action}{if $action eq 'edit'}?id={$smarty.get.id}&{else}?{/if}cancel=1" {if $step eq 'one'} disabled="disabled" {/if}>Cancel</a>
		   <input type="submit" name="complete" value="Save" class="btn btn-success"  />
		 </form>
		</div>
	   {/if}


	   </div>
	   <div class="col-md-10">
	      {if $step eq 'one'}
            {include file='requisition/add.step1.tpl'}
          {elseif $step eq 'two'}
            {include file='requisition/add.step2.tpl'}
          {elseif $step eq 'three'}
            {include file='requisition/add.step3.tpl'}
          {else}
            {include file='requisition/add.step1.tpl'}
          {/if}
	   </div>


    </div>
  </div>
 </div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">
       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>
</div>

</div>
{/if}
