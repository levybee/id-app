
<div id="response2"></div>

<form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}?id={$smarty.get.id}{/if}">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Requisition Information</h3>
        </div>
        <div class="panel-body form-group">
           <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Location</label>
                <div class="col-md-6 col-xs-12">
                    <select name="requisition_location" id="requisition_location"  class="form-control" required>
                      <option value="">Please Select..</option>
                      <option value="IPL1" {if $smarty.post.requisition_location == 'IPL1' || $form_data.requisition_location eq 'IPL1'}selected{/if}>IPL1</option>
                      <option value="IPL2" {if $smarty.post.requisition_location == 'IPL2' || $form_data.requisition_location eq 'IPL2'}selected{/if}>IPL2</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3 control-label">Job #</label>
                <div class="col-md-6">
                    <select name="job_id" id="job_id"  class="form-control" style="width:100%;" ></select>
                    <input type="hidden" name="job_reference" id="job_reference" value="">
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Remarks</label>
                <div class="col-md-6 col-xs-12">
                  <textarea name="requisition_remarks" class="form-control" rows="4">{if $smarty.post.requisition_remarks}{$smarty.post.requisition_remarks}{else}{$form_data.requisition_remarks}{/if}</textarea>
                </div>
            </div>

        </div>
        <div class="panel-footer">
            <input name="next_step" type="hidden" id="next_step" value="two" />
            <button type="submit" class="btn btn-primary pull-right">Continue</button>
        </div>
    </div>
 </form>
