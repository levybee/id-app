<!-- PAGE PLUGINS -->
<script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="/js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>

{literal}
<script type="text/javascript">
$('.select2').select2();
$(document).ready(function(){

   $.fn.reset = function () {
     $(this).each (function() { this.reset(); });
   }

     var page_action =  '{/literal}{$action}{literal}';
     if(page_action == 'edit'){
        var job_id = '{/literal}{$form_data.job_id}{literal}';
     }

     $("#stock_id").select2({
       placeholder: "Type to search...",
       minimumInputLength: 1,
       ajax: {
             url: "/ajax/stock.php?add_item=1",
             dataType: 'json',
             delay: 250,
             data: function (params) {

                 return {
                     q: params.term, // search term
                 };
             },
             processResults: function (data) { // parse the results into the format expected by Select2.
                 // since we are using custom formatting functions we do not need to alter the remote JSON data

                 // Debug:
           console.log("Data: " + JSON.stringify(data) );

                 return { results: data };
             },
             cache: true
         }

     });

      $('#stock_id').change(function() {
        $('#stock_name').val($(this).select2('data')[0].text);
     });

  $("#job_id").select2({
  placeholder: "Type Job ID to search...",
  minimumInputLength: 1,
  ajax: {
   url: "/ajax/jobs.php",
   dataType: 'json',
   delay: 250,
   data: function (params) {

       return {
           q: params.term, // search term
          // status: 'not_pending'
       };
   },
   processResults: function (data) { // parse the results into the format expected by Select2.
       // since we are using custom formatting functions we do not need to alter the remote JSON data

       // Debug:
  console.log("Data: " + JSON.stringify(data) );

       return { results: data };
   },
   cache: true
  }

  });

  $('#job_id').on('change', function (e) {
    if($(this).select2('data')[0] != undefined){
      $('#job_reference').val($(this).select2('data')[0].text.trim());
    }
  });

  if(job_id){
    var job_reference = '{/literal}{$form_data.job_reference}{literal}';
    var job_text = job_id + ': ' + job_reference;
    var job_option = new Option(job_text , job_id, true, true);
    $("#job_id").append(job_option).trigger('change');
  }


  var req_type = $('input[name=type]:checked').val();

  // if(!req_type){
  //     req_type = 'Stock Refill';
  //     $( "#stock" ).prop( "checked", true );
  //
  // }
  if(req_type){
   req_select(req_type);
  }


  $('input[name=type]').on('change',function(){
     req_select($(this).val());
  });

 function req_select(type){
    let id = type.replace(' ', '_').toLowerCase();
    console.log('id', id)
    $( `#${id}`).prop( "checked", true );
  }

  if($('input[name="sample"]').is(":checked")){
    $('.sample_image').show();
  }else{
    $('.sample_image').hide();
  }

  $('input[name="sample"]').on('change', function(e){
    if($(this).is(":checked")){
      $('.sample_image').show();
    }else{
      $('.sample_image').hide();
    }
  })

  $('.edit_item').on('click', function(e){

    e.preventDefault();

    console.log('data', $(this).data("stock_id"));

    type = $(this).data("type");
    stock_id = $(this).data("stock_id");
    stock_name = $(this).data("stock_name");
    item_description = $(this).data("item_description");
    quantity = $(this).data("quantity");
    sample_image = $(this).data("sample_image");
    item_id = $(this).data("item_id");
    ri_id = $(this).data("ri_id");

    req_select(type);

    if(stock_id){
      var stock_option = new Option(stock_name , stock_id, true, true);
      $("#stock_id").append(stock_option).trigger('change');
      $('#stock_name').val(stock_name);
    }

    if(sample_image){
      $( `#sample`).prop( "checked", true );
      $('.sample_display').html(sample_image);
      $('.sample_image').show();
    }

    $('#item_description').val(item_description);
    $('#quantity').val(quantity);
    $('input[name="item_id"]').val(item_id);
    $('input[name="ri_id"]').val(ri_id);

   $('.item_title').text('Edit Item');
   $('input[name="add_item"]').val('Edit Item');
   $('.cancel').show();

  });

  $('.cancel').on('click', function(e){

    $('.item_title').text('Add Item');
    $('.add_item').val('Add Item');
    $('#ri-form').trigger("reset");
    $('input[name="item_id"]').val('');
    $("#stock_id").select2("val", "");
    $('#stock_name').val('');

    $(this).hide();

  });

  $('.cancelReq').on('click', function(e) {
  e.preventDefault();
  req_id = $(this).data("requisition_id");
  $('.modal-title').html('Cancel Requisition #'+req_id);
  $('#cancel_form').attr('action', $(this).attr('href'));
  $('#cancelModal').modal('show');
  });

  cancelSelected = function(e){
    e.preventDefault();
    console.log('cancelled..');
    return;
  }

  $('.cancel_selected').on('click', function(e) {
    e.preventDefault();
    reqCancelUri = "/requisition/list?cancel_multi=1";
    $('.confirmed_check').each(function(){
      let id = $(this).val();
      if($(this).filter(":checked").length > 0){
        reqCancelUri += `&id[]=${id}`;
      }

    });

    $('.modal-title').html('Cancel Requisitions');
    $('#cancel_form').attr('action', reqCancelUri);
    $('#cancelModal').modal('show');

  });

  $('.issueBtn').on('click', function(e) {
     e.preventDefault();
     var req_id = $(this).data("requisition_id");
     var ri_id = $(this).data("ri_id");
     $('#issueModal .modal-title').html(`Issue Items for Requisition  #${req_id}`);
     $('#requisition_id').val(req_id);
     $('#issueModal').modal('show');

     let uri = `/ajax/requisition_items.php`;
      if(ri_id){
        uri += `?ri_id=${ri_id}`;
      }else{
        uri += `?req_id=${req_id}`;
      }

     $.get(uri, function(data) {
       data = JSON.parse(data);
       let $itemsHtml = '';
       if(data.length > 0){

         $.each(data, function(k, item) {
            console.log(k, item)
            var disabled = '';
            var issueHtml = `<input name="issued_qty[${item.ri_id}]" type="text" value="" class="form-control" style="width:100px" />`;
            if(item.balance_qty <= 0){
              issueHtml = `<p class="form-control-static balance_qty">${item.issued_qty} ${item.units}</p><input name="issued_qty[${item.ri_id}]" type="hidden" value="0"/>`;
              disabled = 'disabled';
            }
            $itemsHtml += `<tr>
              <td><p class="form-control-static">${item.stock_name}</p></td>
              <td><p class="form-control-static">${item.quantity} ${item.units}</p></td>
              <td>${issueHtml}</td>
              <td><input name="issued_to[${item.ri_id}]" type="text" value="" class="form-control" ${disabled} /></td>
              <td><p class="form-control-static balance_qty_txt${item.ri_id}">${item.balance_qty}</p>
              <input type='hidden' id='balance_qty${item.ri_id}' value="${item.balance_qty}" />
              </td>
              <td>
                <select name="issued_location[${item.ri_id}]"  class="form-control" style="width:150px" ${disabled}>
                  <option value="">Please select..</option>
                 <option value="Office">Office</option>
                 <option value="Site">Site</option>
                </select>
              </td>
            </tr>`;



         });

       }else{
         $itemsHtml += '<tr><td colspan="6">No items found</td></tr>';
       }

       let $tableBody = $('.issue-items-table tbody');
       $tableBody.empty(); // Just in case
       $tableBody.html($itemsHtml);

     });

  });

  $('#issue_form').submit(function(e){
    e.preventDefault();
    let negativeBlnce = checkNegativeBalance();
    if(!negativeBlnce){
      submit_form('#issue_form', 'items_submit', '#issueResponse', '#issueModal');
    }else{
      alert('Cannot submit the form: some items have negative balance quantities.');
    }

  });

  $(document).on('blur', 'input[name^="issued_qty["]', function() {
      const issued_qty = $(this).val(); // The issued quantity entered
      const nameAttr = $(this).attr('name'); // e.g., "issued_qty[3]"

      // Extract the key (e.g., 3) using regex
      const match = nameAttr.match(/issued_qty\[(\d+)\]/);
      const ri_id = match ? match[1] : null;
      if($.isNumeric(issued_qty)){
        get_balance_qty(ri_id, issued_qty);
      }else{
        $(this).val(0);
      }

  });

  get_balance_qty = function(ri_id, issued_qty){

      const balance_qty = $(`#balance_qty${ri_id}`).val();
      var total_issued = 0;
      var new_balance = 0;

      new_balance = parseFloat(balance_qty) - parseFloat(issued_qty);

      if(new_balance < 0){
        $(`.balance_qty_txt${ri_id}`).css('color','red');
      }else{
        $(`.balance_qty_txt${ri_id}`).css('color','#22262e');
      }

      $(`.balance_qty_txt${ri_id}`).text(new_balance);

  }

  checkNegativeBalance = function () {
    let hasNegativeBalance = false;

    $('.issue-items-table tbody tr').each(function () {
      const $row = $(this);

      // Find the balance text element in the row
      const balanceTextEl = $row.find('[class^="form-control-static balance_qty_txt"]');

      if (balanceTextEl.length > 0) {
        const balanceText = balanceTextEl.text().trim();
        const balanceValue = parseFloat(balanceText);

        if (!isNaN(balanceValue) && balanceValue < 0) {
          console.log('balanceValue', balanceValue);
          hasNegativeBalance = true;

          $row.css('background-color', '#ffe6e6'); // optional styling
          // We can break the loop early if we want
          return false; // break `.each()` loop
        }
      }
    });

    return hasNegativeBalance;
  };

  $('.returnBtn').on('click', function(e) {
     e.preventDefault();
     var req_id = $(this).data("requisition_id");
     var ris_id = $(this).data("ris_id");
     var ri_id = $(this).data("ri_id");
     $('#returnModal .modal-title').html(`Return Items for Requisition  #${req_id}`);

     $('#returnModal').modal('show');

     let uri = `/ajax/issued_stock_items.php`;
      if(ri_id){
        uri += `?ris_id=${ris_id}`;
      }else{
        uri += `?req_id=${req_id}`;
      }

     $.get(uri, function(data) {
       data = JSON.parse(data);
       let $itemsHtml = '';
       if(data.length > 0){

         $.each(data, function(k, item) {
            console.log(k, item)
            let units = item.units? item.units : '';
            var disabled = '';
            var issueHtml = `<input name="return_qty[${item.risi_id}]" type="text" value="" class="form-control" style="width:100px" />`;
            $itemsHtml += `<tr>
              <td><p class="form-control-static">${item.risi_id}</p></td>
              <td><p class="form-control-static">${item.stock_name}</p></td>
              <td class="text-center"><p class="form-control-static">${item.issued_qty} ${units}</p></td>
              <td>${issueHtml}</td>
            </tr>`;
         });

       }else{
         $itemsHtml += '<tr><td colspan="6">No items found</td></tr>';
       }

       let $tableBody = $('.return-items-table tbody');
       $tableBody.empty(); // Just in case
       $tableBody.html($itemsHtml);

     });

  });

  $('#return_form').submit(function(e){
    e.preventDefault();
    let negativeBlnce = checkNegativeBalance();
    submit_form('#return_form', 'return_submit', '#returnResponse', '#returnModal');

  });

  $('input[name="edit_refils"]').click(function(e){
    e.preventDefault();
    submit_form('#requisition_form', 'edit_refils', '#refilResponse', '', false, 'Edit');
  });



 var submit_form = function(form_name, btn_name, response_element='', modal_element='', reload=true, btnTxt='Submit'){

   $('input[name="'+ btn_name +'"]').val('Sending...').attr('disabled','disabled');

   var post_url = $(form_name).attr('action');;
   var post_data = $(form_name).serialize();
   if(btnTxt == 'Edit'){
     post_data += '&edit_refils=1';
   }


   $.ajax({
     type: 'POST',
     url: post_url,
     data: post_data,
     dataType:'json',
     success	:	function(data){

       console.log(data);

          var alert_class = (data.error == true)? 'danger' : 'success';

          var msg_html = "<ul>";
          $.each(data.msg, function(i, item) {
            msg_html += "<li>"+ data.msg[i] +"</li>";
         });
          msg_html += "</ul>";


          $('input[name="'+ btn_name +'"]').val(btnTxt).removeAttr('disabled');

            $(response_element).html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

            if(!data.error){

             // $(form_name)[0].reset();
             if(data.gin_id){
               popupPDF('requisition', data.gin_id, 0, true);
               // myLink = `/requisition/print?id=${gin_id}`;
               // window.open(myLink, '_blank');

             }

              setTimeout(function(){
                 //$('.item_list').prop('checked', false);
                 if(modal_element){
                   $(modal_element).modal('hide');
                 }
                 if(reload){
                   location.reload();
                 }

             },5000);

            }



       },
       error : function(XMLHttpRequest, textStatus,
           errorThrown) {

         console.log("Status: " + textStatus);
         console.log("Error: " + errorThrown);

       }

   });

 }

 function formatNumber(num) {
    console.log('num', num);
    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
  }

 });

</script>
{/literal}

<!-- END PAGE PLUGINS -->
