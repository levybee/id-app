<div class="col-md-12">
    <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>New Job &gt; From Quotation Item</h2>
	</div>
	{if $step eq 'one'}
		{include file="quotes/makejob.convert.step1.tpl"}
	{elseif $step eq 'two'}
		{include file="quotes/makejob.convert.step2.tpl"}
	{else}
		{include file="quotes/makejob.convert.step1.tpl"}
	{/if}
  
</div>
