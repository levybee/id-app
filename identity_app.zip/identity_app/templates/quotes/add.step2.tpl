
{if $smarty.get.subtask neq 'edit'}
{include file="quotes/summary.tpl"}
{/if}

{literal}
<script type="text/javascript">

	var prod = new Array();
{/literal}
	{section name=product_types loop=$product_types}
	prod[{$product_types[product_types].product_id}] = '{$product_types[product_types].product_2rows}';
	{/section}
{literal}
</script>
{/literal}


<form id="quotes-form" class="form-horizontal" method="post" action="/quotes/add{if $smarty.get.subtask eq 'edit'}?subtask=edit&subid={$smarty.get.subid}{/if}">
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">{if $smarty.get.subtask eq 'edit'}Edit{else}Add{/if} Item</h3>

      </div>
       {include file="quotes/quote_item_fields.tpl"}
		
      <div class="panel-footer">

				<input type="hidden" name="subid"  value="{$smarty.get.subid}" />
        <input type="hidden" name="next_step" id="next_step" value="three" />
				{if $smarty.get.subtask eq 'edit'}<a class="btn btn-default" href="/quotes/add">Cancel</a>{/if}
        <input type="submit" name="add_item" class="btn btn-primary pull-right" value="{if $smarty.get.subtask eq 'edit'}Edit{else}Add{/if} Item" />
      <!-- <table>
  <tr>
    <td width="150"><label> <input type="hidden" name="next_step" id="next_step" value="three" />
      <input name="next_step_info" type="radio" id="next_step_info_0" value="three_a" checked="checked" />
      Add Another Item</label></td>
    <td width="150"><input type="radio" name="next_step_info" value="three_b" id="next_step_info_1" />
Add &amp; Print</td>
    <td width="150"><input type="radio" name="next_step_info" value="three_c" id="next_step_info_2" />
Ignore &amp; Print</td>
    <td><div align="center">

    </div></td>
  </tr>
</table>     -->

      </div>
  </div>
  </form>

	{if $smarty.get.debug eq 'lev'}
  <pre>{$item_data|@print_r}</pre>
  {/if}
