<h2>Quotation Information</h2>
<table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td class="header_row"><div align="right"><strong>Quote Date</strong></div></td>
    <td width="200">{$smarty.session.quote.step_1.quote_date|date_format:"%d/%m/%Y"}</td>
  </tr>
  <tr>
    <td width="100" valign="top" class="header_row"><div align="right"><strong>Customer</strong></div></td>
    <td>{$smarty.session.quote.step_1.customer_information.customer_fname} {$smarty.session.quote.step_1.customer_information.customer_lname}<br />
    {$smarty.session.quote.step_1.customer_information.group_company}<br />
    {$smarty.session.quote.step_1.customer_information.customer_address}<br />
    {$smarty.session.quote.step_1.customer_information.customer_city}, {$smarty.session.quote.step_1.customer_information.customer_country}<br />
    <br />
    Phone: {$smarty.session.quote.step_1.customer_information.customer_phone}<br />
    Fax: {$smarty.session.quote.step_1.customer_information.customer_fax}<br />
    Mobile: {$smarty.session.quote.step_1.customer_information.customer_mobile}<br />
    Email: {$smarty.session.quote.step_1.customer_information.customer_email}</td>
  </tr>
  <tr>
    <td valign="top" class="header_row"><div align="right"><strong>Show Details</strong></div></td>
    <td><input type="checkbox" name="show_summary" id="show_summary" value="Y" onclick="show_summary(this);" /></td>
  </tr>
</table>
<div id="summary" style="display:none;">
  <h2>Items</h2>
    {section name=items loop=$smarty.session.quote.items}
    <table  border="1" cellspacing="5" cellpadding="5" class="table">
      <tr>
        <td colspan="3" class="header_row title"><strong>Item # {$smarty.section.items.rownum}</strong></td>
        <td class="header_row title">
        <div align="right">
          <a title="Edit Quote Item" href="/quotes/add/?subtask=edit&subid={$smarty.section.items.rownum}&popup=true" onclick="popupURL(this.href, 'EditQuoteItem', '800', '500'); return false;"><img src="/images/edit.png" alt="Edit" width="16" height="16" border="0"></a> 
          <a title="Delete Quote Item" href="/quotes/add/?subtask=delete&subid={$smarty.section.items.rownum}"><img src="/images/delete.png" alt="Cancel" width="16" height="16" border="0"></a>
        </div></td>
      </tr>
      <tr>
        <td width="100" class="header_row"><div align="right"><strong>Item Type</strong></div></td>
        <td width="200">{$smarty.session.quote.items[items].item_product[0].product_name} {if $smarty.session.quote.items[items].item_product_other}({$smarty.session.quote.items[items].item_product_other}){/if}</td>
        <td width="100" class="header_row"><div align="right"><strong>Title</strong></div></td>
        <td width="200">{$smarty.session.quote.items[items].item_title}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Origination</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_origination}</td>
        <td class="header_row"><div align="right"><strong>Delivery Date</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_delivery_date|date_format:"%d %B %Y"}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Size</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_paper_size[0].paper_size} {if $smarty.session.quote.items[items].item_paper_size_other}({$smarty.session.quote.items[items].item_paper_size_other}){/if}</td>
        <td class="header_row"><div align="right"><strong>Orientation</strong></div></td>
        <td><label>{$smarty.session.quote.items[items].item_orientation|capitalize}</label>
            <label></label>
            <label></label></td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Cover Paper</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_cover_paper_type[0].paper_name} {if $smarty.session.quote.items[items].item_cover_paper_type_other}({$smarty.session.quote.items[items].item_cover_paper_type_other}){/if}</td>
        <td class="header_row"><div align="right"><strong>Description</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_cover_paper_desc}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Paper Weight:</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_cover_paper_weight[0].weight_value} gsm</td>
        <td class="header_row"><div align="right"><strong>Print</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_cover_color[0].color_name} {if $smarty.session.quote.items[items].item_cover_color_other}({$smarty.session.quote.items[items].item_cover_color_other}){/if}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
        <td><label>{$smarty.session.quote.items[items].item_cover_print_options|capitalize}</label>
            <label></label></td>
        <td class="header_row">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      {if $smarty.session.quote.item_product[0].product_2rows == 'Y'}
      <tr>
        <td class="header_row"><div align="right"><strong>Inner Paper</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_inner_paper_type[0].paper_name} {if $smarty.session.quote.items[items].item_inner_paper_type_other}({$smarty.session.quote.items[items].item_inner_paper_type_other}){/if}</td>
        <td class="header_row"><div align="right"><strong>Description</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_inner_paper_desc}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Paper Weight</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_inner_paper_weight[0].weight_value} gsm</td>
        <td class="header_row"><div align="right"><strong>Print</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_inner_color[0].color_name} {if $smarty.session.quote.items[items].item_inner_color_other}({$smarty.session.quote.items[items].item_inner_color_other}){/if}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
        <td><label>{$smarty.session.quote.items[items].item_inner_print_options|capitalize}</label>
            <label></label></td>
        <td class="header_row">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      {/if}
      <tr>
        <td class="header_row"><div align="right"><strong>Pagination</strong></div></td>
        <td colspan="3">{$smarty.session.quote.items[items].item_pagination}</td>
      </tr>
      <tr>
        <td valign="top" class="header_row"><div align="right"><strong>Finishing</strong></div></td>
        <td colspan="3">
            {section name=item_finishing_summary loop=$smarty.session.quote.items[items].item_finishing}
            	{$smarty.session.quote.items[items].item_finishing[item_finishing_summary][0].finishing_type}; 
            {sectionelse}
           	 	None
            {/section}        </td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Payment Terms</strong></div></td>
        <td colspan="3">{$smarty.session.quote.items[items].item_payment_terms[0].payment_term}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Quantity # 1</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_quantity_1|thousand_sep}</td>
        <td class="header_row"><div align="right"><strong>Price in Dhs # 1</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_price_1|thousand_sep}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Quantity # 2</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_quantity_2|thousand_sep}</td>
        <td class="header_row"><div align="right"><strong>Price in Dhs # 2</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_price_2|thousand_sep}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Quantity # 3</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_quantity_3|thousand_sep}</td>
        <td class="header_row"><div align="right"><strong>Price in Dhs # 3</strong></div></td>
        <td>{$smarty.session.quote.items[items].item_price_3|thousand_sep}</td>
      </tr>
      <tr>
        <td valign="top" class="header_row"><div align="right"><strong>Notes</strong></div></td>
        <td colspan="3">{$smarty.session.quote.items[items].item_notes}</td>
      </tr>
      <tr>
        <td valign="top" class="header_row"><div align="right"><strong>Special Remarks</strong></div></td>
        <td colspan="3">{$smarty.session.quote.items[items].item_special_remarks}</td>
      </tr>
    </table>
<br />
    {sectionelse}
  <p>No Items have been added to this quotation yet.</p>
    {/section}
</div>