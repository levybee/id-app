

<form action="" method="post" name="summary">
  <div id="summary" class="panel panel-default">
          
       <div class="panel-heading">
            <h3 class="panel-title">Items</h3>         
      </div>
		  <div class="panel-body panel-body-table">
		
		   <div class="table-responsive">
		       <table class="table datatable_simple">
                 <thead>
                    <tr>
                        <th width="5%">SN</th>
                        <th width="50%">Description</th>
                        <th>Qty</th>
                        <th>Unit Rate</th>
                        <th style="max-width: 130px;">Price{if $smarty.session.quote.step_1.currency}({$smarty.session.quote.step_1.currency}){/if}</th>
                        <th width="120">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                {section name=items loop=$smarty.session.quote.items}
                    <tr>
                        <td>{$smarty.section.items.rownum}</td>
                        <td>{$smarty.session.quote.items[items].item_description_text}</td>
                        <td>{$smarty.session.quote.items[items].item_quantity_1|thousand_sep}</td>
                        <td>{$smarty.session.quote.items[items].item_price_1/$smarty.session.quote.items[items].item_quantity_1|thousand_sep}</td>
                        <td>{$smarty.session.quote.items[items].item_price_1|thousand_sep}</td>
                        <td>
                          <a title="Edit Quote Item" href="/quotes/add/?subtask=edit&subid={$smarty.section.items.rownum}&popup=true" onclick="popupURL(this.href, 'EditQuoteItem', '1000', '500'); return false;" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a> 
                          <a title="Delete Quote Item" href="/quotes/add/?subtask=delete&subid={$smarty.section.items.rownum}"  class="btn btn-danger btn-rounded btn-condensed btn-sm"><span class="fa fa-times"></span></a>
        
                        </td>
                    </tr>
                 {sectionelse}
			      <tr>
			        <td colspan="6">No Items have been added to this quotation yet.</td>
			      </tr>
			    {/section} 
			   {if $smarty.section.items.rownum} 
			   <tr>
			    
			    
			    <td colspan="2"></td>
		        <th colspan="2"  class="text-right">Total Amount</th>
		        <td><input name="quote_total" type="text" id="quote_total" value="{$smarty.session.quote.step_1.quote_total}" style="text-align: right; max-width:130px;"></td>
		        <td >&nbsp;</td>
		       </tr>
		       
		      <tr>
		        <td colspan="2">&nbsp;</td>
		        <th colspan="2" class="text-right">Discount</th>
		        <td><input name="quote_discount" type="text" id="quote_discount" value="{$smarty.session.quote.step_1.quote_discount}" style="text-align: right; max-width:130px;"></td>
		        <td>&nbsp;</td>
		      </tr>
		      <tr>
		        <td colspan="2">&nbsp;</td>
		        <th colspan="2" class="text-right">Total Due</td>
		        <td><input name="quote_total_due" type="text" id="quote_total_due" value="{$smarty.session.quote.step_1.quote_total_due}" style="text-align: right; max-width:130px;"></td>
		        <td>&nbsp;</td>
		      </tr>
		      <tr>
		        <td colspan="2">&nbsp;</td>
		        <th colspan="2" class="text-right">Payment Terms</th>
		        <td>
		          <select name="quote_payment_terms" id="quote_payment_terms" style="max-width:130px;">
		            <option value="0">Please Select</option>
		            
		      
				      {section name=item_payment_terms loop=$item_payment_terms}
				      
				      
				            <option value="{$item_payment_terms[item_payment_terms].payment_id}" {if $item_payment_terms[item_payment_terms].payment_id eq $smarty.session.quote.step_1.quote_payment_terms}selected{/if}>{$item_payment_terms[item_payment_terms].payment_term}</option>
				            
				      
				      {/section}
		    
		    
		            </select>
		          </td>
		          <td>&nbsp;</td>
		        </tr>
		        {/if}
                </tbody> 
              </table>
            </div>
	 </div>     
      
</div>
<div class="col-md-12">
<input name="update_summary" type="hidden" id="update_summary" value="Y" />
<input name="next_step" type="hidden" id="next_step" value="two_update" />
{if $smarty.section.items.rownum} 
<button type="submit" name="submit_summary" class="btn btn-primary pull-right">Update Summary</button>
<div class="clearfix"></div>
<br />
{/if}
</div>

</form>
