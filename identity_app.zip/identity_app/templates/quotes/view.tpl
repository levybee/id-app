{if $privileges.quotes.view}
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
	<li><a href="/">Home</a></li>
	<li><a href="/quotes/list">Quotes</a></li>
	<li class="active"><a href="#"> &nbsp; Quote
			#{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</a></li>
</ul>
<!-- END BREADCRUMB -->

<div class="page-title">
	<h2>
		<span class="fa fa-arrow-circle-o-left"></span>Quote
		#{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}
	</h2>

	<ul class="panel-controls fa panel-controls-title">



	    {if $quote_info[0].quote_status eq 'Confirmed'}
		<!-- <li><a class="btn btn-default" title="Approve"
			href="/quotes/view/?id={$quote_info[0].quote_id}&sub_act=approve"><span
				class="fa fa-check text-info"></span>Approve</a>
		</li>  -->

		<li><a class="btn btn-default" title="Approve"
			id="approve" href="/quotes/view/?id={$quote_info[0].quote_id}&sub_act=approve" onclick="confirmAction('[Approve Quote] Are you sure?', this.href); return false;"><span
				class="fa fa-check text-info"></span>Approve</a>
		</li>

		{/if}

		{if !$quote_info[0].job_lpo_other  && $quote_info[0].quote_status eq 'Approved'}
		  <li><a class="btn btn-default" title="LPO"
			id="lpo" href="javascript:void(0);"><span
				class="fa fa-pencil"></span>LPO</a>
		  </li>
		{/if}



	    <li><a class="btn btn-default" title="View PDF"
			href="/quotes/print?uid={$quote_info[0].quote_id}" target="_blank"><span
				class="fa fa-file-pdf-o text"></span>PDF</a></li>
		{if $quote_info[0].quote_status eq 'Confirmed'}
		<!-- <li><a class="btn btn-default" title="Make Jobs from Quotation Items"
			href="/quotes/makejob?id={$quote_info[0].quote_id}"><span
				class="fa fa-toggle-up text"></span>Make Jobs</a></li> -->
		<li><a class="attach btn btn-default" title="Attach"
			href="#"><span
				class="fa fa-paperclip"></span>Attach</a></li>

	 {/if}
				{if $quote_info[0].quote_status eq 'Pending'}
		<li><a class="btn btn-default" title="Confirm"
			href="/quotes/confirm?id={$quote_info[0].quote_id}&start=1"><span
				class="fa fa-check text-success"></span>Confirm Quote</a></li>

				{/if}
       {if $quote_info[0].quote_status == 'Pending' || $quote_info[0].quote_status ==
	 'Confirmed'}
				{if $override_outstanding && ($privileges.quotes.override_outstanding ||  $smarty.session.user_data[0].user_id == '298')}
					 <li>
						 <a class="btn btn-default overrideBtn" title="" href="javascript:void(0);"></span>Override Outstanding</a>
					 </li>
				 {/if}
     {/if}


			{if $quote_info[0].quote_status == 'Pending' || $quote_info[0].quote_status == 'Confirmed' 
			|| ($quote_info[0].quote_status == 'Approved' 
			&& ($role_data[0].role_name eq 'Administrator' || $smarty.session.user_data[0].user_id == '298')) }
			<li><a class="btn btn-default" title="Edit Quote"
			href="/quotes/edit/?id={$quote_info[0].quote_id}"><span
				class="fa fa-pencil"></span>Edit</a></li>
				<li><a class="btn btn-default" title="Cancel Quote"
			href="/quotes/cancel/?id={$quote_info[0].quote_id}"
			onclick="confirmAction('[Cancel Quote] Are you sure?', this.href); return false;"><span
				class="fa fa-times"></span>Cancel</a></li>
			{/if}

				{if $quote_info[0].quote_status neq
		'Confirmed' || $role_data[0].role_name eq 'Administrator'}

		<li><a class="btn btn-default" title="Mail Quote"
			href="/quotes/mail/?id={$quote_info[0].quote_id}&show_details=1"><span
				class="fa fa-envelope-o"></span>Mail</a></li>
		

				{if $quote_info[0].quote_status eq 'Pending' || $quote_info[0].quote_status eq 'Cancelled'}
	   	<li>
			<a class="btn btn-default" class="color-danger" title="Delete Quote"
			href="/quotes/delete/?id={$quote_info[0].quote_id}"
			onclick="confirmAction('[Delete Quote] Deleting will permanently remove the quote from the system. Are you sure?', this.href); return false;"><span
				class="fa fa-times text-danger"></span>Delete</a>
			</li>


			{/if}

	       			

				{/if}

     {if $quote_info[0].quote_status eq 'Approved' && $sale_exempt}
			<li>
				<a class="btn btn-default" title="Issue DN"
				href="/quotes/view?id={$quote_info[0].quote_id}&sub_act=sale_exempt"
				onclick="confirmAction('Issue Delivery Note, are you sure?', this.href); return false;"><span
					class="fa fa-file"></span>Issue DN</a>
				</li>
      {/if}

			{if $quote_info[0].quote_status eq 'Approved' && $sale_tax}
 			<li>
 				<a class="btn btn-default" title="Issue Invoice"
 				href="/quotes/view?id={$quote_info[0].quote_id}&sub_act=sale_tax"
 				onclick="confirmAction('Issue Invoice, are you sure?', this.href); return false;"><span
 					class="fa fa-file"></span>Invoice</a>
 				</li>
       {/if}

		<li><a class="btn btn-default" title="Duplicate Quote"
			href="/quotes/duplicate?id={$quote_info[0].quote_id}"
			onclick="confirmAction('[Duplicate Quote] Are you sure?', this.href); return false;"><span
				class="fa fa-copy"></span>Duplicate</a></li>
	</ul>

</div>
<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">

	<div class="row">

		{if $message}
		<div class="col-md-12">
			<div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
					<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					{$message}
			</div>
		</div>
			{/if}
		<div class="col-md-3">

			<div class="panel panel-default">

			       <div class="panel-heading">
			            <h3 class="panel-title">Quotation Information</h3>
						 </div>
						 <div class="panel-body panel-body-table">

					   <div class="table-responsive">
					     <table class="table pad-10 table-striped">
					       <tr>
						    <td colspan="2">
						    <div><strong>Quote #</strong></div>
						    <div>{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}</div>
						    </td>
						  </tr>

					       <tr>
						    <td colspan="2">
						    <div><strong>Date</strong></div>
						    <div>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</div>
						    </td>
						  </tr>

						  <tr>
						    <td colspan="2"><div><strong>Customer</strong></div>

						     <div>
						     	{if $quote_info[0].customer_fname}{$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<br />{/if}
							    {if $quote_info[0].group_company}{$quote_info[0].group_company}<br />{/if}
							    {if $quote_info[0].customer_address}{$quote_info[0].customer_address}<br />{/if}
							    {if $quote_info[0].customer_city}{$quote_info[0].customer_city}, {/if}{if $quote_info[0].customer_country}{$quote_info[0].customer_country}{/if}<br />
							    <br />
							    {if $quote_info[0].customer_phone}Phone: {$quote_info[0].customer_phone}<br />{/if}
							    {if $quote_info[0].customer_fax}Fax: {$quote_info[0].customer_fax}<br />{/if}
							    {if $quote_info[0].customer_mobile}Mobile: {$quote_info[0].customer_mobile}<br />{/if}
							    {if $quote_info[0].customer_email}Email: {$quote_info[0].customer_email}{/if}
							 </div>

						    </td>

						  </tr>

						  <tr>
						    <td colspan="2"><div><strong>Payment Terms</strong></div>
						        <div>{if $quote_info[0].credit_terms gt 0}{$quote_info[0].credit_terms} Days{elseif $quote_info[0].credit_terms eq 0}0 Days {else} - {/if}</div>
						    </td>
						  </tr>
                          {if $quote_info[0].job_lpo}
						  <tr>
						    <td colspan="2">
							{if $quote_info[0].job_lpo_other}
						    <div><strong>LPO No</strong></div>
						    <div>{$quote_info[0].job_lpo_other}</div>
							{/if}
							{if $quote_info[0].receipt_id}
							 <div><strong>{$quote_info[0].job_lpo}</strong></div>
						    <div>{$quote_info[0].receipt_amount|number_format:0:".":","} {$quote_info[0].receipt_currency}</div>	
							<div> <a title="View Receipt" target="_blank" href="/receipts/view/?id={$quote_info[0].receipt_id}"  alt="View Receipt">Receipt #{$quote_info[0].receipt_id} </a></div>
							{/if}
						    </td>
						  </tr>
						 {/if}
						   <tr>
						    <td colspan="2"><div><strong>Tax</strong></div>
						        <div>{$quote_info[0].tax} ({$quote_info[0].vat}%)</div>
						    </td>
						  </tr>
							{if $quote_info[0].currency == 'USD'}
							<tr>
							 <td colspan="2"><div><strong>Exchange Rate</strong></div>
									 <div>{$quote_info[0].exch_rate}</div>
							 </td>
						 </tr>
						 {/if}
						 {if $quote_info[0].quote_branch}
						   <tr>
						    <td colspan="2"><div><strong>Branch</strong></div>
						        <div>{$quote_info[0].quote_branch}</div>
						    </td>
						  </tr>
						{/if}

                         {if $quote_info[0].invoicing_type}
                           <tr>
						    <td colspan="2"><div><strong>Invoicing Type</strong></div>
						        <div>{$quote_info[0].invoicing_type}</div>
						    </td>
						  </tr>
						 {/if}
						  <tr>
						    <td colspan="2"><div><strong>Status</strong></div>
						        <div>{$quote_info[0].quote_status}</div>
						    </td>
						  </tr>

			             </table>
			           </div>
			          </div>


			</div>

	    {if $quote_info[0].quote_status eq 'Confirmed' || $quote_info[0].quote_status eq 'Approved'}
		<div class="panel panel-default">

		        <div class="panel-heading">
		            <h3 class="panel-title">Attachments</h3>
		        </div>
		        <div class="panel-body panel-body-table">
		            <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <!-- <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>Description</th>
							    <th width="50">Actions</th>

                            </tr>
                        </thead> -->
                        <tbody>
                          {section name=att loop=$attachment_list}
						  <tr>
						  <td>{$start+$smarty.section.att.rownum}. <a href="/{if $attachment_list[att].attachment_type == 'receipt'}{$attachment_list[att].attachment_path}{else}{$config.attachment_dir}{$attachment_list[att].attachment_path|escape:'url'}{/if}" target = "_blank">{$attachment_list[att].attachment_name}</a> |  <a title="Delete" href="/quotes/view?id={$quote_info[0].quote_id}&task=del_attachmnt&attach_id={$attachment_list[att].attachment_id}" onclick="confirmAction('Are you sure you want to delete this attachment?', this.href); return false;"><span
				class="fa fa-times text-danger"></span></a></td>
						  </tr>
						  {sectionelse}
						  <tr>
						  	<td>No attachments found</td>
						  </tr>
						  {/section}


                        </tbody>
                    </table>

                </div>
		        </div>

		    </div>

		  {/if}


			 <a class="attach btn btn-default" style="margin-bottom:10px;" href="#" ><span class="fa fa-paperclip"></span>Attach</a>

		     <div id="attachmnt_form" class="panel panel-default" {if !$is_error}style="display:none;"{/if}>

                <div class="panel-body">
                    <h4>Attach Documents</h4>
                    <form action="" method="post" class="form-horizontal" enctype="multipart/form-data" name="form1">
                        <div class="form-group">
                            <label>Attachment</label>
                            <input name="attachment_file" type="file" id="attachment_file" class="form-control" />
                        </div>
                        <div class="form-group">
                            <label>Description</label>
                            <input name="attachment_name" type="text" id="attachment_name" class="form-control" />
                        </div>

                        <input type="submit" name="submit_attachmnt" value="Submit" class="btn btn-primary" />

                    </form>
                </div>
            </div>

		</div>

		<div class="col-md-9">




			<div class="panel panel-default">

				<div class="panel-heading">
					<h3 class="panel-title">Items</h3>
				</div>
				<div class="panel-body panel-body-table">

					<div class="table-responsive">
						<table class="table pad-10 table-bordered table-striped table-actions">
							<thead>
								<tr>
									<th width="40" class="text-center">item #</th>
									<th class="text-center">Qty</th>
									<th class="text-left">Description</th>
									<th class="text-center">Unit Price {if
										$quote_info[0].currency}({$quote_info[0].currency}){/if}</th>
									<th class="text-center">Amount {if
										$quote_info[0].currency}({$quote_info[0].currency}){/if}</th>
								   {if $quote_info[0].quote_status eq 'Approved'} <th width="40" >Action</th>	{/if}
								</tr>
							</thead>
							<tbody>
								{section name=items loop=$quote_items}
								<tr>
									<td class="text-center">{$smarty.section.items.rownum}</td>
									<td class="text-center">{$quote_items[items].item_quantity_1|number_format:0:".":","}</td>
									<td>

										{if $quote_items[items].product_name}{$quote_items[items].product_name}{else}{$quote_items[items].item_product}{/if}
										{if $quote_items[items].stock_name}- {$quote_items[items].stock_name}{/if}
										{if
										$quote_items[items].item_product_other}({$quote_items[items].item_product_other}){/if}
										{if $quote_items[items].item_title} - {$quote_items[items].item_title} {/if}
										<p style="line-height: 18px;">Origination:
											{$quote_items[items].item_origination};{if
											$quote_items[items].item_delivery_days} Delivery
											Days:
											{$quote_items[items].item_delivery_days};{/if}
											Size:
											{$quote_items[items].item_paper_size};
											{* if $quote_items[items].item_num_pages}
											  No of Pages: {$quote_items[items].item_num_pages};
											{/if *}
						
											{if
											$quote_items[items].product_type
											eq 'Paper' ||
											$quote_items[items].product_type
											eq 'Books'} {if
											$quote_items[items].item_orientation|capitalize}Orientation:
											{$quote_items[items].item_orientation|capitalize};{/if}
											{if $quote_items[items].item_cover_paper_type}
											Cover Paper: {$quote_items[items].item_cover_paper_type}; {/if}
											{if
											$quote_items[items].item_cover_paper_type_other}({$quote_items[items].item_cover_paper_type_other});{/if}
											{if
											$quote_items[items].item_cover_paper_desc}Cover
											Paper Description:
											{$quote_items[items].item_cover_paper_desc};{/if}
											Paper Weight:
											{$quote_items[items].item_cover_paper_weight}
											gsm; {if
											$quote_items[items].item_cover_color}Print:
											{$quote_items[items].item_cover_color}
											{if
											$quote_items[items].item_cover_color_other}({$quote_items[items].item_cover_color_other}){/if};{/if}
											{if
											$quote_items[items].item_cover_print_options}Print
											Options:
											{$quote_items[items].item_cover_print_options|capitalize};{/if}{/if}
											{if
											$quote_items[items].product_type
											eq 'Books'}
											{if $quote_items[items].item_inner_paper_type}
											Inner Paper:
											{$quote_items[items].item_inner_paper_type};{/if}
											{if
											$quote_items[items].item_inner_paper_desc}Inner
											Paper Description:
											{$quote_items[items].item_inner_paper_desc};{/if}
											{if $quote_items[items].item_inner_paper_weight}
											Inner Paper Weight:
											{$quote_items[items].item_inner_paper_weight}
											gsm;{/if}
											{if $quote_items[items].item_inner_color}
											Inner Print:
											{$quote_items[items].item_inner_color} ;{/if}
											{if
											$quote_items[items].item_inner_color_other}({$quote_items[items].item_inner_color_other});{/if}
											{if
											$quote_items[items].item_inner_print_options}Inner
											Print Options:
											{$quote_items[items].item_inner_print_options|capitalize};{/if}
											{/if} {if
											$quote_items[items].item_print_process}Print
											Process:
											{$quote_items[items].item_print_process};{/if}
											{$quote_items[items].item_process}
											Finishing: {section name=item_finishing_summary
											loop=$quote_items[items].item_finishing}
											{$quote_items[items].item_finishing[item_finishing_summary][0].finishing_type};
											{sectionelse} None; {/section}</p>
											{if
										$quote_items[items].product_ref eq 'FG001'}
										<p style="line-height: 18px;">Specifications:
											{$quote_items[items].product_specifications|@nl2br} </p> {/if}
											{if $quote_items[items].item_notes}
										<p style="line-height: 18px;">Notes:
											{$quote_items[items].item_notes|@nl2br} </p> {/if} {if
										$quote_items[items].item_special_remarks}
										<p style="line-height: 18px;">Special Remarks:
											{$quote_items[items].item_special_remarks}</p>{/if}
											{if $quote_items[items].item_wht_amount gt 0}
										<p>WHT Amount:
											{$quote_items[items].item_wht_amount} {$quote_info[0].currency} </p>{/if}
                                        
									    {if $smarty.get.dbg}
										<pre>{$quote_items[items]|@print_r}</pre>
										
										{/if}		


									</td>
									<td class="text-right">
                  {$quote_items[items].item_price_1|number_format:$quote_info[0].dp:".":","}
									</td>
									<td class="text-right">{$quote_items[items].item_total_price|number_format:$quote_info[0].dp:".":","}</td>
									{if $quote_info[0].quote_status eq 'Approved'}<td class="text-center">
									{if $quote_items[items].job_id}
										<a class="btn" href="/jobs/progress?id={$quote_items[items].job_id}" target="_blank">View Job</a>
										 
									{else}
										<a class="btn btn-default" title="Make Job"  href="/quotes/makejob?item_id={$quote_items[items].item_id}&popup=true"   onclick="popupURL(this.href, 'MakeJob_Item', '1020', '700'); return false;" ><span class="fa fa-check text-success"></span> Make Job</a>
									{/if}
									  </td>{/if}

								</tr>

								{sectionelse}
								<tr>
									<td colspan="5"><div>No Items have been added to this
											quotation yet.</td>
								</tr>
								{/section} {if $quote_items|@count gt 0}
								<tr class="info">
									<td colspan="4" align="right"><strong>Sub Total {if
										$quote_info[0].currency}({$quote_info[0].currency}){/if}</strong></td>
									<td class="text-right">{$quote_total.sub_total|number_format:$quote_info[0].dp:".":","}</td>
									<td></td>
								</tr>
								{if $quote_info[0].quote_discount > 0}
								<tr class="warning">
									<td colspan="4" align="right" align="right"><strong>Discount {if
										$quote_info[0].currency}({$quote_info[0].currency}){/if}</strong></td>
									<td class="text-right">{$quote_info[0].quote_discount|number_format:$quote_info[0].dp:".":","}</td>
									<td></td>
								</tr>
								{/if}
								{if $quote_info[0].tax eq 'Taxable'}
								<tr class="warning">
									<td colspan="4" align="right" align="right"><strong>Taxes {if
										$quote_info[0].currency}({$quote_info[0].currency}){/if}</strong></td>
									<td class="text-right">{$quote_total.taxes|number_format:$quote_info[0].dp:".":","}</td>
									<td></td>
								</tr>
								{/if}

								<tr class="success">
									<td colspan="4" align="right"><strong>Total {if
										$quote_info[0].currency}({$quote_info[0].currency}){/if}</strong></td>
									<td class="text-right">{$quote_total.grand_total|number_format:$quote_info[0].dp:".":","}</td>
									<td></td>
								</tr>
								{/if}

							</tbody>
						</table>

						{if $smarty.get.debug}
						<pre>
						{$quote_items|@print_r}
						</pre>
						{/if}

					</div>


				</div>


			</div>

  {include file="$section/approve_form.tpl"}
  {include file="$section/lpo_form.tpl"}
  {include file="$section/override_form.tpl"}


		</div>
	</div>
</div>
<!-- END PAGE CONTENT WRAPPER -->
</div>
<!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
{else}
<div class="row">
	<div class="col-md-12">
		<div class="panel panel-default">

			<div class="alert alert-danger" role="alert">
				<button type="button" class="close" data-dismiss="alert">
					<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
				</button>
				You are not authorized to view this section
			</div>

		</div>


	</div>

</div>

{/if}
