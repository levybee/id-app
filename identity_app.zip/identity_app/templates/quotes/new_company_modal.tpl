<!-- NEW COMPANY MODAL -->        
  <div class="modal" id="new_company_form" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Add New Company/Group</h4>
              </div>
              <form id="add_company_form" class="form-horizontal" method="post" action="">
	              <div class="modal-body">
	                 <div id="response"></div>
	                 
	                 
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
			                 
			                
			                 <div class="panel-body form-group">
			                   <div class="row">
			                     <div class="col-md-6">
			                     
			                       <div class="form-group">
				                      <label class="col-md-4 control-label">Type<span class="asterisk">*</span></label>
				                      <div class="col-md-8">                                                                                                                                        
				                          <div class="col-md-6">                                    
					                         <label class="check"><input type="radio" class="iradio" name="group_type"  value="Cash" {if !$edit_customer[0].group_type} checked="checked"  {/if}/> Cash</label>
					                      </div>
					                      <div class="col-md-6">                                    
					                         <label class="check"><input type="radio" class="iradio" name="group_type"  value="Account"  /> Account</label>
					                      </div>
				                      </div>
				                  </div>
				                  
			               
			                     </div>
			                     <div class="col-md-6">
			                        &nbsp;
			                     </div>
			                   </div>
			                   <div class="row">   
			                     <div class="col-md-6">
			                        <div class="form-group">
			                         <label class="col-md-4 col-xs-12 control-label">Industry</label>
			                         <div class="col-md-8 col-xs-12">                                                                                            
			                             <select name="industry_id" class="form-control select">
			                                  <option value="0" {if !$edit_customer[0].industry_id}selected{/if}>Please Select...</option>
										        {section name=industries loop=$industries}
										        	<option value="{$industries[industries].industry_id}" >{$industries[industries].industry_name}</option>
										        {/section}
			                             </select>
			                            
			                           </div>
			                         </div>
			                         <div class="form-group">
									    <label class="col-md-4 col-xs-12 control-label">Contact First Name</label>
									    <div class="col-md-8 col-xs-12">                                            
									        <input type="text" name="customer_fname" value="" class="form-control" required />
									                                              
									        
									    </div>
									</div>
									
									 
			                     <div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">Tel</label>
								    <div class="col-md-8 col-xs-12">                                            
								        <input type="text" name="group_phone" value="" class="form-control" />
								                                                 
								        
								    </div>
								</div>
								   
			                    <div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">Mobile</label>
								    <div class="col-md-8 col-xs-12">                                            
								        <input type="text" name="group_mobile" value="" class="form-control"/>
								        
								    </div>
								</div>
								
								   <div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">Address</label>
								    <div class="col-md-8 col-xs-12">                                            
								        <input type="text" name="group_address" value="" class="form-control"/>
								                                              
								        
								    </div>
								   </div>
								
								   <div class="form-group">
			                         <label class="col-md-4 col-xs-12 control-label">Country</label>
			                         <div class="col-md-8 col-xs-12">                                                                                            
			                             <select name="group_country" class="form-control select">
									        {section name=countries loop=$countries}
									        	<option value="{$countries[countries]}">{$countries[countries]}</option>
									        {/section}
									        </select>  
			                         </div>
			                     </div>
								
								
			                     </div>
			                     <div class="col-md-6">
			                        <div class="form-group">
			                         <label class="col-md-4 col-xs-12 control-label">Company<span class="asterisk">*</span></label>
			                         <div class="col-md-8 col-xs-12">                                            
			                             <input type="text" name="group_company" value="" class="form-control" required/>
			                                                                     
			                             
			                         </div>
			                     </div>
			                     <div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">Contact Last Name</label>
								    <div class="col-md-8 col-xs-12">                                            
								       <input type="text" name="customer_lname" value="" class="form-control" required/>
								                                               
								        
								    </div>
								</div>
								 <div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">Fax</label>
								    <div class="col-md-8 col-xs-12">                                            
								        <input type="text" name="group_fax" value="" class="form-control"/>
								      
								    </div>
								</div>
								
								<div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">Email Address <span class="asterisk">*</span></label>
								    <div class="col-md-8 col-xs-12">                                            
								        <input type="text" name="group_email" value="" class="form-control" required/>
								                                            
								        
								    </div>
								</div>	
								<div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">City</label>
								    <div class="col-md-8 col-xs-12">                                            
								        <input type="text" name="group_city" value="" class="form-control"/>
								                                        
								        
								    </div>
								</div>  
								 
								
			                     </div>
			                     
		                        
			                   
			                   </div>
			                   
			                   <div class="row">
			                     <div class="col-md-6">
		                          <div class="form-group">
								    <label class="col-md-4 col-xs-12 control-label">Rating</label>
								    <div class="col-md-8 col-xs-12" style="padding-top:8px;">   
								  
								       <input name="group_rating_star" type="radio" value="1" class="auto-submit-star"  />
							          <input name="group_rating_star" type="radio" value="2" class="auto-submit-star"  />
							          <input name="group_rating_star" type="radio" value="3" class="auto-submit-star"  />
							          <input name="group_rating_star" type="radio" value="4" class="auto-submit-star"  />
							          <input name="group_rating_star" type="radio" value="5" class="auto-submit-star" />
							          <input type="hidden" name="group_rating" id="group_rating" value="" />
								
								  </div>
								</div>
		                        
				                </div>
				                 <div class="col-md-6">
				                   &nbsp;
				                </div>
				                
			                     <div class="col-md-12">
				                  {if $role_data[0].role_is_admin eq 'Yes'}
			                    
			                      <div class="form-group">
								    <label class="col-md-2 col-xs-12 control-label">Private Notes</label>
								    <div class="col-md-8 col-xs-12">                                            
								        
								        <textarea name="group_notes" class="form-control" rows="8"></textarea>
								                                         
								        
								    </div>
								</div>
			           
								{/if} 
				                  
				                </div>
			                   
			                   </div>
			                   
			                
			                     
			                    
			                     
			                   
			                    
			
			                 </div>
			                 
			             </div>
	              
	              </div>
	              <div class="modal-footer">
	                  <input type="hidden" name="add_company_ajax" value="1" />
	                  <button type="submit" id="add_company_button" class="btn btn-primary">Add Company</button>
	                  <button type="button" class="btn btn-default close_company_form" data-dismiss="modal">Close</button>
                  </div>
              </form>
              
          </div>
      </div>
  </div>