<div class="panel panel-default">

       <div class="panel-heading">
            <h3 class="panel-title">Quotation Information</h3>
			 </div>
			 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">
		       <tr>
			    <td colspan="2">
			    <div><strong>Quote Date</strong></div>
			    <div>{$smarty.session.quote.step_1.quote_date|date_format:"%d/%m/%Y"}</div>


			    </td>

			  </tr>
			  <tr>
			    <td colspan="2"><div><strong>Customer</strong></div>

			     <div>{$smarty.session.quote.step_1.customer_information.customer_fname} {$smarty.session.quote.step_1.customer_information.customer_lname}<br />
			    {$smarty.session.quote.step_1.customer_information.group_company}<br />
			    {$smarty.session.quote.step_1.customer_information.customer_address}<br />
			    {if $smarty.session.quote.step_1.customer_information.customer_city}
			    {$smarty.session.quote.step_1.customer_information.customer_city},{/if} {$smarty.session.quote.step_1.customer_information.customer_country}<br />
			    <br />
			    {if $smarty.session.quote.step_1.customer_information.customer_phone}
			    Phone: {$smarty.session.quote.step_1.customer_information.customer_phone}<br />{/if}
			    {if $smarty.session.quote.step_1.customer_information.customer_fax}
			    Fax: {$smarty.session.quote.step_1.customer_information.customer_fax}<br />{/if}
			    {if $smarty.session.quote.step_1.customer_information.customer_mobile}
			    Mobile: {$smarty.session.quote.step_1.customer_information.customer_mobile}<br />{/if}
			    {if $smarty.session.quote.step_1.customer_information.customer_email}
			    Email: {$smarty.session.quote.step_1.customer_information.customer_email} {/if}
			    {if $smarty.session.quote.step_1.customer_information.tin}
			    <br>
			    TIN: {$smarty.session.quote.step_1.customer_information.tin}{/if}
			    </div>

			    </td>

			  </tr>
			  {* <tr>
			    <td colspan="2"><div><strong>Payment Terms</strong></div>
			        <div>{$smarty.session.quote.step_1.quote_payment_terms}</div>

			    </td>

			  </tr> *}
			  {if $smarty.session.quote.step_1.quote_validity}
			  <tr>
			    <td colspan="2"><div><strong>Quote  Validity</strong></div>
			        <div>{$smarty.session.quote.step_1.quote_validity} Days</div>
			    </td>

			  </tr>
			  {/if}

			  <tr>
			    <td colspan="2"><div><strong>Tax</strong></div>
			        <div>{$smarty.session.quote.step_1.quote_tax} ({$smarty.session.quote.step_1.vat}%)</div>
			    </td>

			  </tr>

        {if $smarty.session.quote.step_1.quote_currency == 'USD'}
			  <tr>
			    <td colspan="2"><div><strong>Exchange Rate</strong></div>
			        <div>{$smarty.session.quote.step_1.exch_rate|number_format:2:".":","}</div>
			    </td>

			  </tr>
			  {/if}

			  {if $smarty.session.quote.step_1.quote_branch}
			  <tr>
			    <td colspan="2"><div><strong>Branch</strong></div>
			        <div>{$smarty.session.quote.step_1.quote_branch}</div>
			    </td>

			  </tr>
			  {/if}



			  <tr>
			    <td colspan="2"><div><strong>Show Details</strong>    <input type="checkbox" name="show_summary" id="show_summary" value="Y" checked="checked" onclick="show_summary(this);" /></div></td>

			  </tr>
             </table>

           </div>
          </div>


</div>
