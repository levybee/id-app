<h1>Confirmation &gt; Convert Item to Job Order</h1>
<div class="messageBox">
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tr>
      <td width="40"><div align="center"><img src="/images/messagebox_warning.png" alt="Alert" width="32" height="32" border="0" /></div></td>
      <td>The information on this quotation item will be prefilled in the job order form. <br />
      Please confirm by clicking the proceed button below.</td>
    </tr>
  </table>
</div>
<br />
<form name="form1" method="post" action="/jobs/add?start=1">
<table  border="1" cellpadding="5" cellspacing="5" class="table">
  <tr>
    <td colspan="2" class="header_row title">QUOTE INFORMATION</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Quote # </strong></div></td>
    <td width="200">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Quote Date </strong></div></td>
    <td>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Customer </strong></div></td>
    <td>{$quote_info[0].customer_fname} {$quote_info[0].customer_lname}</td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Representative </strong></div></td>
    <td>{$quote_info[0].customer_representative}</td>
  </tr>
  
  <tr>
    <td colspan="2" class="header_row title">LPO INFORMATION</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>LPO No. </strong></div></td>
    <td>{$quote_info[0].job_lpo} {if $quote_info[0].job_lpo_other}{$quote_info[0].job_lpo_other}{/if}</td>
  </tr>
</table>
<br />
<div id="summary">
  <table  border="1" cellspacing="5" cellpadding="5" class="table">
      <tr>
        <td colspan="4" class="header_row title"><strong>JOB INFORMATION</strong></td>
      </tr>
      <tr>
        <td width="100" class="header_row"><div align="right"><strong>Item Type</strong></div></td>
        <td width="200">{$quote_items[0].item_product} {if $quote_items[0].item_product_other}({$quote_items[0].item_product_other}){/if}</td>
        <td width="100" class="header_row"><div align="right"><strong>Title</strong></div></td>
        <td width="200">{$quote_items[0].item_title}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Origination</strong></div></td>
        <td>{$quote_items[0].item_origination}</td>
        <td class="header_row"><div align="right"><strong>Delivery Date</strong></div></td>
        <td>{if $quote_items[0].item_delivery_date eq '0000-00-00'}TBC{else}{$quote_items[quote_items].item_delivery_date|date_format:"%d %B %Y"}{/if}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Size</strong></div></td>
        <td>{$quote_items[0].item_paper_size} {if $quote_items[0].item_paper_size_other}({$quote_items[0].item_paper_size_other}){/if}</td>
        <td class="header_row"><div align="right"><strong>Orientation</strong></div></td>
        <td><label>{$quote_items[0].item_orientation|capitalize}</label>
            <label></label>
            <label></label></td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Cover Paper</strong></div></td>
        <td>{$quote_items[0].item_cover_paper_type} {if $quote_items[0].item_cover_paper_type_other}({$quote_items[0].item_cover_paper_type_other}){/if}</td>
        <td class="header_row"><div align="right"><strong>Description</strong></div></td>
        <td>{$quote_items[0].item_cover_paper_desc}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Paper Weight:</strong></div></td>
        <td>{$quote_items[0].item_cover_paper_weight} gsm</td>
        <td class="header_row"><div align="right"><strong>Print</strong></div></td>
        <td>{$quote_items[0].item_cover_color} {if $quote_items[0].item_cover_color_other}({$quote_items[0].item_cover_color_other}){/if}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
        <td><label>{$quote_items[0].item_cover_print_options|capitalize}</label>
            <label></label></td>
        <td class="header_row">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      {if $smarty.session.quote.item_product[0].product_2rows == 'Y'}
      <tr>
        <td class="header_row"><div align="right"><strong>Inner Paper</strong></div></td>
        <td>{$quote_items[0].item_inner_paper_type} {if $quote_items[0].item_inner_paper_type_other}({$quote_items[0].item_inner_paper_type_other}){/if}</td>
        <td class="header_row"><div align="right"><strong>Description</strong></div></td>
        <td>{$quote_items[0].item_inner_paper_desc}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Paper Weight</strong></div></td>
        <td>{$quote_items[0].item_inner_paper_weight} gsm</td>
        <td class="header_row"><div align="right"><strong>Print</strong></div></td>
        <td>{$quote_items[0].item_inner_color} {if $quote_items[0].item_inner_color_other}({$quote_items[0].item_inner_color_other}){/if}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
        <td><label>{$quote_items[0].item_inner_print_options|capitalize}</label>
            <label></label></td>
        <td class="header_row">&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      {/if}
      <tr>
        <td class="header_row"><div align="right"><strong>Pagination</strong></div></td>
        <td colspan="3">{$quote_items[0].item_pagination}</td>
      </tr>
      <tr>
        <td valign="top" class="header_row"><div align="right"><strong>Finishing</strong></div></td>
        <td colspan="3">
            {section name=item_finishing loop=$quote_items[0].item_finishing|unserialize}
                {assign var=finishing_array value=$quote_items[0].item_finishing|unserialize}
                {$finishing_array[item_finishing][0].finishing_type}; 
            {sectionelse}
                None
            {/section}        </td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Payment Terms</strong></div></td>
        <td colspan="3">{$quote_items[0].item_payment_terms}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Quantity # 1</strong></div></td>
        <td>{$quote_items[0].item_quantity_1|thousand_sep}</td>
        <td class="header_row"><div align="right"><strong>Price in Dhs # 1</strong></div></td>
        <td>{$quote_items[0].item_price_1|thousand_sep}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Quantity # 2</strong></div></td>
        <td>{$quote_items[0].item_quantity_2|thousand_sep}</td>
        <td class="header_row"><div align="right"><strong>Price in Dhs # 2</strong></div></td>
        <td>{$quote_items[0].item_price_2|thousand_sep}</td>
      </tr>
      <tr>
        <td class="header_row"><div align="right"><strong>Quantity # 3</strong></div></td>
        <td>{$quote_items[0].item_quantity_3|thousand_sep}</td>
        <td class="header_row"><div align="right"><strong>Price in Dhs # 3</strong></div></td>
        <td>{$quote_items[0].item_price_3|thousand_sep}</td>
      </tr>
      <tr>
        <td valign="top" class="header_row"><div align="right"><strong>Notes</strong></div></td>
        <td colspan="3">{$quote_items[0].item_notes}</td>
      </tr>
      <tr>
        <td valign="top" class="header_row"><div align="right"><strong>Special Remarks</strong></div></td>
        <td colspan="3">{$quote_items[0].item_special_remarks}</td>
      </tr>
      <tr>
        <td colspan="4" valign="top"><div align="right">
          <div align="right">
             <input type="hidden" name="item_id" id="item_id" value="{$quote_info[0].item_id}" />
             <input type="hidden" name="group_id" id="group_id" value="{$quote_info[0].group_id}" />
             <input type="submit" name="Submit" value="Proceed" class="input_button" />
          </div>
        </div></td>
      </tr>
    </table>
</div>
<br />
</form>