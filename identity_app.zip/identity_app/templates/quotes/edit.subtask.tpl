{if $message_ignore}
    <div class="alert alert-info" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message_ignore}
         </div>
    <br />
    {literal}
    <script type="text/javascript">
        alert("This window will now close. Please ensure to refresh previous window for new data.");
        window.close();
    </script>
    {/literal}
{/if}
 {* if $message}
  <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      {$message}
  </div>
 {/if *}
{if !$window_close}

  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Edit Item</h3>

      </div>
      <form id="items-form" class="form-horizontal" method="post" action="">
        
     {include file="quotes/quote_item_fields.tpl"}
	 
      <div class="panel-footer">
      <input type="hidden" name="process"  value="Y" />
      <button type="submit" name="Submit" class="btn btn-primary pull-right">Save</button>


      </div>
       </form>
  </div>
 

  {if $smarty.get.debug eq 'lev'}
  <pre>{$item_data[0]|@print_r}</pre>
  {/if}

{/if}
