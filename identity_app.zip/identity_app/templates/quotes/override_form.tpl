<div class="modal" id="overrideModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title">Override Outstanding</h4>
              </div>
              <form id="override_form" name="override_form" method="post" action="" class="form-horizontal">
	              <div class="modal-body">
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			                 <div class="panel-body">
			                     <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Comments</label>
									    <div class="col-md-8 col-xs-12">
									    <textarea name="comments" rows="4"  class="form-control"></textarea>
									    </div>

								</div>

			                   </div>

			             </div>

	              </div>
	              <div class="modal-footer">
	                  <input type="submit" name="override_submit" class="btn btn-primary" value="Submit">
                    <input type="hidden" name="override" value="1">
	                  <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                  </div>
              </form>

          </div>
      </div>
  </div>
