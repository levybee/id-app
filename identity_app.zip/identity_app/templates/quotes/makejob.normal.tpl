 <div id="summary" class="panel panel-default">
          
       <div class="panel-heading">
            <h3 class="panel-title">Quotation Items</h3>         
      </div>
		  <div class="panel-body panel-body-table">
		
		   <div class="table-responsive">
              
              {section name=quote_items loop=$quote_items}
            <table  class="table table-striped">
              <tr>
                <td colspan="3" class="header_row title"><strong>Item # {$smarty.section.quote_items.rownum}</strong></td>
                <td class="header_row title">
                <div align="right">
                  <a title="Convert to Job" href="/quotes/makejob?id={$quote_info[0].quote_id}&subtask=convert&subid={$quote_items[quote_items].item_id}&popup=true" onclick="popupURL(this.href, 'MakeJob_Item', '800', '500'); return false;"><img src="/images/success.png" alt="Convert to Job" width="16" height="16" border="0"></a> 
                </div></td>
              </tr>
              <tr>
                <td width="100" class="header_row"><div align="right"><strong>Item Type</strong></div></td>
                <td width="200">{$quote_items[quote_items].item_product} {if $quote_items[quote_items].item_product_other}({$quote_items[quote_items].item_product_other}){/if}</td>
                <td width="100" class="header_row"><div align="right"><strong>Title</strong></div></td>
                <td width="200">{$quote_items[quote_items].item_title}</td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Origination</strong></div></td>
                <td>{$quote_items[quote_items].item_origination}</td>
                <td class="header_row"><div align="right"><strong>Delivery Date</strong></div></td>
                <td>{if $quote_items[quote_items].item_delivery_date eq '0000-00-00'}TBC{else}{$quote_items[quote_items].item_delivery_date|date_format:"%d %B %Y"}{/if}</td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Size</strong></div></td>
                <td>{$quote_items[quote_items].item_paper_size} {if $quote_items[quote_items].item_paper_size_other}({$quote_items[quote_items].item_paper_size_other}){/if}</td>
                <td class="header_row"><div align="right"><strong>Orientation</strong></div></td>
                <td><label>{$quote_items[quote_items].item_orientation|capitalize}</label>
                    <label></label>
                    <label></label></td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Cover Paper</strong></div></td>
                <td>{$quote_items[quote_items].item_cover_paper_type} {if $quote_items[quote_items].item_cover_paper_type_other}({$quote_items[quote_items].item_cover_paper_type_other}){/if}</td>
                <td class="header_row"><div align="right"><strong>Description</strong></div></td>
                <td>{$quote_items[quote_items].item_cover_paper_desc}</td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Paper Weight:</strong></div></td>
                <td>{$quote_items[quote_items].item_cover_paper_weight} gsm</td>
                <td class="header_row"><div align="right"><strong>Print</strong></div></td>
                <td>{$quote_items[quote_items].item_cover_color} {if $quote_items[quote_items].item_cover_color_other}({$quote_items[quote_items].item_cover_color_other}){/if}</td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
                <td><label>{$quote_items[quote_items].item_cover_print_options|capitalize}</label>
                    <label></label></td>
                <td class="header_row">&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              
              {if $quote_items[quote_items].item_inner_paper_type}
              <tr>
                <td class="header_row"><div align="right"><strong>Inner Paper</strong></div></td>
                <td>{$quote_items[quote_items].item_inner_paper_type} {if $quote_items[quote_items].item_inner_paper_type_other}({$quote_items[quote_items].item_inner_paper_type_other}){/if}</td>
                <td class="header_row"><div align="right"><strong>Description</strong></div></td>
                <td>{$quote_items[quote_items].item_inner_paper_desc}</td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Paper Weight</strong></div></td>
                <td>{$quote_items[quote_items].item_inner_paper_weight} gsm</td>
                <td class="header_row"><div align="right"><strong>Print</strong></div></td>
                <td>{$quote_items[quote_items].item_inner_color} {if $quote_items[quote_items].item_inner_color_other}({$quote_items[quote_items].item_inner_color_other}){/if}</td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
                <td><label>{$quote_items[quote_items].item_inner_print_options|capitalize}</label>
                    <label></label></td>
                <td class="header_row">&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              
              {/if}
              <tr>
                <td class="header_row"><div align="right"><strong>Print Process</strong></div></td>
                <td colspan="3">{$quote_items[quote_items].item_print_process}</td>
              </tr>
              <tr>
                <td valign="top" class="header_row"><div align="right"><strong>Finishing</strong></div></td>
                <td colspan="3">
                    {section name=item_finishing loop=$quote_items[quote_items].item_finishing|unserialize}
                        {assign var=finishing_array value=$quote_items[quote_items].item_finishing|unserialize}
                        {$finishing_array[item_finishing][0].finishing_type}; 
                    {sectionelse}
                        None
                    {/section}        </td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Payment Terms</strong></div></td>
                <td colspan="3">{$quote_items[quote_items].item_payment_terms}</td>
              </tr>
              <tr>
                <td class="header_row"><div align="right"><strong>Quantity</strong></div></td>
                <td>{$quote_items[quote_items].item_quantity_1|thousand_sep}</td>
                <td class="header_row"><div align="right"><strong>Price{if $smarty.session.quote.step_1.currency} in {$smarty.session.quote.step_1.currency}{/if}</strong></div></td>
                <td>{$quote_items[quote_items].item_price_1|thousand_sep}</td>
              </tr>
              
              <tr>
                <td valign="top" class="header_row"><div align="right"><strong>Notes</strong></div></td>
                <td colspan="3">{$quote_items[quote_items].item_notes}</td>
              </tr>
              <tr>
                <td valign="top" class="header_row"><div align="right"><strong>Special Remarks</strong></div></td>
                <td colspan="3">{$quote_items[quote_items].item_special_remarks}</td>
              </tr>
            </table>
            <hr>
            {sectionelse}
          <p>No quote_items have been added to this quotation yet.</p>
            {/section}
              
              
            </div>
	 </div>   
	 

      
</div>



