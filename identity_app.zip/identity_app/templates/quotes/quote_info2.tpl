<div class="panel panel-default">
          
       <div class="panel-heading">
            <h3 class="panel-title">Quotation Information</h3>         
			 </div>
			 <div class="panel-body panel-body-table">
			
		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">
		       <tr>
			    <td colspan="2">
			    <div><strong>Quote Date</strong></div>
			    <div>{$quote_data.quote_date|date_format:"%d/%m/%Y"}</div>
			    
			    
			    </td>
			    
			  </tr>
			  <tr>
			    <td colspan="2"><div><strong>Customer</strong></div>
			    
			     <div>{$quote_data.customer_information.customer_fname} {$quote_data.customer_information.customer_lname}<br />
			    {$quote_data.customer_information.group_company}<br />
			    {$quote_data.customer_information.customer_address}<br />
			    {$quote_data.customer_information.customer_city}, {$quote_data.customer_information.customer_country}<br />
			    <br />
			    Phone: {$quote_data.customer_information.customer_phone}<br />
			    Fax: {$quote_data.customer_information.customer_fax}<br />
			    Mobile: {$quote_data.customer_information.customer_mobile}<br />
			    Email: {$quote_data.customer_information.customer_email}</div>
			    
			    </td>
			   
			  </tr>
			 
			  
             </table>  
     
                   
           </div>
          </div>    
          
         
</div>