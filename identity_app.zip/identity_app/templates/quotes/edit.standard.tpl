


<div id="summary" class="panel panel-default" style="display:none;">

		<div class="panel-heading">
		        <h3 class="panel-title">Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">item #</th>
							    <th>Description</th>
									<th>Qty</th>
							    <th>Unit Price {if $quote_data.currency}({$quote_data.currency}){/if}</th>
							    <th>Amount {if $quote_data.currency}({$quote_data.currency}){/if}</th>
							    <th width="50">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$quote_items}
						  <tr>
						    <td class="text-center">{$smarty.section.items.rownum}</td>

						    <td>
						    {$quote_items[items].product_name} {if $quote_items[items].item_product_other}({$quote_items[items].item_product_other}){/if} - {$quote_items[items].item_title}
						    <p style="line-height:18px;">

									{if $quote_items[items].stock_id}
									 Stock #{$quote_items[items].stock_id}: {$quote_items[items].product_specifications};
									{/if}

						      Origination: {$quote_items[items].item_origination};{if $quote_items[items].item_delivery_days} Delivery Days: {$quote_items[items].item_delivery_days};{/if}
							 {if $quote_items[items].item_paper_size}Size: {$quote_items[items].item_paper_size} {if $quote_items[items].item_paper_size_other} - {$quote_items[items].item_paper_size_other}{/if};{/if}
						      {if $quote_items[items].product_type eq 'Paper' || $quote_items[items].product_type eq 'Books'}
							{if $quote_items[items].item_orientation|capitalize}Orientation: {$quote_items[items].item_orientation|capitalize};{/if} 
							{if $quote_items[items].item_cover_paper_type || $quote_items[items].item_cover_paper_type_other}Cover Paper: {$quote_items[items].item_cover_paper_type} 
							{if $quote_items[items].item_cover_paper_type_other}({$quote_items[items].item_cover_paper_type_other}){/if}{/if}; 
							{if $quote_items[items].item_cover_paper_desc}Cover Paper Description: {$quote_items[items].item_cover_paper_desc};{/if} Paper Weight: {$quote_items[items].item_cover_paper_weight} gsm; {if $quote_items[items].item_cover_color}Print: {$quote_items[items].item_cover_color} {if $quote_items[items].item_cover_color_other}({$quote_items[items].item_cover_color_other}){/if};{/if} {if $quote_items[items].item_cover_print_options}Print Options: {$quote_items[items].item_cover_print_options|capitalize};{/if}{/if}
						    {if $quote_items[items].product_type eq 'Books'}Inner Paper: {$quote_items[items].item_inner_paper_type};
							 {if $quote_items[items].item_inner_paper_desc}Inner Paper Description: {$quote_items[items].item_inner_paper_desc};{/if} 
							{if $quote_items[items].item_inner_paper_weight}Inner Paper Weight: {$quote_items[items].item_inner_paper_weight} gsm;{/if} Inner Print: {$quote_items[items].item_inner_color}
							 {if $quote_items[items].item_inner_color_other}({$quote_items[items].item_inner_color_other}){/if}; 
							{if $quote_items[items].item_inner_print_options}Inner Print Options: {$quote_items[items].item_inner_print_options|capitalize};{/if} 
							{/if} {if $quote_items[items].item_print_process}Print Process: {$quote_items[items].item_print_process};{/if}

                             {if $quote_items[items].item_process}
							 {$quote_items[items].item_process}				
							{/if}
						      Finishing: {section name=item_finishing_summary loop=$quote_items[items].item_finishing}
			            	            {$quote_items[items].item_finishing[item_finishing_summary][0].finishing_type};
							            {sectionelse}
							           	 	None;
							            {/section}

           
						    </p>
						    {if $quote_items[items].item_notes}<p style="line-height:18px;">Notes: {$quote_items[items].item_notes}</p> {/if}
						    {if $quote_items[items].item_special_remarks}<p style="line-height:18px;">Special Remarks: {$quote_items[items].item_special_remarks}</p>{/if}
                        
						     {if $quote_items[items].item_wht_amount > 0}<p>WHT Amount: {$quote_items[items].item_wht_amount} {$quote_data.currency}</p> {/if}
                             
						{* <pre>{$quote_items[items]|@print_r}</pre>		 *}
						    </td>
								<td>
								 <input type="number"  name="item_qty[{$quote_items[items].item_id}]" id="item_qty{$quote_items[items].item_id}" data-item_id="{$quote_items[items].item_id}" class="form-control item_qty" value="{$quote_items[items].item_quantity_1}" step="any">
							 </td>
						    <td>
									<input type="number"  name="item_unit_price[{$quote_items[items].item_id}]" id="item_unit_price{$quote_items[items].item_id}" data-item_id="{$quote_items[items].item_id}" class="form-control item_unit_price" value="{$quote_items[items].item_price_1}" step="any">
							</td>
						    <td id="amount{$quote_items[items].item_id}">{$quote_items[items].item_total_price|number_format:0:".":","}</td>

						    <td>
						      <a title="Edit Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/edit/?id={$quote_data.quote_id}&subtask=edit&subid={$quote_items[items].item_id}"><span class="fa fa-pencil"></span></a>
			                   <a title="Delete Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/edit/?id={$quote_data.quote_id}&subtask=delete&subid={$quote_items[items].item_id}"><span class="fa fa-times"></span></a>
                    <input type="hidden" class="amount{$quote_items[items].item_id} amount" value="{$quote_items[items].item_total_price}">
								 </td>

						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="6"><div>No Items have been added to this quotation yet.</td>
						  </tr>
						  {/section}

						  {if $quote_items|@count gt 0}
						  <tr class="info">
						   <td colspan="4" align="right"><strong>Sub Total</strong></td><td id="subtotal">{$quote_items[0].sub_total|number_format:0:".":","}</td><td></td>
						  </tr>
						  {if $quote_data.tax eq 'Taxable'}
						  <tr class="warning" >
						   <td colspan="4" align="right"align="right"><strong>Taxes</strong></td><td id="taxes">{$quote_items[0].tax|number_format:0:".":","}</td><td></td>
						  </tr>
						  {/if}
						  <tr class="success">
						   <td colspan="4" align="right"><strong>Total</strong></td><td id="total">{$quote_items[0].grand_total|number_format:0:".":","}</td><td></td>
						  </tr>
						  {/if}

                        </tbody>
                    </table>

                </div>

  </div>


</div>

</form>

{literal}
<script type="text/javascript">

	var prod = new Array();
{/literal}
	{section name=product_types loop=$product_types}
	prod[{$product_types[product_types].product_id}] = '{$product_types[product_types].product_2rows}';
	{/section}
{literal}
</script>
{/literal}

{if !$no_edit}
<form id="quotes-form" class="form-horizontal" method="post" action="/quotes/edit?id={$smarty.get.id}&subtask=new">
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Add New Item</h3>

      </div>

      {include file="quotes/quote_item_fields.tpl"}
	  
      <div class="panel-footer">
      <input type="hidden" name="next_step" id="next_step" value="three" />
        <input type="submit" name="add_item" class="btn btn-primary pull-right" value="Add Item" />


      </div>
  </div>
  </form>
	{/if}
