<div class="panel panel-default">
      <div class="panel-body">
      <h3>Duplicate Quote</h3>
      
      
        {if $error_message}
		 <div class="alert alert-danger" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$error_message}
         </div>
		{/if}
        {if $successful}

		<table border="0" cellspacing="0" cellpadding="5">
		  <tr>
		    <td>
		    <button type="submit"  name="Print" class="btn btn-primary" onclick="popupPDF('quote', {if $duplicate_quote_id}{$duplicate_quote_id}{else}0{/if});">View &amp; Print Quotation</button></td>
		    
		    <td>
		    <button type="submit"  name="email_quote" class="btn btn-primary" onclick="toggle2('email_form');">Email Quote</button>
		    </td>
		    <td>
		    <form action="/quotes/edit/?id={$duplicate_quote_id}" method="post">
		  
		  <button type="submit" name="Submit" class="btn btn-primary">Edit Quote</button>
		   </form>
		   </td>
		    <td><form action="/quotes/confirm/?id={$duplicate_quote_id}&start=1" method="post">
		 
		  <button type="submit" name="confirm" class="btn btn-primary">Confirm Quote</button>
		 </form>
		</td>
		  </tr>
		</table>
		{/if}
		      
      </div>
    
    </div>

{include file="quotes/mail.tpl"}
