 
 <div class="modal" id="approve_modal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Approve Quote
			#{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</h4>
              </div>
              <form id="approve_form" name="approve_form" method="post" action="/requisitions" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="response"></div>
	                 
	                 
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
			                 
			                
			                 <div class="panel-body form-group">
			                   <div class="row">
			                 
			                     
			                       <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Payment Terms</label>
									    <div class="col-md-6 col-xs-12">        
									     <select name="quote_payment_terms" id="quote_payment_terms" class="form-control">
									      <option value="0">Please Select</option>
									      
									      {section name=item_payment_terms loop=$item_payment_terms}
									      
									       <option value="{$item_payment_terms[item_payment_terms].payment_term}" {if $item_payment_terms[item_payment_terms].payment_term eq $quote_info[0].quote_payment_terms}selected{/if}>{$item_payment_terms[item_payment_terms].payment_term}</option>
									      
									      {/section}
									    
									     </select>
									    </div>
									  </div>
									  
									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Advance Amount ({$quote_info[0].currency})</label>
									    <div class="col-md-6 col-xs-12"> 
									     
									      <input name="advance_amount" type="text" value="" class="form-control force_decimal" />    
									      
									    </div>
									  </div>
									  
									 
									   <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Advance Mode</label>
									    <div class="col-md-6 col-xs-12"> 
									     
									      <select name="advance_mode" id="advance_mode" class="form-control">
										      <option value="">Please select..</option>
										      <option value="Cash">Cash</option>
										      <option value="Cheque">Cheque</option>
										      <option value="Transfer">Transfer</option>
									      
									     </select>
									      
									    </div>
									  </div>
									  
									   <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Advance Info</label>
									    <div class="col-md-6 col-xs-12"> 
									     
									      <textarea name="advance_info" class="form-control" rows="5"> </textarea>   
									      
									    </div>
									  </div>
									  
									   <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Customer's Credit Limit</label>
									    <div class="col-md-6 col-xs-12">        
									     <p class="form-control-static">{$quote_info[0].credit_limit_currency} {$quote_info[0].credit_limit_amount}</p>
									    </div>
									  </div>
									  
									   <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Remaining Credit</label>
									    <div class="col-md-6 col-xs-12">        
									     <p class="form-control-static">TZS {$remaining_credit|number_format:2:".":","}</p>
									    </div>
									  </div>
									  
									 
			                     
			                   </div>
			               
			
			                 </div>
			                 
			             </div>
	              
	              </div>
	              <div class="modal-footer">
	                  <input type="hidden" name="quote_id" value="{$quote_info[0].quote_id}" >
					  <input type="hidden" name="ajax_action" value="approve" >
	                  <input type="submit" name="approve_quote" class="btn btn-primary" value="Approve">
	                  <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                  </div>
              </form>
              
          </div>
      </div>
  </div>