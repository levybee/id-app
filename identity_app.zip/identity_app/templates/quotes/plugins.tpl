<!-- PAGE PLUGINS -->
       <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
       <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
       <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>
       <script type="text/javascript" src="/js/plugins/star-rating/jquery.rating.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-timepicker.min.js"></script>
       <script type="text/javascript" src="/js/plugins/moment.min.js"></script>
       <script type="text/javascript" src="/js/jquery/jquery.livequery.min.js"></script>
       <script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>
       <script type="text/javascript" src="/js/jquery/relcopy.js"></script>
       <script type="text/javascript" src="/js/new_company_ajax.js"></script>


       <script type='text/javascript' src='/js/plugins/jquery-validation/jquery.validate.js'></script>




{literal}

<script type="text/javascript">


 var obj = null;

 $('#group_id').livequery('change',function() { //start function when any link is clicked


   obj = document.getElementById('customer_id');
   content_show = document.getElementById('group_id').value;
    console.log('Group ID changed: ' + content_show);
   if(content_show != 51){
     $('.customer').show();
     $('.walk_in').hide();
     ajaxLoad(content_show, obj);
   }else{
     $('.customer').hide();
     $('.walk_in').show();
   }

 });

 // Due Dates
 $.each($('input[name="no_sample"]'), function(i, item) {
   console.log(i, item)

   // $("#check_all_print").on('change',function () {
   // })

 });

 $("input[type='checkbox'][name^='no_sample']").each(function () {
      let itemId = $(this).attr("name").match(/\d+/)[0]; // Extract item_id from name attribute
      let sampleDiv = $(".sample" + itemId);

      // Hide if checked on page load
      if ($(this).is(":checked")) {
        sampleDiv.hide();
      }

      // Toggle visibility on change
      $(this).change(function () {
        if ($(this).is(":checked")) {
          sampleDiv.hide();
        } else {
          sampleDiv.show();
        }
      });
    });


 function ajaxLoad(content_show, obj) {

   // Load Content
   $.ajax({
     method: "get",url: "/modules/quotes/customers_ajax.php",data: "group="+content_show,
     dataType: "script",
     beforeSend: function(){ obj.options.length = 0; obj.options[obj.options.length] = new Option('Loading...','0'); }, //show loading just when link is clicked
     complete: function(){
       // Do nothing
     }, //stop showing loading when the process is complete
     success: function(script){ //so, if data is retrieved, store it in html

       console.log('script', script);

       var obj = document.getElementById('customer_id');

       // alert(script);
       obj.options.length = 0;
       obj.options[obj.options.length] = new Option('Please Select','0');
       eval(script); // process JS

       if(obj.options.length == 2){
         obj.selectedIndex = 1;
       }

      }
    }); //close $.ajax(

 }

 // Add New Company Form
 $('.close_company_form').on('click', function(e){

   $('#new_company_form').modal('hide');

 });

 $('.overrideBtn').on('click', function(e){
   $('#overrideModal').modal('show');
 });


 $('#group_id').on('change', function (e) {

    console.log('Company Select: ' + $(this).val());

    if($(this).val() == -1){

      //$('#new_company_form').css('display','block');
     // $('#new_company_form').modal('show');

    }


 });

 $("#group_id").select2({
   placeholder: "Type to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/customers_group.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $("#stock_id").select2({
   placeholder: "Type to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/stock.php?add_item=1",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
                 category: 'Stationary FG'
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $('#stock_id').change(function() {

    $('#stock_description').val($(this).text());

 });

 var $tax = $('#tax').val();
 if($tax == 'Taxable'){
   $('.vat_field').show();
   $('#vat').val('18');
 }else{
   $('.vat_field').hide();
   $('#vat').val('0');
 }

 $('#tax').change(function() {

    if($(this).val() == 'Taxable'){
      $('.vat_field').show();
      $('#vat').val('18');
    }else{
      $('.vat_field').hide();
      $('#vat').val('0');
    }

 });

 if($('#product_id').val() == 114){
   $('.stock_field').show();
   $('.hide-stationary').hide();
}else{
   $('.stock_field').hide();
   $('.hide-stationary').show()
}

 $('#product_id').change(function() {
   console.log('product_id..', $(this).val());

    if($(this).val() == 114){
      $('.stock_field').show();
      $('.hide-stationary').hide();
    }else{
      $('.stock_field').hide();
      $('.hide-stationary').show()
    }

 });

 $('.auto-submit-star').rating({
       callback: function(value, link){

        document.getElementById('group_rating').value = value;

        // To submit the form automatically:
        //this.form.submit();

       }
      });

 $('#item_price_1').on('blur', function() {

   var amount = $('#item_price_1').val().replace(/^\s+|\s+$/g, '');

   if( $.isNumeric(amount) ) {

     if( ($('#item_price_1').val() != '') && (!amount.match(/^$/) )){

         $('#item_price_1').val( parseFloat(amount).toFixed(2));

     }

   } else {

     // Set it to 0.00
     $('#item_price_1').val('0.00');

   }

 });


 $('.item_unit_price').on('blur', function(){
   calcItemAmount($(this));
 });

 $('.item_qty').on('blur', function(){
   calcItemAmount($(this));
 });

var customer_id =  $("#customer_id").val();

 $("#receipt_id").select2({
placeholder: "Type to receipt id to search...",
minimumInputLength: 1,
ajax: {
  url: "/ajax/receipts.php",
  dataType: 'json',
  delay: 250,
  data: function (params) {

      return {
          q: params.term, // search term
          customer_id: customer_id,
          no_order_link: 1
      };
  },
  processResults: function (data) { // parse the results into the format expected by Select2.
      // since we are using custom formatting functions we do not need to alter the remote JSON data
      return { results: data };
  },
  cache: true
}

});

$('#receipt_id').change(function() {
  var currency = $(this).select2('data')[0].receipt_currency;
  var receipt_amount = $(this).select2('data')[0].receipt_amount;
  $('.receipt_amount').text('Amount: ' + formatNumber(receipt_amount) + ' ' + currency );
});

$('#job_lpo').change(function() {

    if($(this).val() == 'Advance Paid' || $(this).val() == 'Full Amount Paid'){
      $('.receipt_field').show();
      $('#job_lpo_other').hide();
    }else{
      $('.receipt_field').hide();
    }

 });

 function calcItemAmount(object){
   var item_id = object.data('item_id');
   var qty = $('#item_qty'+item_id).val();
   var unit_price = $('#item_unit_price'+item_id).val();
   if( $.isNumeric(unit_price) && $.isNumeric(qty) ) {
     amount = unit_price * qty;
     $('#amount'+item_id).html(formatNumber(amount));
     $('.amount'+item_id).val(amount);
   }

   calTotals();

 }

 function calTotals(){

    var total = 0;
    var subTotal = 0;
    var taxes = 0;
    var tax = $('#tax').val();
    $('.amount').each(function(){
       subTotal += parseFloat($(this).val());
    });

    if(tax = 'Taxable'){
      taxes = subTotal * 0.18;
    }

    total = taxes + subTotal;

    $('#subtotal').html(formatNumber(subTotal));
    $('#taxes').html(formatNumber(taxes));
    $('#total').html(formatNumber(total));

 }

 function formatNumber(num) {
   console.log('num', num);
   return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
 }

 // Keep summary details if checkbox is checked
 $(function(){

   if($('#show_summary').is(':checked')) {

     localStorage.show_summary = 'true';
   }

     var check_summary = localStorage.show_summary === 'true'? true: false;
     $('#show_summary').prop('checked', check_summary || false);

     if(localStorage.show_summary === 'true'){

       $('#summary').show();
     }
 });



 $('#show_summary').on('change', function() {
     localStorage.show_summary = $(this).is(':checked');
     console.log(localStorage.show_summary);
 });

 // Size Other
 var item_paper_size = $('#item_paper_size').val();

 if(item_paper_size){
   if(item_paper_size == 9){
     console.log('item_paper_size show', item_paper_size);
     $('#item_paper_size_other').show();
   }
 }



 /* if($('#next_step_info_0').is(':checked')) {

   var jvalidate = $("#quotes-form").validate({
         ignore: [],
         rules: {
             item_price_1: {
                           required: true,
                           number: true
               },
               item_title: {
                     required: true
                 }
             }
         });


   } */

   {/literal}{if $smarty.get.id}{literal}


      // Quotes approval
       // $('#approve').on('click', function(){

       // 	console.log('Approval..');

       // 	$('#approve_modal').modal('show');


       // });

       $('#lpo').on('click', function(){

         $('#lpo_modal').modal('show');

       });

       $('#approve_form').submit(function(e){


       e.preventDefault();

       $('input[name="approve_quote"]').val('Sending...').attr('disabled','disabled');

         var post_url = "/quotes/ajax";
       var post_data = $(this).serialize();


       console.log('Post data ', post_data);

       $.ajax({
         type: 'POST',
         url: post_url,
         data: post_data,
         dataType:'json',
         success	:	function(data){


              console.log('Data:' + JSON.stringify(data));

              var alert_class = (data.error == true)? 'danger' : 'success';

              var msg_html = "<ul>";
              $.each(data.msg, function(i, item) {
                msg_html += "<li>"+ data.msg[i] +"</li>";
             });
              msg_html += "</ul>";

              $('#response').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

              $('input[name="approve_quote"]').val('Submit').removeAttr('disabled');

              if(data.error == false){

                $('#approve_form').reset();

                setTimeout(function(){

                   $('#approve_modal').modal('hide');

               },4000);

                location.reload();

              }

           },
           error : function(XMLHttpRequest, textStatus,
               errorThrown) {

             console.log("Status: " + textStatus);
             console.log("Error: " + errorThrown);

           }


       });


       });


   $('#lpo_form').submit(function(e){


       e.preventDefault();

       $('input[name="job_lpo"]').val('Sending...').attr('disabled','disabled');

         var post_url = "/quotes/ajax";
       var post_data = $(this).serialize();

       $.ajax({
         type: 'POST',
         url: post_url,
         data: post_data,
         dataType:'json',
         success	:	function(data){


              console.log('Data:' + JSON.stringify(data));

              var alert_class = (data.error == true)? 'danger' : 'success';

              var msg_html = "<ul>";
              $.each(data.msg, function(i, item) {
                msg_html += "<li>"+ data.msg[i] +"</li>";
             });
              msg_html += "</ul>";

              $('#lpo_response').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

              $('input[name="job_lpo"]').val('Submit').removeAttr('disabled');

              if(data.error == false){

                $('#lpo_form').reset();

                setTimeout(function(){

                   $('#lpo_modal').modal('hide');

               },4000);

                location.reload();

              }

           },
           error : function(XMLHttpRequest, textStatus,
               errorThrown) {

             console.log("Status: " + textStatus);
             console.log("Error: " + errorThrown);

           }


       });


       });

   {/literal}{/if}{literal}


</script>
{/literal}

{if $smarty.session.quote.step_1.customer_information.group_id && $smarty.session.current_step != 'two'}
       {literal}
       <script type="text/javascript">

       $(document).ready(function(){


         obj = document.getElementById('customer_id');
         var group_id = {/literal}{$smarty.session.quote.step_1.customer_information.group_id}{literal};
     var group_company_text = "{/literal}{$smarty.session.quote.step_1.customer_information.group_company}{literal}";
     var customer_id =  {/literal}{$smarty.session.quote.step_1.customer_information.customer_id}{literal};

     //console.log('ID: '+ group_id);

       ajaxLoad(group_id, obj);

       var newOption = new Option(group_company_text, group_id, true, true);
       $("#group_id").append(newOption).trigger('change');
       $('#customer_id').val(customer_id);


       });


       </script>
       {/literal}

{/if}


<!-- END PAGE PLUGINS -->
