
          <form name="form1" class = "form-horizontal" method="post" action="/quotes/confirm?id={$smarty.get.id}" enctype="multipart/form-data">
           <div class="panel panel-default">
               {* <div class="panel-heading">
                   <h3 class="panel-title">QUOTE INFORMATION</h3>

               </div> *}

               <div class="panel-body form-group">
                  <div class="row">
                    <h5>QUOTE INFORMATION</h5>
                    <br /> <br />
                    <div class="col-md-12">
                      <label class="col-md-2 col-xs-12 control-label">Customer</label>
                      <div class="col-md-10 col-xs-12">
                      <p class="form-control-static" >
                        {$quote_info[0].group_company} - {$quote_info[0].customer_fname} {$quote_info[0].customer_lname}
                      </p>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group" style="padding-bottom:15px;">
                           <label class="col-md-4 col-xs-12 control-label">Quote #</label>
                            <div class="col-md-6 col-xs-12">
                            <p class="form-control-static" >
                                {$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}
                            </p>
                         </div>
                       </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group" style="padding-bottom:15px;">
                      <label class="col-md-4 col-xs-12 control-label">Quote Date</label>
                      <div class="col-md-6 col-xs-12">
                      <p class="form-control-static" >
                          {$quote_info[0].quote_date|date_format:"%d %B %Y"}
                      </p>
                      </div>
                      </div>
                    </div>



                    <div class="col-md-6">
                      <div class="form-group" style="padding-bottom:15px;">
                      <label class="col-md-4 col-xs-12 control-label">Designer <span class="asterisk">*</span></label>
                      <div class="col-md-6 col-xs-12">
                        <select name="employee_id" id="employee_id" class="form-control" required>
                               <option value="">Select..</option>
                        {section name=employees loop=$employees}

                        <option value="{$employees[employees].id}" {if $smarty.post.employee_id eq $employees[employees].id}selected{/if}>{$employees[employees].first_name} {$employees[employees].last_name}</option>

                        {/section}

                        </select>
                      </div>
                      </div>
                    </div>

                    <div class="col-md-6">
                     <div class="form-group" style="padding-bottom:15px;">
                         <label class="col-md-4 control-label">Department</label>
                         <div class="col-md-6 col-xs-12">
   	                          <select name="department_id" id="department_id" class="form-control">

   						      {section name=departments loop=$departments}

   						      <option value="{$departments[departments].department_id}" {if $smarty.post.department_id eq $departments[departments].department_id}selected{elseif $config.default_department_id eq $departments[departments].department_id}selected{/if}>{$departments[departments].department_name}</option>

   						      {/section}

   						    </select>
   					       </div>
                     </div>
                   </div>

                    <div class="col-md-6">
                      {* <div class="form-group">
                      <label class="col-md-4 col-xs-12 control-label">Due Date <span class="asterisk">*</span></label>
                      <div class="col-md-6 col-xs-12">
                      <input name="job_due_date" type="text" id="job_due_date" value="{if $smarty.post.job_due_date}{$smarty.post.job_due_date|date_format:'%Y-%m-%d'}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control datepicker" readonly="true" />
                      </div>
                      </div> *}
                      <div class="form-group" style="padding-bottom:15px;">
                        <label class="col-md-4 col-xs-12 control-label">Invoicing Type <span class="asterisk">*</span></label>
                        <div class="col-md-6 col-xs-12">
                          <select name="invoicing_type" id="invoicing_type" class="form-control" required>
                              <option value="">Select..</option>
                              <option value="Partial Invoicing Applicable" {if $smarty.post.invoicing_type eq "Partial Invoicing Applicable"}selected{/if}>Partial Invoicing Applicable</option>
                              <option value="Full Invoicing Applicable" {if $smarty.post.invoicing_type eq "Full Invoicing Applicable"}selected{/if}>Full Invoicing Applicable</option>
                            </select>
                        </div>
                      </div>
                    </div>


                    {* <div class="col-md-6">
                      <div class="form-group">
                          <label class="col-md-4 control-label">Due Time</label>
                          <div class="col-md-6">

    					    {html_select_time prefix="job_due_" display_seconds=false use_24_hours=true minute_interval=15}
                          <div class="clearfix" style="height:15px;"></div>
                          </div>
                      </div>
                    </div> *}



                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="col-md-4 col-xs-12 control-label">LPO No. <span class="asterisk">*</span></label>
                      <div class="col-md-6 col-xs-12">
                        <select name="job_lpo" id="job_lpo" class="form-control" onchange="checkOther(this.value, 'LPO Number', 'job_lpo_other');" required>
                            <option value="">Select..</option>
                            <option value="Signed Quote" {if $smarty.post.job_lpo eq "Signed Quote"}selected{/if}>Signed Quote</option>
                            <option value="Verbal Approval" {if $smarty.post.job_lpo eq "Verbal Approval"}selected{/if}>Verbal Approval</option>
                            <option value="Email Confirmation" {if $smarty.post.job_lpo eq "Email Confirmation"}selected{/if}>Email Confirmation</option>
                            <option value="LPO Number" {if $smarty.post.job_lpo eq "LPO Number"}selected{/if}>LPO Number</option>
                               <option value="Advance Paid" {if $smarty.post.job_lpo eq "Advance Paid"}selected{/if}>Advance Paid</option>
                                 <option value="Full Amount Paid" {if $smarty.post.job_lpo eq "Full Amount Paid"}selected{/if}>Full Amount Paid</option>
                          </select>
                            <input name="job_lpo_other" type="text" id="job_lpo_other" value="{if $smarty.post.job_lpo_other}{$smarty.post.job_lpo_other}{/if}" size="10" class="form-control"  style="{if $smarty.post.job_lpo !== "LPO Number"}display:none;{/if} float:left; width:100px; margin-top:5px;" /></td>
                           <input type="hidden" id="customer_id" value="{$quote_info[0].customer_id}">
                              </div>
                    </div>

                    <div class="form-group receipt_field" style="padding-bottom:15px; {if $smarty.post.job_lpo != 'Advance Paid' && $smarty.post.job_lpo != 'Full Amount Paid'}display:none;{/if}">
                      <label class="col-md-4 col-xs-12 control-label">Receipt <span class="asterisk">*</span></label>
                      <div class="col-md-6 col-xs-12">
                        <select name="receipt_id" id="receipt_id"  class="form-control" style="width:100%"></select>
                      </div>
                    </div>
                  </div>

                  <div class="col-md-6">

                  </div>

                  </div>

                  <div class="row">
                   <br /> <br />
                   <h5>DELIVERY INFORMATION</h5>
                   <div class="delivery col-md-12" style="padding-bottom:15px;">
                     <div class="col-md-6">

                          <div class="form-group">
                             <label class="col-md-4 control-label">Contact Name <span class="asterisk">*</span></label>
                             <div class="col-md-8 col-xs-12" style="padding:0;">
                                  <div class="col-xs-8">
                                    <input name="job_delivery_name[]" id="job_delivery_name" type="text"  value="{$smarty.post.job_delivery_name[0]}" class="form-control"  />
                                  </div>
                                  <div class="col-xs-4" style="padding:0;">
                                    <select name="job_delivery_name_select[]" id="job_delivery_name_select" onchange="fillContact(this)" class="form-control select_link">
       					        	<option value="0">Select..</option>
       					        	{section name=contact_list loop=$contact_list}
       					        	<option value="{$contact_list[contact_list].customer_fname} {$contact_list[contact_list].customer_lname}"  data-address="{$contact_list[contact_list].customer_address}" data-phone="{$contact_list[contact_list].customer_phone} {if $contact_list[contact_list].customer_mobile}{if $contact_list[contact_list].customer_phone} | {/if}{$contact_list[contact_list].customer_mobile}{/if}" >{$contact_list[contact_list].group_company} - {$contact_list[contact_list].customer_fname} {$contact_list[contact_list].customer_lname}</option>
       						        {/section}
       						     </select>
                                  </div>


       	                  </div>
                         </div>
                         <div class="form-group">
                             <label class="col-md-4 control-label">Address</label>
                             <div class="col-md-8 col-xs-12">

       					    <input name="job_delivery_address[]" id="job_delivery_address" type="text"  value="{$smarty.post.job_delivery_address[0]}" class="form-control"  />

                             </div>
                         </div>



                     </div>

                     <div class="col-md-6">

                          <div class="form-group">
                             <label class="col-md-4 control-label">Phone No. <span class="asterisk">*</span></label>
                             <div class="col-md-8 col-xs-12">
                             <input name="job_delivery_phone[]" id="job_delivery_phone" type="text" value="{$smarty.post.job_delivery_phone[0]}" class="form-control" />
                             </div>
                         </div>


                     </div>

                   </div>

                  <a href="#" class="copy" rel=".delivery"><span class="fa fa-plus text-info"></span> Add More Contacts</a>

                  </div>

                  <div class="row">
                    <br>
                    {section name=items loop=$quote_items}

                    <div class="col-md-12">
                      <h5>Item #{$smarty.section.items.rownum}:
                      {if $quote_items[items].product_name}{$quote_items[items].product_name}{else}{$quote_items[items].item_product}{/if}
                      {if $quote_items[items].stock_name}- {$quote_items[items].stock_name}{/if}
                    </h5>
                      <div class="col-md-6">
                        <label class="col-md-4 col-xs-12 control-label">&nbsp;</label>
                        <div class="col-md-5 col-xs-12" style="padding-left:20px;">
                          <div class="checkbox pull-left">
                              <label><input type="checkbox" name="no_sample[{$quote_items[items].item_id}]" value="1"> No Sample</label>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12">
                      <div class="form-group col-md-6" >
                          <label class="col-md-4 col-xs-12 control-label">Job Due Date</label>
                          <div class="col-md-6 col-xs-12">
                              <div class="input-group date">
                                  <input type="text" class="form-control datepicker" name="job_due_date[{$quote_items[items].item_id}]"  value="{if $smarty.post.job_due_date[{$quote_items[items].item_id}]}{$smarty.post.job_due_date[{$quote_items[items].item_id}]|date_format:'%Y-%m-%d'}{else}{/if}" autocomplete="off" readonly="readonly">
                                  <span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
                              </div>
                          </div>
                      </div>
                      <div class="form-group col-md-6">
                      <label class="col-md-5 col-xs-12 control-label">Job Due Time</label>
                      <div class="col-md-5 col-xs-12">
                      <div class="input-group bootstrap-timepicker">
                         <input type="text" name="job_due_time[{$quote_items[items].item_id}]" value="{$smarty.post.job_due_time[{$quote_items[items].item_id}]}" autocomplete="off" class="form-control timepicker24"/>
                         <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                      </div>
                      </div>
                      </div>
                        </div>


                      <div class="col-md-12 sample{$quote_items[items].item_id}">
                        <div class="form-group col-md-6" >
                            <label class="col-md-5 col-xs-12 control-label">Sample Due Date</label>
                            <div class="col-md-5 col-xs-12">
                                <div class="input-group date">
                                    <input type="text" class="form-control datepicker" name="sample_due_date[{$quote_items[items].item_id}]"  value="{if $smarty.post.sample_due_date[{$quote_items[items].item_id}]}{$smarty.post.sample_due_date[{$quote_items[items].item_id}]|date_format:'%Y-%m-%d'}{else}{/if}" autocomplete="off" readonly="readonly">
                                    <span class="input-group-addon add-on"><span class="glyphicon glyphicon-calendar"></span></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                        <label class="col-md-5 col-xs-12 control-label">Sample Due Time</label>
                        <div class="col-md-5 col-xs-12">
                        <div class="input-group bootstrap-timepicker">
                           <input type="text" name="sample_due_time[{$quote_items[items].item_id}]" value="{$smarty.post.sample_due_time[{$quote_items[items].item_id}]}" autocomplete="off" class="form-control timepicker24"/>
                           <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                        </div>
                        </div>
                        </div>
                      </div>

                    </div>
                    {/section}
                  </div>

                  <div class="row">
                   <br /> <br />
                   <h5>DOCUMENTS</h5>

                   <div class="col-md-6">
                   <div class="form-group">
                      <label class="col-md-4 control-label">Attachment</label>
                      <div class="col-md-6 col-xs-12">
                          <input name="attachment_file" type="file" id="attachment_file" class="form-control" style="max-width:300px;" />
                      </div>
                   </div>
                   </div>

                   <div class="col-md-6">
                   <div class="form-group">
                      <label class="col-md-4 control-label">Description</label>
                      <div class="col-md-6 col-xs-12">
                          <input name="attachment_name" type="text" id="attachment_name" class="form-control" style="max-width:300px;"/>
                      </div>
                   </div>
                   </div>
                 </div>
               </div>

               <div class="panel-footer">
                 <input type="hidden" name="next_step" id="next_step" value="two" />
                   <button type="submit" name="submit" class="btn btn-primary pull-right" {if $outstanding}disabled{/if}>Confirm Quote</button>
               </div>


               </div>



           </div>

         </form>


          </div>

</div>