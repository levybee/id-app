

<div class="panel panel-default">

       <div class="panel-heading">
            <h3 class="panel-title">Quotation Information</h3>
			 </div>
			 <div class="panel-body panel-body-table">

			   <div class="table-responsive">
			     <table class="table table-striped">
			       <tr>
					    <td colspan="2"><div><strong>Quote #</strong></div>
					     <div>{$quote_data.quote_date|substr:0:4}-{$quote_data.quote_date|substr:5:2}-{$quote_data.quote_id|leading_zero:5}-{$quote_data.user_fname|substr:0:1}{$quote_data.user_lname|substr:0:1}</div>
					    </td>

					  </tr>
					  <tr>
					    <td colspan="2"><div><strong>Quote Date</strong></div>
					      <div>{$quote_data.quote_date|date_format:"%d/%m/%Y"}</div>
					    </td>

					  </tr>
					  <tr>
					    <td colspan="2"><div><strong>Customer</strong></div>
					      <div>
						    {if $quote_data.customer_id eq 0}
						    {$quote_data.customer_fname} {$quote_data.customer_lname}<br />
						    {$quote_data.group_company}<br />
						    {$quote_data.customer_address}<br />
						    {$quote_data.customer_city}, {$quote_data.customer_country}<br />
						    <br />
						    Phone: {$quote_data.customer_phone}<br />
						    Fax: {$quote_data.customer_fax}<br />
						    Mobile: {$quote_data.customer_mobile}<br />
						    Email: {$quote_data.customer_email}
						    {else}
						    {$quote_data.quote_customer}
						    {/if}
					    </div>

					    </td>

					  </tr>

            <tr>
					    <td colspan="2"><div><strong>Tax</strong></div>
                {if $step == 'one'}
                <div class="form-group">
                   <select name="tax" id="tax" class="form-control">
    				            <option value="Taxable"  {if $smarty.post.tax eq "Taxable" || $quote_data.tax eq "Taxable"}selected{/if}>Taxable</option>
    				        	<option value="Exempt"  {if $smarty.post.tax eq "Exempt" || $quote_data.tax eq "Exempt"}selected{/if}>Exempt</option>
    				     </select>


                </div>
                {else}
                <div>
                {$smarty.post.tax}
                 </div>
                {/if}
					    </td>

					  </tr>
            <tr>
					    <td colspan="2"><div><strong>VAT </strong></div>
                {if $step == 'one'}
                <div class="form-group">
                   <select name="vat" id="vat" class="form-control">
    				            <option value="18"  {if $smarty.post.vat eq "18" || $quote_data.vat eq "18"}selected{/if}>18%</option>
                          <option value="15"  {if $smarty.post.vat eq "15" || $quote_data.vat eq "15"}selected{/if}>15%</option>
    				        	<option value="0"  {if $smarty.post.vat eq "0" || $quote_data.vat eq "0"}selected{/if}>0%</option>
    				     </select>
              
                </div>
                {else}
                <div>
                {$smarty.post.vat}%
                 </div>
                {/if}
					    </td>

					  </tr>

            <tr>
              <td colspan="2"><div><strong>Currency</strong></div>
                {if $step == 'one'}
                <div class="form-group">
                   <select name="currency" id="currency" class="form-control">
                        <option value="TZS"  {if $smarty.post.currency eq "TZS" || $quote_data.currency eq "TZS"}selected{/if}>TZS</option>
                      <option value="USD"  {if $smarty.post.currency eq "USD" || $quote_data.currency eq "USD"}selected{/if}>USD</option>
                 </select>
                </div>
                {else}
                <div>
                {$smarty.post.currency}
                 </div>
                {/if}
              </td>

            </tr>

            <tr>
              <td colspan="2"><div><strong>Exchange Rate</strong></div>
                {if $step == 'one'}
                <div class="form-group">
                  <input type="text" name="exch_rate"  id="exch_rate" class="form-control"  value="{if $smarty.post.exch_rate}{$smarty.post.exch_rate}{else}{$quote_data.exch_rate}{/if}" />
                </div>
                {else}
                <div>
                {$smarty.post.exch_rate|number_format:2:".":","}
                 </div>
                {/if}
              </td>

            </tr>

			<tr>
					    <td colspan="2"><div><strong>Branch</strong></div>
                {if $step == 'one'}
                <div class="form-group">
                   <select name="quote_branch" id="quote_branch" class="form-control">
    				            <option value="Main Branch"  {if $smarty.post.quote_branch eq "Main Branch" || $quote_data.quote_branch eq "Main Branch"}selected{/if}>Main Branch (Mwenge)</option>
    				        	<option value="Zanzibar"  {if $smarty.post.quote_branch eq "Zanzibar" || $quote_data.quote_branch eq "Zanzibar"}selected{/if}>Zanzibar</option>
    				     </select>


                </div>
                {else}
                <div>
                {$smarty.post.quote_branch}
                 </div>
                {/if}
					    </td>

					  </tr>



			   {if $step neq 'two'}
			    <tr>
			    <td colspan="2"><div><strong>Show Details</strong>&nbsp;&nbsp;
			       <input type="checkbox" name="show_summary" id="show_summary" value="Y" onclick="show_summary(this);" checked />
			    </div>
			    </td>
			  </tr>
			 {/if}

             </table>
           </div>
          </div>

</div>

{if $step == 'one'}

{if !$no_edit}
 <div align="center" style="padding:10px 0 15px;">

       {* <a class="btn btn-default" href="/quotes/edit?id={$smarty.request.id}&amp;step=two">Done? Save!</a> *}
       {* <button type="submit" name="Submit" class="btn btn-default">Done? Save!</button> *}
       <input type="hidden" name="step"  value="two" />
       <input type="hidden" name="edit_items"  value="1" />

   {if !$smarty.get.subid}
       <button type="submit" name="edit_close" value="1" class="btn btn-primary" >Edit And Close</button>
   {if $privileges.quotes.approve}
       <button type="submit" name="edit_approve"  value="1" class="btn btn-success">Edit And Approve</button>
   {/if}
  {/if}

   {* <a class="btn btn-default" href="/quotes/edit?id={$smarty.request.id}">Refresh</a> *}
    </div>
    {/if}
   {/if}
