
 <div id="summary" class="panel panel-default">
          
       <div class="panel-heading">
            <h3 class="panel-title">Quotation Items</h3>         
      </div>
		  <div class="panel-body panel-body-table">
		
		   <div class="table-responsive">
		       <table class="table datatable_simple">
                 <thead>
                    <tr>
                        <th width="5%">SN</th>
                        <th width="50%">Description</th>
                        <th>Qty</th>
                        <th>Unit Rate</th>
                        <th style="max-width: 130px;">Price{if $quote_info[0].currency}({$quote_info[0].currency}){/if}</th>
                        <th width="80">&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                {section name=quote_items loop=$quote_items}
                    <tr>
                        <td>{$smarty.section.items.rownum}</td>
                        <td>{$quote_items[quote_items].item_description_text}</td>
                        <td>{$quote_items[quote_items].item_quantity_1|thousand_sep}</td>
                        <td>{$quote_items[quote_items].item_price_1/$quote_items[quote_items].item_quantity_1|thousand_sep}</td>
                        <td>{$quote_items[quote_items].item_price_1|thousand_sep}</td>
                        <td>
                          <a title="Convert to Job" href="/quotes/makejob?id={$quote_info[0].quote_id}&subtask=convert&subid={$quote_items[quote_items].item_id}&popup=true" onclick="popupURL(this.href, 'MakeJob_Item', '1000', '500'); return false;"><img src="/images/success.png" alt="Convert to Job" width="16" height="16" border="0"></a>
                        </td>
                    </tr>
                 {sectionelse}
			      <tr>
			        <td colspan="6">No Items have been added to this quotation yet.</td>
			      </tr>
			    {/section} 
			   {if $smarty.section.quote_items.rownum} 
			   <tr>
			    
			    
			    <td colspan="2"></td>
		        <th colspan="2"  class="text-right">Total Amount</th>
		        <td>{$quote_info[0].quote_total|thousand_sep}</td>
		        <td >&nbsp;</td>
		       </tr>
		       
		      <tr>
		        <td colspan="2">&nbsp;</td>
		        <th colspan="2" class="text-right">Discount</th>
		        <td>{$quote_info[0].quote_discount|thousand_sep}</td>
		        <td>&nbsp;</td>
		      </tr>
		      <tr>
		        <td colspan="2">&nbsp;</td>
		        <th colspan="2" class="text-right">Total Due</td>
		        <td>{$quote_info[0].quote_total_due|thousand_sep}</td>
		        <td>&nbsp;</td>
		      </tr>
		      <tr>
		        <td colspan="2">&nbsp;</td>
		        <th colspan="2" class="text-right">Payment Terms</th>
		        <td>
		          {$quote_info[0].quote_payment_terms}
		          </td>
		          <td>&nbsp;</td>
		        </tr>
		        {/if}
                </tbody> 
              </table>
            </div>
	 </div>     
      
</div>

