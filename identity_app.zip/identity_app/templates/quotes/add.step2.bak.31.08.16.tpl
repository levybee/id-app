{include file="quotes/summary.tpl"}
{literal}
<script type="text/javascript">

	var prod = new Array();
{/literal}	
	{section name=product_types loop=$product_types}
	prod[{$product_types[product_types].product_id}] = '{$product_types[product_types].product_2rows}';
	{/section}
{literal}	
</script>
{/literal}


<form id="quotes-form" class="form-horizontal" method="post" action="/quotes/add">
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Add Item</h3>
          
      </div>
     
      <div class="panel-body">                                                                        
          
          <div class="row">
              
              <div class="col-md-6">
                  
                  <div class="form-group">
                      <label class="col-md-4 control-label">Product Type <span class="asterisk">*</span></label>
                      <div class="col-md-8">                                            
                          <select name="product_id" id="product_id" class="form-control" onchange="toggle_2rows(this.value, $(this).find(':selected').attr('data-type')); checkOther(this.value, 13, 'item_product_other');">
					      <option value="0">Please Select</option>
					      {section name=product_types loop=$product_types}
					      <option value="{$product_types[product_types].product_id}" data-type = "{$product_types[product_types].product_type}" {if $formdata.product_id eq $product_types[product_types].product_id}selected{/if}>{$product_types[product_types].product_name} ({$product_types[product_types].product_ref})</option>
					      {/section}
                          </select> 
                          <input name="item_product_other" type="text" id="item_product_other" value="{$product_types[product_types].item_product_other}" class="form-control" style="display:none; margin-top:5px;" />                                          
                         
                      </div>
                  </div>
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Origination</label>
                      <div class="col-md-8 col-xs-12">
                         <select name="item_origination" id="item_origination" class="form-control">
				        {section name=item_origination loop=$item_origination}
				        	<option value="{$item_origination[item_origination]}" {if $formdata.item_origination eq $item_origination[item_origination]}selected{/if}>{$item_origination[item_origination]}</option>
				        {/section}
				    	</select>         
                      </div>
                  </div>
                  
                  <div class="form-group">
                      <label class="col-md-4 control-label">Size <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">                                            
                          <select name="item_paper_size" id="item_paper_size" class="form-control" onchange="checkOther(this.value, 9, 'item_paper_size_other');">
					      <option value="0">Please Select</option>
					      {section name=paper_sizes_finished loop=$paper_sizes_finished}
					      <option value="{$paper_sizes_finished[paper_sizes_finished].size_id}" {if $formdata.item_paper_size eq $paper_sizes_finished[paper_sizes_finished].size_id}selected{/if}>{$paper_sizes_finished[paper_sizes_finished].paper_size}</option>
					      {/section}
					    </select> 
					    <input name="item_paper_size_other" type="text" id="item_paper_size_other" value="{$formdata.item_paper_size_other}" class="form-control"  style="display:none;"  /></td>
					    
                      </div>
                 
                  </div>
                  <div class="form-group paper-row" style="display:none;">
                      <label class="col-md-4 control-label">Orientation</label>
                      <div class="col-md-8">                                                                                                                                        
                          <div class="col-md-6">                                    
	                         <label class="check"><input type="radio" class="iradio" name="item_orientation" id="item_orientation_0" value="Portrait" {if !$formdata.item_orientation}checked="checked"{/if}{if $formdata.item_orientation eq 'Portrait'}checked="checked"{/if}/> Portrait</label>
	                      </div>
	                      <div class="col-md-6">                                    
	                         <label class="check"><input type="radio" class="iradio" name="item_orientation" id="item_orientation_1" value="Landscape" {if $formdata.item_orientation eq 'Landscape'}checked="checked"{/if} /> Landscape</label>
	                      </div>
                      </div>
                  </div>
                  
                  
              </div>
              <div class="col-md-6">
                  
                   <div class="form-group">                                        
                      <label class="col-md-4 control-label">Title <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
                          <input name="item_title" type="text" id="item_title" value="{$formdata.item_title}" class="form-control" />          
                      </div>
                  </div>
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Delivery Days</label>
                      <div class="col-md-8">
                         <input name="item_delivery_days" type="number" id="item_delivery_days" value="{if $product_types[product_types].item_delivery_days}{$product_types[product_types].item_delivery_days}{/if}"  class="form-control">    
                      </div>
                  </div>
                  
                  <!-- <div class="form-group">
                      <label class="col-md-4 control-label">Open Size <span class="asterisk">*</span></label>
                      <div class="col-md-8">
                          <select name="item_paper_size_open" id="item_paper_size_open" class="form-control" onchange="checkOther(this.value, 9, 'item_paper_size_open_other');">
						      <option value="0">Please Select</option>
						      {section name=paper_sizes_finished loop=$paper_sizes_finished}
						      <option value="{$paper_sizes_finished[paper_sizes_finished].size_id}" {if $paper_sizes_finished[paper_sizes_finished].size_id eq $formdata.item_paper_size_open}selected{/if}>{$paper_sizes_finished[paper_sizes_finished].paper_size}</option>
						      {/section}
						    </select> 
						    <input name="item_paper_size_open_other" type="text" id="item_paper_size_open_other" value="{$formdata.item_paper_size_open_other}" class="form-control"  style="display:none;" /></td>
						  
                      </div>
                  </div> -->
              
              </div>
           
          </div>
          <div class="row paper-row" style="display:none;">
             <br /> <br />
              
              
              
              <div class="col-md-6">
                  
                  <div class="form-group">
                      <label class="col-md-4 control-label">Cover Paper <span class="asterisk">*</span></label>
                      <div class="col-md-8">                                            
                          <select name="item_cover_paper_type" id="item_cover_paper_type" class="form-control" onchange="checkOther(this.value, 11, 'item_cover_paper_type_other');">
					      <option value="0">Please Select</option>
					      {section name=paper_types loop=$paper_types}
					      <option value="{$paper_types[paper_types].paper_id}" {if $paper_types[paper_types].paper_id eq $formdata.item_cover_paper_type}selected{/if}>{$paper_types[paper_types].paper_name}</option>
					      {/section}
					    </select> 
					    <input name="item_cover_paper_type_other" type="text" id="item_cover_paper_type_other" value="{$formdata.item_cover_paper_type_other}" class="form-control" style="display:none; margin-top:5px;" /></td>
					    
                      </div>
                  </div>
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Paper Weight <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
                         <select name="item_cover_paper_weight" id="item_cover_paper_weight" class="form-control" >
					      <option value="0">Please Select</option>
					      
					      {section name=paper_weights loop=$paper_weights}
					      
					      <option value="{$paper_weights[paper_weights].weight_value}" {if $paper_weights[paper_weights].weight_value eq $formdata.item_cover_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
					      
					      {/section}
					    
					    </select>       
                      </div>
                  </div>
                  
                  
                  <div class="form-group">
                      <label class="col-md-4 control-label">Print Options</label>
                      <div class="col-md-8">                                                                                                                                        
                          <div class="col-md-6">                                    
	                         <label class="check"><input type="radio" class="iradio" name="item_cover_print_options" id="item_cover_print_options_0" value="Single" {if $formdata.item_cover_print_options eq 'Single'}checked="checked"{/if} />Single Side</label>
	                      </div>
	                      <div class="col-md-6">                                    
	                         <label class="check"><input type="radio" class="iradio" name="item_cover_print_options" id="item_cover_print_options_1" value="Both" {if $formdata.item_cover_print_options eq 'Both'}checked="checked"{/if} />Both Sides</label>
	                      </div>
                      </div>
                  </div>
                 
                  
              </div>
              <div class="col-md-6">
                  
                   <div class="form-group">                                        
                      <label class="col-md-4 control-label">Description</label>
                      <div class="col-md-8 col-xs-12">
                          <input name="item_cover_paper_desc" type="text" id="item_cover_paper_desc" value="{$formdata.item_cover_paper_desc}" class="form-control" />           
                      </div>
                  </div>
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Print</label>
                      <div class="col-md-8">
                          <select name="item_cover_color" id="item_cover_color" class="form-control" onchange="checkOther(this.value, 16, 'item_cover_color_other');">
					      <option value="0">Please Select</option>
					      {section name=print_colors loop=$print_colors}
					  
					      <option value="{$print_colors[print_colors].color_id}" {if $print_colors[print_colors].color_id eq $formdata.item_cover_color}selected{/if}>{$print_colors[print_colors].color_name}</option>
					     
					      {/section}
					    </select> 
					    <input name="item_cover_color_other" type="text" id="item_cover_color_other" value="{$formdata.item_cover_color_other}" class="form-control" style="display:none;" /></td>
					  
                      </div>
                  </div>
                  
                
              
              </div>
          </div>
          
          
          <div class="row books-row" {if !$formdata.item_inner_paper_type}style="display:none;"{/if}>
             <br /> <br />
              
       
              <div class="col-md-6">
                  
                  <div class="form-group">
                      <label class="col-md-4 control-label">Inner Paper</label>
                      <div class="col-md-8">   
                      
                         <select name="item_inner_paper_type" id="item_inner_paper_type" class="form-control" onchange="checkOther(this.value, 11, 'item_inner_paper_type_other');">
					      <option value="0">Please Select</option>
					      {section name=paper_types loop=$paper_types}
					      <option value="{$paper_types[paper_types].paper_id}" {if $paper_types[paper_types].paper_id eq $formdata.item_inner_paper_type}selected{/if}>{$paper_types[paper_types].paper_name}</option>
					      {/section}
					    </select> <input name="item_inner_paper_type_other" type="text" id="item_inner_paper_type_other" value="{$formdata.item_inner_paper_type_other}" class="form-control" style="display:none;" />
					                                                               
                         
                      </div>
                  </div>
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Paper Weight</label>
                      <div class="col-md-8 col-xs-12">
                        <select name="item_inner_paper_weight" id="item_inner_paper_weight" class="form-control">
					      <option value="0">Please Select</option>
					      {section name=paper_weights loop=$paper_weights}
					      <option value="{$paper_weights[paper_weights].weight_value}" {if $paper_weights[paper_weights].weight_value eq $formdata.item_inner_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
					      {/section}
					    </select>     
                      </div>
                  </div>
                  
                  
                  <div class="form-group">
                      <label class="col-md-4 control-label">Inner Print Options</label>
                      <div class="col-md-8">                                                                                                                                        
                          <div class="col-md-6">                                    
	                         <label class="check"><input type="radio" class="iradio" name="item_inner_print_options" id="item_inner_print_options_0" value="Single" {if $formdata.item_inner_print_options eq 'Single'}checked="checked"{/if} />Single Side</label>
	                      </div>
	                      <div class="col-md-6">                                    
	                         <label class="check"><input type="radio" class="iradio" name="item_inner_print_options" id="item_inner_print_options_1" value="Both" {if $formdata.item_inner_print_options eq 'Both'}checked="checked"{/if} />Both Sides</label>
	                      </div>
                      </div>
                  </div>
                 
                  
              </div>
              <div class="col-md-6">
                  
                   <div class="form-group">                                        
                      <label class="col-md-4 control-label">Description</label>
                      <div class="col-md-8 col-xs-12">
                          <input name="item_inner_paper_desc" type="text" id="item_inner_paper_desc" value="{$formdata.item_inner_paper_desc}" class="form-control" />           
                      </div>
                  </div>
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Print</label>
                      <div class="col-md-8">
                          <select name="item_inner_color" id="item_inner_color" class="form-control" onchange="checkOther(this.value, 16, 'item_inner_color_other');">
					        <option value="0">Please Select</option>
					      {section name=print_colors loop=$print_colors}
					      <option value="{$print_colors[print_colors].color_id}" {if $print_colors[print_colors].color_id eq $formdata.item_inner_color}selected{/if}>{$print_colors[print_colors].color_name}</option>
					      {/section}
					    </select> <input name="item_inner_color_other" type="text" id="item_inner_color_other" value="{$formdata.item_inner_color_other}" class="form-control" style="display:none;" />
                      </div>
                  </div>
                  
                
              
              </div>
          </div>
          
          <div class="row paper-row" style="display:none;">
             <br /> <br />
           
              <div class="col-md-12">
                <!-- <div class="form-group">                                        
                      <label class="col-md-2 control-label text-left">Pagination</label>
                      <div class="col-md-6">
                          <input name="item_pagination" type="text" id="item_pagination" value="{$formdata.item_pagination}" class="form-control" />
                      </div>
                  </div> -->
                  
                <div class="form-group">                                        
                      <label class="col-md-2 control-label">Print Process</label>
                      <div class="col-md-6">
                          <select name="item_print_process" id="item_print_process" class="form-control">
					        <option value="0">Please Select</option>
					        {section name=print_processes loop=$print_processes}
					        <option value="{$print_processes[print_processes].print_process_id}" {if $print_processes[print_processes].print_process_id eq $formdata.item_print_process}selected{/if}>{$print_processes[print_processes].print_process_name}</option>
					        {sectionelse}
					        <option value="0">No print processes created</option>
					        {/section}
					    </select> 
                      </div>
                  </div>
                  
                <div class="form-group">                                        
                      <label class="col-md-2 control-label text-left">Finishing</label>
                      <div class="col-md-9">
                       {section name=item_finishing loop=$item_finishing}
			            <div class="col-md-4">                                    
                              <label class="check"><input type="checkbox" class="icheckbox" name="item_finishing_{$smarty.section.item_finishing.rownum}" id="item_finishing_{$smarty.section.item_finishing.rownum}" value="{$item_finishing[item_finishing].finishing_id}" {if $item_finishing_array}{if $item_finishing[item_finishing].finishing_id|in_array:$item_finishing_array}checked="checked"{/if}{/if} /> {$item_finishing[item_finishing].finishing_type}</label>
                          </div>
			      	  {/section}
                          
                          
                      </div>
                  </div>
                  
              </div>
              
              
         </div>
         
         
         <div class="row">
             <br /> <br />
           
              <div class="col-md-12">
                <div class="form-group">                                        
                      <label class="col-md-2 control-label text-left">Notes</label>
                      <div class="col-md-9">
                       <textarea name="item_notes" id="item_notes" class="form-control"  rows="5">{$formdata.item_notes}</textarea>
                       </div>
                 </div>
                  
                <div class="form-group">                                        
                      <label class="col-md-2 control-label text-left" style="line-height:15px;">Special Remarks<br />
                       <span class="text-danger">(CONFIDENTIAL)</span>
                      </label>
                      <div class="col-md-9">
                       <label><input type="checkbox" name="show_spremarks" id="show_spremarks" value="Y" onclick="show_textarea(this, 'special_remarks');" {if $formdata.show_spremarks eq 'Y'} checked="checked" {/if}></label>
                       <div id="special_remarks" {if $formdata.show_spremarks neq 'Y'} style="display:none;" {/if}><textarea name="item_special_remarks" id="item_special_remarks" class="form-control" rows="5">{$formdata.item_special_remarks}</textarea></div>  
                          
                      </div>
                 </div>
                  
              </div>
              
              
         </div>
         
         <div class="row">
            <br /> <br />
            
            <div class="col-md-6">
                  
                  <!--  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Payment Terms <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
	                          <select name="item_payment_terms" id="item_payment_terms" class="form-control">
						      <option value="0">Please Select</option>
						      
						      {section name=item_payment_terms loop=$item_payment_terms}
						      
						      <option value="{$item_payment_terms[item_payment_terms].payment_id}" {if $item_payment_terms[item_payment_terms].payment_id eq $formdata.item_payment_terms}selected{/if}>{$item_payment_terms[item_payment_terms].payment_term}</option>
						      
						      {/section}
						    
						     </select>
	                  </div>
                  </div> -->
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                      <div class="col-md-8">
                         
					    <input name="item_quantity_1" type="number" id="item_quantity_1" value="{$formdata.item_quantity_1}" class="form-control" />
                      </div>
                  </div>
                  
                
              
              </div>
              
              <div class="col-md-6">
                  
                  <!-- <div class="form-group">                                        
                      <label class="col-md-4 control-label">Currency</label>
                      <div class="col-md-8 col-xs-12">
                         <select name="currency" id="currency" class="form-control">
				            <option value="TZS"  {if $formdata.currency eq "TZS"}selected{/if}>TZS</option>
				        	<option value="USD"  {if $formdata.currency eq "USD"}selected{/if}>USD</option>
				    	</select>         
                      </div>
                  </div> -->
                  
                  <div class="form-group">                                        
                      <label class="col-md-4 control-label">Price <span class="asterisk">*</span></label>
                      <div class="col-md-8">
                         
					    <input name="item_price_1" type="text" id="item_price_1" value="{$formdata.item_price_1}" class="form-control" />
					 </div>
                  </div>
                   
              </div>
         
         
         </div>

      </div>
      <div class="panel-footer"> 
      <table>
  <tr>
    <td width="150"><label> <input type="hidden" name="next_step" id="next_step" value="three" />
      <input name="next_step_info" type="radio" id="next_step_info_0" value="three_a" checked="checked" />
      Add Another Item</label></td>
    <td width="150"><input type="radio" name="next_step_info" value="three_b" id="next_step_info_1" />
Add &amp; Print</td>
    <td width="150"><input type="radio" name="next_step_info" value="three_c" id="next_step_info_2" />
Ignore &amp; Print</td>
    <td><div align="center">
      <button type="submit" name="Submit" class="btn btn-primary pull-right">Proceed</button>
    </div></td>
  </tr>
</table>                     
          
      </div>
  </div>
  </form>
