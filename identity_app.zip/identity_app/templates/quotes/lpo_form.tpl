 
 <div class="modal" id="lpo_modal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Job LPO for Quote
			#{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</h4>
              </div>
              <form id="lpo_form" name="lpo_form" method="post" action="" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="lpo_response"></div>
	                 
	                 
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
			                 
			                
			                 <div class="panel-body form-group">
			                   <div class="row">
			                 
									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Job LPO Number</label>
									    <div class="col-md-6 col-xs-12"> 
									     
									      <input name="lpo_number" type="text" value="" class="form-control" />    
									      
									    </div>
									  </div>
									  
			                   </div>
			               
			
			                 </div>
			                 
			             </div>
	              
	              </div>
	              <div class="modal-footer">
	                  <input type="hidden" name="job_group_id" value="{$quote_info[0].job_group_id}" >
					  <input type="hidden" name="ajax_action" value="lpo" >
	                  <input type="submit" name="job_lpo" class="btn btn-primary" value="Submit">
	                  <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                  </div>
              </form>
              
          </div>
      </div>
  </div>