{if $smarty.get.new}
{include file="quotes/add.step1.new.tpl"}
{else}
<h2>Quote Information</h2>
<form name="form1" method="post" action="/quotes/add">  <!-- action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}" -->
<table  border="1" cellspacing="5" cellpadding="5" class="table">
<tr>
  <td width="100" class="header_row"><div align="right"><strong>Date </strong></div></td>
  <td><input name="quote_date" type="text" id="quote_date" value="{$smarty.now|date_format:'%Y-%m-%d'}" readonly="true"></td>
  <td><img src="/images/cal.png" alt="Calendar" width="24" height="20" id="trigger1"></td>
</tr>
</table>
<h2>Customer Information</h2>
<table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Select Customer</strong></div></td>
    <td>
    	<select name="customer_id" id="customer_id" style="width: 220px;">
        	<option value="0">Please Select</option>
            {section name=customer_list loop=$customer_list}
            <option value="{$customer_list[customer_list].customer_id}">{$customer_list[customer_list].group_company} - {$customer_list[customer_list].customer_fname} {$customer_list[customer_list].customer_lname}</option>
            {/section}
        </select>
        <a href="#" onclick="customerSelector(); return false;"><img src="/images/find.png" alt="Select Customer" width="16" height="16" border="0"></a>
    </td>
  </tr>
</table>
<br />
<table width="400" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><div align="right">
        <input name="next_step" type="hidden" id="next_step" value="two" />
        <input type="submit" name="Submit" value="Go to Step 2" class="input_button" />
      </div></td>
    </tr>
</table>
<br />
</form>
{dhtml_calendar inputField="quote_date" button="trigger1" singleClick=true ifFormat="%Y-%m-%d"}
{/if}