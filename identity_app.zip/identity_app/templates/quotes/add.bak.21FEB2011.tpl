{if $privileges.quotes.add}
	<script type="text/javascript" src="/js/quote.js"></script>
    {if $smarty.get.subtask eq 'edit'}
        {include file=quotes/add.edit.subtask.tpl}
    {else}
        <table border="0" align="right" cellpadding="5" cellspacing="0" id="progress_bar">
          <tr>
            <td width="75" class="step_1" {if $step eq 'one'}id="current"{/if}>Step 1</td>
            <td width="75" class="step_2" {if $step eq 'two'}id="current"{/if}>Step 2</td>
            <td width="75" class="step_3" {if $step eq 'three'}id="current"{/if}>Step 3</td>
          </tr>
          <tr>
            <td class="progress_information">Prepare Quote</td>
            <td class="progress_information">Add Items</td>
            <td class="progress_information">Save &amp; Print!</td>
          </tr>
          <tr>
            <td colspan="3"><div align="center"><a href="/quotes/add?cancel=1">Cancel Quote &amp; Start Over</a></div></td>
          </tr>
          <tr>
            <td colspan="3"><div align="center"><a href="/quotes/add"><strong>Refresh</strong></a></div></td>
          </tr>
        </table>
        <br style="float:right" />
        <h1>New Quote - Step {$step|capitalize}</h1>
        {if $step eq 'one'}
            {include file="quotes/add.step1.tpl"}
        {elseif $step eq 'two'}
            {include file="quotes/add.step2.tpl"}
        {elseif $step eq 'three'}
            {include file="quotes/add.step3.tpl"}
        {else}
            {include file="quotes/add.step1.tpl"}
        {/if}
    {/if}
{/if}