{include file="quotes/summary.blank.tpl"}
{literal}
 <script type="text/javascript">

	var prod = new Array();
	
{/literal}	
	{section name=product_types loop=$product_types}
	prod[{$product_types[product_types].product_id}] = '{$product_types[product_types].product_2rows}';
	{/section}
{literal}	
</script> 
{/literal}

<form class="form-horizontal" method="post" action="/quotes/add">
     <div class="panel panel-default">
         <div class="panel-heading">
             <h3 class="panel-title">Add New Items</h3>
             
         </div>
         <div class="panel-body">
           <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Description</label>
                <div class="col-md-6 col-xs-12">                                            
                    <textarea name="item_description_text" id="item_description_text" class="form-control"  rows="5">{$formdata.item_description_text}</textarea>
                   
                </div>
            </div>
            
           <!--  <div class="form-group">                                        
                      <label class="col-md-3 control-label">Currency</label>
                      <div class="col-md-6 col-xs-12">
                         <select name="currency" id="currency" class="form-control" readonly>
				            <option value="TZS"  {if $formdata.currency eq "TZS" || $smarty.session.step_1.quote_currency eq 'TZS'}selected{/if}>TZS</option>
				        	<option value="USD"  {if $formdata.currency eq "USD" || $smarty.session.step_1.quote_currency eq 'USD'}selected{/if}>USD</option>
				    	</select>         
                      </div>
                  </div> -->
            
            <div class="form-group">                                        
                <label class="col-md-3 col-xs-12 control-label">Quantity</label>
                <div class="col-md-2">
                 <input type="number" name="item_quantity_1" id="item_quantity_1" value="{$formdata.item_quantity_1}"  class="form-control">
                </div>
                <div class="col-md-2 text-right">
                <label class="control-label">Price</label>
                </div>
                <div class="col-md-2">
                 <input type="text" class="form-control" name="item_price_1" id="item_price_1" value="{$formdata.item_price_1}">
                </div>
                                                            
            </div>
            
         </div>
       
       
     </div>
     
     
<h3>Next step</h3>     
<table>
  <tr>
    <td width="150"><label> <input type="hidden" name="next_step" id="next_step" value="three" />
      <input name="next_step_info" type="radio" id="next_step_info_0" value="three_a" checked="checked" />
      Add Another Item</label></td>
    <td width="150"><input type="radio" name="next_step_info" value="three_b" id="next_step_info_1" />
Add &amp; Print</td>
    <td width="150"><input type="radio" name="next_step_info" value="three_c" id="next_step_info_2" />
Ignore &amp; Print</td>
    <td>
    <div align="center">
      <button type="submit" name="Submit" class="btn btn-primary">Proceed</button>
    </div></td>
  </tr>
  <tr>
   <td colspan="2">&nbsp;</td>
  </tr>
</table>
     
     
     </form>
