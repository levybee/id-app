<h2>Quotation Information</h2>
<table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td class="header_row"><div align="right"><strong>Quote Date</strong></div></td>
    <td>{$smarty.session.quote.step_1.quote_date}</td>
  </tr>
  <tr>
    <td width="100" valign="top" class="header_row"><div align="right"><strong>Customer</strong></div></td>
    <td>{$smarty.session.quote.step_1.customer_information.customer_fname} {$smarty.session.quote.step_1.customer_information.customer_lname}<br />
    {$smarty.session.quote.step_1.customer_information.group_company}<br />
    {$smarty.session.quote.step_1.customer_information.customer_address}<br />
    {$smarty.session.quote.step_1.customer_information.customer_city}, {$smarty.session.quote.step_1.customer_information.customer_country}<br />
    <br />
    Phone: {$smarty.session.quote.step_1.customer_information.customer_phone}<br />
    Fax: {$smarty.session.quote.step_1.customer_information.customer_fax}<br />
    Email: {$smarty.session.quote.step_1.customer_information.customer_email}</td>
  </tr>
</table>
<h2>Items</h2>
{section name=items loop=$smarty.session.quote.items}
<table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td class="header_row"><div align="right"><strong>Item Type</strong></div></td>
    <td width="200">{$smarty.session.quote.items[items].item_product[0].product_name}</td>
    <td class="header_row">&nbsp;</td>
    <td width="200">&nbsp;</td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Title</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_title}</td>
    <td width="100" class="header_row"><div align="right"><strong>Origination</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_origination}</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Artwork Date</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_artwork_date|date_format:"%d %B %Y"}</td>
    <td width="100" class="header_row"><div align="right"><strong>Delivery Date</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_delivery_date|date_format:"%d %B %Y"}</td>
  </tr>
  
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Paper</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_paper_type[0].paper_name}</td>
    <td width="100" class="header_row"><div align="right"><strong>Size</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_paper_size[0].paper_size}</td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Pagination</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_pagination}</td>
    <td class="header_row"><div align="right"><strong>Colour</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_color[0].color_name}</td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Finishing</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_finishing[0].finishing_type}</td>
    <td class="header_row"><div align="right"><strong>Others</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_others}</td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Quantity</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_quantity}</td>
    <td class="header_row">&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Price in Dhs</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_price}</td>
    <td class="header_row"><div align="right"><strong>Payment Terms</strong></div></td>
    <td>{$smarty.session.quote.items[items].item_payment_terms}</td>
  </tr>
  <tr>
    <td valign="top" class="header_row"><div align="right"><strong>Notes</strong></div></td>
    <td colspan="3">{$smarty.session.quote.items[items].item_notes}</td>
  </tr>
</table>
<br />
{sectionelse}
<p>No Items have been added to this quotation yet.</p>
{/section}