
<div id="summary" class="panel panel-default" style="display:none;">

       <div class="panel-heading">
		        <h3 class="panel-title">Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">item #</th>
                                <th>Qty</th>
							    <th>Description</th>
							    <th>Unit Price {if $smarty.session.quote.step_1.quote_currency}({$smarty.session.quote.step_1.quote_currency}){/if}</th>
							    <th>Amount {if $smarty.session.quote.step_1.quote_currency}({$smarty.session.quote.step_1.quote_currency}){/if}</th>
							    <th width="50">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.quote.items}
						  <tr>
						    <td class="text-center">{$smarty.section.items.rownum}</td>
						    <td>{$smarty.session.quote.items[items].item_quantity_1|number_format:0:".":","}</td>
						    <td>
							
						    {$smarty.session.quote.items[items].item_product[0].product_name} {if $smarty.session.quote.items[items].item_product_other}({$smarty.session.quote.items[items].item_product_other}){/if} - {$smarty.session.quote.items[items].item_title}
						    <p style="line-height:18px;">
						        

                  {if $smarty.session.quote.items[items].stock_id}
                   Stock #{$smarty.session.quote.items[items].stock_id}: {$smarty.session.quote.items[items].stock_name}; 
                  {/if}

						      Origination: {$smarty.session.quote.items[items].item_origination};{if $smarty.session.quote.items[items].item_delivery_days} Delivery Days: {$smarty.session.quote.items[items].item_delivery_days};{/if} Size: {$smarty.session.quote.items[items].item_paper_size[0].paper_size};
						      {if $smarty.session.quote.items[items].item_product[0].product_type eq 'Paper' || $smarty.session.quote.items[items].item_product[0].product_type eq 'Books'}
							{if $smarty.session.quote.items[items].item_orientation}Orientation: {$smarty.session.quote.items[items].item_orientation|capitalize};{/if} 
							{if $smarty.session.quote.items[items].item_num_pages} No of Pages: {$smarty.session.quote.items[items].item_num_pages};{/if} 
							 {if $smarty.session.quote.items[items].item_cover_paper_type}Cover Paper:  {$smarty.session.quote.items[items].item_cover_paper_type}{/if} 
							{if $smarty.session.quote.items[items].item_cover_paper_type_other}({$smarty.session.quote.items[items].item_cover_paper_type_other}){/if}; {if $smarty.session.quote.items[items].item_cover_paper_desc}Cover Paper Description: {$smarty.session.quote.items[items].item_cover_paper_desc};{/if} 
							{if isset($smarty.session.quote.items[items].item_cover_paper_weight[0].weight_value)}Paper Weight: {$smarty.session.quote.items[items].item_cover_paper_weight[0].weight_value} gsm;{/if} 
							{if $smarty.session.quote.items[items].item_cover_color[0].color_name}Print: {$smarty.session.quote.items[items].item_cover_color[0].color_name} {if $smarty.session.quote.items[items].item_cover_color_other}({$smarty.session.quote.items[items].item_cover_color_other}){/if};{/if} 
							{if $smarty.session.quote.items[items].item_cover_print_options}Print Options: {$smarty.session.quote.items[items].item_cover_print_options|capitalize};{/if}
							{if !$smarty.session.quote.items[items].item_process}
							{if $smarty.session.quote.items[items].item_cover_material} Material: {$smarty.session.quote.items[items].item_cover_material};{/if}
							{if $smarty.session.quote.items[items].item_cover_machine} Machine: {$smarty.session.quote.items[items].item_cover_machine};{/if}
							{/if}
							{/if}
						      {if $smarty.session.quote.items[items].item_product[0].product_type eq 'Books'} 
							{if $smarty.session.quote.items[items].item_inner_paper_type}Inner Paper: {$smarty.session.quote.items[items].item_inner_paper_type};{/if} 
                           {if $smarty.session.quote.items[items].item_inner_material}Material: {$smarty.session.quote.items[items].item_inner_material};{/if} 
							{if $smarty.session.quote.items[items].item_inner_notes}Notes: {$smarty.session.quote.items[items].item_inner_notes};{/if} 

							{if $smarty.session.quote.items[items].item_inner_paper_desc}Inner Paper Description: {$smarty.session.quote.items[items].item_inner_paper_desc};{/if} 
							{if isset($smarty.session.quote.items[items].item_inner_paper_weight[0].weight_value)}Inner Paper Weight: {$smarty.session.quote.items[items].item_inner_paper_weight[0].weight_value} gsm;{/if} 
							{if $smarty.session.quote.items[items].item_inner_color[0].color_name}Inner Print: {$smarty.session.quote.items[items].item_inner_color[0].color_name}{/if} 
							{if $smarty.session.quote.items[items].item_inner_color_other}({$smarty.session.quote.items[items].item_inner_color_other}){/if}; 
							{if $smarty.session.quote.items[items].item_inner_print_options}Inner Print Options: {$smarty.session.quote.items[items].item_inner_print_options|capitalize};{/if} {/if} 
							{if $smarty.session.quote.items[items].item_print_process}Print Process: {$smarty.session.quote.items[items].item_print_process};{/if}
							{if $smarty.session.quote.items[items].item_process}{$smarty.session.quote.items[items].item_process}{/if}
							{if $smarty.session.quote.items[items].item_inner_stationary_type}Stationary Type: {$smarty.session.quote.items[items].item_inner_stationary_type}; {/if}	
						    {if $smarty.session.quote.items[items].item_inner_stationary_notes}Notes: {$smarty.session.quote.items[items].item_inner_stationary_notes}; {/if}			
							{if $smarty.session.quote.items[items].item_inner_wide_format_info}
							      Wide Format: {$smarty.session.quote.items[items].item_inner_wide_format_info[0].item_inner_material} - Quantity: {$smarty.session.quote.items[items].item_inner_wide_format_info[0].item_inner_quantity}; 
								  Notes: {$smarty.session.quote.items[items].item_inner_wide_format_info[0].item_inner_notes};
							{/if}
 
						      Finishing: {section name=item_finishing_summary loop=$smarty.session.quote.items[items].item_finishing}
			            	            {$smarty.session.quote.items[items].item_finishing[item_finishing_summary][0].finishing_type};
							            {sectionelse}
							           	 	None;
							            {/section}

									{if $smarty.get.debug eq 'lev'} <pre> {$smarty.session.quote.items[items]|@print_r}</pre> {/if}
						    </p>
						    {if $smarty.session.quote.items[items].item_notes}<p style="line-height:18px;">Notes: {$smarty.session.quote.items[items].item_notes}</p> {/if}
						    {if $smarty.session.quote.items[items].item_special_remarks}<p style="line-height:18px;">Special Remarks: {$smarty.session.quote.items[items].item_special_remarks}</p>{/if}
						    
						     {if $smarty.session.quote.items[items].item_wht_amount > 0}<p>WHT Amount: {$smarty.session.quote.items[items].item_wht_amount} {$smarty.session.quote.step_1.quote_currency}</p> {/if}
                              {if $smarty.get.dbg}
                              <pre>{$smarty.session.quote.items[items]|@print_r}</pre>
							  {/if}
						    </td>
						    <td>{$smarty.session.quote.items[items].item_price_1|thousand_sep} </td>
						    <td>{$smarty.session.quote.items[items].item_total_price|thousand_sep}</td>

						    <td>
						      <a title="Edit Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/add/?subtask=edit&subid={$smarty.section.items.rownum}"><span class="fa fa-pencil"></span></a>
			                   <a title="Delete Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/add/?subtask=delete&subid={$smarty.section.items.rownum}"><span class="fa fa-times"></span></a>
						     </td>

						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="6"><div>No Items have been added to this quotation yet.</td>
						  </tr>
						  {/section}

						  {if $smarty.session.quote.items|@count gt 0}
						  <tr class="info">
						   <td colspan="4" align="right"><strong>Sub Total</strong></td><td>{$quote_totals.quote_subtotal|thousand_sep}</td><td></td>
						  </tr>
						  {if $smarty.session.quote.step_1.quote_discount > 0}
						  <tr class="info">
						   <td colspan="4" align="right"><strong>Discount</strong></td><td>{$quote_totals.quote_discount|thousand_sep}</td><td></td>
						  </tr>
						  {/if} 
						  
						  {if $smarty.session.quote.step_1.quote_tax eq 'Taxable'}
						  <tr class="warning" >
						   <td colspan="4" align="right"align="right"><strong>Taxes</strong></td><td>{$quote_totals.quote_taxes|thousand_sep}</td><td></td>
						  </tr>
						  {/if}
						  <tr class="success">
						   <td colspan="4" align="right"><strong>Total</strong></td><td>{$quote_totals.quote_grandtotal|thousand_sep}</td><td></td>
						  </tr>
						  {/if}

                        </tbody>
                    </table>
                   

                </div>


  </div>


</div>
