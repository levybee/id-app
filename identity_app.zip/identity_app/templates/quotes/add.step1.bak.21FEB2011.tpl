{literal}
<script type="text/javascript">
	$(document).ready(function(){
		
		$('#group_id').livequery('change',function() { //start function when any link is clicked
			
			var obj = document.getElementById('customer_id');			
			content_show = document.getElementById('group_id').value;
			
			ajaxLoad(content_show, obj); 
			 
		}); 

	});
	
	function ajaxLoad(content_show, obj) {
		
		// Load Content
		$.ajax({
			method: "get",url: "/modules/quotes/customers_ajax.php",data: "group="+content_show,
			dataType: "script",
			beforeSend: function(){ obj.options.length = 0; obj.options[obj.options.length] = new Option('Loading...','0'); }, //show loading just when link is clicked
			complete: function(){ 
				// Do nothing 
			}, //stop showing loading when the process is complete
			success: function(script){ //so, if data is retrieved, store it in html
				
				var obj = document.getElementById('customer_id');
				
				// alert(script);
				obj.options.length = 0; 
				obj.options[obj.options.length] = new Option('Please Select','0');
				eval(script); // process JS
			 }
		 }); //close $.ajax(
		
	}
	
</script>
{/literal}
<h2>Quote Information</h2>
<form name="form1" method="post" action="/quotes/add">  <!-- action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}" -->
<table  border="1" cellspacing="5" cellpadding="5" class="table">
<tr>
  <td width="100" class="header_row"><div align="right"><strong>Date </strong></div></td>
  <td><input name="quote_date" type="text" id="quote_date" value="{$smarty.now|date_format:'%Y-%m-%d'}" readonly="true"></td>
  <td><img src="/images/cal.png" alt="Calendar" width="24" height="20" id="trigger1"></td>
</tr>
</table>
<h2>Customer Information</h2>
<table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Company / Group</strong></div></td>
    <td>
    	<select name="group_id" id="group_id" style="width: 220px;">
        	<option value="0">Please Select</option>
            {section name=customers_group loop=$customers_group}
            <option value="{$customers_group[customers_group].group_id}">{$customers_group[customers_group].group_company}</option>
            {/section}
        </select>
    </td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Customer</strong></div></td>
    <td>
    	<select name="customer_id" id="customer_id" style="width: 220px;">
        	<option value="0">Please Select</option>
        </select>
        <a href="#" onclick="customerSelector(); return false;"><img src="/images/find.png" alt="Select Customer" width="16" height="16" border="0"></a>    </td>
  </tr>
</table>
<br />
<table width="400" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><div align="right">
        <input name="next_step" type="hidden" id="next_step" value="two" />
        <input type="submit" name="Submit" value="Go to Step 2" class="input_button" />
      </div></td>
    </tr>
</table>
<br />
</form>
{dhtml_calendar inputField="quote_date" button="trigger1" singleClick=true ifFormat="%Y-%m-%d"}