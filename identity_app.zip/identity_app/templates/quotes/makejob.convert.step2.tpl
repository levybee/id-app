<div class="panel panel-default">
  <div class="panel-body">
	<h3>Save &amp; Print!
	</h3>
	<p>Success! The job order is ready for PDF print / save. </p>
	{if $error_message}
	 <div class="alert alert-danger" role="alert">
	    <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	    The following errors occurred: <br />
	{$error_message}
	      </div>
	   
	{/if}
	<p>
	  <button type="submit" name="Submit"  class="btn btn-primary" onclick="popupPDF('job', {if $job_id}{$job_id}{else}0{/if});">View &amp; Print Job Order</button>
	</p>
  </div>
</div>

{if $job_id}	     
<div class="panel panel-default">
 <div class="panel-body">	
   <iframe style="width:100%;" height="500" src="/jobs/print?uid={$job_id}"></iframe>     
 </div>
</div>
{/if}
