{if $privileges.quotes.list}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Quotes</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Quotes List</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <a href="/quotes/add" class="btn btn-default">Add a new Quote</a>

        <br><br>


        <div class="col-md-12" style="margin-bottom:10px;">

          <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/quotes/list?page=1" class="btn btn-default">Clear</a> | Filter By Status: <a href="/quotes/list?page=1{if $search_str}&{$search_str}{/if}" class="btn {if !$smarty.get.fby_param}btn-success{/if} btn-flat btn-rad">All</a> <a href="/quotes/list?page=1&filter=1&fby=status&fby_param=Pending{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Pending'}btn-success{else}btn-default{/if}">Pending</a> <a href="/quotes/list?page=1&filter=1&fby=status&fby_param=Cancelled{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled</a> <a href="/quotes/list?page=1&filter=1&fby=status&fby_param=Confirmed{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Confirmed'}btn-success{else}btn-default{/if}">Confirmed</a> <a href="/quotes/list?page=1&filter=1&fby=status&fby_param=Approved{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Approved'}btn-success{else}btn-default{/if}">Approved</a>
		  {include file='search/mini.quotes.tpl'}
		</div>
        <div class="panel panel-default">

            <div class="panel-heading">
                {if $smarty.get.fby_param eq 'Confirmed'} <label for="approve_selected" class="btn btn-danger">Approve Selected</label>{else} <h3 class="panel-title">Quotes Table</h3>  {/if}
                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/quotes/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/quotes/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                          {* if $privileges.jobs.listprint}
					         <a href="/quotes/print?popup=1&print=1&page=*{if $search_str}&{$search_str}{/if}" onClick="popupURL(this.href, 'QuotesList', 800, 500); return false;">
					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
					         </a>
					      {/if *}

                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">
             <form method="post" action="">
               <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">

                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>

                                <th width="40">#</th>
                                {if $smarty.get.fby_param eq 'Confirmed'}<th width="40"><input type="checkbox" id="check_all_confirmed"/></th>{/if}
                                <th>Ref #</th>
							    <th>Date</th>
							    <th>Customer</th>
							    <th>Items #</th>
                  <th>Open Jobs</th>
							    <th>Status</th>
							    <th>User</th>
							    <th width="50">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=quote_list loop=$quote_list}
						  <tr>

						    <td class="text-center">{$start+$smarty.section.quote_list.rownum}</td>
						    {if $smarty.get.fby_param eq 'Confirmed'}<td class="text-center"><input type="checkbox" name="confirmed_check[{$quote_list[quote_list].quote_info.quote_id}]" class="confirmed_check" value="1" /></td>{/if}
						    <td><a title="View Quote" href="/quotes/view/?id={$quote_list[quote_list].quote_info.quote_id}"  alt="View Quote">{$quote_list[quote_list].quote_info.quote_date|substr:0:4}-{$quote_list[quote_list].quote_info.quote_date|substr:5:2}-{$quote_list[quote_list].quote_info.quote_id|leading_zero:5}</a></td>
						    <td>{$quote_list[quote_list].quote_info.quote_date|date_format:"%d %B %Y"}</td>
						    <td>
                  {if $quote_list[quote_list].quote_info.customer_id eq 0 || $quote_list[quote_list].quote_info.customer_id eq 52}{$quote_list[quote_list].quote_info.quote_customer}{else}{$quote_list[quote_list].quote_info.group_company} - {$quote_list[quote_list].quote_info.customer_fname} {$quote_list[quote_list].quote_info.customer_lname}{/if}
                  {if $quote_list[quote_list].quote_info.job_lpo_other}<br><span class="text-danger">LPO No. {$quote_list[quote_list].quote_info.job_lpo_other}</span>{/if}
                  {if $quote_list[quote_list].quote_info.job_lpo == 'Advance Paid' || $quote_list[quote_list].quote_info.job_lpo == 'Full Amount Paid'}  
                   <br><i class="text-danger">{$quote_list[quote_list].quote_info.job_lpo}: {$quote_list[quote_list].quote_info.receipt_amount|number_format:2:".":","} {$quote_list[quote_list].quote_info.receipt_currency}</i>
                  {/if} 
                    </td>
						    <td class="text-center">{$quote_list[quote_list].quote_items_num}</td>
                <td class="text-center">{$quote_list[quote_list].open_jobs}</td>
                <td>{$quote_list[quote_list].quote_info.quote_status}
                  {if $quote_list[quote_list].quote_info.quote_status eq 'Approved'}
                  <br> <i>By {$quote_list[quote_list].quote_info.approval_user}</i>
                  {/if}
                   {if $quote_list[quote_list].quote_info.quote_status eq 'Confirmed'}
                  <br> <i>By {$quote_list[quote_list].quote_info.confirmed_user}</i>
                  {/if}
                {if $quote_list[quote_list].quote_info.quote_status eq 'Approved' &&  $quote_list[quote_list].quote_info.lpos}
                <br><i>LPOs: {$quote_list[quote_list].quote_info.lpos}</i>
                {/if}
                {if $quote_list[quote_list].quote_info.quote_status eq 'Confirmed' && $quote_list[quote_list].quote_info.date_confirmed}
                <br />({$quote_list[quote_list].quote_info.date_confirmed|date_format:"%H:%M:%S"})
                {/if}
                {if $quote_list[quote_list].quote_info.quote_status eq 'Confirmed' && $quote_list[quote_list].quote_info.override_comments}
                <br /><i>Outstanding Comments: {$quote_list[quote_list].quote_info.override_comments}</i>
                {/if}

                 

                </td>
						    <td>{$quote_list[quote_list].quote_info.user}</td>
						    {if !$smarty.get.print}
						    <td class="text-center">
						      <a title="View Quote" href="/quotes/view/?id={$quote_list[quote_list].quote_info.quote_id}"  alt="View Quote" width="16" height="16" border="0"> View</a>
						     </td>
						    {/if}
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="8"><div align="center">No records found.</td>
						  </tr>
						 {/section}
                        </tbody>
                    </table>

                </div>
              </form>

            </div>
             <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/quotes/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/quotes/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>

                 </ul>
            </div>

        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
