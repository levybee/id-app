{literal}
<script type="text/javascript">


        /* console.log('inside!');

        document.getElementById('group_id').('change',function() { //start function when any link is clicked

			 console.log('inside 2!');


			var obj = document.getElementById('customer_id');
			content_show = document.getElementById('group_id').value;

			ajaxLoad(content_show, obj);

		});



	function ajaxLoad(content_show, obj) {

		// Load Content
		$.ajax({
			method: "get",url: "/modules/quotes/customers_ajax.php",data: "group="+content_show,
			dataType: "script",
			beforeSend: function(){ obj.options.length = 0; obj.options[obj.options.length] = new Option('Loading...','0'); }, //show loading just when link is clicked
			complete: function(){
				// Do nothing
			}, //stop showing loading when the process is complete
			success: function(script){ //so, if data is retrieved, store it in html

				var obj = document.getElementById('customer_id');

				// alert(script);
				obj.options.length = 0;
				obj.options[obj.options.length] = new Option('Please Select','0');
				eval(script); // process JS
			 }
		 }); //close $.ajax(

	} */

</script>
{/literal}

<div id="response2"></div>

<form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Quote & Customer Information </h3>
        </div>

        <div class="panel-body form-group">
             <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Date</label>
                <div class="col-md-6 col-xs-12">
                    <div class="input-group">
                        <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                        <input name="quote_date" type="text" class="form-control datepicker" value="{if $smarty.session.quote.step_1.quote_date}{$smarty.session.quote.step_1.quote_date}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" readonly="readonly">
                    </div>

                </div>
            </div>
            {* <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Branch</label>
                <div class="col-md-6 col-xs-12">
                     <select name="quote_branch" id="quote_branch" class="form-control">
				            <option value="Main Branch"  {if $formdata.quote_branch eq "Main Branch" || $smarty.session.quote.step_1.quote_branch eq "Main Branch"}selected{/if}>Main Branch (Mwenge)</option>
				        	<option value="Zanzibar"  {if $formdata.quote_branch eq "Zanzibar" || $smarty.session.quote.step_1.quote_branch eq "Zanzibar"}selected{/if}>Zanzibar</option>
				     </select>
                </div>
            </div> *}

            <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Company / Group</label>
                <div class="col-md-6 col-xs-12">

                    <select name="group_id" id="group_id"  class="form-control"></select>

                </div>
            </div>

            <div class="form-group customer">
                <label class="col-md-3 col-xs-12 control-label">Customer</label>
                <div class="col-md-6 col-xs-12">
                  <div class="input-group">
                    <select name="customer_id" id="customer_id" class="form-control">
			        	<option value="0">Please Select or click the right icon</option>
			        </select>
			         <span class="input-group-addon">
				        <a title="Select Customer" href="#" onclick="customerSelector(); return false;"><span class="fa fa-search"></span></a>
				    </span>

                  </div>
                </div>
            </div>
            <div class="form-group walk_in" style="display:none;">
                <label class="col-md-3 col-xs-12 control-label">Customer Name</label>
                <div class="col-md-6 col-xs-12">
                   <input name="customer_name" type="text" class="form-control" value="{if $smarty.session.quote.step_1.customer_name}{$smarty.session.quote.step_1.customer_name}{else}{$smarty.post.customer_name}{/if}" >
                </div>
            </div>

            <div class="form-group walk_in" style="display:none;">
                <label class="col-md-3 col-xs-12 control-label">TIN</label>
                <div class="col-md-6 col-xs-12">
                   <input name="customer_tin" type="text" class="form-control" value="{if $smarty.session.quote.step_1.customer_tin}{$smarty.session.quote.step_1.customer_tin}{else}{$smarty.post.customer_tin}{/if}" >
                </div>
            </div>

             {* <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Payment Terms</label>
                <div class="col-md-6 col-xs-12">
                     <select name="quote_payment_terms" id="quote_payment_terms" class="form-control" required>
				      <option value="">Please Select..</option>

				      {section name=item_payment_terms loop=$item_payment_terms}

				       <option value="{$item_payment_terms[item_payment_terms].payment_id}" {if $item_payment_terms[item_payment_terms].payment_id eq $formdata.item_payment_terms || $smarty.session.quote.step_1.quote_payment_terms[0].payment_id eq $item_payment_terms[item_payment_terms].payment_id}selected{/if}>{$item_payment_terms[item_payment_terms].payment_term}</option>

				      {/section}

				     </select>
                </div>

            </div> *}

             <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Quote Validity</label>
                <div class="col-md-6 col-xs-12">
								 <select name="quote_validity" id="quote_validity" class="form-control">
									 <option value="">Please Select..</option>
									 <option value="30"  {if $formdata.quote_validity eq "30" || $smarty.session.quote.step_1.quote_validity eq "30"}selected{/if}>30 Days</option>
									 <option value="60"  {if $formdata.quote_validity eq "60" || $smarty.session.quote.step_1.quote_validity eq "60"}selected{/if}>60 Days</option>
									 <option value="90"  {if $formdata.quote_validity eq "90" || $smarty.session.quote.step_1.quote_validity eq "90"}selected{/if}>90 Days</option>
								 </select>

                   {* <input name="quote_validity" type="text" class="form-control" value="{if $smarty.session.quote.step_1.quote_validity}{$smarty.session.quote.step_1.quote_validity}{else}{$smarty.post.quote_validity}{/if}" > *}

                </div>
            </div>

             <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Currency</label>
                <div class="col-md-6 col-xs-12">
                     <select name="currency" id="currency" class="form-control">
				            <option value="TZS"  {if $formdata.currency eq "TZS" || $smarty.session.quote.step_1.quote_currency eq "TZS"}selected{/if}>TZS</option>
				        	<option value="USD"  {if $formdata.currency eq "USD" || $smarty.session.quote.step_1.quote_currency eq "USD"}selected{/if}>USD</option>
				    	</select>
                </div>
            </div>
            <div class="form-group">
                    <label class="col-md-3 control-label">Exchange Rate</label>
                    <div class="col-md-6">
                      <input type="text" name="exch_rate"  id="exch_rate" class="form-control"  value="{if $smarty.post.exch_rate}{$smarty.post.exch_rate}{else}{$smarty.session.quote.step_1.exch_rate}{/if}" />
                    </div>
               </div>

            <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Tax</label>
                <div class="col-md-6 col-xs-12">
                     <select name="tax" id="tax" class="form-control">
				            <option value="Taxable"  {if $formdata.tax eq "Taxable" || $smarty.session.quote.step_1.quote_tax eq "Taxable"}selected{/if}>Taxable</option>
				        	<option value="Exempt"  {if $formdata.tax eq "Exempt" || $smarty.session.quote.step_1.quote_tax eq "Exempt"}selected{/if}>Exempt</option>
				     </select>
                </div>
            </div>

            <div class="form-group vat_field" {if $formdata.tax eq "Taxable" || $smarty.session.quote.step_1.quote_tax eq "Taxable"}{else}style="display:none;"{/if}>
                <label class="col-md-3 col-xs-12 control-label">VAT %</label>
                <div class="col-md-6 col-xs-12">
                     <select name="vat" id="vat" class="form-control">
				            <option value="18"  {if $formdata.vat eq "18" || $smarty.session.quote.step_1.vat eq "18"}selected{/if}>18%</option>
                            <option value="15"  {if $formdata.vat eq "15" || $smarty.session.quote.step_1.vat eq "15"}selected{/if}>15%</option>
				        	<option value="0"  {if $formdata.vat eq "0" || $smarty.session.quote.step_1.vat eq "0"}selected{/if}>0%</option>
				     </select>
                </div>
            </div>

             <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Discount</label>
                <div class="col-md-6 col-xs-12">
                   <input name="quote_discount" type="text" class="form-control" value="{if $smarty.session.quote.step_1.quote_discount}{$smarty.session.quote.step_1.quote_discount}{else}{$smarty.post.quote_discount}{/if}" >
                </div>
            </div>

        </div>
        <div class="panel-footer">
            <input name="next_step" type="hidden" id="next_step" value="two" />
            <input name="quote_template" type="hidden" value="normal" />
            <button type="submit" class="btn btn-primary pull-right">Go to Step 2</button>
        </div>


    </div>
 </form>


 {include file = 'quotes/new_company_modal.tpl'}
