 <!-- PAGE PLUGINS -->
        <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
        <script type="text/javascript" src="/js/jquery/jquery.livequery.min.js"></script>
        <script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>
        <!--  <script type="text/javascript" src="/js/plugins/smartwizard/jquery.smartWizard-2.0.min.js"></script>  -->
        
        <script type='text/javascript' src='/js/plugins/jquery-validation/jquery.validate.js'></script>                
        
        {literal}
        
<script type="text/javascript">
	
	var obj = null;
		
	$('#group_id').livequery('change',function() { //start function when any link is clicked
		
		
		obj = document.getElementById('customer_id');			
		content_show = document.getElementById('group_id').value;
		
		ajaxLoad(content_show, obj); 
		 
	}); 

	function ajaxLoad(content_show, obj) {
		
		// Load Content
		$.ajax({
			method: "get",url: "/modules/quotes/customers_ajax.php",data: "group="+content_show,
			dataType: "html",
			beforeSend: function(){ obj.options.length = 0; obj.options[obj.options.length] = new Option('Loading...','0'); }, //show loading just when link is clicked
			complete: function(){ 
				// Do nothing 
			}, //stop showing loading when the process is complete
			success: function(script){ //so, if data is retrieved, store it in html
				
				console.log(script);
				
				var obj = document.getElementById('customer_id');
				
				// alert(script);
				obj.options.length = 0; 
				obj.options[obj.options.length] = new Option('Please Select','0');
				eval(script); // process JS
			 }
		 }); //close $.ajax(
		
	}
	
	$('#item_price_1').on('blur', function() {
		
		var amount = $('#item_price_1').val().replace(/^\s+|\s+$/g, '');

		if( $.isNumeric(amount) ) { 
		
			if( ($('#item_price_1').val() != '') && (!amount.match(/^$/) )){

			    $('#item_price_1').val( parseFloat(amount).toFixed(2));
			    
			}

		} else {

			// Set it to 0.00
			$('#item_price_1').val('0.00');
			
		}
		
	});
	
	// Keep summary details if checkbox is checked	
	$(function(){
		
		if($('#show_summary').is(':checked')) {
			
			localStorage.show_summary = 'true';
		}
		
	    var check_summary = localStorage.show_summary === 'true'? true: false;
	    $('#show_summary').prop('checked', check_summary || false);
	    
	    if(localStorage.show_summary === 'true'){
	    	
	    	$('#summary').show();
	    }
	});
	
	

	$('#show_summary').on('change', function() {
	    localStorage.show_summary = $(this).is(':checked');
	    console.log(localStorage.show_summary);
	});
	
	
	
	/* if($('#next_step_info_0').is(':checked')) {
		
		var jvalidate = $("#quotes-form").validate({
	        ignore: [],
	        rules: {                                            
		        	item_price_1: {
		                        required: true,
		                        number: true
		            },
		            item_title: {  
	                    required: true
	                }
	            }                                        
	        });     
		
		
    } */
	
	
	
</script>
{/literal}
        
<!-- END PAGE PLUGINS --> 