


<div id="summary" class="panel panel-default" style="display:none;">

		<div class="panel-heading">
		        <h3 class="panel-title">Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">item #</th>
							    <th>Description</th>
									<th>Qty</th>
							    <th>Unit Price {if $quote_data.currency}({$quote_data.currency}){/if}</th>
							    <th>Amount {if $quote_data.currency}({$quote_data.currency}){/if}</th>
							    <th width="50">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$quote_items}
						  <tr>
						    <td class="text-center">{$smarty.section.items.rownum}</td>

						    <td>
						    {$quote_items[items].product_name} {if $quote_items[items].item_product_other}({$quote_items[items].item_product_other}){/if} - {$quote_items[items].item_title}
						    <p style="line-height:18px;">

									{if $quote_items[items].stock_id}
									 Stock #{$quote_items[items].stock_id}: {$quote_items[items].product_specifications};
									{/if}

						      Origination: {$quote_items[items].item_origination};{if $quote_items[items].item_delivery_days} Delivery Days: {$quote_items[items].item_delivery_days};{/if}
							 {if $quote_items[items].item_paper_size}Size: {$quote_items[items].item_paper_size} {if $quote_items[items].item_paper_size_other} - {$quote_items[items].item_paper_size_other}{/if};{/if}
						      {if $quote_items[items].product_type eq 'Paper' || $quote_items[items].product_type eq 'Books'}
							{if $quote_items[items].item_orientation|capitalize}Orientation: {$quote_items[items].item_orientation|capitalize};{/if} 
							{if $quote_items[items].item_cover_paper_type || $quote_items[items].item_cover_paper_type_other}Cover Paper: {$quote_items[items].item_cover_paper_type} 
							{if $quote_items[items].item_cover_paper_type_other}({$quote_items[items].item_cover_paper_type_other}){/if}{/if}; 
							{if $quote_items[items].item_cover_paper_desc}Cover Paper Description: {$quote_items[items].item_cover_paper_desc};{/if} Paper Weight: {$quote_items[items].item_cover_paper_weight} gsm; {if $quote_items[items].item_cover_color}Print: {$quote_items[items].item_cover_color} {if $quote_items[items].item_cover_color_other}({$quote_items[items].item_cover_color_other}){/if};{/if} {if $quote_items[items].item_cover_print_options}Print Options: {$quote_items[items].item_cover_print_options|capitalize};{/if}{/if}
						    {if $quote_items[items].product_type eq 'Books'}Inner Paper: {$quote_items[items].item_inner_paper_type};
							 {if $quote_items[items].item_inner_paper_desc}Inner Paper Description: {$quote_items[items].item_inner_paper_desc};{/if} 
							{if $quote_items[items].item_inner_paper_weight}Inner Paper Weight: {$quote_items[items].item_inner_paper_weight} gsm;{/if} Inner Print: {$quote_items[items].item_inner_color}
							 {if $quote_items[items].item_inner_color_other}({$quote_items[items].item_inner_color_other}){/if}; 
							{if $quote_items[items].item_inner_print_options}Inner Print Options: {$quote_items[items].item_inner_print_options|capitalize};{/if} 
							{/if} {if $quote_items[items].item_print_process}Print Process: {$quote_items[items].item_print_process};{/if}

                             {if $quote_items[items].item_process}
							 {$quote_items[items].item_process}				
							{/if}
						      Finishing: {section name=item_finishing_summary loop=$quote_items[items].item_finishing}
			            	            {$quote_items[items].item_finishing[item_finishing_summary][0].finishing_type};
							            {sectionelse}
							           	 	None;
							            {/section}

           
						    </p>
						    {if $quote_items[items].item_notes}<p style="line-height:18px;">Notes: {$quote_items[items].item_notes}</p> {/if}
						    {if $quote_items[items].item_special_remarks}<p style="line-height:18px;">Special Remarks: {$quote_items[items].item_special_remarks}</p>{/if}
                        
						     {if $quote_items[items].item_wht_amount > 0}<p>WHT Amount: {$quote_items[items].item_wht_amount} {$quote_data.currency}</p> {/if}
                             
						{* <pre>{$quote_items[items]|@print_r}</pre>		 *}
						    </td>
								<td>
								 <input type="number"  name="item_qty[{$quote_items[items].item_id}]" id="item_qty{$quote_items[items].item_id}" data-item_id="{$quote_items[items].item_id}" class="form-control item_qty" value="{$quote_items[items].item_quantity_1}" step="any">
							 </td>
						    <td>
									<input type="number"  name="item_unit_price[{$quote_items[items].item_id}]" id="item_unit_price{$quote_items[items].item_id}" data-item_id="{$quote_items[items].item_id}" class="form-control item_unit_price" value="{$quote_items[items].item_price_1}" step="any">
							</td>
						    <td id="amount{$quote_items[items].item_id}">{$quote_items[items].item_total_price|number_format:0:".":","}</td>

						    <td>
						      <a title="Edit Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/edit/?id={$quote_data.quote_id}&subtask=edit&subid={$quote_items[items].item_id}"><span class="fa fa-pencil"></span></a>
			                   <a title="Delete Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/edit/?id={$quote_data.quote_id}&subtask=delete&subid={$quote_items[items].item_id}"><span class="fa fa-times"></span></a>
                    <input type="hidden" class="amount{$quote_items[items].item_id} amount" value="{$quote_items[items].item_total_price}">
								 </td>

						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="6"><div>No Items have been added to this quotation yet.</td>
						  </tr>
						  {/section}

						  {if $quote_items|@count gt 0}
						  <tr class="info">
						   <td colspan="4" align="right"><strong>Sub Total</strong></td><td id="subtotal">{$quote_items[0].sub_total|number_format:0:".":","}</td><td></td>
						  </tr>
						  {if $quote_data.tax eq 'Taxable'}
						  <tr class="warning" >
						   <td colspan="4" align="right"align="right"><strong>Taxes</strong></td><td id="taxes">{$quote_items[0].tax|number_format:0:".":","}</td><td></td>
						  </tr>
						  {/if}
						  <tr class="success">
						   <td colspan="4" align="right"><strong>Total</strong></td><td id="total">{$quote_items[0].grand_total|number_format:0:".":","}</td><td></td>
						  </tr>
						  {/if}

                        </tbody>
                    </table>

                </div>

  </div>


</div>

</form>

{literal}
<script type="text/javascript">

	var prod = new Array();
{/literal}
	{section name=product_types loop=$product_types}
	prod[{$product_types[product_types].product_id}] = '{$product_types[product_types].product_2rows}';
	{/section}
{literal}
</script>
{/literal}

{if !$no_edit}
<form id="quotes-form" class="form-horizontal" method="post" action="/quotes/edit?id={$smarty.get.id}&subtask=new">
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Add New Item</h3>

      </div>

      <div class="panel-body">

          <div class="row">

              <div class="col-md-6">

                  <div class="form-group">
                      <label class="col-md-4 control-label">Product Type <span class="asterisk">*</span></label>
                      <div class="col-md-8">
                          <select name="product_id" id="product_id" class="form-control" onchange="toggle_2rows(this.value, $(this).find(':selected').attr('data-type')); checkOther(this.value, 13, 'item_product_other');" required>
					      <option value="0">Please Select</option>
					      {section name=product_types loop=$product_types}
					      <option value="{$product_types[product_types].product_id}" data-type = "{$product_types[product_types].product_type}" {if $smarty.post.product_id && $smarty.post.product_id == $product_types[product_types].product_id}selected{elseif !$smarty.post.product_id && $item_data.item_product[0].product_id eq $product_types[product_types].product_id}selected{/if}>{$product_types[product_types].product_name} ({$product_types[product_types].product_ref})</option>
					      {/section}
                          </select>
                          <input name="item_product_other" type="text" id="item_product_other" value="{$item_data.item_product_other}" class="form-control" style="display:none; margin-top:5px;" />

                      </div>
                  </div>

                  <div class="form-group hide-stationary">
                      <label class="col-md-4 control-label">Origination</label>
                      <div class="col-md-8 col-xs-12">
                         <select name="item_origination" id="item_origination" class="form-control">
				        {section name=item_origination loop=$item_origination}
				        	<option value="{$item_origination[item_origination]}" {if $smarty.post.item_origination && $smarty.post.item_origination eq $item_origination[item_origination]}selected{elseif !$smarty.post.item_origination && $item_data.item_origination eq $item_origination[item_origination]}selected{/if}>{$item_origination[item_origination]}</option>
				        {/section}
				    	</select>
                      </div>
                  </div>

                  <div class="form-group hide-stationary">
                      <label class="col-md-4 control-label">Size <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
                          <select name="item_paper_size" id="item_paper_size" class="form-control" onchange="checkOther(this.value, 9, 'item_paper_size_other');">
					      <option value="0">Please Select</option>
					      {section name=paper_sizes_finished loop=$paper_sizes_finished}
					      <option value="{$paper_sizes_finished[paper_sizes_finished].size_id}" {if $smarty.post.item_paper_size && $smarty.post.item_paper_size eq $paper_sizes_finished[paper_sizes_finished].size_id}selected{elseif !$smarty.post.item_paper_size && isset($item_data.item_paper_size[0].paper_size) && $item_data.item_paper_size[0].paper_size eq $paper_sizes_finished[paper_sizes_finished].paper_size}selected{elseif !$smarty.post.item_paper_size && $item_data.item_paper_size eq $paper_sizes_finished[paper_sizes_finished].size_id}selected{/if}>{$paper_sizes_finished[paper_sizes_finished].paper_size}</option>
					      {/section}
					    </select>
					    <input name="item_paper_size_other" type="text" id="item_paper_size_other" value="{$item_data.item_paper_size_other}" class="form-control"  style="display:none;"  /></td>

                      </div>

                  </div>
                  <div class="form-group paper-row" style="display:none;">
                      <label class="col-md-4 control-label">Orientation</label>
                      <div class="col-md-8">
                          <div class="col-md-6">
	                         <label class="check"><input type="radio" class="iradio" name="item_orientation" id="item_orientation_0" value="Portrait" {if !$item_data.item_orientation}checked="checked"{/if}{if $item_data.item_orientation eq 'Portrait'}checked="checked"{/if}/> Portrait</label>
	                      </div>
	                      <div class="col-md-6">
	                         <label class="check"><input type="radio" class="iradio" name="item_orientation" id="item_orientation_1" value="Landscape" {if $item_data.item_orientation eq 'Landscape'}checked="checked"{/if} /> Landscape</label>
	                      </div>
                      </div>
                  </div>

                   <div class="form-group paper-row" {if $smarty.post.product_type == 'Books'}style="display:block;"{elseif isset($item_data.item_product[0].product_type) && $item_data.item_product[0].product_type == 'Books'}style="display:block;"{else}style="display:none;"{/if}>
                      <label class="col-md-4 control-label">No. of Pages <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					    <input name="item_num_pages" type="number" id="item_num_pages" value="{$item_data.item_num_pages}" class="form-control" />
                      </div>
                  </div>

									<div class="form-group stock_field" style="display:none;">
											 <label class="col-md-4 control-label">Stock <span class="asterisk">*</span></label>
											 <div class="col-md-8 col-xs-12">

													 <select name="stock_id" id="stock_id"  class="form-control" style="width:100%;"></select>
													 <input type="hidden" name="stock_description" id="stock_description" value="" >

											 </div>
									 </div>


              </div>
              <div class="col-md-6">

                   <div class="form-group hide-stationary">
                      <label class="col-md-4 control-label">Reference <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
                          <input name="item_title" type="text" id="item_title" value="{$item_data.item_title}" class="form-control" />
                      </div>
                  </div>

                  <div class="form-group hide-stationary">
                      <label class="col-md-4 control-label">Delivery Days</label>
                      <div class="col-md-8">
                         <input name="item_delivery_days" type="number" id="item_delivery_days" value="{if $item_data.item_delivery_days}{$item_data.item_delivery_days}{/if}"  class="form-control">
                      </div>
                  </div>

                  <div class="form-group">
                      <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					    <input name="item_quantity_1" type="number" id="item_quantity_1" value="{$item_data.item_quantity_1}" class="form-control"  required/>
                      </div>
                  </div>

                  <div class="form-group">
                      <label class="col-md-4 control-label">Price <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					    <input name="item_price_1" type="text" id="item_price_1" value="{$item_data.item_price_1}" class="form-control" required />
					 </div>
                  </div>
                  
                  <div class="form-group">
                      <label class="col-md-4 control-label">WHT Amount</label>
                      <div class="col-md-8">

					    <input name="item_wht_amount" type="text" id="item_wht_amount" value="{$item_data.item_wht_amount}" class="form-control"/>
					 </div>
                  </div>

              </div>

          </div>


          <div class="row books-row" style="display:none;">
              <br /> <br />
              <h4>PRINTING (COVER PAPER) <span class="asterisk">*</span></h4>

               <div class="col-md-2">
                 <div class="form-group">
                    <div class="col-md-12">
                    <label class="check"><input type="radio" class="iradio" name="cover_print_options" id="item_cover_digital" value="item_cover_digital" {if $smarty.post.cover_print_options eq 'item_cover_digital'}checked{elseif $item_data.item_cover_digital eq 'Y'}checked{/if} />Digital</label>
                    </div>
                </div>
               </div>
               <div class="col-md-2">
                  <div class="form-group">

                    <div class="col-md-12">
                    <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="item_cover_offset" value="item_cover_offset" {if $smarty.post.cover_print_options eq 'item_cover_offset'}checked{elseif $item_data.item_cover_offset eq 'Y'}checked{/if} />Offset</label>
                    </div>
                </div>
               </div>
               <div class="col-md-3">
                 <div class="form-group">

                    <div class="col-md-12">
                    <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="item_cover_wide_format" value="item_cover_wide_format" {if $smarty.post.cover_print_options eq 'item_cover_wide_format'}checked{elseif $item_data.item_cover_wide_format eq 'Y'}checked{/if} />Wide Format</label>
                    </div>
                </div>
               </div>
               <div class="col-md-2">
                 <div class="form-group">

                    <div class="col-md-12">
                    <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="item_cover_promotional" value="item_cover_promotional" {if $smarty.post.cover_print_options eq 'item_cover_promotional'}checked{elseif $item_data.item_cover_promotional eq 'Y'}checked{/if} />Promotional</label>
                    </div>
                </div>
               </div>
               {* <div class="col-md-3">
                  <div class="form-group">

                    <div class="col-md-12">
                    <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="item_cover_cnc" value="item_cover_cnc" {if $smarty.post.cover_print_options eq 'item_cover_cnc'}checked{elseif $item_data.item_cover_cnc eq 'Y'}checked{/if} />Signage / CNC</label>
                    </div>
                </div>
               </div> *}


              <div class="col-md-12 item_cover_digital" style="margin-top:15px;  {if $smarty.post.cover_print_options eq 'item_cover_digital'}{elseif $item_data.item_cover_digital eq 'Y'}{else}display:none;{/if}">
               <div class="col-md-6">
                 <div class="form-group">
                       <label class="col-md-4 control-label">Paper Type</label>
                       <div class="col-md-8 col-xs-12">
 	                          <select name="item_cover_digital_paper_type" id="item_cover_digital_paper_type" onchange="checkOther(this.value, 11, 'item_cover_digital_paper_type_other');" class="form-control">
 							      <option value="">Please Select</option>
 							      {section name=paper_types loop=$paper_types}
 							      <option value="{$paper_types[paper_types].paper_id}" {if $smarty.post.item_cover_digital_paper_type && $smarty.post.item_cover_digital_paper_type eq $paper_types[paper_types].paper_id}selected{elseif !$smarty.post.item_cover_digital_paper_type && $item_data.item_cover_digital_paper_type eq $paper_types[paper_types].paper_id}selected{/if}>{$paper_types[paper_types].paper_name}</option> 
 							      {/section}
 							    </select> <input name="item_cover_digital_paper_type_other" type="text" id="item_cover_digital_paper_type_other" value="{if $smarty.post.item_cover_digital_paper_type_other}{$smarty.post.item_cover_digital_paper_type_other}{elseif $item_data.item_cover_paper_type_other}{$item_data.item_cover_paper_type_other}{/if}" class="form-control" style="display:none;" />
 					</div>

                   </div>
                   <div class="form-group">
                       <label class="col-md-4 control-label">Paper Weight</label>
                       <div class="col-md-8">

 					    <select name="item_cover_digital_paper_weight" id="item_cover_digital_paper_weight" class="form-control">
 					      <option value="0">Please Select</option>
 					      {section name=paper_weights loop=$paper_weights}
 					      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.item_cover_digital_paper_weight && $smarty.post.item_cover_digital_paper_weight eq $paper_weights[paper_weights].weight_value}selected{elseif !$smarty.post.item_cover_digital_paper_weight && $paper_weights[paper_weights].weight_value eq $item_data.item_cover_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
 					      {/section}
 					    </select>
 					   </div>
                   </div>
               </div>
               <div class="col-md-6">
                 <div class="form-group">
                       <label class="col-md-6 control-label">No. of A3+ Sheets <span class="asterisk">*</span></label>
                       <div class="col-md-6">

 					    <input name="item_cover_digital_num_sheets_fsize" type="text" id="item_cover_digital_num_sheets_fsize" value="{if $smarty.post.item_cover_digital_num_sheets_fsize}{$smarty.post.item_cover_digital_num_sheets_fsize}{elseif $item_data.item_cover_num_sheets}{$item_data.item_cover_num_sheets}{/if}" class="form-control" />
 					 </div>
                   </div>
                   <div class="form-group">
                    <label class="col-md-4 control-label">Print Options</label>
                    <div class="col-md-8">
                    <div class="col-md-6">
                        <label class="check"><input type="radio" class="iradio" name="item_cover_digital_print_options" id="item_cover_digital_print_options_2" value="Single" {if $smarty.post.item_cover_digital_print_options eq 'Single'}checked="checked"{elseif $item_data.item_cover_print_options eq 'Single'}checked="checked"{/if} />Single Side</label>
                     </div>
                     <div class="col-md-6">
                        <label class="check"><input type="radio" class="iradio" name="item_cover_digital_print_options" id="item_cover_digital_print_options_3" value="Both" {if $smarty.post.item_cover_digital_print_options eq 'Both'}checked="checked"{elseif $item_data.item_cover_print_options eq 'Both'}checked="checked"{/if} />Both Sides</label>
                     </div>
                    </div>
                </div>
               </div>
             </div>

             <div class="col-md-12 item_cover_offset" style="margin-top:15px; {if $smarty.post.cover_print_options eq 'item_cover_offset'}{elseif $item_data.item_cover_offset eq 'Y'}{else} display:none; {/if}">


                {section name=cover_offset loop=$cover_offset_info}

                   <div class="col-md-12 offset_cover_section" style="padding:0 0 15px;">
                    {assign var=count value=$smarty.section.cover_offset.index+1}
 	                 <h5 class="master_label">Section {$count}</h5>
 	                 <div class="col-md-6">
 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Type</label>
 		                      <div class="col-md-8 col-xs-12">
 			                          <select name="item_cover_offset_paper_type[]" id="item_cover_offset_paper_type" onchange="toggleOther(this, 11, 'cover');" class="form-control">
 									      <option value="0">Please Select</option>
 									      {section name=paper_types loop=$paper_types}
 									      <option value="{$paper_types[paper_types].paper_id}" {if isset($smarty.post.item_cover_offset_paper_type[0]) && $smarty.post.item_cover_offset_paper_type[0] eq $paper_types[paper_types].paper_id}selected{elseif !isset($smarty.post.item_cover_offset_paper_type[0]) && $cover_offset_info[cover_offset].item_cover_paper_type_id eq $paper_types[paper_types].paper_id}selected{/if}>{$paper_types[paper_types].paper_name}</option>
 									      {/section}
 									    </select> <input name="item_cover_offset_paper_type_other[]" type="text" id="item_cover_offset_paper_type_other" value="{if $smarty.post.item_cover_offset_paper_type_other[0]}{$smarty.post.item_cover_offset_paper_type_other[0]}{elseif $cover_offset_info[cover_offset].item_cover_paper_type_other}{$cover_offset_info[cover_offset].item_cover_paper_type_other}{/if}" class="form-control" {if !$cover_offset_info[cover_offset].item_cover_paper_type_other}style="display:none;"{/if} />
 							</div>
 		                  </div>
 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">Impressions</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_cover_offset_impressions[]" type="number" id="item_cover_offset_impressions" value="{if $smarty.post.item_cover_offset_impressions[0]}{$smarty.post.item_cover_offset_impressions[0]}{elseif $cover_offset_info[cover_offset].item_cover_impressions}{$cover_offset_info[cover_offset].item_cover_impressions}{/if}"  class="form-control" onblur="calc_num_of_sheets(this, 'cover');" />
 		                   </div>
 		               </div>

 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Pre Press</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_cover_offset_pre_press[]" id="item_cover_offset_pre_press" onchange="calc_total_plates(this, 'cover');" class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="Work/Turn" {if isset($smarty.post.item_cover_offset_pre_press[0]) && $smarty.post.item_cover_offset_pre_press[0] eq 'Work/Turn'}selected{elseif !isset($smarty.post.item_cover_offset_pre_press[0]) && $cover_offset_info[cover_offset].item_cover_pre_press eq 'Work/Turn'}selected{/if}>Work/Turn</option>
 								      <option value="Work/Tumble" {if isset($smarty.post.item_cover_offset_pre_press[0]) && $smarty.post.item_cover_offset_pre_press[0] eq 'Work/Tumble'}selected{elseif !isset($smarty.post.item_cover_offset_pre_press[0]) && $cover_offset_info[cover_offset].item_cover_pre_press eq 'Work/Tumble'}selected{/if}>Work/Tumble</option>
 								      <option value="Front/Back" {if isset($smarty.post.item_cover_offset_pre_press[0]) && $smarty.post.item_cover_offset_pre_press[0] eq 'Front/Back'}selected{elseif !isset($smarty.post.item_cover_offset_pre_press[0]) && $cover_offset_info[cover_offset].item_cover_pre_press eq 'Front/Back'}selected{/if}>Front/Back</option>
 								      <option value="One Side" {if isset($smarty.post.item_cover_offset_pre_press[0]) && $smarty.post.item_cover_offset_pre_press[0] eq 'One Side'}selected{elseif !isset($smarty.post.item_cover_offset_pre_press[0]) && $cover_offset_info[cover_offset].item_cover_pre_press eq 'One Side'}selected{/if}>One Side</option>
 							      </select>
 			                  </div>
 		                  </div>

 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">No of Colours</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_cover_offset_no_of_colors[]" type="text" id="item_cover_offset_no_of_colors" onblur="calc_total_plates(this, 'cover');" value="{if $smarty.post.item_cover_offset_no_of_colors[0]}{$smarty.post.item_cover_offset_no_of_colors[0]}{elseif $cover_offset_info[cover_offset].item_cover_no_of_colors}{$cover_offset_info[cover_offset].item_cover_no_of_colors}{/if}" class="form-control" />
 		                   </div>
 		               </div>
 		               <div class="form-group">
 		                     <label class="col-md-4 control-label">No of Sheets </label>
 		                     <div class="col-md-8">
 						     <input name="item_cover_offset_num_sheets[]" type="text" id="item_cover_offset_num_sheets" value="{if $smarty.post.item_cover_offset_num_sheets[0]}{$smarty.post.item_cover_offset_num_sheets[0]}{elseif $cover_offset_info[cover_offset].item_cover_num_sheets}{$cover_offset_info[cover_offset].item_cover_num_sheets}{/if}" class="form-control" />
 						 </div>
 		                 </div>
 		            </div>

 		            <div class="col-md-6">
 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Weight</label>
 		                      <div class="col-md-8">

 							    <select name="item_cover_offset_paper_weight[]" id="item_cover_offset_paper_weight" class="form-control">
 							      <option value="0">Please Select</option>
 							      {section name=paper_weights loop=$paper_weights}
 							      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.item_cover_offset_paper_weight[0] eq $paper_weights[paper_weights].weight_value}selected{elseif isset($cover_offset_info[cover_offset].item_cover_paper_weight) && $cover_offset_info[cover_offset].item_cover_paper_weight eq $paper_weights[paper_weights].weight_value}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
 							      {/section}
 							    </select>
 							   </div>
 		                  </div>
 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">Machine</label>
 		                   <div class="col-md-8 col-xs-12">
 			                   <select name="item_cover_offset_machine[]" id="item_cover_offset_machine" class="form-control">
 							        <option value="0">Please Select</option>
 							      {section name=job_printers loop=$job_printers}
 							      <option value="{$job_printers[job_printers].printer_name}" {if isset($smarty.post.item_cover_offset_machine[0]) && $smarty.post.item_cover_offset_machine[0] eq $job_printers[job_printers].printer_name}selected{elseif !isset($smarty.post.item_cover_offset_machine[0]) && $cover_offset_info[cover_offset].item_cover_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
 							      {/section}
 							    </select>
 		                   </div>
 		               </div>

 		               <div class="form-group">
 		                      <label class="col-md-4 control-label">Plate Size</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_cover_offset_plate_size[]"  class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="SM74" {if isset($smarty.post.item_cover_offset_plate_size[0]) && $smarty.post.item_cover_offset_plate_size[0] eq 'SM74'}selected{elseif !isset($smarty.post.item_cover_offset_plate_size[0]) && $cover_offset_info[cover_offset].item_cover_plate_size eq 'SM74'}selected{/if}>SM74</option>
 								      <option value="Sm52" {if isset($smarty.post.item_cover_offset_plate_size[0]) && $smarty.post.item_cover_offset_plate_size[0] eq 'Sm52'}selected{elseif !isset($smarty.post.item_cover_offset_plate_size[0]) && $cover_offset_info[cover_offset].item_cover_plate_size eq 'Sm52'}selected{/if}>Sm52</option>
 								      <option value="GTO46" {if isset($smarty.post.item_cover_offset_plate_size[0]) && $smarty.post.item_cover_offset_plate_size[0] eq 'GTO46'}selected{elseif !isset($smarty.post.item_cover_offset_plate_size[0]) && $cover_offset_info[cover_offset].item_cover_plate_size eq 'GTO46'}selected{/if}>GTO46</option>
 							      </select>
 			                  </div>
 		                  </div>

 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">Total Plates</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_cover_offset_total_plates[]" type="text" id="item_cover_offset_total_plates" value="{if $smarty.post.item_cover_offset_total_plates[0]}{$smarty.post.item_cover_offset_total_plates[0]}{elseif $cover_offset_info[cover_offset].item_cover_total_plates}{$cover_offset_info[cover_offset].item_cover_total_plates}{/if}" class="form-control" readonly/>
 		                   </div>
 		               </div>
 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Press Sheet Size</label>

 		                      <div class="col-md-8">
 		                         <select name="item_cover_offset_sheet_size[]" id="item_cover_offset_sheet_size" onchange="calc_num_of_sheets(this, 'cover');" class="form-control" style="margin-bottom:5px;">
 								      <option value="A1" {if isset($smarty.post.item_cover_offset_sheet_size[0]) && $smarty.post.item_cover_offset_sheet_size[0] eq 'A1'}selected{elseif !isset($smarty.post.item_cover_offset_sheet_size[0]) && $cover_offset_info[cover_offset].item_cover_sheet_size eq 'A1'}selected{/if}>A1</option>
 								      <option value="A2" {if isset($smarty.post.item_cover_offset_sheet_size[0]) && $smarty.post.item_cover_offset_sheet_size[0] eq 'A2'}selected{elseif !isset($smarty.post.item_cover_offset_sheet_size[0]) && $cover_offset_info[cover_offset].item_cover_sheet_size eq 'A2'}selected{/if}>A2</option>
 								      <option value="A3" {if isset($smarty.post.item_cover_offset_sheet_size[0]) && $smarty.post.item_cover_offset_sheet_size[0] eq 'A3'}selected{elseif !isset($smarty.post.item_cover_offset_sheet_size[0]) && $cover_offset_info[cover_offset].item_cover_sheet_size eq 'A3'}selected{/if}>A3</option>
 								      <option value="A4" {if isset($smarty.post.item_cover_offset_sheet_size[0]) && $smarty.post.item_cover_offset_sheet_size[0] eq 'A4'}selected{elseif !isset($smarty.post.item_cover_offset_sheet_size[0]) && $cover_offset_info[cover_offset].item_cover_sheet_size eq 'A4'}selected{/if}>A4</option>
 								      <option value="Other" {if isset($smarty.post.item_cover_offset_sheet_size[0]) && $smarty.post.item_cover_offset_sheet_size[0] eq 'Other'}selected{elseif !isset($smarty.post.item_cover_offset_sheet_size[0]) && $cover_offset_info[cover_offset].item_cover_sheet_size eq 'Other'}selected{/if}>Other</option>
 							    </select>
 							    <span id="cover_sheet_size_other" {if $cover_offset_info[cover_offset].item_cover_sheet_size neq 'Other'}style="display:none;"{/if}>
 							      <input type="text" name="item_cover_offset_sheet_w[]" class="form-control" placeholder="Width" value="{if $smarty.post.item_cover_offset_sheet_w[0]}{$smarty.post.item_cover_offset_sheet_w[0]}{elseif $cover_offset_info[cover_offset].item_cover_sheet_size_w}{$cover_offset_info[cover_offset].item_cover_sheet_size_w}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;" > x
 		                          <input type="text" name="item_cover_offset_sheet_h[]" class="form-control" placeholder="Height" value="{if $smarty.post.item_cover_offset_sheet_h[0]}{$smarty.post.item_cover_offset_sheet_h[0]}{elseif $cover_offset_info[cover_offset].item_cover_sheet_size_h}{$cover_offset_info[cover_offset].item_cover_sheet_size_h}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;">

 							    </span>

 							 </div>
 		                  </div>



 		            </div>

 		          {if $count neq '1'}  <a class="remove" title="Remove" href="#" onclick="$(this).parent().remove();  return false"><span class="fa fa-times text-danger"></span></a>{/if}

 	            </div>

 	            {sectionelse}

 	              <div class="col-md-12 offset_cover_section" style="padding:0 0 15px;">
 	                 <h5 class="master_label">Section 1</h5>
 	                 <div class="col-md-6">
 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Type</label>
 		                      <div class="col-md-8 col-xs-12">
 			                          <select name="item_cover_offset_paper_type[]" id="item_cover_offset_paper_type" onchange="toggleOther(this, 11, 'cover');" class="form-control">
 									      <option value="0">Please Select</option>
 									      {section name=paper_types loop=$paper_types}
 									      <option value="{$paper_types[paper_types].paper_id}" {if $smarty.post.item_cover_offset_paper_type[0] eq $paper_types[paper_types].paper_id}selected{elseif isset($item_data.item_cover_offset_paper_type[0].paper_id) && $paper_types[paper_types].paper_id eq $item_data.item_cover_offset_paper_type[0].paper_id}selected{/if}>{$paper_types[paper_types].paper_name}</option>
 									      {/section}
 									    </select> <input name="item_cover_offset_paper_type_other[]" type="text" id="item_cover_offset_paper_type_other" value="{if $smarty.post.item_cover_offset_paper_type_other[0]}{$smarty.post.item_cover_offset_paper_type_other[0]}{else}{$item_data.item_cover_offset_paper_type_other}{/if}" class="form-control" style="display:none;" />
 							</div>
 		                  </div>
 		               <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Weight</label>
 		                      <div class="col-md-8">

 							    <select name="item_cover_offset_paper_weight[]" id="item_cover_offset_paper_weight" class="form-control">
 							      <option value="0">Please Select</option>
 							      {section name=paper_weights loop=$paper_weights}
 							      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.item_cover_offset_paper_weight eq $paper_weights[paper_weights].weight_value}selected{elseif $paper_weights[paper_weights].weight_value eq $quote_items[0].item_cover_paper_weight}selected{elseif isset($item_data.item_cover_paper_weight[0].weight_value) && $paper_weights[paper_weights].weight_value eq $item_data.item_cover_paper_weight[0].weight_value}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
 							      {/section}
 							    </select>
 							   </div>
 		                  </div>

 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Pre Press</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_cover_offset_pre_press[]" id="item_cover_offset_pre_press" onchange="calc_total_plates(this, 'cover');" class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="Work/Turn" {if $smarty.post.item_cover_offset_pre_press[0] eq 'Work/Turn' || $item_data.item_cover_offset_pre_press eq 'Work/Turn'}selected{/if}>Work/Turn</option>
 								      <option value="Work/Tumble" {if $smarty.post.item_cover_offset_pre_press[0] eq 'Work/Tumble' || $item_data.item_cover_offset_pre_press eq 'Work/Tumble'}selected{/if}>Work/Tumble</option>
 								      <option value="Front/Back" {if $smarty.post.item_cover_offset_pre_press[0] eq 'Front/Back' || $item_data.item_cover_offset_pre_press eq 'Front/Back'}selected{/if}>Front/Back</option>
 								      <option value="One Side" {if $smarty.post.item_cover_offset_pre_press[0] eq 'One Side' || $item_data.item_cover_offset_pre_press eq 'One Side'}selected{/if}>One Side</option>
 							      </select>
 			                  </div>
 		                  </div>

 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">No of Colours</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_cover_offset_no_of_colors[]" type="text" id="item_cover_offset_no_of_colors" onblur="calc_total_plates(this, 'cover');" value="{if $smarty.post.item_cover_offset_no_of_colors[0]}{$smarty.post.item_cover_offset_no_of_colors[0]}{elseif $item_data.item_cover_offset_no_of_colors}{$item_data.item_cover_offset_no_of_colors}{/if}" class="form-control" />
 		                   </div>
 		               </div>
 		               <div class="form-group">
 		                     <label class="col-md-4 control-label">No of Sheets </label>
 		                     <div class="col-md-8">
 						     <input name="item_cover_offset_num_sheets[]" type="text" id="item_cover_offset_num_sheets" value="{$smarty.post.item_cover_num_sheets[0]}" class="form-control" />
 						 </div>
 		                 </div>
 		            </div>

 		            <div class="col-md-6">

 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">Impressions</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_cover_offset_impressions[]" type="number" id="item_cover_offset_impressions" value="{if $smarty.post.item_cover_offset_impressions[0]}{$smarty.post.item_cover_offset_impressions[0]}{/if}"  class="form-control" onblur="calc_num_of_sheets(this, 'cover');" />
 		                   </div>
 		               </div>
 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">Machine</label>
 		                   <div class="col-md-8 col-xs-12">
 			                   <select name="item_cover_offset_machine[]" id="item_cover_offset_machine" class="form-control">
 							        <option value="0">Please Select</option>
 							      {section name=job_printers loop=$job_printers}
 							      <option value="{$job_printers[job_printers].printer_name}" {if $job_printers[job_printers].printer_name[0] eq '$smarty.post.item_cover_offset_machine' || $item_data.item_cover_offset_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
 							      {/section}
 							    </select>
 		                   </div>
 		               </div>

 		               <div class="form-group">
 		                      <label class="col-md-4 control-label">Plate Size</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_cover_offset_plate_size[]"  class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="SM74" {if $smarty.post.item_cover_offset_plate_size[0] eq 'SM74' || $item_data.item_cover_plate_size eq 'SM74'}selected{/if}>SM74</option>
 								      <option value="Sm52" {if $smarty.post.item_cover_offset_plate_size[0] eq 'Sm52' || $item_data.item_cover_plate_size eq 'Sm52'}selected{/if}>Sm52</option>
 								      <option value="GTO46" {if $smarty.post.item_cover_offset_plate_size[0] eq 'GTO46' || $item_data.item_cover_plate_size eq 'GTO46'}selected{/if}>GTO46</option>
 							      </select>
 			                  </div>
 		                  </div>

 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">Total Plates</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_cover_offset_total_plates[]" type="text" id="item_cover_offset_total_plates" value="{if $smarty.post.item_cover_offset_total_plates[0]}{$smarty.post.item_cover_offset_total_plates[0]}{elseif $item_data.item_cover_total_plates}{$item_data.item_cover_total_plates}{/if}" class="form-control" readonly/>
 		                   </div>
 		               </div>
 		               <div class="form-group">
 		                      <label class="col-md-4 control-label">Press Sheet Size</label>

 		                      <div class="col-md-8">
 		                         <select name="item_cover_offset_sheet_size[]" id="item_cover_offset_sheet_size" onchange="calc_num_of_sheets(this, 'cover');" class="form-control" style="margin-bottom:5px;">
 								      <option value="A1" {if $smarty.post.item_cover_offset_sheet_size[0] eq 'A1' || $item_data.item_cover_offset_sheet_size eq 'A1'}selected{/if} selected>A1</option>
 								      <option value="A2" {if $smarty.post.item_cover_offset_sheet_size[0] eq 'A2' || $item_data.item_cover_offset_sheet_size eq 'A2'}selected{/if}>A2</option>
 								      <option value="A3" {if $smarty.post.item_cover_offset_sheet_size[0] eq 'A3' || $item_data.item_cover_offset_sheet_size eq 'A3'}selected{/if}>A3</option>
 								      <option value="A4" {if $smarty.post.item_cover_offset_sheet_size[0] eq 'A4' || $item_data.item_cover_offset_sheet_size eq 'A4'}selected{/if}>A4</option>
 								      <option value="Other" {if $smarty.post.item_cover_offset_sheet_size[0] eq 'Other' || $item_data.item_cover_offset_sheet_size_other}selected{/if}>Other</option>
 							    </select>
 							    <span id="cover_sheet_size_other" style="display:none;">
 							      <input type="text" name="item_cover_offset_sheet_w[]" class="form-control" placeholder="Width" value="{if $smarty.post.item_cover_offset_sheet_w[0]}{$smarty.post.item_cover_offset_sheet_w[0]}{elseif $item_data.item_cover_cut_size_w}{$item_data.item_cover_cut_size_w}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;" > x
 		                          <input type="text" name="item_cover_offset_sheet_h[]" class="form-control" placeholder="Height" value="{if $smarty.post.item_cover_offset_sheet_h[0]}{$smarty.post.item_cover_offset_sheet_h[0]}{elseif $item_data.item_cover_cut_size_h}{$item_data.item_cover_cut_size_h}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;">

 							    </span>

 							 </div>
 		                  </div>


 		            </div>

 	            </div>

 	          {/section}

                <a href="#" class="offset_copy" rel=".offset_cover_section" style="diplay:block; float:left; margin-right:10px;" ><span class="fa fa-plus text-info"></span> Add More Sections</a>

                <a href="#" class="offset_duplicate" rel=".offset_cover_section" style="diplay:block; float:left; padding-left:10px; border-left:1px solid #ccc;"><span class="fa fa-plus-square text-info"></span> Duplicate First Section</a>

          </div>
          <div class="col-md-12 item_cover_wide_format" style="margin-top:15px; {if $smarty.post.cover_print_options eq 'item_cover_wide_format'}{elseif $item_data.item_cover_wide_format eq 'Y'}{else}display:none;{/if}">
 	         <div class="col-md-6">
 	               <div class="form-group">
 	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
 	                   <div class="col-md-8 col-xs-12">
 		                   <select name="item_cover_wide_format_material" id="item_cover_wide_format_material" class="form-control">
 						        <option value="0">Please Select</option>
 						      {section name=materials loop=$materials}
 						      <option value="{$materials[materials].material_name}" {if $smarty.post.item_cover_wide_format_material && $smarty.post.item_cover_wide_format_material eq $materials[materials].material_name}selected{elseif !$smarty.post.item_cover_wide_format_material && $item_data.item_cover_material eq $materials[materials].material_name}selected{/if}>{$materials[materials].material_name}</option>
 						      {/section}
 						    </select>
 	                   </div>
 	               </div>
 	                <div class="form-group">
                       <label class="col-md-4 control-label">Size</label>
                       <div class="col-md-8">

 					      <input type="text" id="item_cover_wide_format_w" name="item_cover_wide_format_w" class="form-control" placeholder="Width(m)" value="{if $smarty.post.item_cover_wide_format_w}{$smarty.post.item_cover_wide_format_w}{elseif $item_data.item_cover_cut_size_w}{$item_data.item_cover_cut_size_w}{/if}" onblur="calc_wide_format_sq_m('cover')" style="width:100px; display: inline-block; padding: 6px 8px;" > x
                           <input type="text" id="item_cover_wide_format_h" name="item_cover_wide_format_h" class="form-control" placeholder="Height(m)" value="{if $smarty.post.item_cover_wide_format_h}{$smarty.post.item_cover_wide_format_h}{elseif $item_data.item_cover_cut_size_h}{$item_data.item_cover_cut_size_h}{/if}" onblur="calc_wide_format_sq_m('cover')" style="width:100px; display: inline-block; padding: 6px 8px;">

 					 </div>
                   </div>


 	         </div>

 	         <div class="col-md-6">
 	          <div class="form-group">
 	                   <label class="col-md-4 control-label">Machine</label>
 	                   <div class="col-md-8 col-xs-12">
 		                   <select name="item_cover_wide_format_machine" id="item_cover_wide_format_machine" class="form-control">
 						        <option value="0">Please Select</option>
 						      {section name=job_printers loop=$job_printers}
 						      <option value="{$job_printers[job_printers].printer_name}" {if $smarty.post.item_cover_wide_format_machine && $smarty.post.item_cover_wide_format_machine eq $job_printers[job_printers].printer_name}selected{elseif !$smarty.post.item_cover_wide_format_machine && $item_data.item_cover_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
 						      {/section}
 						    </select>
 	                   </div>
 	               </div>
 	                <div class="form-group">
 	                   <label class="col-md-4 control-label">Total Sq Meter</label>
 	                   <div class="col-md-8 col-xs-12">
 	                   <input id="item_cover_wide_format_total_sq_meter" name="item_cover_wide_format_total_sq_meter" type="text" id="item_cover_wide_format_total_sq_meter" value="{if $smarty.post.item_cover_wide_format_total_sq_meter}{$smarty.post.item_cover_wide_format_total_sq_meter }{elseif $item_data.item_cover_total_sq_meter }{$item_data.item_cover_total_sq_meter }{/if}" class="form-control" readonly />
 	                   </div>
 	               </div>
 	         </div>
 	          <div class="col-md-12">
 	          <br>

                 <div class="form-group">
                       <label class="col-md-2 control-label text-right">Notes</label>
                       <div class="col-md-9">
                           <textarea name="item_cover_wide_format_notes"  class="form-control">{if $smarty.post.item_cover_wide_format_notes}{$smarty.post.item_cover_wide_format_notes}{else}{$item_data.item_cover_notes}{/if}</textarea>
                        </div>
                   </div>

 	         </div>


          </div>

           <div class="col-md-12 item_cover_promotional" style="margin-top:15px; {if $smarty.post.cover_print_options eq 'item_cover_promotional'}{elseif $item_data.item_cover_promotional eq 'Y'}{else}display:none;{/if}">
 	         <div class="col-md-6">
 	               <div class="form-group">
 	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
 	                   <div class="col-md-8 col-xs-12">
 	                    <input name="item_cover_promotional_material" type="text" id="item_cover_promotional_material" value="{if $smarty.post.item_cover_promotional_material}{$smarty.post.item_cover_promotional_material}{elseif $item_data.item_cover_material}{$item_data.item_cover_material}{/if}" placeholder="TShirt, Bag, Caps,.." class="form-control" />
 	                   </div>
 	               </div>
 	         </div>

 	         <div class="col-md-6">
 	          <div class="form-group">
                    <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                    <div class="col-md-8 col-xs-12">
                    <input name="item_cover_promotional_quantity" type="number" id="item_cover_promotional_quantity" value="{if $smarty.post.item_cover_promotional_quantity}{$smarty.post.item_cover_promotional_quantity}{elseif $item_data.item_cover_quantity}{$item_data.item_cover_quantity}{/if}" class="form-control" />
                    </div>
                </div>
 	         </div>
 	         <div class="col-md-12" style="margin-top:10px;">
 	           <div class="col-md-2">
 	           &nbsp;
 	           </div>
 	           <div class="col-md-3">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_promotional_screen_printing" id="item_cover_promotional_screen_printing" value="Y" {if $smarty.post.item_cover_promotional_screen_printing}checked{elseif $item_data.item_cover_screen_printing eq 'Y'}checked{/if} />Screen Printing</label>
                    <div class="col-md-12 item_cover_promotional_screen_printing" style="padding:0; {if $smarty.post.item_cover_promotional_screen_printing}{elseif $item_data.item_cover_screen_printing eq 'Y'}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_cover_screen_printing_notes"  class="form-control">{if $smarty.post.item_cover_screen_printing_notes}{$smarty.post.item_cover_screen_printing_notes}{elseif $item_data.item_cover_screen_printing_notes}{$item_data.item_cover_screen_printing_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-3">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_promotional_embroidery" id="item_cover_promotional_embroidery" value="Y" {if $smarty.post.item_cover_promotional_embroidery}checked{elseif $item_data.item_cover_embroidery eq 'Y'}checked{/if} />Embroidery</label>

                     <div class="col-md-12 item_cover_promotional_embroidery" style="padding:0; {if $smarty.post.item_cover_promotional_embroidery}{elseif $item_data.item_cover_embroidery eq 'Y'}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_embroidery_notes"  class="form-control">{if $smarty.post.item_cover_embroidery_notes}{$smarty.post.item_cover_embroidery_notes}{elseif $item_data.item_cover_embroidery_notes}{$item_data.item_cover_embroidery_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-3">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_promotional_heat_transfer" id="item_cover_promotional_heat_transfer" value="Y" {if $smarty.post.item_cover_promotional_heat_transfer}checked{elseif $item_data.item_cover_heat_transfer eq 'Y'}checked{/if} />Heat Transfer</label>
                    <div class="col-md-12 item_cover_promotional_heat_transfer" style="padding:0; {if $smarty.post.item_cover_promotional_heat_transfer}{elseif $item_data.item_cover_heat_transfer eq 'Y'}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_heat_transfer_notes"  class="form-control">{if $smarty.post.item_cover_heat_transfer_notes}{$smarty.post.item_cover_heat_transfer_notes}{elseif $item_data.item_cover_heat_transfer_notes}{$item_data.item_cover_heat_transfer_notes}{/if}</textarea>
                    </div>
                </div>
 	         </div>
          </div>

          <div class="col-md-12 item_cover_cnc" style="margin-top:15px; {if $smarty.post.cover_print_options eq 'item_cover_cnc' || $item_data.item_cover_cnc eq 'Y'}{else}display:none;{/if}">

 	          <div class="col-md-6">
 	            <div class="form-group">
                       <label class="col-md-4 control-label">Type <span class="asterisk">*</span></label>
                       <div class="col-md-8 col-xs-12">
 	                             <select name="item_cover_cnc_type" id="item_cover_cnc_type" onchange="checkOther(this.value, 'Other', 'item_cover_cnc_type_other');" class="form-control">
 							      <option value="0">Please Select</option>
 							      <option value="Lightbox" {if $smarty.post.item_cover_cnc_type && $smarty.post.item_cover_cnc_type eq 'Lightbox'}selected{elseif !$smarty.post.item_cover_cnc_type && $item_data.item_cover_paper_type eq 'Lightbox'}selected{/if}>Lightbox</option>
 							      <option value="Cut-out" {if $smarty.post.item_cover_cnc_type && $smarty.post.item_cover_cnc_type eq 'Cut-out'}selected{elseif !$smarty.post.item_cover_cnc_type && $item_data.item_cover_paper_type eq 'Cut-out'}selected{/if}>Cut-out</option>
 							      <option value="Pylon" {if $smarty.post.item_cover_cnc_type && $smarty.post.item_cover_cnc_type eq 'Pylon'}selected{elseif !$smarty.post.item_cover_cnc_type && $item_data.item_cover_paper_type eq 'Pylon'}selected{/if}>Pylon</option>
 							      <option value="Other" {if $smarty.post.item_cover_cnc_type && $smarty.post.item_cover_cnc_type eq 'Other'}selected{elseif !$smarty.post.item_cover_cnc_type && $item_data.item_cover_paper_type eq 'Other'}selected{/if}>Other</option>

 							    </select>
 							    <input name="item_cover_cnc_type_other" type="text" id="item_cover_cnc_type_other" value="{if $smarty.post.item_cover_cnc_type_other}{$smarty.post.item_cover_cnc_type_other}{elseif $item_data.item_cover_paper_type_other}{$item_data.item_cover_paper_type_other}{/if}" class="form-control" style="display:none; margin-top:10px;" />
 					</div>

                   </div>
 	         </div>
 	         <div class="col-md-6">
 	               <div class="form-group">
 	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
 	                   <div class="col-md-8 col-xs-12">
 	                    <input name="item_cover_cnc_material" type="text" id="item_cover_cnc_material" value="{if $smarty.post.item_cover_cnc_material}{$smarty.post.item_cover_cnc_material }{elseif $item_data.item_cover_material }{$item_data.item_cover_material}{/if}" class="form-control" />
 	                   </div>
 	               </div>
 	         </div>

 	         <div class="col-md-6" style="margin-top:10px;">
 	          <div class="form-group">
                    <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                    <div class="col-md-8 col-xs-12">
                    <input name="item_cover_cnc_quantity" type="number" id="item_cover_cnc_quantity" value="{if $smarty.post.item_cover_cnc_quantity}{$smarty.post.item_cover_cnc_quantity}{elseif $item_data.item_cover_quantity }{$item_data.item_cover_quantity}{/if}" class="form-control"/>
                    </div>
                </div>
 	         </div>
 	         <div class="col-md-12" style="margin-top:10px;">

 	           <label class="col-md-2 control-label">Processes</label>

 	           <div class="col-md-10">

 	             <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_fabrication" id="item_cover_cnc_fabrication" value="Y" {if $smarty.post.item_cover_cnc_fabrication || $item_cover_cnc_process_data.fabrication eq 'Y' || (isset($item_data.item_cover_cnc_process_data.fabrication) && $item_data.item_cover_cnc_process_data.fabrication eq 'Y')}checked{/if} />Fabrication</label>
                    <div class="col-md-12 item_cover_cnc_fabrication" style="padding:0; {if $smarty.post.item_cover_cnc_fabrication eq 'Y' || $item_cover_cnc_process_data.fabrication eq 'Y' || (isset($item_data.item_cover_cnc_process_data.fabrication) && $item_data.item_cover_cnc_process_data.fabrication eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_cover_fabrication_notes"  class="form-control">{if $item_cover_cnc_process_data.fabrication_notes}{$item_cover_cnc_process_data.fabrication_notes}{elseif isset($item_data.item_cover_cnc_process_data.fabrication_notes) && $item_data.item_cover_cnc_process_data.fabrication_notes}{$item_data.item_cover_cnc_process_data.fabrication_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_cnc_cutting" id="item_cover_cnc_cnc_cutting" value="Y" {if $smarty.post.item_cover_cnc_cnc_cutting ||  $item_cover_cnc_process_data.cnc_cutting eq 'Y'}checked{/if} />CNC Cutting</label>

                     <div class="col-md-12 item_cover_cnc_cnc_cutting" style="padding:0; {if $smarty.post.item_cover_cnc_cnc_cutting eq 'Y' || $item_cover_cnc_process_data.cnc_cutting eq 'Y' || (isset($item_data.item_cover_cnc_process_data.cnc_cutting) && $item_data.item_cover_cnc_process_data.cnc_cutting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_cnc_cutting_notes"  class="form-control">{if $item_cover_cnc_process_data.cnc_cutting_notes}{$item_cover_cnc_process_data.cnc_cutting_notes}{elseif isset($item_data.item_cover_cnc_process_data.cnc_cutting_notes) && $item_data.item_cover_cnc_process_data.cnc_cutting_notes}{$item_data.item_cover_cnc_process_data.cnc_cutting_notes}{/if}</textarea>
                     </div>

                </div>

                 <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_spraying" id="item_cover_cnc_spraying" value="Y" {if $smarty.post.item_cover_cnc_spraying || $item_cover_cnc_process_data.spraying eq 'Y' || (isset($item_data.item_cover_cnc_process_data.spraying) && $item_data.item_cover_cnc_process_data.spraying eq 'Y')}checked{/if} />Spraying</label>
                    <div class="col-md-12 item_cover_cnc_spraying" style="padding:0; {if $smarty.post.item_cover_cnc_spraying eq 'Y' || $item_cover_cnc_process_data.spraying eq 'Y' || (isset($item_data.item_cover_cnc_process_data.spraying) && $item_data.item_cover_cnc_process_data.spraying eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_cover_spraying_notes"  class="form-control">{if $item_cover_cnc_process_data.spraying_notes}{$item_cover_cnc_process_data.spraying_notes}{elseif isset($item_data.item_cover_cnc_process_data.spraying_notes) && $item_data.item_cover_cnc_process_data.spraying_notes}{$item_data.item_cover_cnc_process_data.spraying_notes}{/if}</textarea>
                    </div>

                </div>

                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_cutting" id="item_cover_cnc_cutting" value="Y" {if $smarty.post.item_cover_cnc_cutting || $item_cover_cnc_process_data.cutting eq 'Y' || (isset($item_data.item_cover_cnc_process_data.cutting) && $item_data.item_cover_cnc_process_data.cutting eq 'Y')}checked{/if} />Cutting</label>
                    <div class="col-md-12 item_cover_cnc_cutting" style="padding:0; {if $smarty.post.item_cover_cnc_cutting eq 'Y' || $item_cover_cnc_process_data.cutting eq 'Y' || (isset($item_data.item_cover_cnc_process_data.cutting) && $item_data.item_cover_cnc_process_data.cutting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_cutting_notes"  class="form-control">{if $item_cover_cnc_process_data.cutting_notes}{$item_cover_cnc_process_data.cutting_notes}{elseif isset($item_data.item_cover_cnc_process_data.cutting_notes) && $item_data.item_cover_cnc_process_data.cutting_notes}{$item_data.item_cover_cnc_process_data.cutting_notes}{/if}</textarea>
                    </div>


                </div>

                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_bending" id="item_cover_cnc_bending" value="Y" {if $smarty.post.item_cover_cnc_bending || $item_cover_cnc_process_data.bending eq 'Y' || (isset($item_data.item_cover_cnc_process_data.bending) && $item_data.item_cover_cnc_process_data.bending eq 'Y')}checked{/if} />Bending</label>

                     <div class="col-md-12 item_cover_cnc_bending" style="padding:0; {if $smarty.post.item_cover_cnc_bending eq 'Y' || $item_cover_cnc_process_data.bending eq 'Y' || (isset($item_data.item_cover_cnc_process_data.bending) && $item_data.item_cover_cnc_process_data.bending eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_bending_notes"  class="form-control">{if $item_cover_cnc_process_data.bending_notes}{$item_cover_cnc_process_data.bending_notes}{elseif isset($item_data.item_cover_cnc_process_data.bending_notes) && $item_data.item_cover_cnc_process_data.bending_notes}{$item_data.item_cover_cnc_process_data.bending_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_led" id="item_cover_cnc_led" value="Y" {if $smarty.post.item_cover_cnc_led || $item_cover_cnc_process_data.led eq 'Y' || (isset($item_data.item_cover_cnc_process_data.led) && $item_data.item_cover_cnc_process_data.led eq 'Y')}checked{/if} />Lighting Attachment (LED)</label>
                    <div class="col-md-12 item_cover_cnc_led" style="padding:0; {if $smarty.post.item_cover_cnc_led eq 'Y' || $item_cover_cnc_process_data.led eq 'Y' || (isset($item_data.item_cover_cnc_process_data.led) && $item_data.item_cover_cnc_process_data.led eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_led_notes"  class="form-control">{if $item_cover_cnc_process_data.led_notes}{$item_cover_cnc_process_data.led_notes}{elseif isset($item_data.item_cover_cnc_process_data.led_notes) && $item_data.item_cover_cnc_process_data.led_notes}{$item_data.item_cover_cnc_process_data.led_notes}{/if}</textarea>
                    </div>


                </div>
                 <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_lighting" id="item_cover_cnc_lighting" value="Y" {if $smarty.post.item_cover_cnc_lighting || $item_cover_cnc_process_data.lighting eq 'Y' || (isset($item_data.item_cover_cnc_process_data.lighting) && $item_data.item_cover_cnc_process_data.lighting eq 'Y')}checked{/if} />Lighting (tube lights)</label>
                    <div class="col-md-12 item_cover_cnc_lighting" style="padding:0; {if $smarty.post.item_cover_cnc_lighting eq 'Y' || $item_cover_cnc_process_data.lighting eq 'Y' || (isset($item_data.item_cover_cnc_process_data.lighting) && $item_data.item_cover_cnc_process_data.lighting eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_cover_lighting_notes"  class="form-control">{if $item_cover_cnc_process_data.lighting_notes}{$item_cover_cnc_process_data.lighting_notes}{elseif isset($item_data.item_cover_cnc_process_data.lighting_notes) && $item_data.item_cover_cnc_process_data.lighting_notes}{$item_data.item_cover_cnc_process_data.lighting_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_rivetting" id="item_cover_cnc_rivetting" value="Y" {if $smarty.post.item_cover_cnc_rivetting || $item_cover_cnc_process_data.rivetting eq 'Y' || (isset($item_data.item_cover_cnc_process_data.rivetting) && $item_data.item_cover_cnc_process_data.rivetting eq 'Y')}checked{/if} />Rivetting</label>

                     <div class="col-md-12 item_cover_cnc_rivetting" style="padding:0; {if $smarty.post.item_cover_cnc_rivetting eq 'Y' || $item_cover_cnc_process_data.rivetting eq 'Y' || (isset($item_data.item_cover_cnc_process_data.rivetting) && $item_data.item_cover_cnc_process_data.rivetting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_rivetting_notes"  class="form-control">{if $item_cover_cnc_process_data.rivetting_notes}{$item_cover_cnc_process_data.rivetting_notes}{elseif isset($item_data.item_cover_cnc_process_data.rivetting_notes) && $item_data.item_cover_cnc_process_data.rivetting_notes}{$item_data.item_cover_cnc_process_data.rivetting_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_cover_cnc_site_installation" id="item_cover_cnc_site_installation" value="Y" {if $smarty.post.item_cover_cnc_site_installation || $item_cover_cnc_process_data.site_installation eq 'Y' || (isset($item_data.item_cover_cnc_process_data.site_installation) && $item_data.item_cover_cnc_process_data.site_installation eq 'Y')}checked{/if} />Site installation</label>
                    <div class="col-md-12 item_cover_cnc_site_installation" style="padding:0; {if $smarty.post.item_cover_cnc_site_installation eq 'Y' || $item_cover_cnc_process_data.site_installation eq 'Y' || (isset($item_data.item_cover_cnc_process_data.site_installation) && $item_data.item_cover_cnc_process_data.site_installation eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_cover_site_installation_notes"  class="form-control">{if $item_cover_cnc_process_data.site_installation_notes}{$item_cover_cnc_process_data.site_installation_notes}{elseif isset($item_data.item_cover_cnc_process_data.site_installation_notes) && $item_data.item_cover_cnc_process_data.site_installation_notes}{$item_data.item_cover_cnc_process_data.site_installation_notes}{/if}</textarea>
                    </div>


                </div>


 	           </div>


 	         </div>


          </div>


          </div>

          <div class="row hide-stationary">
              <br /> <br />
              <h4>PRINTING <span class="offset_label" style="display:none;">(INNER  PAPER)</span><span class="specifications_label">(SPECIFICATIONS)</span> <span class="asterisk">*</span></h4>


               {* <div class="col-md-3">
                 <div class="form-group">
                    <div class="col-md-12 col-xs-12">
                    <label class="check"><input type="radio" class="iradio" name="inner_print_options" id="item_inner_digital" value="item_inner_digital" {if $smarty.post.inner_print_options eq 'item_inner_digital' || $item_data.item_inner_digital eq 'Y'}checked{/if} />Digital</label>
                    </div>
                </div>
               </div> *}
			   <div class="col-md-2">
                 <div class="form-group">
                    <div class="col-md12 col-xs-12">
                    <label class="check"><input type="radio" class="iradio" name="inner_print_options" id="item_inner_stationary" value="item_inner_stationary" {if $smarty.post.inner_print_options eq 'item_inner_stationary' || $item_data.item_inner_stationary eq 'Y'}checked{/if} />Stationary</label>
                    </div>
                </div>
               </div>
               <div class="col-md-2">
                  <div class="form-group">

                    <div class="col-md-12 col-xs-12">
                    <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="item_inner_offset" value="item_inner_offset" {if $smarty.post.inner_print_options eq 'item_inner_offset' || $item_data.item_inner_offset eq 'Y'}checked{/if} />Offset</label>
                    </div>
                </div>
               </div>
               <div class="col-md-2">
                 <div class="form-group">

                    <div class="col-md-12 col-xs-12">
                    <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="item_inner_wide_format" value="item_inner_wide_format" {if $smarty.post.inner_print_options eq 'item_inner_wide_format' || $item_data.item_inner_wide_format eq 'Y'}checked{/if} />Wide Format</label>
                    </div>
                </div>
               </div>
               <div class="col-md-2">
                 <div class="form-group">
                    <div class="col-md-12 col-xs-12">
                    <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="item_inner_promotional" value="item_inner_promotional" {if $smarty.post.inner_print_options eq 'item_inner_promotional' || $item_data.item_inner_promotional eq 'Y'}checked{/if} />Promotional</label>
                    </div>
                </div>
               </div>
               <div class="col-md-2">
                  <div class="form-group">

                    <div class="col-md-12">
                    <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="item_inner_cnc" value="item_inner_cnc" {if $smarty.post.inner_print_options eq 'item_inner_cnc' || $item_data.item_inner_cnc eq 'Y'}checked{/if} />Signage / CNC</label>
                    </div>
                </div>
               </div> 


              <div class="col-md-12 item_inner_stationary" style="margin-top:15px;  {if $smarty.post.inner_print_options eq 'item_inner_stationary'}{elseif $item_data.item_inner_stationary eq 'Y'}{else}display:none;{/if}">
               
                 <div class="form-group">
                       <label class="col-md-2 control-label">Type<span class="asterisk">*</span></label>
                       <div class="col-md-5 col-xs-12">
 	                          <select name="item_inner_stationary_type" id="item_inner_stationary_type"  class="form-control">
 							      <option value="0">Please Select</option>
 							      {section name=type loop=$stationary_types}
 							      <option value="{$stationary_types[type]}" {if $smarty.post.item_inner_stationary_type eq $stationary_types[type]}selected{elseif isset($item_data.item_inner_stationary_type) && $item_data.item_inner_stationary_type eq $stationary_types[type]}selected{/if}>{$stationary_types[type]}</option>
 							      {/section}
 							    </select> 
								{*<input name="item_inner_digital_paper_type_other" type="text" id="item_inner_digital_paper_type_other" value="{if $smarty.post.item_inner_digital_paper_type_other}{$smarty.post.item_inner_digital_paper_type_other}{elseif $item_data.item_inner_paper_type_other}{$item_data.item_inner_paper_type_other}{/if}" class="form-control" style="display:none;" /> *}
 					</div>

                   </div>

             
			  
			   <div class="form-group">
                       <label class="col-md-2 control-label">Specifications</label>
                       <div class="col-md-8 col-xs-12">
					   <textarea name="item_inner_stationary_notes"  class="form-control">{if $smarty.post.item_inner_stationary_notes}{$smarty.post.item_inner_stationary_notes}{elseif isset($item_data[0].item_inner_stationary_notes) && $item_data[0].item_inner_stationary_notes}{$item_data[0].item_inner_stationary_notes}{/if}</textarea>
					   </div>
					</div>
            
            
             </div>

          <div class="col-md-12 item_inner_offset" style="margin-top:15px; {if $smarty.post.inner_print_options eq 'item_inner_offset' || $item_data.item_inner_offset eq 'Y'}{else} display:none; {/if}">


                {section name=inner_offset loop=$inner_offset_info}

                   <div class="col-md-12 offset_inner_section" style="padding:0 0 15px;">
                    {assign var=count value=$smarty.section.inner_offset.index+1}
 	                 <h5 class="master_label">Section {$count}</h5>
 	                 <div class="col-md-6">
 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Type</label>
 		                      <div class="col-md-8 col-xs-12">
 			                          <select name="item_inner_offset_paper_type[]" id="item_inner_offset_paper_type" onchange="toggleOther(this, 11, 'inner');" class="form-control">
 									      <option value="0">Please Select</option>
 									      {section name=paper_types loop=$paper_types}
 									      <option value="{$paper_types[paper_types].paper_id}" {if isset($smarty.post.item_inner_offset_paper_type[0]) && $smarty.post.item_inner_offset_paper_type[0] eq $paper_types[paper_types].paper_id}selected{elseif !isset($smarty.post.item_inner_offset_paper_type[0]) && $inner_offset_info[inner_offset].item_inner_paper_type_id eq $paper_types[paper_types].paper_id}selected{/if}>{$paper_types[paper_types].paper_name}</option>
 									      {/section}
 									    </select> <input name="item_inner_offset_paper_type_other[]" type="text" id="item_inner_offset_paper_type_other" value="{if $smarty.post.item_inner_offset_paper_type_other[0]}{$smarty.post.item_inner_offset_paper_type_other[0]}{elseif $inner_offset_info[inner_offset].item_inner_paper_type_other}{$inner_offset_info[inner_offset].item_inner_paper_type_other}{/if}" class="form-control" {if !$inner_offset_info[inner_offset].item_inner_paper_type_other}style="display:none;"{/if} />
 							</div>
 		                  </div>
 		               {* <div class="form-group">
 		                   <label class="col-md-4 control-label">Impressions</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_inner_offset_impressions[]" type="number" id="item_inner_offset_impressions" value="{if $smarty.post.item_inner_offset_impressions[0]}{$smarty.post.item_inner_offset_impressions[0]}{elseif $inner_offset_info[inner_offset].item_inner_impressions}{$inner_offset_info[inner_offset].item_inner_impressions}{/if}"  class="form-control" onblur="calc_num_of_sheets(this, 'inner');" />
 		                   </div>
 		               </div> *}
									 <div class="form-group">
 		                   <label class="col-md-4 control-label">Remarks</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   {* <input name="item_inner_offset_impressions[]" type="number" id="item_inner_offset_impressions" value="{if $smarty.post.item_inner_offset_impressions[0]}{$smarty.post.item_inner_offset_impressions[0]}{elseif $inner_offset_info[inner_offset].item_inner_impressions}{$inner_offset_info[inner_offset].item_inner_impressions}{/if}"  class="form-control" onblur="calc_num_of_sheets(this, 'inner');" /> *}
                       <textarea name="item_inner_offset_remarks[]" >{if $smarty.post.item_inner_offset_remarks}{$smarty.post.item_inner_offset_remarks[0]}{elseif $inner_offset_info[inner_offset].item_inner_offset_remarks}{$inner_offset_info[inner_offset].item_inner_offset_remarks}{/if}</textarea>
											 </div>
 		               </div>


 		                {* <div class="form-group">
 		                      <label class="col-md-4 control-label">Pre Press</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_inner_offset_pre_press[]" id="item_inner_offset_pre_press" onchange="calc_total_plates(this, 'inner');" class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="Work/Turn" {if $smarty.post.item_inner_offset_pre_press[0] eq 'Work/Turn' || $inner_offset_info[inner_offset].item_inner_pre_press eq 'Work/Turn'}selected{/if}>Work/Turn</option>
 								      <option value="Work/Tumble" {if $smarty.post.item_inner_offset_pre_press[0] eq 'Work/Tumble' || $inner_offset_info[inner_offset].item_inner_pre_press eq 'Work/Tumble'}selected{/if}>Work/Tumble</option>
 								      <option value="Front/Back" {if $smarty.post.item_inner_offset_pre_press[0] eq 'Front/Back' || $inner_offset_info[inner_offset].item_inner_pre_press eq 'Front/Back'}selected{/if}>Front/Back</option>
 								      <option value="One Side" {if $smarty.post.item_inner_offset_pre_press[0] eq 'One Side' || $inner_offset_info[inner_offset].item_inner_pre_press eq 'One Side'}selected{/if}>One Side</option>
 							      </select>
 			                  </div>
 		                  </div> *}

 		               {* <div class="form-group">
 		                   <label class="col-md-4 control-label">No of Colours</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_inner_offset_no_of_colors[]" type="text" id="item_inner_offset_no_of_colors" onblur="calc_total_plates(this, 'inner');" value="{if $smarty.post.item_inner_offset_no_of_colors[0]}{$smarty.post.item_inner_offset_no_of_colors[0]}{elseif $inner_offset_info[inner_offset].item_inner_no_of_colors}{$inner_offset_info[inner_offset].item_inner_no_of_colors}{/if}" class="form-control" />
 		                   </div>
 		               </div> *}
 		               {* <div class="form-group">
 		                     <label class="col-md-4 control-label">No of Sheets </label>
 		                     <div class="col-md-8">
 						     <input name="item_inner_offset_num_sheets[]" type="text" id="item_inner_offset_num_sheets" value="{if $smarty.post.item_inner_offset_num_sheets[0]}{$smarty.post.item_inner_offset_num_sheets[0]}{elseif $inner_offset_info[inner_offset].item_inner_num_sheets}{$inner_offset_info[inner_offset].item_inner_num_sheets}{/if}" class="form-control" />
 						 </div>
 		                 </div> *}
 		            </div>

 		            <div class="col-md-6">
 		               <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Weight</label>
 		                      <div class="col-md-8">

 							    <select name="item_inner_offset_paper_weight[]" id="item_inner_offset_paper_weight" class="form-control">
 							      <option value="0">Please Select</option>
 							      {section name=paper_weights loop=$paper_weights}
 							      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.item_inner_offset_paper_weight[0] eq $paper_weights[paper_weights].weight_value}selected{elseif $paper_weights[paper_weights].weight_value eq $inner_offset_info[inner_offset].item_inner_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
 							      {/section}
 							    </select>
 							   </div>
 		                  </div>
 		               {* <div class="form-group">
 		                   <label class="col-md-4 control-label">Machine</label>
 		                   <div class="col-md-8 col-xs-12">
 			                   <select name="item_inner_offset_machine[]" id="item_inner_offset_machine" class="form-control">
 							        <option value="0">Please Select</option>
 							      {section name=job_printers loop=$job_printers}
 							      <option value="{$job_printers[job_printers].printer_name}" {if $job_printers[job_printers].printer_name[0] eq '$smarty.post.item_inner_offset_machine' || $inner_offset_info[inner_offset].item_inner_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
 							      {/section}
 							    </select>
 		                   </div>
 		               </div> *}

 		               {* <div class="form-group">
 		                      <label class="col-md-4 control-label">Plate Size</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_inner_offset_plate_size[]"  class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="SM74" {if $smarty.post.item_inner_offset_plate_size[0] eq 'SM74' || $inner_offset_info[inner_offset].item_inner_plate_size eq 'SM74'}selected{/if}>SM74</option>
 								      <option value="Sm52" {if $smarty.post.item_inner_offset_plate_size[0] eq 'Sm52' || $inner_offset_info[inner_offset].item_inner_plate_size eq 'Sm52'}selected{/if}>Sm52</option>
 								      <option value="GTO46" {if $smarty.post.item_inner_offset_plate_size[0] eq 'GTO46' || $inner_offset_info[inner_offset].item_inner_plate_size eq 'GTO46'}selected{/if}>GTO46</option>
 							      </select>
 			                  </div>
 		                  </div> *}

 		               {* <div class="form-group">
 		                   <label class="col-md-4 control-label">Total Plates</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_inner_offset_total_plates[]" type="text" id="item_inner_offset_total_plates" value="{if $smarty.post.item_inner_offset_total_plates[0]}{$smarty.post.item_inner_offset_total_plates[0]}{elseif $inner_offset_info[inner_offset].item_inner_total_plates}{$inner_offset_info[inner_offset].item_inner_total_plates}{/if}" class="form-control" readonly/>
 		                   </div>
 		               </div> *}
 		               {* <div class="form-group">
 		                      <label class="col-md-4 control-label">Press Sheet Size</label>

 		                      <div class="col-md-8">
 		                         <select name="item_inner_offset_sheet_size[]" id="item_inner_offset_sheet_size" onchange="calc_num_of_sheets(this, 'inner');" class="form-control" style="margin-bottom:5px;">
 								      <option value="A1" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A1' || $inner_offset_info[inner_offset].item_inner_sheet_size eq 'A1'}selected{/if} selected>A1</option>
 								      <option value="A2" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A2' || $inner_offset_info[inner_offset].item_inner_sheet_size eq 'A2'}selected{/if}>A2</option>
 								      <option value="A3" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A3' || $inner_offset_info[inner_offset].item_inner_sheet_size eq 'A3'}selected{/if}>A3</option>
 								      <option value="A4" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A4' || $inner_offset_info[inner_offset].item_inner_sheet_size eq 'A4'}selected{/if}>A4</option>
 								      <option value="Other" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'Other' || $inner_offset_info[inner_offset].item_inner_sheet_size eq 'Other'}selected{/if}>Other</option>
 							    </select>
 							    <span id="inner_sheet_size_other" {if $inner_offset_info[inner_offset].item_inner_sheet_size neq 'Other'}style="display:none;"{/if}>
 							      <input type="text" name="item_inner_offset_sheet_w[]" class="form-control" placeholder="Width" value="{if $smarty.post.item_inner_offset_sheet_w[0]}{$smarty.post.item_inner_offset_sheet_w[0]}{elseif $inner_offset_info[inner_offset].item_inner_sheet_size_w}{$inner_offset_info[inner_offset].item_inner_sheet_size_w}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;" > x
 		                          <input type="text" name="item_inner_offset_sheet_h[]" class="form-control" placeholder="Height" value="{if $smarty.post.item_inner_offset_sheet_h[0]}{$smarty.post.item_inner_offset_sheet_h[0]}{elseif $inner_offset_info[inner_offset].item_inner_sheet_size_h}{$inner_offset_info[inner_offset].item_inner_sheet_size_h}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;">

 							    </span>

 							 </div>
 		                  </div> *}


 		            </div>
 		             {if $count neq '1'}  <a class="remove" title="Remove" href="#" onclick="$(this).parent().remove();  return false"><span class="fa fa-times text-danger"></span></a>{/if}

 	            </div>

 	            {sectionelse}

 	              <div class="col-md-12 offset_inner_section" style="padding:0 0 15px;">
 	                 <h5 class="master_label">Section 1</h5>
 	                 <div class="col-md-6">
 		                <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Type</label>
 		                      <div class="col-md-8 col-xs-12">
 			                          <select name="item_inner_offset_paper_type[]" id="item_inner_offset_paper_type" onchange="toggleOther(this, 11, 'inner');" class="form-control">
 									      <option value="0">Please Select</option>
 									      {section name=paper_types loop=$paper_types}
 									      <option value="{$paper_types[paper_types].paper_id}" {if $smarty.post.item_inner_offset_paper_type[0] eq $paper_types[paper_types].paper_id}selected{/if}>{$paper_types[paper_types].paper_name}</option>
 									      {/section}
 									    </select> <input name="item_inner_offset_paper_type_other[]" type="text" id="item_inner_offset_paper_type_other" value="{if $smarty.post.item_inner_offset_paper_type_other[0]}{$smarty.post.item_inner_offset_paper_type_other[0]}{else}{$item_data.item_inner_offset_paper_type_other}{/if}" class="form-control" style="display:none;" />
 							</div>
 		                  </div>
 		                 <div class="form-group">
 		                      <label class="col-md-4 control-label">Paper Weight</label>
 		                      <div class="col-md-8">

 							    <select name="item_inner_offset_paper_weight[]" id="item_inner_offset_paper_weight" class="form-control">
 							      <option value="0">Please Select</option>
 							      {section name=paper_weights loop=$paper_weights}
 							      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.item_inner_offset_paper_weight eq $paper_weights[paper_weights].weight_value}selected{elseif $paper_weights[paper_weights].weight_value eq $quote_items[0].item_inner_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
 							      {/section}
 							    </select>
 							   </div>
 		                  </div>

 		                {* <div class="form-group">
 		                      <label class="col-md-4 control-label">Pre Press</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_inner_offset_pre_press[]" id="item_inner_offset_pre_press" onchange="calc_total_plates(this, 'inner');" class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="Work/Turn" {if $smarty.post.item_inner_offset_pre_press[0] eq 'Work/Turn' || $item_data.item_inner_offset_pre_press eq 'Work/Turn'}selected{/if}>Work/Turn</option>
 								      <option value="Work/Tumble" {if $smarty.post.item_inner_offset_pre_press[0] eq 'Work/Tumble' || $item_data.item_inner_offset_pre_press eq 'Work/Tumble'}selected{/if}>Work/Tumble</option>
 								      <option value="Front/Back" {if $smarty.post.item_inner_offset_pre_press[0] eq 'Front/Back' || $item_data.item_inner_offset_pre_press eq 'Front/Back'}selected{/if}>Front/Back</option>
 								      <option value="One Side" {if $smarty.post.item_inner_offset_pre_press[0] eq 'One Side' || $item_data.item_inner_offset_pre_press eq 'One Side'}selected{/if}>One Side</option>
 							      </select>
 			                  </div>
 		                  </div>

 		               <div class="form-group">
 		                   <label class="col-md-4 control-label">No of Colours</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_inner_offset_no_of_colors[]" type="text" id="item_inner_offset_no_of_colors" onblur="calc_total_plates(this, 'inner');" value="{if $smarty.post.item_inner_offset_no_of_colors[0]}{$smarty.post.item_inner_offset_no_of_colors[0]}{elseif $item_data.item_inner_offset_no_of_colors}{$item_data.item_inner_offset_no_of_colors}{/if}" class="form-control" />
 		                   </div>
 		               </div>
 		               <div class="form-group">
 		                     <label class="col-md-4 control-label">No of Sheets </label>
 		                     <div class="col-md-8">
 						     <input name="item_inner_offset_num_sheets[]" type="text" id="item_inner_offset_num_sheets" value="{$smarty.post.item_inner_num_sheets[0]}" class="form-control" />
 						 </div>
 		                 </div> *}
 		            </div>

 		            <div class="col-md-6">
									<div class="form-group">
											<label class="col-md-4 control-label">Remarks</label>
											<div class="col-md-8 col-xs-12">
											{* <input name="item_inner_offset_impressions[]" type="number" id="item_inner_offset_impressions" value="{if $smarty.post.item_inner_offset_impressions[0]}{$smarty.post.item_inner_offset_impressions[0]}{elseif $inner_offset_info[inner_offset].item_inner_impressions}{$inner_offset_info[inner_offset].item_inner_impressions}{/if}"  class="form-control" onblur="calc_num_of_sheets(this, 'inner');" /> *}
											<textarea name="item_inner_offset_remarks[]">{if $smarty.post.item_inner_offset_remarks[0]}{$smarty.post.item_inner_offset_remarks[0]}{/if}</textarea>
											</div>
									</div>

 		               {* <div class="form-group">
 		                   <label class="col-md-4 control-label">Machine</label>
 		                   <div class="col-md-8 col-xs-12">
 			                   <select name="item_inner_offset_machine[]" id="item_inner_offset_machine" class="form-control">
 							        <option value="0">Please Select</option>
 							      {section name=job_printers loop=$job_printers}
 							      <option value="{$job_printers[job_printers].printer_name}" {if $job_printers[job_printers].printer_name[0] eq '$smarty.post.item_inner_offset_machine' || $item_data.item_inner_offset_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
 							      {/section}
 							    </select>
 		                   </div>
 		               </div> *}

 		               {* <div class="form-group">
 		                      <label class="col-md-4 control-label">Plate Size</label>
 		                      <div class="col-md-8 col-xs-12">
 		                          <select name="item_inner_offset_plate_size[]"  class="form-control">
 								      <option value="0">Please Select</option>
 								      <option value="SM74" {if $smarty.post.item_inner_offset_plate_size[0] eq 'SM74' || $item_data.item_inner_plate_size eq 'SM74'}selected{/if}>SM74</option>
 								      <option value="Sm52" {if $smarty.post.item_inner_offset_plate_size[0] eq 'Sm52' || $item_data.item_inner_plate_size eq 'Sm52'}selected{/if}>Sm52</option>
 								      <option value="GTO46" {if $smarty.post.item_inner_offset_plate_size[0] eq 'GTO46' || $item_data.item_inner_plate_size eq 'GTO46'}selected{/if}>GTO46</option>
 							      </select>
 			                  </div>
 		                  </div> *}

 		               {* <div class="form-group">
 		                   <label class="col-md-4 control-label">Total Plates</label>
 		                   <div class="col-md-8 col-xs-12">
 		                   <input name="item_inner_offset_total_plates[]" type="text" id="item_inner_offset_total_plates" value="{if $smarty.post.item_inner_offset_total_plates[0]}{$smarty.post.item_inner_offset_total_plates[0]}{elseif $item_data.item_inner_total_plates}{$item_data.item_inner_total_plates}{/if}" class="form-control" readonly/>
 		                   </div>
 		               </div> *}
 		               {* <div class="form-group">
 		                      <label class="col-md-4 control-label">Press Sheet Size</label>

 		                      <div class="col-md-8">
 		                         <select name="item_inner_offset_sheet_size[]" id="item_inner_offset_sheet_size" onchange="calc_num_of_sheets(this, 'inner');" class="form-control" style="margin-bottom:5px;">
 								      <option value="A1" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A1' || $item_data.item_inner_offset_sheet_size eq 'A1'}selected{/if} selected>A1</option>
 								      <option value="A2" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A2' || $item_data.item_inner_offset_sheet_size eq 'A2'}selected{/if}>A2</option>
 								      <option value="A3" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A3' || $item_data.item_inner_offset_sheet_size eq 'A3'}selected{/if}>A3</option>
 								      <option value="A4" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'A4' || $item_data.item_inner_offset_sheet_size eq 'A4'}selected{/if}>A4</option>
 								      <option value="Other" {if $smarty.post.item_inner_offset_sheet_size[0] eq 'Other' || $item_data.item_inner_offset_sheet_size_other}selected{/if}>Other</option>
 							    </select>
 							    <span id="inner_sheet_size_other" style="display:none;">
 							      <input type="text" name="item_inner_offset_sheet_w[]" class="form-control" placeholder="Width" value="{if $smarty.post.item_inner_offset_sheet_w[0]}{$smarty.post.item_inner_offset_sheet_w[0]}{elseif $item_data.item_inner_cut_size_w}{$item_data.item_inner_cut_size_w}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;" > x
 		                          <input type="text" name="item_inner_offset_sheet_h[]" class="form-control" placeholder="Height" value="{if $smarty.post.item_inner_offset_sheet_h[0]}{$smarty.post.item_inner_offset_sheet_h[0]}{elseif $item_data.item_inner_cut_size_h}{$item_data.item_inner_cut_size_h}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;">

 							    </span>

 							 </div>
 		                  </div> *}


 		            </div>

 	            </div>

 	          {/section}


              <a href="#" class="offset_copy" rel=".offset_inner_section" style="diplay:block; float:left; margin-right:10px;" ><span class="fa fa-plus text-info"></span> Add More Sections</a>

              <a href="#" class="offset_duplicate" rel=".offset_inner_section" style="diplay:block; float:left; padding-left:10px; border-left:1px solid #ccc;"><span class="fa fa-plus-square text-info"></span> Duplicate First Section</a>

              <div class="clearfix"></div>

          </div>
           <div class="col-md-12 item_inner_wide_format" style="margin-top:15px; {if $smarty.post.inner_print_options eq 'item_inner_wide_format' || $item_data.item_inner_wide_format eq 'Y'}{else}display:none;{/if}">
 	         <div class="col-md-6">
 	               <div class="form-group">
 	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
 	                   <div class="col-md-8 col-xs-12">
 		                   <select name="item_inner_wide_format_material" id="item_inner_wide_format_material" class="form-control">
 						        <option value="0">Please Select</option>
 						      {section name=materials loop=$materials}
 						      <option value="{$materials[materials].material_name}" {if $smarty.post.item_inner_wide_format_material && $smarty.post.item_inner_wide_format_material eq $materials[materials].material_name}selected{elseif !$smarty.post.item_inner_wide_format_material && $item_data.item_inner_material eq $materials[materials].material_name}selected{/if}>{$materials[materials].material_name}</option>
 						      {/section}
 						    </select>
 	                   </div>
 	               </div>
 	    
 	         </div>
			 {* <div class="col-md-6">
 	            <div class="form-group">
                       <label class="col-md-4 control-label">Type</label>
                       <div class="col-md-8 col-xs-12">
 	                             <select name="item_inner_cnc_type" id="item_inner_cnc_type" onchange="checkOther(this.value, 'Other', 'item_inner_cnc_type_other');" class="form-control">
 							      <option value="0">Please Select</option>
 							      <option value="Lightbox" {if $smarty.post.item_inner_cnc_type eq 'Lightbox' || $item_data.item_inner_paper_type eq 'Lightbox'}selected{/if}>Lightbox</option>
 							      <option value="Cut-out" {if $smarty.post.item_inner_cnc_type eq 'Cut-out' || $item_data.item_inner_paper_type eq 'Cut-out'}selected{/if}>Cut-out</option>
 							      <option value="Pylon" {if $smarty.post.item_inner_cnc_type eq 'Pylon' || $item_data.item_inner_paper_type eq 'Pylon'}selected{/if}>Pylon</option>
 							      <option value="Other" {if $smarty.post.item_inner_cnc_type eq 'Other' || $item_data.item_inner_paper_type eq 'Other'}selected{/if}>Other</option>

 							    </select>
 							    <input name="item_inner_cnc_type_other" type="text" id="item_inner_cnc_type_other" value="{if $smarty.post.item_inner_cnc_type_other}{$smarty.post.item_inner_cnc_type_other}{elseif $item_data.item_inner_paper_type_other}{$item_data.item_inner_paper_type_other}{/if}" class="form-control" style="display:none; margin-top:10px;" />
 					</div>

                   </div>
 	         </div> *}

 	        
 	          <div class="col-md-12">
 	          <br>

                 <div class="form-group">
                       <label class="col-md-2 control-label text-right">Notes</label>
                       <div class="col-md-9">
                           <textarea name="item_inner_wide_format_notes"  class="form-control">{if $smarty.post.item_inner_wide_format_notes}{$smarty.post.item_inner_wide_format_notes}{else}{$item_data.item_inner_notes}{/if}</textarea>
                        </div>
                   </div>

 	         </div>

 	          
 	         <div class="col-md-6">
 	               {* <div class="form-group">
 	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
 	                   <div class="col-md-8 col-xs-12">
 	                    <input name="item_inner_cnc_material" type="text" id="item_inner_cnc_material" value="{if $smarty.post.item_inner_cnc_material}{$smarty.post.item_inner_cnc_material }{elseif $item_data.item_inner_material }{$item_data.item_inner_material}{/if}" class="form-control" />
 	                   </div>
 	               </div> *}
 	         </div>

 	         <div class="col-md-6" style="margin-top:10px;">
 	          {* <div class="form-group">
                    <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                    <div class="col-md-8 col-xs-12">
                    <input name="item_inner_cnc_quantity" type="number" id="item_inner_cnc_quantity" value="{if $smarty.post.item_inner_cnc_quantity}{$smarty.post.item_inner_cnc_quantity}{elseif $item_data.item_inner_quantity }{$item_data.item_inner_quantity}{/if}" class="form-control"/>
                    </div>
                </div> *}
 	         </div>
 	         {* <div class="col-md-12" style="margin-top:10px;">



 	           <label class="col-md-2 control-label">Processes</label>

 	           <div class="col-md-10">

 	             <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_fabrication" id="item_inner_cnc_fabrication" value="Y" {if $smarty.post.item_inner_cnc_fabrication || $item_inner_cnc_process_data.fabrication eq 'Y' || (isset($item_data.item_inner_cnc_process_data.fabrication) && $item_data.item_inner_cnc_process_data.fabrication eq 'Y')}checked{/if} />Fabrication</label>
                    <div class="col-md-12 item_inner_cnc_fabrication" style="padding:0; {if $smarty.post.item_inner_cnc_fabrication eq 'Y' || $item_inner_cnc_process_data.fabrication eq 'Y' || (isset($item_data.item_inner_cnc_process_data.fabrication) && $item_data.item_inner_cnc_process_data.fabrication eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_inner_fabrication_notes"  class="form-control">{if $item_inner_cnc_process_data.fabrication_notes}{$item_inner_cnc_process_data.fabrication_notes}{elseif isset($item_data.item_inner_cnc_process_data.fabrication_notes) && $item_data.item_inner_cnc_process_data.fabrication_notes}{$item_data.item_inner_cnc_process_data.fabrication_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_cnc_cutting" id="item_inner_cnc_cnc_cutting" value="Y" {if $smarty.post.item_inner_cnc_cnc_cutting ||  $item_inner_cnc_process_data.cnc_cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cnc_cutting) && $item_data.item_inner_cnc_process_data.cnc_cutting eq 'Y')}checked{/if} />CNC Cutting</label>

                     <div class="col-md-12 item_inner_cnc_cnc_cutting" style="padding:0; {if $smarty.post.item_inner_cnc_cutting eq 'Y' ||  $item_inner_cnc_process_data.cnc_cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cnc_cutting) && $item_data.item_inner_cnc_process_data.cnc_cutting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_cnc_cutting_notes"  class="form-control">{if $item_inner_cnc_process_data.cnc_cutting_notes}{$item_inner_cnc_process_data.cnc_cutting_notes}{elseif isset($item_data.item_inner_cnc_process_data.cnc_cutting_notes) && $item_data.item_inner_cnc_process_data.cnc_cutting_notes}{$item_data.item_inner_cnc_process_data.cnc_cutting_notes}{/if}</textarea>
                     </div>

                </div>

                 <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_spraying" id="item_inner_cnc_spraying" value="Y" {if $smarty.post.item_inner_cnc_spraying || $item_inner_cnc_process_data.spraying eq 'Y' || (isset($item_data.item_inner_cnc_process_data.spraying) && $item_data.item_inner_cnc_process_data.spraying eq 'Y')}checked{/if} />Spraying</label>
                    <div class="col-md-12 item_inner_cnc_spraying" style="padding:0; {if $smarty.post.item_inner_cnc_spraying eq 'Y' || $item_inner_cnc_process_data.spraying eq 'Y' || (isset($item_data.item_inner_cnc_process_data.spraying) && $item_data.item_inner_cnc_process_data.spraying eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_inner_spraying_notes"  class="form-control">{if $item_inner_cnc_process_data.spraying_notes}{$item_inner_cnc_process_data.spraying_notes}{elseif isset($item_data.item_inner_cnc_process_data.spraying_notes) && $item_data.item_inner_cnc_process_data.spraying_notes}{$item_data.item_inner_cnc_process_data.spraying_notes}{/if}</textarea>
                    </div>

                </div>

                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_cutting" id="item_inner_cnc_cutting" value="Y" {if $smarty.post.item_inner_cnc_cutting || $item_inner_cnc_process_data.cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cutting) && $item_data.item_inner_cnc_process_data.cutting eq 'Y')}checked{/if} />Cutting</label>
                    <div class="col-md-12 item_inner_cnc_cutting" style="padding:0; {if $smarty.post.item_inner_cnc_cutting eq 'Y' || $item_inner_cnc_process_data.cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cutting) && $item_data.item_inner_cnc_process_data.cutting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_cutting_notes"  class="form-control">{if $item_inner_cnc_process_data.cutting_notes}{$item_inner_cnc_process_data.cutting_notes}{elseif isset($item_data.item_inner_cnc_process_data.cutting_notes) && $item_data.item_inner_cnc_process_data.cutting_notes}{$item_data.item_inner_cnc_process_data.cutting_notes}{/if}</textarea>
                    </div>


                </div>

                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_bending" id="item_inner_cnc_bending" value="Y" {if $smarty.post.item_inner_cnc_bending || $item_inner_cnc_process_data.bending eq 'Y' || (isset($item_data.item_inner_cnc_process_data.bending) && $item_data.item_inner_cnc_process_data.bending eq 'Y')}checked{/if} />Bending</label>

                     <div class="col-md-12 item_inner_cnc_bending" style="padding:0; {if $smarty.post.item_inner_cnc_bending eq 'Y' || $item_inner_cnc_process_data.bending eq 'Y' || (isset($item_data.item_inner_cnc_process_data.bending) && $item_data.item_inner_cnc_process_data.bending eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_bending_notes"  class="form-control">{if $item_inner_cnc_process_data.bending_notes}{$item_inner_cnc_process_data.bending_notes}{elseif isset($item_data.item_inner_cnc_process_data.bending_notes) && $item_data.item_inner_cnc_process_data.bending_notes}{$item_data.item_inner_cnc_process_data.bending_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_led" id="item_inner_cnc_led" value="Y" {if $smarty.post.item_inner_cnc_led || $item_inner_cnc_process_data.led eq 'Y' || (isset($item_data.item_inner_cnc_process_data.led) && $item_data.item_inner_cnc_process_data.led eq 'Y')}checked{/if} />Lighting Attachment (LED)</label>
                    <div class="col-md-12 item_inner_cnc_led" style="padding:0; {if $smarty.post.item_inner_cnc_led eq 'Y' || $item_inner_cnc_process_data.led eq 'Y' || (isset($item_data.item_inner_cnc_process_data.led) && $item_data.item_inner_cnc_process_data.led eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_led_notes"  class="form-control">{if $item_inner_cnc_process_data.led_notes}{$item_inner_cnc_process_data.led_notes}{elseif isset($item_data.item_inner_cnc_process_data.led_notes) && $item_data.item_inner_cnc_process_data.led_notes}{$item_data.item_inner_cnc_process_data.led_notes}{/if}</textarea>
                    </div>


                </div>
                 <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_lighting" id="item_inner_cnc_lighting" value="Y" {if $smarty.post.item_inner_cnc_lighting || $item_inner_cnc_process_data.lighting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.lighting) && $item_data.item_inner_cnc_process_data.lighting eq 'Y')}checked{/if} />Lighting (tube lights)</label>
                    <div class="col-md-12 item_inner_cnc_lighting" style="padding:0; {if $smarty.post.item_inner_cnc_lighting eq 'Y' || $item_inner_cnc_process_data.lighting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.lighting) && $item_data.item_inner_cnc_process_data.lighting eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_inner_lighting_notes"  class="form-control">{if $item_inner_cnc_process_data.lighting_notes}{$item_inner_cnc_process_data.lighting_notes}{elseif isset($item_data.item_inner_cnc_process_data.lighting_notes) && $item_data.item_inner_cnc_process_data.lighting_notes}{$item_data.item_inner_cnc_process_data.lighting_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_rivetting" id="item_inner_cnc_rivetting" value="Y" {if $smarty.post.item_inner_cnc_rivetting || $item_inner_cnc_process_data.rivetting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.rivetting) && $item_data.item_inner_cnc_process_data.rivetting eq 'Y')}checked{/if} />Rivetting</label>

                     <div class="col-md-12 item_inner_cnc_rivetting" style="padding:0; {if $smarty.post.item_inner_cnc_rivetting eq 'Y' || $item_inner_cnc_process_data.rivetting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.rivetting) && $item_data.item_inner_cnc_process_data.rivetting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_rivetting_notes"  class="form-control">{if $item_inner_cnc_process_data.rivetting_notes}{$item_inner_cnc_process_data.rivetting_notes}{elseif isset($item_data.item_inner_cnc_process_data.rivetting_notes) && $item_data.item_inner_cnc_process_data.rivetting_notes}{$item_data.item_inner_cnc_process_data.rivetting_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_site_installation" id="item_inner_cnc_site_installation" value="Y" {if $smarty.post.item_inner_cnc_site_installation || $item_inner_cnc_process_data.site_installation eq 'Y' || (isset($item_data.item_inner_cnc_process_data.site_installation) && $item_data.item_inner_cnc_process_data.site_installation eq 'Y')}checked{/if} />Site installation</label>
                    <div class="col-md-12 item_inner_cnc_site_installation" style="padding:0; {if $smarty.post.item_inner_cnc_site_installation eq 'Y' || $item_inner_cnc_process_data.site_installation eq 'Y' || (isset($item_data.item_inner_cnc_process_data.site_installation) && $item_data.item_inner_cnc_process_data.site_installation eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_site_installation_notes"  class="form-control">{if $item_inner_cnc_process_data.site_installation_notes}{$item_inner_cnc_process_data.site_installation_notes}{elseif isset($item_data.item_inner_cnc_process_data.site_installation_notes) && $item_data.item_inner_cnc_process_data.site_installation_notes}{$item_data.item_inner_cnc_process_data.site_installation_notes}{/if}</textarea>
                    </div>


                </div>


 	           </div>


 	         </div> *}


          </div>

          <div class="col-md-12 item_inner_promotional" style="margin-top:15px; {if $smarty.post.inner_print_options eq 'item_inner_promotional' || $item_data.item_inner_promotional eq 'Y'}{else}display:none;{/if}">
 	         <div class="col-md-6">
 	               <div class="form-group">
 	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
 	                   <div class="col-md-8 col-xs-12">
 	                    <input name="item_inner_promotional_material" type="text" id="item_inner_promotional_material" value="{if $smarty.post.item_inner_promotional_material}{$smarty.post.item_inner_promotional_material}{elseif $item_data.item_inner_material}{$item_data.item_inner_material}{/if}" placeholder="TShirt, Bag, Caps,.." class="form-control" />
 	                   </div>
 	               </div>
 	         </div>

 	         <div class="col-md-6">
 	          {* <div class="form-group">
                    <label class="col-md-4 control-label">Quantity</label>
                    <div class="col-md-8 col-xs-12">
                    <input name="item_inner_promotional_quantity" type="number" id="item_inner_promotional_quantity" value="{if $smarty.post.item_inner_promotional_quantity}{$smarty.post.item_inner_promotional_quantity}{elseif $item_data.item_inner_quantity}{$item_data.item_inner_quantity}{/if}" class="form-control" />
                    </div>
                </div> *}
 	         </div>
 	         <div class="col-md-12" style="margin-top:10px;">
 	           <div class="col-md-2">
 	           &nbsp;
 	           </div>
 	           <div class="col-md-3">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_promotional_screen_printing" id="item_inner_promotional_screen_printing" value="Y" {if $smarty.post.item_inner_promotional_screen_printing || $item_data.item_inner_screen_printing eq 'Y'}checked{/if} />Screen Printing</label>
                    <div class="col-md-12 item_inner_promotional_screen_printing" style="padding:0; {if $smarty.post.item_inner_promotional_screen_printing neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_inner_screen_printing_notes"  class="form-control">{if $smarty.post.item_inner_screen_printing_notes}{$smarty.post.item_inner_screen_printing_notes}{elseif $item_data.item_inner_screen_printing_notes}{$item_data.item_inner_screen_printing_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-3">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_promotional_embroidery" id="item_inner_promotional_embroidery" value="Y" {if $smarty.post.item_inner_promotional_embroidery || $item_data.item_inner_embroidery eq 'Y'}checked{/if} />Embroidery</label>

                     <div class="col-md-12 item_inner_promotional_embroidery" style="padding:0; {if $smarty.post.item_inner_promotional_embroidery || $item_data.item_inner_embroidery eq 'Y'}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_embroidery_notes"  class="form-control">{if $smarty.post.item_inner_embroidery_notes}{$smarty.post.item_inner_embroidery_notes}{elseif $item_data.item_inner_embroidery_notes}{$item_data.item_inner_embroidery_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-3">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_promotional_heat_transfer" id="item_inner_promotional_heat_transfer" value="Y" {if $smarty.post.item_inner_promotional_heat_transfer || $item_data.item_inner_heat_transfer eq 'Y'}checked{/if} />Heat Transfer</label>
                    <div class="col-md-12 item_inner_promotional_heat_transfer" style="padding:0; {if $smarty.post.item_inner_promotional_heat_transfer || $item_data.item_inner_heat_transfer eq 'Y'}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_heat_transfer_notes"  class="form-control">{if $smarty.post.item_inner_heat_transfer_notes}{$smarty.post.item_inner_heat_transfer_notes}{elseif $item_data.item_inner_heat_transfer_notes}{$item_data.item_inner_heat_transfer_notes}{/if}</textarea>
                    </div>
                </div>
 	         </div>
          </div>
           <div class="col-md-12 item_inner_cnc" style="margin-top:15px; {if $smarty.post.inner_print_options eq 'item_inner_cnc' || $item_data.item_inner_cnc eq 'Y'}{else}display:none;{/if}">

 	          <div class="col-md-6">
 	            <div class="form-group">
                       <label class="col-md-4 control-label">Type <span class="asterisk">*</span></label>
                       <div class="col-md-8 col-xs-12">
 	                             <select name="item_inner_cnc_type" id="item_inner_cnc_type" onchange="checkOther(this.value, 'Other', 'item_inner_cnc_type_other');" class="form-control">
 							      <option value="0">Please Select</option>
 							      <option value="Lightbox" {if $smarty.post.item_inner_cnc_type eq 'Lightbox' || $item_data.item_inner_paper_type eq 'Lightbox'}selected{/if}>Lightbox</option>
 							      <option value="Cut-out" {if $smarty.post.item_inner_cnc_type eq 'Cut-out' || $item_data.item_inner_paper_type eq 'Cut-out'}selected{/if}>Cut-out</option>
 							      <option value="Pylon" {if $smarty.post.item_inner_cnc_type eq 'Pylon' || $item_data.item_inner_paper_type eq 'Pylon'}selected{/if}>Pylon</option>
 							      <option value="Other" {if $smarty.post.item_inner_cnc_type eq 'Other' || $item_data.item_inner_paper_type eq 'Other'}selected{/if}>Other</option>

 							    </select>
 							    <input name="item_inner_cnc_type_other" type="text" id="item_inner_cnc_type_other" value="{if $smarty.post.item_inner_cnc_type_other}{$smarty.post.item_inner_cnc_type_other}{elseif $item_data.item_inner_paper_type_other}{$item_data.item_inner_paper_type_other}{/if}" class="form-control" style="display:none; margin-top:10px;" />
 					</div>

                   </div>
 	         </div>
 	         <div class="col-md-6">
 	               {* <div class="form-group">
 	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
 	                   <div class="col-md-8 col-xs-12">
 	                    <input name="item_inner_cnc_material" type="text" id="item_inner_cnc_material" value="{if $smarty.post.item_inner_cnc_material}{$smarty.post.item_inner_cnc_material }{elseif $item_data.item_inner_material }{$item_data.item_inner_material}{/if}" class="form-control" />
 	                   </div>
 	               </div> *}
 	         </div>

 	         <div class="col-md-6" style="margin-top:10px;">
 	          {* <div class="form-group">
                    <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                    <div class="col-md-8 col-xs-12">
                    <input name="item_inner_cnc_quantity" type="number" id="item_inner_cnc_quantity" value="{if $smarty.post.item_inner_cnc_quantity}{$smarty.post.item_inner_cnc_quantity}{elseif $item_data.item_inner_quantity }{$item_data.item_inner_quantity}{/if}" class="form-control"/>
                    </div>
                </div> *}
 	         </div>
 	         <div class="col-md-12" style="margin-top:10px;">


 	           <label class="col-md-2 control-label">Processes</label>

 	           <div class="col-md-10">

 	             <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_fabrication" id="item_inner_cnc_fabrication" value="Y" {if $smarty.post.item_inner_cnc_fabrication || $item_inner_cnc_process_data.fabrication eq 'Y' || (isset($item_data.item_inner_cnc_process_data.fabrication) && $item_data.item_inner_cnc_process_data.fabrication eq 'Y')}checked{/if} />Fabrication</label>
                    <div class="col-md-12 item_inner_cnc_fabrication" style="padding:0; {if $smarty.post.item_inner_cnc_fabrication eq 'Y' || $item_inner_cnc_process_data.fabrication eq 'Y' || (isset($item_data.item_inner_cnc_process_data.fabrication) && $item_data.item_inner_cnc_process_data.fabrication eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_inner_fabrication_notes"  class="form-control">{if $item_inner_cnc_process_data.fabrication_notes}{$item_inner_cnc_process_data.fabrication_notes}{elseif isset($item_data.item_inner_cnc_process_data.fabrication_notes) && $item_data.item_inner_cnc_process_data.fabrication_notes}{$item_data.item_inner_cnc_process_data.fabrication_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_cnc_cutting" id="item_inner_cnc_cnc_cutting" value="Y" {if $smarty.post.item_inner_cnc_cnc_cutting ||  $item_inner_cnc_process_data.cnc_cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cnc_cutting) && $item_data.item_inner_cnc_process_data.cnc_cutting eq 'Y')}checked{/if} />CNC Cutting</label>

                     <div class="col-md-12 item_inner_cnc_cnc_cutting" style="padding:0; {if $smarty.post.item_inner_cnc_cutting eq 'Y' ||  $item_inner_cnc_process_data.cnc_cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cnc_cutting) && $item_data.item_inner_cnc_process_data.cnc_cutting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_cnc_cutting_notes"  class="form-control">{if $item_inner_cnc_process_data.cnc_cutting_notes}{$item_inner_cnc_process_data.cnc_cutting_notes}{elseif isset($item_data.item_inner_cnc_process_data.cnc_cutting_notes) && $item_data.item_inner_cnc_process_data.cnc_cutting_notes}{$item_data.item_inner_cnc_process_data.cnc_cutting_notes}{/if}</textarea>
                     </div>

                </div>

                 <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_spraying" id="item_inner_cnc_spraying" value="Y" {if $smarty.post.item_inner_cnc_spraying || $item_inner_cnc_process_data.spraying eq 'Y' || (isset($item_data.item_inner_cnc_process_data.spraying) && $item_data.item_inner_cnc_process_data.spraying eq 'Y')}checked{/if} />Spraying</label>
                    <div class="col-md-12 item_inner_cnc_spraying" style="padding:0; {if $smarty.post.item_inner_cnc_spraying eq 'Y' || $item_inner_cnc_process_data.spraying eq 'Y' || (isset($item_data.item_inner_cnc_process_data.spraying) && $item_data.item_inner_cnc_process_data.spraying eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_inner_spraying_notes"  class="form-control">{if $item_inner_cnc_process_data.spraying_notes}{$item_inner_cnc_process_data.spraying_notes}{elseif isset($item_data.item_inner_cnc_process_data.spraying_notes) && $item_data.item_inner_cnc_process_data.spraying_notes}{$item_data.item_inner_cnc_process_data.spraying_notes}{/if}</textarea>
                    </div>

                </div>

                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_cutting" id="item_inner_cnc_cutting" value="Y" {if $smarty.post.item_inner_cnc_cutting || $item_inner_cnc_process_data.cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cutting) && $item_data.item_inner_cnc_process_data.cutting eq 'Y')}checked{/if} />Cutting</label>
                    <div class="col-md-12 item_inner_cnc_cutting" style="padding:0; {if $smarty.post.item_inner_cnc_cutting eq 'Y' || $item_inner_cnc_process_data.cutting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.cutting) && $item_data.item_inner_cnc_process_data.cutting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_cutting_notes"  class="form-control">{if $item_inner_cnc_process_data.cutting_notes}{$item_inner_cnc_process_data.cutting_notes}{elseif isset($item_data.item_inner_cnc_process_data.cutting_notes) && $item_data.item_inner_cnc_process_data.cutting_notes}{$item_data.item_inner_cnc_process_data.cutting_notes}{/if}</textarea>
                    </div>


                </div>

                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_bending" id="item_inner_cnc_bending" value="Y" {if $smarty.post.item_inner_cnc_bending || $item_inner_cnc_process_data.bending eq 'Y' || (isset($item_data.item_inner_cnc_process_data.bending) && $item_data.item_inner_cnc_process_data.bending eq 'Y')}checked{/if} />Bending</label>

                     <div class="col-md-12 item_inner_cnc_bending" style="padding:0; {if $smarty.post.item_inner_cnc_bending eq 'Y' || $item_inner_cnc_process_data.bending eq 'Y' || (isset($item_data.item_inner_cnc_process_data.bending) && $item_data.item_inner_cnc_process_data.bending eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_bending_notes"  class="form-control">{if $item_inner_cnc_process_data.bending_notes}{$item_inner_cnc_process_data.bending_notes}{elseif isset($item_data.item_inner_cnc_process_data.bending_notes) && $item_data.item_inner_cnc_process_data.bending_notes}{$item_data.item_inner_cnc_process_data.bending_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_led" id="item_inner_cnc_led" value="Y" {if $smarty.post.item_inner_cnc_led || $item_inner_cnc_process_data.led eq 'Y' || (isset($item_data.item_inner_cnc_process_data.led) && $item_data.item_inner_cnc_process_data.led eq 'Y')}checked{/if} />Lighting Attachment (LED)</label>
                    <div class="col-md-12 item_inner_cnc_led" style="padding:0; {if $smarty.post.item_inner_cnc_led eq 'Y' || $item_inner_cnc_process_data.led eq 'Y' || (isset($item_data.item_inner_cnc_process_data.led) && $item_data.item_inner_cnc_process_data.led eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_led_notes"  class="form-control">{if $item_inner_cnc_process_data.led_notes}{$item_inner_cnc_process_data.led_notes}{elseif isset($item_data.item_inner_cnc_process_data.led_notes) && $item_data.item_inner_cnc_process_data.led_notes}{$item_data.item_inner_cnc_process_data.led_notes}{/if}</textarea>
                    </div>


                </div>
                 <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_lighting" id="item_inner_cnc_lighting" value="Y" {if $smarty.post.item_inner_cnc_lighting || $item_inner_cnc_process_data.lighting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.lighting) && $item_data.item_inner_cnc_process_data.lighting eq 'Y')}checked{/if} />Lighting (tube lights)</label>
                    <div class="col-md-12 item_inner_cnc_lighting" style="padding:0; {if $smarty.post.item_inner_cnc_lighting eq 'Y' || $item_inner_cnc_process_data.lighting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.lighting) && $item_data.item_inner_cnc_process_data.lighting eq 'Y')}{else}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="item_inner_lighting_notes"  class="form-control">{if $item_inner_cnc_process_data.lighting_notes}{$item_inner_cnc_process_data.lighting_notes}{elseif isset($item_data.item_inner_cnc_process_data.lighting_notes) && $item_data.item_inner_cnc_process_data.lighting_notes}{$item_data.item_inner_cnc_process_data.lighting_notes}{/if}</textarea>
                    </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_rivetting" id="item_inner_cnc_rivetting" value="Y" {if $smarty.post.item_inner_cnc_rivetting || $item_inner_cnc_process_data.rivetting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.rivetting) && $item_data.item_inner_cnc_process_data.rivetting eq 'Y')}checked{/if} />Rivetting</label>

                     <div class="col-md-12 item_inner_cnc_rivetting" style="padding:0; {if $smarty.post.item_inner_cnc_rivetting eq 'Y' || $item_inner_cnc_process_data.rivetting eq 'Y' || (isset($item_data.item_inner_cnc_process_data.rivetting) && $item_data.item_inner_cnc_process_data.rivetting eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_rivetting_notes"  class="form-control">{if $item_inner_cnc_process_data.rivetting_notes}{$item_inner_cnc_process_data.rivetting_notes}{elseif isset($item_data.item_inner_cnc_process_data.rivetting_notes) && $item_data.item_inner_cnc_process_data.rivetting_notes}{$item_data.item_inner_cnc_process_data.rivetting_notes}{/if}</textarea>
                     </div>

                </div>
                <div class="col-md-4">
                    <label class="check"><input type="checkbox" class="icheckbox" name="item_inner_cnc_site_installation" id="item_inner_cnc_site_installation" value="Y" {if $smarty.post.item_inner_cnc_site_installation || $item_inner_cnc_process_data.site_installation eq 'Y' || (isset($item_data.item_inner_cnc_process_data.site_installation) && $item_data.item_inner_cnc_process_data.site_installation eq 'Y')}checked{/if} />Site installation</label>
                    <div class="col-md-12 item_inner_cnc_site_installation" style="padding:0; {if $smarty.post.item_inner_cnc_site_installation eq 'Y' || $item_inner_cnc_process_data.site_installation eq 'Y' || (isset($item_data.item_inner_cnc_process_data.site_installation) && $item_data.item_inner_cnc_process_data.site_installation eq 'Y')}{else}display:none;{/if}">
                       <label class="col-md-12 control-label text-left">Notes</label>
                       <textarea name="item_inner_site_installation_notes"  class="form-control">{if $item_inner_cnc_process_data.site_installation_notes}{$item_inner_cnc_process_data.site_installation_notes}{elseif isset($item_data.item_inner_cnc_process_data.site_installation_notes) && $item_data.item_inner_cnc_process_data.site_installation_notes}{$item_data.item_inner_cnc_process_data.site_installation_notes}{/if}</textarea>
                    </div>


                </div>


 	           </div>


 	         </div>

          </div>

       </div>

				<div class="row hide-stationary">
					 <br /> <br />
					 <h4>FINISHING</h4>
					<div class="col-md-12">
						<div class="form-group">
	 								{section name=item_finishing loop=$item_finishing}
									<div class="col-md-3">
															<label class="check"><input type="checkbox" class="icheckbox" name="item_finishing_{$smarty.section.item_finishing.rownum}" id="item_finishing_{$smarty.section.item_finishing.rownum}" value="{$item_finishing[item_finishing].finishing_id}" {if $item_finishing_array}{if $item_finishing[item_finishing].finishing_id|in_array:$item_finishing_array}checked="checked"{/if}{/if} /> {$item_finishing[item_finishing].finishing_type}</label>
													</div>
	 				 {/section}
	 					 </div>
					</div>
				</div>



         <div class="row">
             <br /> <br />
          <h4>REMARKS / SPECIAL INSTRUCTIONS</h4>
              <div class="col-md-12">
                <div class="form-group">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <div class="col-md-12">
                       <textarea name="item_notes" id="item_notes" class="form-control"  rows="5">{$item_data.item_notes}</textarea>
                       </div>
                 </div>

                <div class="form-group">
                      <label class="col-md-12 control-label text-left">Special Remarks <span class="text-danger">(CONFIDENTIAL)</span>
                       <input type="checkbox" name="show_spremarks" id="show_spremarks" value="Y" onclick="show_textarea(this, 'special_remarks');" {if $item_data.show_spremarks eq 'Y'} checked="checked" {/if}>
                      </label>

                      <div class="col-md-12" id="special_remarks" {if !$item_data.item_special_remarks} style="display:none;"{else} style="margin-top: 10px;" {/if}>
                       <textarea name="item_special_remarks" id="item_special_remarks" class="form-control" rows="5">{$item_data.item_special_remarks}</textarea>
                      </div>
                 </div>

              </div>


         </div>



      </div>
      <div class="panel-footer">
      <input type="hidden" name="next_step" id="next_step" value="three" />
        <input type="submit" name="add_item" class="btn btn-primary pull-right" value="Add Item" />


      </div>
  </div>
  </form>
	{/if}
