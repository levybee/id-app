{if $privileges.quotes.makejob}

<ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/quotes/list">Quotes</a></li>
     <li class="active"><a href="">Confirmed Quotation</a></li>
	 </ul>
	 <!-- END BREADCRUMB -->
	 
	 {if $subtask eq 'convert'}
	    <script type="text/javascript" src="/js/quote.js"></script> 
        {include file='quotes/makejob.convert.tpl'}
        
     {else}
     
	 <div class="page-title">                    
	    <h2><span class="fa fa-arrow-circle-o-left"></span>Confirmed Quotation &gt; Convert Item to Job Order</h2>
	</div>

   
    <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
        {/if}
        
        <div  class="panel panel-default">
          
		       
        
         <div class="panel-body panel-body-table">
			   
			   <div class="table-responsive">
			   
			     <table class="table table-striped">
			       <tr>
		            <td colspan="2" class="header_row title">QUOTE INFORMATION</td>
		          </tr>
		          <tr>
		            <td width="100" class="header_row"><div align="right"><strong>Quote # </strong></div></td>
		            <td width="300">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
		          </tr>
		          <tr>
		            <td width="100" class="header_row"><div align="right"><strong>Quote Date </strong></div></td>
		            <td>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</td>
		          </tr>
		          <tr>
		            <td width="100" class="header_row"><div align="right"><strong>Customer </strong></div></td>
		            <td>{$quote_info[0].group_company} - {$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<input type="hidden" name="customer_id" id="customer_id" value="{$quote_info[0].customer_id}" /><input type="hidden" name="job_representative" id="job_representative" value="{$quote_info[0].job_representative}" /></td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>Representative </strong></div></td>
		            <td>{$quote_info[0].customer_representative}</td>
		          </tr>
		          
		          <tr>
		            <td colspan="2" class="header_row title">LPO INFORMATION</td>
		          </tr>
		          <tr>
		            <td width="100" class="header_row"><div align="right"><strong>LPO No. </strong></div></td>
		            <td>{$quote_info[0].job_lpo} {if $quote_info[0].job_lpo eq 'LPO Number'}: {$quote_info[0].job_lpo_other}{/if}</td>
		          </tr>
             </table>  
            
           </div>
          </div> 
          
          </div>
          
           {if $quote_info[0].quote_template eq 'Blank'}
        	  {include file="quotes/makejob.blank.tpl"}
            {else}
        	  {include file="quotes/makejob.normal.tpl"}
            {/if}
	         
        	   
	   
	
    </div>
  </div>
 </div>
 <!-- END PAGE CONTENT WRAPPER --> 
 
  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
 {/if}

{*
    <script type="text/javascript" src="/js/quote.js"></script>
    {if $subtask eq 'convert'}
        {include file='quotes/makejob.convert.tpl'}
    {else}
        <h1>Confirmed Quotation &gt; Convert Item to Job Order</h1>
        <table  border="1" cellpadding="5" cellspacing="5" class="table">
          <tr>
            <td colspan="2" class="header_row title">QUOTE INFORMATION</td>
          </tr>
          <tr>
            <td width="100" class="header_row"><div align="right"><strong>Quote # </strong></div></td>
            <td width="300">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
          </tr>
          <tr>
            <td width="100" class="header_row"><div align="right"><strong>Quote Date </strong></div></td>
            <td>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</td>
          </tr>
          <tr>
            <td width="100" class="header_row"><div align="right"><strong>Customer </strong></div></td>
            <td>{$quote_info[0].group_company} - {$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<input type="hidden" name="customer_id" id="customer_id" value="{$quote_info[0].customer_id}" /><input type="hidden" name="job_representative" id="job_representative" value="{$quote_info[0].job_representative}" /></td>
          </tr>
          <tr>
            <td class="header_row"><div align="right"><strong>Representative </strong></div></td>
            <td>{$quote_info[0].customer_representative}</td>
          </tr>
          
          <tr>
            <td colspan="2" class="header_row title">LPO INFORMATION</td>
          </tr>
          <tr>
            <td width="100" class="header_row"><div align="right"><strong>LPO No. </strong></div></td>
            <td>{$quote_info[0].job_lpo} {if $quote_info[0].job_lpo eq 'LPO Number'}: {$quote_info[0].job_lpo_other}{/if}</td>
          </tr>
          </tr>
        </table>
        <div id="summary">
          <h2>Quotation Items</h2>
            {if $quote_info[0].quote_template eq 'Blank'}
            	{include file="quotes/makejob.blank.tpl"}
            {else}
            	{include file="quotes/makejob.normal.tpl"}
            {/if}
        </div>
    {/if *}
    
    
{/if}