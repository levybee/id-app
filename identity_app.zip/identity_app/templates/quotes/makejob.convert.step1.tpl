<div class="row">
<div class="col-md-12">
{if $message_ignore_2}
    <div class="alert alert-info" role="alert">
          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
          {$message_ignore_2}
      </div>
{/if}

       {if $message}
         <div class="alert alert-danger" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
        {/if}

{if $show_job_order}
<form id="quotes-form" class="form-horizontal" method="post" action="">
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">New Job > From Quotation Item</h3>
      </div>

      <div class="panel-body">

          <div class="row">
              <h3>QUOTE INFORMATION</h3>
              <div class="col-md-6">

                  <div class="form-group">
                      <label class="col-md-4 control-label">Quote #</label>
                      <div class="col-md-8">
                         <label class="control-label">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}
                      </label>
                     </div>
                  </div>



              </div>
              <div class="col-md-6">

                   <div class="form-group">
                      <label class="col-md-4 control-label">Quote Date</label>
                      <div class="col-md-8 col-xs-12">
                         <label class="control-label"> {$quote_info[0].quote_date|date_format:"%d %B %Y"}</label>

                      </div>
                  </div>


              </div>

          </div>
          <div class="row">
             <br /> <br />
              {literal}
			<script type="text/javascript">

				var prod = new Array();
			{/literal}
				{section name=product_types loop=$product_types}
				prod[{$product_types[product_types].product_id}] = '{$product_types[product_types].product_2rows}';
				{/section}
			{literal}
			</script>
			{/literal}

             <h3>JOB INFORMATION</h3>

              <div class="col-md-6">

                  <div class="form-group">
                      <label class="col-md-4 control-label">Date In</label>
                      <div class="col-md-8">
                           <input name="job_date" type="text" id="job_date" value="{if $smarty.post.job_date}{$smarty.post.job_date|date_format:'%Y-%m-%d'}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" class="form-control datepicker" readonly="true">
                      </div>
                  </div>

                  <div class="form-group">
                      <label class="col-md-4 control-label">LPO Number</label>
                      <div class="col-md-8 col-xs-12">
                        <label class="control-label">{$quote_info[0].job_lpo} {if $quote_info[0].job_lpo_other}{$quote_info[0].job_lpo_other}{/if}</label>
                      </div>
                  </div>


                  <div class="form-group">
                      <label class="col-md-4 control-label">Company <span class="asterisk">*</span></label>
                      <div class="col-md-8">
                          <label class="control-label">{$quote_info[0].group_company} | {$quote_info[0].customer_fname} {$quote_info[0].customer_lname}</label>
                      </div>
                  </div>

                  <div class="form-group">
                      <label class="col-md-4 control-label">Job Reference <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					   <input name="job_reference" type="text" id="job_reference" value="{if $smarty.post.job_reference}{$smarty.post.job_reference}{else}{$quote_items[0].item_title}{/if}" class="form-control" />
					 </div>
                  </div>
                  <div class="form-group">
                      <label class="col-md-4 control-label">Due Date <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					    <input name="job_due_date" type="text" id="job_due_date" value="{if $smarty.post.job_due_date}{$smarty.post.job_due_date|date_format:'%Y-%m-%d'}{else}{if $quote_items[0].item_delivery_date eq '0000-00-00'}{else}{$quote_items[0].item_delivery_date|date_format:'%Y-%m-%d'}{/if}{/if}" class="form-control datepicker" readonly="true" />
                      </div>
                  </div>

                  <div class="form-group">
                      <label class="col-md-4 control-label">Designer <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
	                          <select name="employee_id" id="employee_id" class="form-control" required>
                         <option value="">Select..</option>
						      {section name=employees loop=$employees}

						      <option value="{$employees[employees].id}" {if $smarty.post.employee_id eq $employees[employees].id}selected{/if}>{$employees[employees].first_name} {$employees[employees].last_name}</option>

						      {/section}

						    </select>
					 </div>
                  </div>


              </div>
              <div class="col-md-6">

                   <div class="form-group">
                      <label class="col-md-4 control-label">Time In</label>
                      <div class="col-md-8 col-xs-12">
                          {html_select_time prefix="job_time_" display_seconds=false use_24_hours=true minute_interval=15}
                      </div>
                  </div>

                  <div class="form-group">
                      <label class="col-md-4 control-label">Priority</label>
                      <div class="col-md-8">
                          <select name="job_priority" id="job_priority" class="form-control" {literal} onchange="if(this.value == 'High') { this.style.backgroundColor='#FF0000'; this.style.color='#FFFFFF'; } else { this.style.backgroundColor='#FFFFFF'; this.style.color='#000000'; }"  {/literal}>
					      <option value="Normal" style="background-color: #FFFFFF; color: #000000;" {if $smarty.post.job_priority eq 'Normal'}selected{/if}>Normal</option>
					      <option value="High" style="background-color: #FF0000; color: #FFFFFF;" {if $smarty.post.job_priority eq 'Normal'}selected{/if}>High</option>
					    </select>
                      </div>
                  </div>
                   <!-- <div class="form-group">
                      <label class="col-md-4 control-label">Representative</label>
                      <div class="col-md-8 col-xs-12">
                          <label class="control-label">{$quote_info[0].customer_representative}</label>
                      </div>
                  </div> -->
                  <div class="form-group">
                      <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					   <input name="job_paper_quantity" type="text" id="job_paper_quantity" value="{if $smarty.post.job_paper_quantity}{$smarty.post.job_paper_quantity}{else}{$def_item_quantity}{/if}" class="form-control" />
					 </div>
                  </div>
                  <div class="form-group">
                      <label class="col-md-4 control-label">Due Time</label>
                      <div class="col-md-8">

					    {html_select_time prefix="job_due_" display_seconds=false use_24_hours=true minute_interval=15}
                      </div>
                  </div>
                   <div class="form-group">
                      <label class="col-md-4 control-label">Department</label>
                      <div class="col-md-8 col-xs-12">
	                          <select name="department_id" id="department_id" class="form-control">

						      {section name=departments loop=$departments}

						      <option value="{$departments[departments].department_id}" {if $smarty.post.department_id eq $departments[departments].department_id}selected{elseif $config.default_department_id eq $departments[departments].department_id}selected{/if}>{$departments[departments].department_name}</option>

						      {/section}

						    </select>
					 </div>
                  </div>


              </div>
          </div>

          <div class="row">
            <br /> <br />
            <h3>DELIVERY INFORMATION</h3>
             <div class="delivery col-md-12" style="padding-bottom:15px;">
              <div class="col-md-6">

                   <div class="form-group">
                      <label class="col-md-4 control-label">Contact Name</label>
                      <div class="col-md-8 col-xs-12" style="padding:0;">
                           <div class="col-xs-8">
                             <input name="job_delivery_name[]" id="job_delivery_name" type="text"  value="{$smarty.post.job_delivery_name[0]}" class="form-control"  />
                           </div>
                           <div class="col-xs-4" style="padding:0;">
                             <select name="job_delivery_name_select[]" id="job_delivery_name_select" onchange="fillContact(this)" class="form-control select_link">
					        	<option value="0">Select..</option>
					        	{section name=customer_list loop=$customer_list}
					        	<option value="{$customer_list[customer_list].customer_fname} {$customer_list[customer_list].customer_lname}"  data-address="{$customer_list[customer_list].customer_address}" data-phone="{$customer_list[customer_list].customer_phone} {if $customer_list[customer_list].customer_mobile}{if $customer_list[customer_list].customer_phone} | {/if}{$customer_list[customer_list].customer_mobile}{/if}">{$customer_list[customer_list].group_company} - {$customer_list[customer_list].customer_fname} {$customer_list[customer_list].customer_lname}</option>
						        {/section}
						     </select>
                           </div>


	                  </div>
                  </div>
                  <div class="form-group">
                      <label class="col-md-4 control-label">Address</label>
                      <div class="col-md-8 col-xs-12">

					    <input name="job_delivery_address[]" id="job_delivery_address" type="text"  value="{$smarty.post.job_delivery_address[0]}" class="form-control"  />

                      </div>
                  </div>



              </div>

              <div class="col-md-6">

                   <div class="form-group">
                      <label class="col-md-4 control-label">Phone No.</label>
                      <div class="col-md-8 col-xs-12">
                      <input name="job_delivery_phone[]" id="job_delivery_phone" type="text" value="{$smarty.post.job_delivery_phone[0]}" class="form-control" />
                      </div>
                  </div>


              </div>

            </div>

           <a href="#" class="copy" rel=".delivery"><span class="fa fa-plus text-info"></span> Add More Contacts</a>

           </div>

		   <div class="row">
            <br /> <br />
            <h3>ITEM DESCRIPTION / REMARKS</h3>
            <div class="col-md-6">
                   <div class="form-group">
                      <label class="col-md-4 control-label">Product Type <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
	                          <select name="product_id" id="product_id" style="width:185px;" onchange="toggle_2rows(this.value, $(this).find(':selected').attr('data-type')); checkOther(this.value, 8, 'job_ncr_div');" class="form-control">
						      <option value="0">Please Select</option>

						      {section name=product_types loop=$product_types}

						      <option value="{$product_types[product_types].product_id}" data-type = "{$product_types[product_types].product_type}" {if $smarty.post.product_id eq $product_types[product_types].product_id}selected{elseif $product_types[product_types].product_ref eq $quote_items[0].item_product}selected{/if}>{$product_types[product_types].product_name} ({$product_types[product_types].product_ref})</option>

						      {/section}

						    </select>
	                  </div>
                  </div>

              </div>

              <div class="col-md-6">

                    <div class="form-group">
                      <label class="col-md-4 control-label">Size <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
                        <select name="job_paper_size_open" id="job_paper_size_open" style="width:185px;" onchange="checkOther(this.value, 9, 'job_paper_size_open_other');" class="form-control">
					        <option value="0">Please Select</option>
					      {section name=paper_sizes_finished loop=$paper_sizes_finished}
					      <option value="{$paper_sizes_finished[paper_sizes_finished].size_id}" {if $smarty.post.job_paper_size_open eq $paper_sizes_finished[paper_sizes_finished].size_id}selected{elseif $paper_sizes_finished[paper_sizes_finished].paper_size eq $quote_items[0].item_paper_size}selected{/if}>{$paper_sizes_finished[paper_sizes_finished].paper_size}</option>
					      {/section}
					    </select>

					    <input name="job_paper_size_open_other" type="text" id="job_paper_size_open_other" value="{if $smarty.post.job_paper_size_open_other}{$smarty.post.job_paper_size_open_other}{else}{$quote_items[0].item_paper_size_other}{/if}" class="form-control"  {if $quote_items[0].item_paper_size eq 'Other' || $smarty.post.job_paper_size_open_other eq 'Other'}{else}style="display:none;"{/if}  /></td>


                      </div>
                  </div>



              </div>
             <div class="col-md-6 books-row" style="display:none;">
                 <br />

                   <div class="form-group">
                      <label class="col-md-4 control-label">No. of Pages <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
                      <input name="job_num_pages" type="number" id="job_num_pages" value="{if $smarty.post.job_num_pages}{$smarty.post.job_num_pages}{else}{$job_info[0].job_num_pages}{/if}" class="form-control" />
                      </div>
                  </div>

              </div>


         </div>
          <div class="row">
             <br /> <br />

              <div class="col-md-12">
                <div class="form-group">
                      <label class="col-md-2 control-label text-left">Description</label>
                      <div class="col-md-9">
                          <textarea name="job_description_remarks" id="job_description_remarks" class="form-control"  rows="5">{if $smarty.post.job_description_remarks}{$smarty.post.job_description_remarks}{else}{$quote_items[0].item_notes}{/if}</textarea>
                       </div>
                  </div>

              </div>


         </div>


             <br>
             {$quote_info[0].item_inner_color}

         <div class="row books-row" style="display:none;">


             <br /> <br />
             <h3>PRINTING (COVER PAPER)</h3>
              <div class="col-md-2">
                <div class="form-group">
                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input type="radio" class="iradio" name="cover_print_options" id="job_cover_digital" value="job_cover_digital" {if $smarty.post.cover_print_options eq 'job_cover_digital' || $quote_items[0].item_cover_color eq 'Digital Offset'} }checked{/if} />Digital</label>
                   <!-- <label class="check"><input name="job_cover_digital" type="checkbox" id="job_cover_digital" value="1" onclick="toggle_checked(this, 'job_cover_digital');" {if $smarty.post.job_digital eq '1'}checked{/if} /></label> -->
                   </div>
               </div>
              </div>
              <div class="col-md-2">
                 <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="job_cover_offset" value="job_cover_offset" {if $smarty.post.cover_print_options eq 'job_cover_offset' || $quote_items[0].item_cover_color eq 'Offset'}checked{/if} />Offset</label>
                   </div>
               </div>
              </div>
              <div class="col-md-3" style="padding:0;">
                <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="job_cover_wide_format" value="job_cover_wide_format" {if $smarty.post.cover_print_options eq 'job_cover_wide_format'}checked{/if} />Wide Format</label>
                   </div>
               </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="job_cover_promotional" value="job_cover_promotional" {if $smarty.post.cover_print_options eq 'job_cover_promotional'}checked{/if} />Promotional</label>
                   </div>
               </div>
              </div>
              <div class="col-md-3" style="padding:0;">
                <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="cover_print_options" type="radio" class="iradio"  id="job_cover_cnc" value="job_cover_cnc" {if $smarty.post.cover_print_options eq 'job_cover_cnc'}checked{/if} />Signage / CNC</label>
                   </div>
               </div>
              </div>

            <div class="col-md-12 job_cover_digital" style="margin-top:15px; {if $smarty.post.cover_print_options eq 'job_cover_digital' || $quote_items[0].item_cover_color eq 'Digital Offset'}{else}display:none;{/if}">
              <div class="col-md-6">
                <div class="form-group">
                      <label class="col-md-4 control-label">Paper Type</label>
                      <div class="col-md-8 col-xs-12">
	                          <select name="job_cover_digital_paper_type" id="job_cover_digital_paper_type" onchange="checkOther(this.value, 11, 'job_cover_digital_paper_type_other');" class="form-control">
							      <option value="0">Please Select</option>
							      {section name=paper_types loop=$paper_types}
							      <option value="{$paper_types[paper_types].paper_id}" {if $smarty.post.job_cover_digital_paper_type eq $paper_types[paper_types].paper_id}selected{/if}>{$paper_types[paper_types].paper_name}</option>
							      {/section}
							    </select> <input name="job_cover_digital_paper_type_other" type="text" id="job_cover_digital_paper_type_other" value="{if $smarty.post.job_cover_digital_paper_type_other}{$smarty.post.job_cover_digital_paper_type_other}{else}{$job_info[0].job_cover_digital_paper_type_other}{/if}" class="form-control" style="display:none;" />
					</div>
                  </div>
                   <div class="form-group">
                      <label class="col-md-4 control-label">Paper Weight</label>
                      <div class="col-md-8">

					    <select name="job_cover_digital_paper_weight" id="job_cover_digital_paper_weight" class="form-control">
					      <option value="0">Please Select</option>
					      {section name=paper_weights loop=$paper_weights}
					      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.job_cover_digital_paper_weight eq $paper_weights[paper_weights].weight_value}selected{elseif $paper_weights[paper_weights].weight_value eq $quote_items[0].item_cover_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
					      {/section}
					    </select>
					   </div>
                  </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                      <label class="col-md-4 control-label">No. A3+ Sheets <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					    <input name="job_cover_digital_num_sheets_fsize" type="text" id="job_cover_digital_num_sheets_fsize" value="{if $smarty.post.job_cover_digital_num_sheets_fsize}{$smarty.post.job_cover_digital_num_sheets_fsize}{elseif $job_info[0].job_cover_digital_num_sheets_fsize}{$job_info[0].job_cover_digital_num_sheets_fsize}{/if}" class="form-control" />
					 </div>
                  </div>
                  <div class="form-group">
                   <label class="col-md-4 control-label">Print Options</label>
                   <div class="col-md-8 col-xs-12">
                   <div class="col-md-6">
                       <label class="check"><input type="radio" class="iradio" name="job_cover_digital_print_options" id="job_cover_digital_print_options_2" value="Single" {if $smarty.post.job_cover_digital_print_options eq 'Single' || $quote_items[0].item_cover_print_options eq 'Single'}checked="checked"{/if} />Single Side</label>
                    </div>
                    <div class="col-md-6">
                       <label class="check"><input type="radio" class="iradio" name="job_cover_digital_print_options" id="job_cover_digital_print_options_3" value="Both" {if $smarty.post.job_cover_digital_print_options eq 'Both' || $quote_items[0].item_cover_print_options eq 'Both'}checked="checked"{/if} />Both Sides</label>
                    </div>
                   </div>
               </div>
              </div>
            </div>

            <div class="col-md-12 job_cover_offset" style="margin-top:15px; {if $smarty.post.cover_print_options eq 'job_cover_offset' || $quote_items[0].item_cover_color eq 'Offset'}{else}display:none;{/if}">
	            <div class="col-md-12 offset_cover_section" style="padding:0 0 15px;">
	                 <h5 class="master_label">Section 1</h5>
	                 <div class="col-md-6">
		                <div class="form-group">
		                      <label class="col-md-4 control-label">Paper Type</label>
		                      <div class="col-md-8 col-xs-12">
			                          <select name="job_cover_offset_paper_type[]" id="job_cover_offset_paper_type" onchange="toggleOther(this, 11, 'cover');" class="form-control">
									      <option value="0">Please Select</option>
									      {section name=paper_types loop=$paper_types}
									      <option value="{$paper_types[paper_types].paper_id}" {if $smarty.post.job_cover_offset_paper_type[0] eq $paper_types[paper_types].paper_id || $quote_items[0].item_cover_paper_type eq $paper_types[paper_types].paper_name}selected{/if}>{$paper_types[paper_types].paper_name}</option>
									      {/section}
									    </select> <input name="job_cover_offset_paper_type_other[]" type="text" id="job_cover_offset_paper_type_other" value="{if $smarty.post.job_cover_offset_paper_type_other[0]}{$smarty.post.job_cover_offset_paper_type_other[0]}{else}{$job_info[0].job_cover_offset_paper_type_other}{/if}" class="form-control" style="display:none;" />
							</div>
		                  </div>
		                <div class="form-group">
		                      <label class="col-md-4 control-label">Paper Weight</label>
		                      <div class="col-md-8">

							    <select name="job_cover_offset_paper_weight[]" id="job_cover_offset_paper_weight" class="form-control">
							      <option value="0">Please Select</option>
							      {section name=paper_weights loop=$paper_weights}
							      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.job_cover_offset_paper_weight eq $paper_weights[paper_weights].weight_value}selected{elseif $paper_weights[paper_weights].weight_value eq $quote_items[0].item_cover_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
							      {/section}
							    </select>
							   </div>
		                  </div>


		                <div class="form-group">
		                      <label class="col-md-4 control-label">Pre Press</label>
		                      <div class="col-md-8 col-xs-12">
		                          <select name="job_cover_offset_pre_press[]" id="job_cover_offset_pre_press" onchange="calc_total_plates(this, 'cover');" class="form-control">
								      <option value="0">Please Select</option>
								      <option value="Work/Turn" {if $smarty.post.job_cover_offset_pre_press[0] eq 'Work/Turn' || $job_info[0].job_cover_offset_pre_press eq 'Work/Turn'}selected{/if}>Work/Turn</option>
								      <option value="Work/Tumble" {if $smarty.post.job_cover_offset_pre_press[0] eq 'Work/Tumble' || $job_info[0].job_cover_offset_pre_press eq 'Work/Tumble'}selected{/if}>Work/Tumble</option>
								      <option value="Front/Back" {if $smarty.post.job_cover_offset_pre_press[0] eq 'Front/Back' || $job_info[0].job_cover_offset_pre_press eq 'Front/Back'}selected{/if}>Front/Back</option>
								      <option value="One Side" {if $smarty.post.job_cover_offset_pre_press[0] eq 'One Side' || $job_info[0].job_cover_offset_pre_press eq 'One Side'}selected{/if}>One Side</option>
							      </select>
			                  </div>
		                  </div>

		               <div class="form-group">
		                   <label class="col-md-4 control-label">No of Colours</label>
		                   <div class="col-md-8 col-xs-12">
		                   <input name="job_cover_offset_no_of_colors[]" type="text" id="job_cover_offset_no_of_colors" onblur="calc_total_plates(this, 'cover');" value="{if $smarty.post.job_cover_offset_no_of_colors[0]}{$smarty.post.job_cover_offset_no_of_colors[0]}{elseif $job_info[0].job_cover_offset_no_of_colors}{$job_info[0].job_cover_offset_no_of_colors}{/if}" class="form-control" />
		                   </div>
		               </div>
		               <div class="form-group">
		                     <label class="col-md-4 control-label">No of Sheets </label>
		                     <div class="col-md-8">
						     <input name="job_cover_offset_num_sheets[]" type="text" id="job_cover_offset_num_sheets" value="{$smarty.post.job_cover_num_sheets[0]}" class="form-control" />
						 </div>
		                 </div>
		            </div>

		            <div class="col-md-6">
		               <div class="form-group">
		                   <label class="col-md-4 control-label">Impressions </label>
		                   <div class="col-md-8 col-xs-12">
		                   <input name="job_cover_offset_impressions[]" type="number" id="job_cover_offset_impressions" value="{if $smarty.post.job_cover_offset_impressions[0]}{$smarty.post.job_cover_offset_impressions[0]}{/if}"  class="form-control" onblur="calc_num_of_sheets(this, 'cover');" />
		                   </div>
		               </div>
		               <div class="form-group">
		                   <label class="col-md-4 control-label">Machine <span class="asterisk">*</span></label>
		                   <div class="col-md-8 col-xs-12">
			                   <select name="job_cover_offset_machine[]" id="job_cover_offset_machine" class="form-control">
							        <option value="0">Please Select</option>
							      {section name=job_printers loop=$job_printers}
							      <option value="{$job_printers[job_printers].printer_name}" {if $job_printers[job_printers].printer_name[0] eq '$smarty.post.job_cover_offset_machine' || $job_info[0].job_cover_offset_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
							      {/section}
							    </select>
		                   </div>
		               </div>

		               <div class="form-group">
		                      <label class="col-md-4 control-label">Plate Size</label>
		                      <div class="col-md-8 col-xs-12">
		                          <select name="job_cover_offset_plate_size[]"  class="form-control">
								      <option value="0">Please Select</option>
								      <option value="SM74" {if $smarty.post.job_cover_offset_plate_size[0] eq 'SM74' || $job_info[0].job_cover_plate_size eq 'SM74'}selected{/if}>SM74</option>
								      <option value="Sm52" {if $smarty.post.job_cover_offset_plate_size[0] eq 'Sm52' || $job_info[0].job_cover_plate_size eq 'Sm52'}selected{/if}>Sm52</option>
								      <option value="GTO46" {if $smarty.post.job_cover_offset_plate_size[0] eq 'GTO46' || $job_info[0].job_cover_plate_size eq 'GTO46'}selected{/if}>GTO46</option>
							      </select>
			                  </div>
		                  </div>

		               <div class="form-group">
		                   <label class="col-md-4 control-label">Total Plates</label>
		                   <div class="col-md-8 col-xs-12">
		                   <input name="job_cover_offset_total_plates[]" type="text" id="job_cover_offset_total_plates" value="{if $smarty.post.job_cover_offset_total_plates[0]}{$smarty.post.job_cover_offset_total_plates[0]}{elseif $job_info[0].job_cover_total_plates}{$job_info[0].job_cover_total_plates}{/if}" class="form-control" readonly/>
		                   </div>
		               </div>
		               <div class="form-group">
		                      <label class="col-md-4 control-label">Press Sheet Size<span class="asterisk">*</span></label>

		                      <div class="col-md-8">
		                         <select name="job_cover_offset_sheet_size[]" id="job_cover_offset_sheet_size" onchange="calc_num_of_sheets(this, 'cover');" class="form-control" style="margin-bottom:5px;">
								      <option value="A1" {if $smarty.post.job_cover_offset_sheet_size[0] eq 'A1' || $job_info[0].job_cover_offset_sheet_size eq 'A1'}selected{/if} selected>A1</option>
								      <option value="A2" {if $smarty.post.job_cover_offset_sheet_size[0] eq 'A2' || $job_info[0].job_cover_offset_sheet_size eq 'A2'}selected{/if}>A2</option>
								      <option value="A3" {if $smarty.post.job_cover_offset_sheet_size[0] eq 'A3' || $job_info[0].job_cover_offset_sheet_size eq 'A3'}selected{/if}>A3</option>
								      <option value="A4" {if $smarty.post.job_cover_offset_sheet_size[0] eq 'A4' || $job_info[0].job_cover_offset_sheet_size eq 'A4'}selected{/if}>A4</option>
								      <option value="Other" {if $smarty.post.job_cover_offset_sheet_size[0] eq 'Other' || $job_info[0].job_cover_offset_sheet_size_other}selected{/if}>Other</option>
							    </select>
							    <span id="cover_sheet_size_other" style="display:none;">
							      <input type="text" name="job_cover_offset_sheet_w[]" class="form-control" placeholder="Width" value="{if $smarty.post.job_cover_offset_sheet_w[0]}{$smarty.post.job_cover_offset_sheet_w[0]}{elseif $job_info[0].job_cover_cut_size_w}{$job_info[0].job_cover_cut_size_w}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;" > x
		                          <input type="text" name="job_cover_offset_sheet_h[]" class="form-control" placeholder="Height" value="{if $smarty.post.job_cover_offset_sheet_h[0]}{$smarty.post.job_cover_offset_sheet_h[0]}{elseif $job_info[0].job_cover_cut_size_h}{$job_info[0].job_cover_cut_size_h}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;">

							    </span>

							 </div>
		                  </div>


		            </div>

	            </div>
                <a href="#" class="offset_copy" rel=".offset_cover_section" style="diplay:block; float:left; margin-right:10px;" ><span class="fa fa-plus text-info"></span> Add More Sections</a>

                <a href="#" class="offset_duplicate" rel=".offset_cover_section" style="diplay:block; float:left; padding-left:10px; border-left:1px solid #ccc;"><span class="fa fa-plus-square text-info"></span> Duplicate First Section</a>


         </div>

         <div class="col-md-12 job_cover_wide_format" style="margin-top:15px; {if $smarty.post.cover_print_options eq 'job_cover_wide_format' || $job_info[0].job_cover_wide_format eq 'Y'}{else}display:none;{/if}">
	         <div class="col-md-6">
	               <div class="form-group">
	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
		                   <select name="job_cover_wide_format_material" id="job_cover_wide_format_material" class="form-control">
						        <option value="0">Please Select</option>
						      {section name=materials loop=$materials}
						      <option value="{$materials[materials].material_name}" {if $materials[materials].material_name eq '$smarty.post.job_cover_wide_format_material' || $job_info[0].job_cover_material eq $materials[materials].material_name}selected{/if}>{$materials[materials].material_name}</option>
						      {/section}
						    </select>
	                   </div>
	               </div>
	                <div class="form-group">
                      <label class="col-md-4 control-label">Size</label>
                      <div class="col-md-8">

					      <input type="text" id="job_cover_wide_format_w" name="job_cover_wide_format_w" class="form-control" placeholder="Width(m)" value="{if $smarty.post.job_cover_wide_format_w}{$smarty.post.job_cover_wide_format_w}{elseif $job_info[0].job_cover_cut_size_w}{$job_info[0].job_cover_cut_size_w}{/if}" onblur="calc_wide_format_sq_m('cover')" style="width:100px; display: inline-block; padding: 6px 8px;" > x
                          <input type="text" id="job_cover_wide_format_h" name="job_cover_wide_format_h" class="form-control" placeholder="Height(m)" value="{if $smarty.post.job_cover_wide_format_h}{$smarty.post.job_cover_wide_format_h}{elseif $job_info[0].job_cover_cut_size_h}{$job_info[0].job_cover_cut_size_h}{/if}" onblur="calc_wide_format_sq_m('cover')" style="width:100px; display: inline-block; padding: 6px 8px;">

					 </div>
                  </div>


	         </div>

	         <div class="col-md-6">
	          <div class="form-group">
	                   <label class="col-md-4 control-label">Machine <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
		                   <select name="job_cover_wide_format_machine" id="job_cover_wide_format_machine" class="form-control">
						        <option value="0">Please Select</option>
						      {section name=job_printers loop=$job_printers}
						      <option value="{$job_printers[job_printers].printer_name}" {if $job_printers[job_printers].printer_name eq '$smarty.post.job_cover_wide_format_machine' || $job_info[0].job_cover_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
						      {/section}
						    </select>
	                   </div>
	               </div>
	                <div class="form-group">
	                   <label class="col-md-4 control-label">Total Sq Meter</label>
	                   <div class="col-md-8 col-xs-12">
	                   <input id="job_cover_wide_format_total_sq_meter" name="job_cover_wide_format_total_sq_meter" type="text" id="job_cover_wide_format_total_sq_meter" value="{if $smarty.post.job_cover_wide_format_total_sq_meter}{$smarty.post.job_cover_wide_format_total_sq_meter }{elseif $job_info[0].job_cover_total_sq_meter }{$job_info[0].job_cover_total_sq_meter }{/if}" class="form-control" readonly />
	                   </div>
	               </div>
	         </div>
	          <div class="col-md-12">
	          <br>

                <div class="form-group">
                      <label class="col-md-2 control-label text-right">Notes</label>
                      <div class="col-md-9">
                          <textarea name="job_cover_wide_format_notes"  class="form-control">{if $smarty.post.job_cover_wide_format_notes}{$smarty.post.job_cover_wide_format_notes}{else}{$job_info[0].job_cover_notes}{/if}</textarea>
                       </div>
                  </div>

	         </div>


         </div>


          <div class="col-md-12 job_cover_promotional" style="margin-top:15px; {if $smarty.post.cover_print_options neq 'job_cover_promotional'}display:none;{/if}">
	         <div class="col-md-6">
	               <div class="form-group">
	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
	                    <input name="job_cover_promotional_material" type="text" id="job_cover_promotional_material" value="{if $smarty.post.job_cover_promotional_material}{$smarty.post.job_cover_promotional_material}{elseif $job_info[0].job_cover_material}{$job_info[0].job_cover_material}{/if}" placeholder="TShirt, Bag, Caps,.." class="form-control" />
	                   </div>
	               </div>
	         </div>

	         <div class="col-md-6">
	          <div class="form-group">
                   <label class="col-md-4 control-label">Quantity</label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_cover_promotional_quantity" type="number" id="job_cover_promotional_quantity" value="{if $smarty.post.job_cover_promotional_quantity}{$smarty.post.job_cover_promotional_quantity}{elseif $job_info[0].job_cover_quantity}{$job_info[0].job_cover_quantity}{/if}" class="form-control" />
                   </div>
               </div>
	         </div>
	         <div class="col-md-12" style="margin-top:10px;">
	           <div class="col-md-2">
	           &nbsp;
	           </div>
	           <div class="col-md-3">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_promotional_screen_printing" id="job_cover_promotional_screen_printing" value="Y" {if $smarty.post.job_cover_promotional_screen_printing || $job_info[0].job_cover_screen_printing eq 'Y'}checked{/if} />Screen Printing</label>
                   <div class="col-md-12 job_cover_promotional_screen_printing" style="padding:0; {if $smarty.post.job_cover_promotional_screen_printing neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_cover_screen_printing_notes"  class="form-control"></textarea>
                   </div>

               </div>
               <div class="col-md-3">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_promotional_embroidery" id="job_cover_promotional_embroidery" value="Y" {if $smarty.post.job_cover_promotional_embroidery || $job_info[0].job_cover_embroidery eq 'Y'}checked{/if} />Embroidery</label>

                    <div class="col-md-12 job_cover_promotional_embroidery" style="padding:0; {if $smarty.post.job_cover_promotional_embroidery neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_embroidery_notes"  class="form-control"></textarea>
                    </div>

               </div>
               <div class="col-md-3">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_promotional_heat_transfer" id="job_cover_promotional_heat_transfer" value="Y" {if $smarty.post.job_cover_promotional_heat_transfer || $job_info[0].job_cover_heat_transfer eq 'Y'}checked{/if} />Heat Transfer</label>
                   <div class="col-md-12 job_cover_promotional_heat_transfer" style="padding:0; {if $smarty.post.job_cover_promotional_heat_transfer neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_heat_transfer_notes"  class="form-control"></textarea>
                   </div>


               </div>

	         </div>


         </div>

         <div class="col-md-12 job_cover_cnc" style="margin-top:15px; {if $smarty.post.cover_print_options neq 'job_cover_cnc'}display:none;{/if}">

	          <div class="col-md-6">
	            <div class="form-group">
                      <label class="col-md-4 control-label">Type <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
	                             <select name="job_cover_cnc_type" id="job_cover_cnc_type" onchange="checkOther(this.value, 'Other', 'job_cover_cnc_type_other');" class="form-control" required>
							      <option value="0">Please Select</option>
							      <option value="Lightbox" {if $smarty.post.job_cover_cnc_type eq 'Lightbox' || $job_info[0].job_cover_paper_type eq 'Lightbox'}selected{/if}>Lightbox</option>
							      <option value="Cut-out" {if $smarty.post.job_cover_cnc_type eq 'Cut-out' || $job_info[0].job_cover_paper_type eq 'Cut-out'}selected{/if}>Cut-out</option>
							      <option value="Pylon" {if $smarty.post.job_cover_cnc_type eq 'Pylon' || $job_info[0].job_cover_paper_type eq 'Pylon'}selected{/if}>Pylon</option>
							      <option value="Other" {if $smarty.post.job_cover_cnc_type eq 'Other' || $job_info[0].job_cover_paper_type eq 'Other'}selected{/if}>Other</option>

							    </select>
							    <input name="job_cover_cnc_type_other" type="text" id="job_cover_cnc_type_other" value="{if $smarty.post.job_cover_cnc_type_other}{$smarty.post.job_cover_cnc_type_other}{elseif $job_info[0].job_cover_paper_type_other}{$job_info[0].job_cover_paper_type_other}{/if}" class="form-control" style="display:none; margin-top:10px;" />
					</div>

                  </div>
	         </div>
	         <div class="col-md-6">
	               <div class="form-group">
	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
	                    <input name="job_cover_cnc_material" type="text" id="job_cover_cnc_material" value="{if $smarty.post.job_cover_cnc_material}{$smarty.post.job_cover_cnc_material }{elseif $job_info[0].job_cover_material }{$job_info[0].job_cover_material}{/if}" class="form-control" />
	                   </div>
	               </div>
	         </div>

	         <div class="col-md-6" style="margin-top:10px;">
	          <div class="form-group">
                   <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_cover_cnc_quantity" type="number" id="job_cover_cnc_quantity" value="{if $smarty.post.job_cover_cnc_quantity}{$smarty.post.job_cover_cnc_quantity}{elseif $job_info[0].job_cover_quantity }{$job_info[0].job_cover_quantity}{/if}" class="form-control"/>
                   </div>
               </div>
	         </div>
	         <div class="col-md-12" style="margin-top:10px;">

	           <label class="col-md-2 control-label">Processes</label>

	           <div class="col-md-10">

	             <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_fabrication" id="job_cover_cnc_fabrication" value="Y" {if $smarty.post.job_cover_cnc_fabrication || $job_info[0].job_cover_fabrication eq 'Y'}checked{/if} />Fabrication</label>
                   <div class="col-md-12 job_cover_cnc_fabrication" style="padding:0; {if $smarty.post.job_cover_cnc_fabrication neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_cover_fabrication_notes"  class="form-control"></textarea>
                   </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_cnc_cutting" id="job_cover_cnc_cnc_cutting" value="Y" {if $smarty.post.job_cover_cnc_cnc_cutting || $job_info[0].job_cover_cnc_cnc_cutting eq 'Y'}checked{/if} />CNC Cutting</label>

                    <div class="col-md-12 job_cover_cnc_cnc_cutting" style="padding:0; {if $smarty.post.job_cover_cnc_cutting neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_cnc_cutting_notes"  class="form-control"></textarea>
                    </div>

               </div>

                <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_spraying" id="job_cover_cnc_spraying" value="Y" {if $smarty.post.job_cover_cnc_spraying || $job_info[0].job_cover_spraying eq 'Y'}checked{/if} />Spraying</label>
                   <div class="col-md-12 job_cover_cnc_spraying" style="padding:0; {if $smarty.post.job_cover_cnc_spraying neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_cover_spraying_notes"  class="form-control"></textarea>
                   </div>

               </div>

               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_cutting" id="job_cover_cnc_cutting" value="Y" {if $smarty.post.job_cover_cnc_cutting || $job_info[0].job_cover_cutting eq 'Y'}checked{/if} />Cutting</label>
                   <div class="col-md-12 job_cover_cnc_cutting" style="padding:0; {if $smarty.post.job_cover_cnc_cutting neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_cutting_notes"  class="form-control"></textarea>
                   </div>


               </div>

               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_bending" id="job_cover_cnc_bending" value="Y" {if $smarty.post.job_cover_cnc_bending || $job_info[0].job_cover_bending eq 'Y'}checked{/if} />Bending</label>

                    <div class="col-md-12 job_cover_cnc_bending" style="padding:0; {if $smarty.post.job_cover_cnc_bending neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_bending_notes"  class="form-control"></textarea>
                    </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_led" id="job_cover_cnc_led" value="Y" {if $smarty.post.job_cover_cnc_led || $job_info[0].job_cover_led eq 'Y'}checked{/if} />Lighting Attachment (LED)</label>
                   <div class="col-md-12 job_cover_cnc_led" style="padding:0; {if $smarty.post.job_cover_cnc_led neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_led_notes"  class="form-control"></textarea>
                   </div>


               </div>
                <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_lighting" id="job_cover_cnc_lighting" value="Y" {if $smarty.post.job_cover_cnc_lighting || $job_info[0].job_cover_lighting eq 'Y'}checked{/if} />Lighting (tube lights)</label>
                   <div class="col-md-12 job_cover_cnc_lighting" style="padding:0; {if $smarty.post.job_cover_cnc_lighting neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_cover_lighting_notes"  class="form-control"></textarea>
                   </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_rivetting" id="job_cover_cnc_rivetting" value="Y" {if $smarty.post.job_cover_cnc_rivetting || $job_info[0].job_cover_rivetting eq 'Y'}checked{/if} />Rivetting</label>

                    <div class="col-md-12 job_cover_cnc_rivetting" style="padding:0; {if $smarty.post.job_cover_cnc_rivetting neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_rivetting_notes"  class="form-control"></textarea>
                    </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_cover_cnc_site_installation" id="job_cover_cnc_site_installation" value="Y" {if $smarty.post.job_cover_cnc_site_installation || $job_info[0].job_cover_site_installation eq 'Y'}checked{/if} />Site installation</label>
                   <div class="col-md-12 job_cover_cnc_site_installation" style="padding:0; {if $smarty.post.job_cover_cnc_site_installation neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_cover_site_installation_notes"  class="form-control"></textarea>
                   </div>


               </div>


	           </div>


	         </div>


         </div>


         </div>

         <div class="row">

            <br />

            <br />
            <h3>PRINTING <span class="offset_label" style="display:none;">(INNER  PAPER)</span><span class="specifications_label">(SPECIFICATIONS)</span></h3>

            <div class="col-md-2">
                <div class="form-group">
                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input type="radio" class="iradio" name="inner_print_options" id="job_inner_digital" value="job_inner_digital" {if $smarty.post.inner_print_options eq 'job_inner_digital' || $quote_items[0].item_inner_color eq 'Digital Offset'}checked{/if} />Digital</label>
                   <!-- <label class="check"><input name="job_inner_digital" type="checkbox" id="job_inner_digital" value="1" onclick="toggle_checked(this, 'job_inner_digital');" {if $smarty.post.job_digital eq '1'}checked{/if} /></label> -->
                   </div>
               </div>
              </div>
              <div class="col-md-2">
                 <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="job_inner_offset" value="job_inner_offset" {if $smarty.post.inner_print_options eq 'job_inner_offset' || $quote_items[0].item_cover_color eq 'Offset'}checked{/if} />Offset</label>
                   </div>
               </div>
              </div>
              <div class="col-md-3" style="padding:0;">
                <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="job_inner_wide_format" value="job_inner_wide_format" {if $smarty.post.inner_print_options eq 'job_inner_wide_format'}checked{/if} />Wide Format</label>
                   </div>
               </div>
              </div>
              <div class="col-md-2">
                <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="job_inner_promotional" value="job_inner_promotional" {if $smarty.post.inner_print_options eq 'job_inner_promotional'}checked{/if} />Promotional</label>
                   </div>
               </div>
              </div>
              <div class="col-md-3" style="padding:0;">
                <div class="form-group">

                   <div class="col-md-12 col-xs-12">
                   <label class="check"><input name="inner_print_options" type="radio" class="iradio"  id="job_inner_cnc" value="job_inner_cnc" {if $smarty.post.inner_print_options eq 'job_inner_cnc'}checked{/if} />Signage / CNC</label>
                   </div>
               </div>
              </div>

              <div class="col-md-12 job_inner_digital" style="margin-top:15px; {if $smarty.post.inner_print_options eq 'job_inner_digital' || $quote_items[0].item_inner_color eq 'Digital Offset'}{else}display:none;{/if}">
              <div class="col-md-6">

                <div class="form-group">
                      <label class="col-md-4 control-label">Paper Type</label>
                      <div class="col-md-8 col-xs-12">
	                          <select name="job_inner_digital_paper_type" id="job_inner_digital_paper_type"  onchange="checkOther(this.value, 11, 'job_inner_digital_paper_type_other');" class="form-control">
						      <option value="0">Please Select</option>
						      {section name=paper_types loop=$paper_types}
						      <option value="{$paper_types[paper_types].paper_id}" {if $smarty.post.job_inner_digital_paper_type eq $paper_types[paper_types].paper_id}selected{elseif $paper_types[paper_types].paper_name eq $quote_items[0].item_inner_paper_type}selected{/if}>{$paper_types[paper_types].paper_name}</option>
						      {/section}
						    </select> <input name="job_inner_digital_paper_type" type="text" id="job_inner_digital_paper_type_other" value="{if $smarty.post.job_inner_digital_paper_type_other}{$smarty.post.job_inner_digital_paper_type_other}{/if}" class="form-control" style="display:none;"  /></td>

	                  </div>
                  </div>
                  <div class="form-group">
                      <label class="col-md-4 control-label">Paper Weight</label>
                      <div class="col-md-8">

					    <select name="job_inner_digital_paper_weight" id="job_inner_digital_paper_weight" class="form-control">
					      <option value="0">Please Select</option>
					      {section name=paper_weights loop=$paper_weights}
					      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.job_inner_digital_paper_weight eq $paper_weights[paper_weights].weight_value}selected{elseif $paper_weights[paper_weights].weight_value eq $quote_items[0].item_inner_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
					      {/section}
					    </select>
					   </div>
                  </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                      <label class="col-md-4 control-label">No. A3+ Sheets <span class="asterisk">*</span></label>
                      <div class="col-md-8">

					    <input name="job_inner_digital_num_sheets_fsize" type="number" id="job_inner_digital_num_sheets_fsize" value="{$smarty.post.job_inner_digital_num_sheets_fsize}" class="form-control" />
					 </div>
                  </div>
                  <div class="form-group">
                   <label class="col-md-4 control-label">Print Options</label>
                   <div class="col-md-8 col-xs-12">
                   <div class="col-md-6">
                       <label class="check"><input type="radio" class="iradio" name="job_inner_digital_print_options" id="job_inner_digital_print_options_2" value="Single" {if $smarty.post.job_inner_digital_print_options eq 'Single' || $quote_items[0].item_inner_print_options eq 'Single'}checked="checked"{/if} />Single Side</label>
                    </div>
                    <div class="col-md-6">
                       <label class="check"><input type="radio" class="iradio" name="job_inner_digital_print_options" id="job_inner_digital_print_options_3" value="Both" {if $smarty.post.job_inner_digital_print_options eq 'Both' || $quote_items[0].item_inner_print_options eq 'Both'}checked="checked"{/if} />Both Sides</label>
                    </div>
                   </div>
               </div>
              </div>
            </div>
            <div class="col-md-12 job_inner_offset" style="margin-top:15px; {if $smarty.post.inner_print_options eq 'job_inner_offset' || $quote_items[0].item_inner_color eq 'Offset'}{else}display:none;{/if}">
	             <div class="col-md-12 offset_inner_section" style="padding:0 0 15px;">
	                 <h5 class="master_label">Section 1</h5>
	                 <div class="col-md-6">
		                <div class="form-group">
		                      <label class="col-md-4 control-label">Paper Type</label>
		                      <div class="col-md-8 col-xs-12">
			                          <select name="job_inner_offset_paper_type[]" id="job_inner_offset_paper_type" onchange="toggleOther(this, 11, 'inner');" class="form-control">
									      <option value="0">Please Select</option>
									      {section name=paper_types loop=$paper_types}
									      <option value="{$paper_types[paper_types].paper_id}" {if $smarty.post.job_inner_offset_paper_type[0] eq $paper_types[paper_types].paper_id || $quote_items[0].item_inner_paper_type eq $paper_types[paper_types].paper_name}selected{/if}>{$paper_types[paper_types].paper_name}</option>
									      {/section}
									    </select> <input name="job_inner_offset_paper_type_other[]" type="text" id="job_inner_offset_paper_type_other" value="{if $smarty.post.job_inner_offset_paper_type_other[0]}{$smarty.post.job_inner_offset_paper_type_other[0]}{else}{$job_info[0].job_inner_offset_paper_type_other}{/if}" class="form-control" style="display:none;" />
							</div>
		                  </div>
		                   <div class="form-group">
		                      <label class="col-md-4 control-label">Paper Weight</label>
		                      <div class="col-md-8">

							    <select name="job_inner_offset_paper_weight[]" id="job_inner_offset_paper_weight" class="form-control">
							      <option value="0">Please Select</option>
							      {section name=paper_weights loop=$paper_weights}
							      <option value="{$paper_weights[paper_weights].weight_value}" {if $smarty.post.job_inner_offset_paper_weight eq $paper_weights[paper_weights].weight_value}selected{elseif $paper_weights[paper_weights].weight_value eq $quote_items[0].item_inner_paper_weight}selected{/if}>{$paper_weights[paper_weights].weight_value} gsm</option>
							      {/section}
							    </select>
							   </div>
		                  </div>


		                <div class="form-group">
		                      <label class="col-md-4 control-label">Pre Press</label>
		                      <div class="col-md-8 col-xs-12">
		                          <select name="job_inner_offset_pre_press[]" id="job_inner_offset_pre_press" onchange="calc_total_plates(this, 'inner');" class="form-control">
								      <option value="0">Please Select</option>
								      <option value="Work/Turn" {if $smarty.post.job_inner_offset_pre_press[0] eq 'Work/Turn' || $job_info[0].job_inner_offset_pre_press eq 'Work/Turn'}selected{/if}>Work/Turn</option>
								      <option value="Work/Tumble" {if $smarty.post.job_inner_offset_pre_press[0] eq 'Work/Tumble' || $job_info[0].job_inner_offset_pre_press eq 'Work/Tumble'}selected{/if}>Work/Tumble</option>
								      <option value="Front/Back" {if $smarty.post.job_inner_offset_pre_press[0] eq 'Front/Back' || $job_info[0].job_inner_offset_pre_press eq 'Front/Back'}selected{/if}>Front/Back</option>
								      <option value="One Side" {if $smarty.post.job_inner_offset_pre_press[0] eq 'One Side' || $job_info[0].job_inner_offset_pre_press eq 'One Side'}selected{/if}>One Side</option>
							      </select>
			                  </div>
		                  </div>

		               <div class="form-group">
		                   <label class="col-md-4 control-label">No of Colours</label>
		                   <div class="col-md-8 col-xs-12">
		                   <input name="job_inner_offset_no_of_colors[]" type="text" id="job_inner_offset_no_of_colors" onblur="calc_total_plates(this, 'inner');" value="{if $smarty.post.job_inner_offset_no_of_colors[0]}{$smarty.post.job_inner_offset_no_of_colors[0]}{elseif $job_info[0].job_inner_offset_no_of_colors}{$job_info[0].job_inner_offset_no_of_colors}{/if}" class="form-control" />
		                   </div>
		               </div>
		               <div class="form-group">
		                     <label class="col-md-4 control-label">No of Sheets </label>
		                     <div class="col-md-8">
						     <input name="job_inner_offset_num_sheets[]" type="text" id="job_inner_offset_num_sheets" value="{$smarty.post.job_inner_num_sheets[0]}" class="form-control" />
						 </div>
		                 </div>
		            </div>

		            <div class="col-md-6">
		               <div class="form-group">
		                   <label class="col-md-4 control-label">Impressions </label>
		                   <div class="col-md-8 col-xs-12">
		                   <input name="job_inner_offset_impressions[]" type="number" id="job_inner_offset_impressions" value="{if $smarty.post.job_inner_offset_impressions[0]}{$smarty.post.job_inner_offset_impressions[0]}{/if}"  class="form-control" onblur="calc_num_of_sheets(this, 'inner');" />
		                   </div>
		               </div>
		               <div class="form-group">
		                   <label class="col-md-4 control-label">Machine <span class="asterisk">*</span></label>
		                   <div class="col-md-8 col-xs-12">
			                   <select name="job_inner_offset_machine[]" id="job_inner_offset_machine" class="form-control">
							        <option value="0">Please Select</option>
							      {section name=job_printers loop=$job_printers}
							      <option value="{$job_printers[job_printers].printer_name}" {if $job_printers[job_printers].printer_name[0] eq '$smarty.post.job_inner_offset_machine' || $job_info[0].job_inner_offset_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
							      {/section}
							    </select>
		                   </div>
		               </div>

		               <div class="form-group">
		                      <label class="col-md-4 control-label">Plate Size</label>
		                      <div class="col-md-8 col-xs-12">
		                          <select name="job_inner_offset_plate_size[]"  class="form-control">
								      <option value="0">Please Select</option>
								      <option value="SM74" {if $smarty.post.job_inner_offset_plate_size[0] eq 'SM74' || $job_info[0].job_inner_plate_size eq 'SM74'}selected{/if}>SM74</option>
								      <option value="Sm52" {if $smarty.post.job_inner_offset_plate_size[0] eq 'Sm52' || $job_info[0].job_inner_plate_size eq 'Sm52'}selected{/if}>Sm52</option>
								      <option value="GTO46" {if $smarty.post.job_inner_offset_plate_size[0] eq 'GTO46' || $job_info[0].job_inner_plate_size eq 'GTO46'}selected{/if}>GTO46</option>
							      </select>
			                  </div>
		                  </div>

		               <div class="form-group">
		                   <label class="col-md-4 control-label">Total Plates</label>
		                   <div class="col-md-8 col-xs-12">
		                   <input name="job_inner_offset_total_plates[]" type="text" id="job_inner_offset_total_plates" value="{if $smarty.post.job_inner_offset_total_plates[0]}{$smarty.post.job_inner_offset_total_plates[0]}{elseif $job_info[0].job_inner_total_plates}{$job_info[0].job_inner_total_plates}{/if}" class="form-control" readonly/>
		                   </div>
		               </div>
		               <div class="form-group">
		                      <label class="col-md-4 control-label">Press Sheet Size<span class="asterisk">*</span></label>

		                      <div class="col-md-8">
		                         <select name="job_inner_offset_sheet_size[]" id="job_inner_offset_sheet_size" onchange="calc_num_of_sheets(this, 'inner');" class="form-control" style="margin-bottom:5px;">
								      <option value="A1" {if $smarty.post.job_inner_offset_sheet_size[0] eq 'A1' || $job_info[0].job_inner_offset_sheet_size eq 'A1'}selected{/if} selected>A1</option>
								      <option value="A2" {if $smarty.post.job_inner_offset_sheet_size[0] eq 'A2' || $job_info[0].job_inner_offset_sheet_size eq 'A2'}selected{/if}>A2</option>
								      <option value="A3" {if $smarty.post.job_inner_offset_sheet_size[0] eq 'A3' || $job_info[0].job_inner_offset_sheet_size eq 'A3'}selected{/if}>A3</option>
								      <option value="A4" {if $smarty.post.job_inner_offset_sheet_size[0] eq 'A4' || $job_info[0].job_inner_offset_sheet_size eq 'A4'}selected{/if}>A4</option>
								      <option value="Other" {if $smarty.post.job_inner_offset_sheet_size[0] eq 'Other' || $job_info[0].job_inner_offset_sheet_size_other}selected{/if}>Other</option>
							    </select>
							    <span id="inner_sheet_size_other" style="display:none;">
							      <input type="text" name="job_inner_offset_sheet_w[]" class="form-control" placeholder="Width" value="{if $smarty.post.job_inner_offset_sheet_w[0]}{$smarty.post.job_inner_offset_sheet_w[0]}{elseif $job_info[0].job_inner_cut_size_w}{$job_info[0].job_inner_cut_size_w}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;" > x
		                          <input type="text" name="job_inner_offset_sheet_h[]" class="form-control" placeholder="Height" value="{if $smarty.post.job_inner_offset_sheet_h[0]}{$smarty.post.job_inner_offset_sheet_h[0]}{elseif $job_info[0].job_inner_cut_size_h}{$job_info[0].job_inner_cut_size_h}{/if}" style="width:60px; display: inline-block; padding: 6px 8px;">

							    </span>

							 </div>
		                  </div>


		            </div>

	            </div>
                 <a href="#" class="offset_copy" rel=".offset_inner_section" style="diplay:block; float:left; margin-right:10px;" ><span class="fa fa-plus text-info"></span> Add More Sections</a>

                <a href="#" class="offset_duplicate" rel=".offset_inner_section" style="diplay:block; float:left; padding-left:10px; border-left:1px solid #ccc;"><span class="fa fa-plus-square text-info"></span> Duplicate Fisrt Section</a>

         </div>

         <div class="col-md-12 job_inner_wide_format" style="margin-top:15px; {if $smarty.post.inner_print_options eq 'job_inner_wide_format' || $job_info[0].job_inner_wide_format eq 'Y'}{else}display:none;{/if}">
	         <div class="col-md-6">
	               <div class="form-group">
	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
		                   <select name="job_inner_wide_format_material" id="job_inner_wide_format_material" class="form-control">
						        <option value="0">Please Select</option>
						      {section name=materials loop=$materials}
						      <option value="{$materials[materials].material_name}" {if $materials[materials].material_name eq '$smarty.post.job_inner_wide_format_material' || $job_info[0].job_inner_material eq $materials[materials].material_name}selected{/if}>{$materials[materials].material_name}</option>
						      {/section}
						    </select>
	                   </div>
	               </div>
	                <div class="form-group">
                      <label class="col-md-4 control-label">Size</label>
                      <div class="col-md-8">

					      <input type="text" id="job_inner_wide_format_w" name="job_inner_wide_format_w" class="form-control" placeholder="Width(m)" value="{if $smarty.post.job_inner_wide_format_w}{$smarty.post.job_inner_wide_format_w}{elseif $job_info[0].job_inner_cut_size_w}{$job_info[0].job_inner_cut_size_w}{/if}" onblur="calc_wide_format_sq_m('inner')" style="width:100px; display: inline-block; padding: 6px 8px;" > x
                          <input type="text" id="job_inner_wide_format_h" name="job_inner_wide_format_h" class="form-control" placeholder="Height(m)" value="{if $smarty.post.job_inner_wide_format_h}{$smarty.post.job_inner_wide_format_h}{elseif $job_info[0].job_inner_cut_size_h}{$job_info[0].job_inner_cut_size_h}{/if}" onblur="calc_wide_format_sq_m('inner')" style="width:100px; display: inline-block; padding: 6px 8px;">

					 </div>
                  </div>


	         </div>

	         <div class="col-md-6">
	          <div class="form-group">
	                   <label class="col-md-4 control-label">Machine <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
		                   <select name="job_inner_wide_format_machine" id="job_inner_wide_format_machine" class="form-control">
						        <option value="0">Please Select</option>
						      {section name=job_printers loop=$job_printers}
						      <option value="{$job_printers[job_printers].printer_name}" {if $job_printers[job_printers].printer_name eq '$smarty.post.job_inner_wide_format_machine' || $job_info[0].job_inner_machine eq $job_printers[job_printers].printer_name}selected{/if}>{$job_printers[job_printers].printer_name}</option>
						      {/section}
						    </select>
	                   </div>
	               </div>
	                <div class="form-group">
	                   <label class="col-md-4 control-label">Total Sq Meter</label>
	                   <div class="col-md-8 col-xs-12">
	                   <input id="job_inner_wide_format_total_sq_meter" name="job_inner_wide_format_total_sq_meter" type="text" id="job_inner_wide_format_total_sq_meter" value="{if $smarty.post.job_inner_wide_format_total_sq_meter}{$smarty.post.job_inner_wide_format_total_sq_meter }{elseif $job_info[0].job_inner_total_sq_meter }{$job_info[0].job_inner_total_sq_meter }{/if}" class="form-control" readonly />
	                   </div>
	               </div>
	         </div>
	          <div class="col-md-12">
	          <br>

                <div class="form-group">
                      <label class="col-md-2 control-label text-right">Notes</label>
                      <div class="col-md-9">
                          <textarea name="job_inner_wide_format_notes"  class="form-control">{if $smarty.post.job_inner_wide_format_notes}{$smarty.post.job_inner_wide_format_notes}{else}{$job_info[0].job_inner_notes}{/if}</textarea>
                       </div>
                  </div>

	         </div>


         </div>

         <div class="col-md-12 job_inner_promotional" style="margin-top:15px; {if $smarty.post.inner_print_options neq 'job_inner_promotional'}display:none;{/if}">
	         <div class="col-md-6">
	               <div class="form-group">
	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
	                    <input name="job_inner_promotional_material" type="text" id="job_inner_promotional_material" value="{if $smarty.post.job_inner_promotional_material}{$smarty.post.job_inner_promotional_material}{elseif $job_info[0].job_inner_material}{$job_info[0].job_inner_material}{/if}" placeholder="TShirt, Bag, Caps,.." class="form-control" />
	                   </div>
	               </div>
	         </div>

	         <div class="col-md-6">
	          <div class="form-group">
                   <label class="col-md-4 control-label">Quantity</label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_inner_promotional_quantity" type="number" id="job_inner_promotional_quantity" value="{if $smarty.post.job_inner_promotional_quantity}{$smarty.post.job_inner_promotional_quantity}{elseif $job_info[0].job_inner_quantity}{$job_info[0].job_inner_quantity}{/if}" class="form-control" />
                   </div>
               </div>
	         </div>
	         <div class="col-md-12" style="margin-top:10px;">
	           <div class="col-md-2">
	           &nbsp;
	           </div>
	           <div class="col-md-3">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_promotional_screen_printing" id="job_inner_promotional_screen_printing" value="Y" {if $smarty.post.job_inner_promotional_screen_printing || $job_info[0].job_inner_screen_printing eq 'Y'}checked{/if} />Screen Printing</label>
                   <div class="col-md-12 job_inner_promotional_screen_printing" style="padding:0; {if $smarty.post.job_inner_promotional_screen_printing neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_inner_screen_printing_notes"  class="form-control"></textarea>
                   </div>

               </div>
               <div class="col-md-3">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_promotional_embroidery" id="job_inner_promotional_embroidery" value="Y" {if $smarty.post.job_inner_promotional_embroidery || $job_info[0].job_inner_embroidery eq 'Y'}checked{/if} />Embroidery</label>

                    <div class="col-md-12 job_inner_promotional_embroidery" style="padding:0; {if $smarty.post.job_inner_promotional_embroidery neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_embroidery_notes"  class="form-control"></textarea>
                    </div>

               </div>
               <div class="col-md-3">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_promotional_heat_transfer" id="job_inner_promotional_heat_transfer" value="Y" {if $smarty.post.job_inner_promotional_heat_transfer || $job_info[0].job_inner_heat_transfer eq 'Y'}checked{/if} />Heat Transfer</label>
                   <div class="col-md-12 job_inner_promotional_heat_transfer" style="padding:0; {if $smarty.post.job_inner_promotional_heat_transfer neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_heat_transfer_notes"  class="form-control"></textarea>
                   </div>


               </div>

	         </div>


         </div>

         <div class="col-md-12 job_inner_cnc" style="margin-top:15px; {if $smarty.post.inner_print_options neq 'job_inner_cnc'}display:none;{/if}">

	          <div class="col-md-6">
	            <div class="form-group">
                      <label class="col-md-4 control-label">Type <span class="asterisk">*</span></label>
                      <div class="col-md-8 col-xs-12">
	                             <select name="job_inner_cnc_type" id="job_inner_cnc_type" onchange="checkOther(this.value, 'Other', 'job_inner_cnc_type_other');" class="form-control" required>
							      <option value="0">Please Select</option>
							      <option value="Lightbox" {if $smarty.post.job_inner_cnc_type eq 'Lightbox' || $job_info[0].job_inner_paper_type eq 'Lightbox'}selected{/if}>Lightbox</option>
							      <option value="Cut-out" {if $smarty.post.job_inner_cnc_type eq 'Cut-out' || $job_info[0].job_inner_paper_type eq 'Cut-out'}selected{/if}>Cut-out</option>
							      <option value="Pylon" {if $smarty.post.job_inner_cnc_type eq 'Pylon' || $job_info[0].job_inner_paper_type eq 'Pylon'}selected{/if}>Pylon</option>
							      <option value="Other" {if $smarty.post.job_inner_cnc_type eq 'Other' || $job_info[0].job_inner_paper_type eq 'Other'}selected{/if}>Other</option>

							    </select>
							    <input name="job_inner_cnc_type_other" type="text" id="job_inner_cnc_type_other" value="{if $smarty.post.job_inner_cnc_type_other}{$smarty.post.job_inner_cnc_type_other}{elseif $job_info[0].job_inner_paper_type_other}{$job_info[0].job_inner_paper_type_other}{/if}" class="form-control" style="display:none; margin-top:10px;" />
					</div>

                  </div>
	         </div>
	         <div class="col-md-6">
	               <div class="form-group">
	                   <label class="col-md-4 control-label">Material <span class="asterisk">*</span></label>
	                   <div class="col-md-8 col-xs-12">
	                    <input name="job_inner_cnc_material" type="text" id="job_inner_cnc_material" value="{if $smarty.post.job_inner_cnc_material}{$smarty.post.job_inner_cnc_material }{elseif $job_info[0].job_inner_material }{$job_info[0].job_inner_material}{/if}" class="form-control" />
	                   </div>
	               </div>
	         </div>

	         <div class="col-md-6" style="margin-top:10px;">
	          <div class="form-group">
                   <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_inner_cnc_quantity" type="number" id="job_inner_cnc_quantity" value="{if $smarty.post.job_inner_cnc_quantity}{$smarty.post.job_inner_cnc_quantity}{elseif $job_info[0].job_inner_quantity }{$job_info[0].job_inner_quantity}{/if}" class="form-control"/>
                   </div>
               </div>
	         </div>
	         <div class="col-md-12" style="margin-top:10px;">

	           <label class="col-md-2 control-label">Processes</label>

	           <div class="col-md-10">

	             <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_fabrication" id="job_inner_cnc_fabrication" value="Y" {if $smarty.post.job_inner_cnc_fabrication || $job_info[0].job_inner_fabrication eq 'Y'}checked{/if} />Fabrication</label>
                   <div class="col-md-12 job_inner_cnc_fabrication" style="padding:0; {if $smarty.post.job_inner_cnc_fabrication neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_inner_fabrication_notes"  class="form-control"></textarea>
                   </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_cnc_cutting" id="job_inner_cnc_cnc_cutting" value="Y" {if $smarty.post.job_inner_cnc_cnc_cutting || $job_info[0].job_inner_cnc_cnc_cutting eq 'Y'}checked{/if} />CNC Cutting</label>

                    <div class="col-md-12 job_inner_cnc_cnc_cutting" style="padding:0; {if $smarty.post.job_inner_cnc_cutting neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_cnc_cutting_notes"  class="form-control"></textarea>
                    </div>

               </div>

                <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_spraying" id="job_inner_cnc_spraying" value="Y" {if $smarty.post.job_inner_cnc_spraying || $job_info[0].job_inner_spraying eq 'Y'}checked{/if} />Spraying</label>
                   <div class="col-md-12 job_inner_cnc_spraying" style="padding:0; {if $smarty.post.job_inner_cnc_spraying neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_inner_spraying_notes"  class="form-control"></textarea>
                   </div>

               </div>

               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_cutting" id="job_inner_cnc_cutting" value="Y" {if $smarty.post.job_inner_cnc_cutting || $job_info[0].job_inner_cutting eq 'Y'}checked{/if} />Cutting</label>
                   <div class="col-md-12 job_inner_cnc_cutting" style="padding:0; {if $smarty.post.job_inner_cnc_cutting neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_cutting_notes"  class="form-control"></textarea>
                   </div>


               </div>

               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_bending" id="job_inner_cnc_bending" value="Y" {if $smarty.post.job_inner_cnc_bending || $job_info[0].job_inner_bending eq 'Y'}checked{/if} />Bending</label>

                    <div class="col-md-12 job_inner_cnc_bending" style="padding:0; {if $smarty.post.job_inner_cnc_bending neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_bending_notes"  class="form-control"></textarea>
                    </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_led" id="job_inner_cnc_led" value="Y" {if $smarty.post.job_inner_cnc_led || $job_info[0].job_inner_led eq 'Y'}checked{/if} />Lighting Attachment (LED)</label>
                   <div class="col-md-12 job_inner_cnc_led" style="padding:0; {if $smarty.post.job_inner_cnc_led neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_led_notes"  class="form-control"></textarea>
                   </div>


               </div>
                <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_lighting" id="job_inner_cnc_lighting" value="Y" {if $smarty.post.job_inner_cnc_lighting || $job_info[0].job_inner_lighting eq 'Y'}checked{/if} />Lighting (tube lights)</label>
                   <div class="col-md-12 job_inner_cnc_lighting" style="padding:0; {if $smarty.post.job_inner_cnc_lighting neq 'Y'}display:none;{/if}">
                     <label class="col-md-12 control-label text-left">Notes</label>
                     <textarea name="job_inner_lighting_notes"  class="form-control"></textarea>
                   </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_rivetting" id="job_inner_cnc_rivetting" value="Y" {if $smarty.post.job_inner_cnc_rivetting || $job_info[0].job_inner_rivetting eq 'Y'}checked{/if} />Rivetting</label>

                    <div class="col-md-12 job_inner_cnc_rivetting" style="padding:0; {if $smarty.post.job_inner_cnc_rivetting neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_rivetting_notes"  class="form-control"></textarea>
                    </div>

               </div>
               <div class="col-md-4">
                   <label class="check"><input type="checkbox" class="icheckbox" name="job_inner_cnc_site_installation" id="job_inner_cnc_site_installation" value="Y" {if $smarty.post.job_inner_cnc_site_installation || $job_info[0].job_inner_site_installation eq 'Y'}checked{/if} />Site installation</label>
                   <div class="col-md-12 job_inner_cnc_site_installation" style="padding:0; {if $smarty.post.job_inner_cnc_site_installation neq 'Y'}display:none;{/if}">
                      <label class="col-md-12 control-label text-left">Notes</label>
                      <textarea name="job_inner_site_installation_notes"  class="form-control"></textarea>
                   </div>


               </div>


	           </div>


	         </div>


         </div>

         </div>

         <!-- <div class="row" id="job_ncr_div" {if $quote_items[0].item_product neq 'NCR'}style="display:none;"{/if}>
             <br /> <br />
             <h3>NCR</h3>
            <div class="col-md-6">
              <div class="form-group">
                   <label class="col-md-4 control-label">No of Books</label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_num_books" type="text" id="job_num_books" value="{$smarty.post.job_num_books}" size="30" />
                   </div>
               </div>
               <div class="form-group">
                   <label class="col-md-4 control-label">Book No.</label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_book_no" type="text" id="job_book_no" value="{$smarty.post.job_book_no}" size="30" />
                   </div>
               </div>
               <div class="form-group">
                   <label class="col-md-4 control-label">Cover Colour</label>
                   <div class="col-md-8 col-xs-12">
                    <input name="job_ncr_color" type="text" id="job_ncr_color" value="{if $smarty.post.job_ncr_color}{$smarty.post.job_ncr_color}{else}{$job_info[0].job_ncr_color}{/if}" size="30" maxlength="15" />
                   <input name="job_ncr_color_other" type="text" id="job_ncr_color_other" value="{if $smarty.post.job_ncr_color_other}{$smarty.post.job_ncr_color_other}{else}{$quote_items[0].item_cover_color_other}{/if}" size="30" style="display:none;" /></td>

                   </div>


               </div>



            </div>

            <div class="col-md-6">
              <div class="form-group">
                   <label class="col-md-4 control-label">S. No</label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_start_no" type="text" id="job_start_no" value="{$smarty.post.job_start_no}" size="30" />
                   </div>
               </div>
               <div class="form-group">
                   <label class="col-md-4 control-label">Perforate All</label>
                   <div class="col-md-8 col-xs-12">
                   <input name="job_perforate_all" type="checkbox" id="job_perforate_all" value="Y" {if $smarty.post.job_perforate_all eq 'Y'}checked{/if} />
                   </div>
               </div>
               <div class="form-group">
                   <label class="col-md-4 control-label">&nbsp;</label>
                   <div class="col-md-8 col-xs-12">

                   </div>
               </div>


            </div>
            <div class="col-md-12">
              <table class="table table-responsive">
		          <tr>
		            <td class="title"><div align="center"><strong>1</strong></div></td>
		            <td class="title"><div align="center"><strong>2</strong></div></td>
		            <td class="title"><div align="center"><strong>3</strong></div></td>
		            <td class="title"><div align="center"><strong>4</strong></div></td>
		            <td class="title"><div align="center"><strong>5</strong></div></td>
		            <td class="title"><div align="center"><strong>6</strong></div></td>
		            <td class="title"><div align="center"><strong>7</strong></div></td>
		            </tr>
		          <tr>
		            <td width="100"><div align="center">ORIGINAL</div></td>
		            <td width="80"><div align="center">
		                <select name="job_ygbp_2" id="job_ygbp_2">
		                  <option value="none" {if $smarty.post.job_ygbp_2 eq 'none'}selected{/if}>none</option>
		                  <option value="Yellow" {if $smarty.post.job_ygbp_2 eq 'Yellow'}selected{/if}>Yellow</option>
		                  <option value="Green" {if $smarty.post.job_ygbp_2 eq 'Green'}selected{/if}>Green</option>
		                  <option value="Blue" {if $smarty.post.job_ygbp_2 eq 'Blue'}selected{/if}>Blue</option>
		                  <option value="Pink" {if $smarty.post.job_ygbp_2 eq 'Pink'}selected{/if}>Pink</option>
		                  <option value="White" {if $smarty.post.job_ygbp_2 eq 'White'}selected{/if}>White</option>
		                </select>
		            </div></td>
		            <td width="80"><div align="center">
		                <select name="job_ygbp_3" id="job_ygbp_3">
		                  <option value="none" {if $smarty.post.job_ygbp_3 eq 'none'}selected{/if}>none</option>
		                  <option value="Yellow" {if $smarty.post.job_ygbp_3 eq 'Yellow'}selected{/if}>Yellow</option>
		                  <option value="Green" {if $smarty.post.job_ygbp_3 eq 'Green'}selected{/if}>Green</option>
		                  <option value="Blue" {if $smarty.post.job_ygbp_3 eq 'Blue'}selected{/if}>Blue</option>
		                  <option value="Pink" {if $smarty.post.job_ygbp_3 eq 'Pink'}selected{/if}>Pink</option>
		                  <option value="White" {if $smarty.post.job_ygbp_3 eq 'White'}selected{/if}>White</option>
		                </select></div></td>
		            <td width="80"><div align="center">
		                <select name="job_ygbp_4" id="job_ygbp_4">
		                  <option value="none" {if $smarty.post.job_ygbp_4 eq 'none'}selected{/if}>none</option>
		                  <option value="Yellow" {if $smarty.post.job_ygbp_4 eq 'Yellow'}selected{/if}>Yellow</option>
		                  <option value="Green" {if $smarty.post.job_ygbp_4 eq 'Green'}selected{/if}>Green</option>
		                  <option value="Blue" {if $smarty.post.job_ygbp_4 eq 'Blue'}selected{/if}>Blue</option>
		                  <option value="Pink" {if $smarty.post.job_ygbp_4 eq 'Pink'}selected{/if}>Pink</option>
		                  <option value="White" {if $smarty.post.job_ygbp_4 eq 'White'}selected{/if}>White</option>
		                </select></div></td>
		            <td width="80"><div align="center">
		                <select name="job_ygbp_5" id="job_ygbp_5">
		                  <option value="none" {if $smarty.post.job_ygbp_5 eq 'none'}selected{/if}>none</option>
		                  <option value="Yellow" {if $smarty.post.job_ygbp_5 eq 'Yellow'}selected{/if}>Yellow</option>
		                  <option value="Green" {if $smarty.post.job_ygbp_5 eq 'Green'}selected{/if}>Green</option>
		                  <option value="Blue" {if $smarty.post.job_ygbp_5 eq 'Blue'}selected{/if}>Blue</option>
		                  <option value="Pink" {if $smarty.post.job_ygbp_5 eq 'Pink'}selected{/if}>Pink</option>
		                  <option value="White" {if $smarty.post.job_ygbp_5 eq 'White'}selected{/if}>White</option>
		                </select></div></td>
		            <td width="80"><div align="center">
		                <select name="job_ygbp_6" id="job_ygbp_6">
		                  <option value="none" {if $smarty.post.job_ygbp_6 eq 'none'}selected{/if}>none</option>
		                  <option value="Yellow" {if $smarty.post.job_ygbp_6 eq 'Yellow'}selected{/if}>Yellow</option>
		                  <option value="Green" {if $smarty.post.job_ygbp_6 eq 'Green'}selected{/if}>Green</option>
		                  <option value="Blue" {if $smarty.post.job_ygbp_6 eq 'Blue'}selected{/if}>Blue</option>
		                  <option value="Pink" {if $smarty.post.job_ygbp_6 eq 'Pink'}selected{/if}>Pink</option>
		                  <option value="White" {if $smarty.post.job_ygbp_6 eq 'White'}selected{/if}>White</option>
		                </select></div></td>
		            <td width="80"><div align="center">
		                <select name="job_ygbp_7" id="job_ygbp_7">
		                  <option value="none" {if $smarty.post.job_ygbp_7 eq 'none'}selected{/if}>none</option>
		                  <option value="Yellow" {if $smarty.post.job_ygbp_7 eq 'Yellow'}selected{/if}>Yellow</option>
		                  <option value="Green" {if $smarty.post.job_ygbp_7 eq 'Green'}selected{/if}>Green</option>
		                  <option value="Blue" {if $smarty.post.job_ygbp_7 eq 'Blue'}selected{/if}>Blue</option>
		                  <option value="Pink" {if $smarty.post.job_ygbp_7 eq 'Pink'}selected{/if}>Pink</option>
		                  <option value="White" {if $smarty.post.job_ygbp_7 eq 'White'}selected{/if}>White</option>
		                </select></div></td>
		            </tr>
		        </table>

            </div>


         </div>   -->


         <div class="row">
             <br /> <br />
             <h3>FINISHING</h3>
            <div class="col-md-12">
              {section name=job_finishing loop=$job_finishing}
	            <div class="col-md-3">
	                           <label class="check"><input type="checkbox" class="icheckbox" name="job_finishing_{$smarty.section.job_finishing.rownum}" id="job_finishing_{$smarty.section.job_finishing.rownum}" value="{$job_finishing[job_finishing].finishing_id}" {if $smarty.post}{if $job_finishing[job_finishing].finishing_id|in_array:$item_finishing_array_posted}checked="checked"{/if}{else}{if $job_finishing[job_finishing].finishing_type|in_array:$item_finishing_array}checked="checked"{/if}{/if} /> {$job_finishing[job_finishing].finishing_type}</label>
	               </div>
	      	  {/section}
            </div>

         </div>
          <div class="row">
             <br /> <br />
             <h3>REMARKS / SPECIAL INSTRUCTIONS</h3>
              <div class="col-md-12">

                <div class="form-group">


                       <!-- <label><input type="checkbox" name="show_remarks" id="show_remarks" onchange="show_textarea(this, 'job_remarks');"></label> -->
                        <textarea name="job_remarks" id="job_remarks" class="form-control" rows="5">{if $smarty.post.job_remarks}{$smarty.post.job_remarks}{else}{$quote_items[0].item_special_remarks}{/if}</textarea>


                 </div>

              </div>


         </div>

      </div>
      <div class="panel-footer">
      <input type="hidden" name="next_step" id="next_step" value="two" />
       <input type="hidden" name="group_id" id="group_id" value="{$quote_info[0].group_id}" />
      <input type="submit" name="Submit" class="btn btn-primary pull-right" value="Make Job Order" />


      </div>
  </div>
  </form>
{/if}

</div>
</div>
