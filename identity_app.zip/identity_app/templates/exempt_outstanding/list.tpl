{if $privileges.bills.list}
<style>
.bg-light {
    background-color: #f7f7f7;
}

.table > tbody > tr > td{
  background: none !important;
}
.table-striped > tbody > tr:nth-child(2n+1) > td{
  background: none !important;
}

/* Floating table header */
.floating-thead {
    position: fixed;
    top: 0;
    left: 0;
    display: none;
    z-index: 999;
    background: #f5f5f5;
    border-bottom: 1px solid #ccc;
}

.floating-thead th {
    background: #f5f5f5;
    box-shadow: 0 2px 2px -1px rgba(0,0,0,0.15);
}


@media print {
    .no-print {
        display: none !important;
    }
	body {
        font-size: 11px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th, td {
        border: 1px solid #000;
        padding: 4px;
    }

    .floating-thead {
        display: none !important;
    }
}
</style>


<!-- START BREADCRUMB -->
 <ul class="breadcrumb no-print">
     <li><a href="/">Home</a></li>
     <li><a href="#">Exempt Outstanding</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Exempt Outstanding - DN</h2>
</div>


 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-6 no-print" style="margin-bottom:10px;">
            {* <a href="/bills/summary" class="btn btn-default">Summary</a>
            <br><br> *}

          <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/exempt_outstanding/list" class="btn btn-default">Clear</a>


		</div>
    <div class="col-md-6 no-print">
      <div class="col-sm-6">
      Sort By Sales Person: {$smarty.get.sort}
     <a href="{if $smarty.get.search}http://{$smarty.server.HTTP_HOST}{$smarty.server.REQUEST_URI}&sort=user_asc{else}/exempt_outstanding/list?sort=user_asc{/if}" class="btn {if $smarty.get.sort == 'user_asc'}btn-success{else}btn-default{/if}">ASC</a>
     <a href="{if $smarty.get.search}http://{$smarty.server.HTTP_HOST}{$smarty.server.REQUEST_URI}&sort=user_desc{else}/exempt_outstanding/list?sort=user_desc{/if}" class="btn {if $smarty.get.sort == 'user_desc'}btn-success{else}btn-default{/if}">DESC</a>

        
      </div>
      <div class="col-sm-6 text-right">
         <form class="form-inline no-print" method="post" action="/exempt_outstanding/list{if $search_str}?search=1&{$search_str}{/if}">
                    <input type="hidden" name="export" value="excel" >
                    <button name="submit" type="submit" class="btn btn-default">Excel Export</button>
                </form>
      </div>
    
   </div>
   {include file="$section/search.tpl"}
        <div class="panel panel-default">

            <div class="panel-heading">
                 <!-- <h3 class="panel-title">bills Table</h3> -->

                  <ul class="panel-controls panel-controls-title">
                      <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                            <div class="form-group">
                            
                               <label> Displaying {$resultsCount}</label>
                           </div> 
                        &nbsp;&nbsp;

        					         <a href="" onclick="window.print();" class="no-print" title="Print">
        					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
        					                </a>
                     </form>
                     </li>
                   
                     


                 </ul>
            </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">

                    <table class="table pad-5 table-bordered  table-actions">
                        <thead class="hoverable">
                            <tr>
                                <th class="text-center" width="15%">Company</th>
                                <th class="text-center" width="15%">Quote # / DN Date / DN #</th>
                                <th width="135" class="text-center">Amount</th>
                                <th width="135" class="text-center">Amount Paid</th>
                                <th width="135" class="text-center">Balance</th>
                                <th width="135" class="text-center">Total Unpaid</th>
                                {if $smarty.get.sort && !$smarty.post.sales_user_id}<th width="135" class="text-center">Sales Person Total</th>{/if}
                                <th width="135" class="text-center">Sales Person</th>
                                <th width="120" class="text-center no-print">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                          {section name=bill_list loop=$bill_list}

          {* Detect company change *}
          {if $bill_list[bill_list].group_company ne $prev_company}

              {* Toggle row shading only when company changes *}
              {if $row_class eq ''}
                  {assign var=row_class value='bg-light'}
              {else}
                  {assign var=row_class value=''}
              {/if}

              {* Update previous company *}
              {assign var=prev_company value=$bill_list[bill_list].group_company}

              {* Flag to show company name *}
              {assign var=show_company value=true}

          {else}
              {* Same company, hide name *}
              {assign var=show_company value=false}
          {/if}

          {* if $bill_list[bill_list].salesperson_total}
<tr class="info">
    <td colspan="5"><strong>Sales Person:
        {$bill_list[bill_list].user_fname} {$bill_list[bill_list].user_lname}
    </strong>
   </td>

    <td class="text-right">
        <strong>
            {$bill_list[bill_list].salesperson_total|number_format:0:".":","}
            {$bill_list[bill_list].currency}
        </strong>
    </td>

    <td colspan="2"></td>
</tr>
{/if *}

          <tr class="{$row_class}">
              <td>
                  {if $show_company}
                      {$bill_list[bill_list].group_company}
                  {/if}
              </td>
             

              <td>
                    {* first line: quote id (aligned with bill_amount) *}
                    <a target="_blank" title="View Quote" href="/quotes/view/?id={$bill_list[bill_list].quote_id}">
                        Q# {$bill_list[bill_list].quote_id|leading_zero:5}
                    </a><br>

                    {* next lines: dn date + dn id (aligned with dn_amount lines) *}
                    {if $bill_list[bill_list].items}
                        {foreach from=$bill_list[bill_list].items item=dn}
                            {$dn.dn_date|date_format:"%d/%m/%Y"} |
                            <a target="_blank" title="View Delivery Note" href="/deliveries/view?id={$dn.dn_id}">
                                DN #{$dn.dn_id}
                            </a><br>
                        {/foreach}
                    {else}
                        -<br>
                    {/if}
                </td>
              <td class="text-right">
                {$bill_list[bill_list].bill_amount|number_format:0:".":","}
                {$bill_list[bill_list].currency}

                {if $bill_list[bill_list].items}
                    <br>
                    {foreach from=$bill_list[bill_list].items item=dn}
                        <small>
                            {$dn.dn_amount|number_format:0:".":","}
                        </small><br>
                    {/foreach}
                {/if}
            </td>

              <td class="text-right">
                  {if $bill_list[bill_list].amount_paid > 0}
                      {$bill_list[bill_list].amount_paid|number_format:0:".":","}
                      {$bill_list[bill_list].currency}
                  {else}-{/if}
              </td>

              <td class="text-right">
                  {$bill_list[bill_list].balance|number_format:0:".":","}
                  {$bill_list[bill_list].currency}
              </td>

              <td class="text-right">
                  {if $bill_list[bill_list].total}
                      {$bill_list[bill_list].total|number_format:0:".":","}
                      {$bill_list[bill_list].currency}
                  {/if}
              </td>
              {if $smarty.get.sort && !$smarty.post.sales_user_id}
              <td class="text-right">
                  {if $bill_list[bill_list].salesperson_total}
                  {$bill_list[bill_list].salesperson_total|number_format:0:".":","}
                  {$bill_list[bill_list].currency}
                  {/if}
              </td>
              {/if}

              <td class="text-right">
                  {$bill_list[bill_list].salesperson_name}
              </td>

           
              <td class="text-center no-print">
                  <a class="btn btn-default btn-rounded btn-condensed btn-sm"
                     href="/quotes/print?uid={$bill_list[bill_list].quote_id}"
                     target="_blank">
                     <span class="fa fa-file-pdf-o"></span>
                  </a>
                  {if $privileges.exempt_outstanding.ledger &&  $show_company}
                <a class="btn btn-default btn-rounded btn-condensed btn-sm"  title="View Ledger" href="/exempt_ledgers/view?group_id={$bill_list[bill_list].group_id}"  alt="View Ledger" target = "_blank"><span class="fa fa-adjust"></span></a>
                {/if}

                  {if $smarty.session.role_name == 'Administrator' || $smarty.session.user_id == '298'}
                  <a href="/exempt_outstanding/list?del={$bill_list[bill_list].id}"
                     class="btn btn-warning btn-rounded btn-condensed btn-sm"
                     onclick="confirmAction('Remove this record?', this.href); return false;">
                     <span class="fa fa-times"></span>
                  </a>
                  {/if}
              </td>
             
          </tr>

      {sectionelse}

						  <tr>
						    <td colspan="6"><div align="center">No records found.</td>
						  </tr>
						 {/section}
             <tr>
               <td class="text-right" colspan="2"><strong>Total</strong></td><td class="text-right">{$bill_list[0].grand_total|number_format:0:".":","} TZS</td><td class="text-right">{$bill_list[0].paid_total|number_format:0:".":","} TZS</td><td></td><td class="text-right">{$bill_list[0].balance_total|number_format:0:".":","} TZS</td><td colspan="2"></td>
             </tr>
                        </tbody>
                    </table>

                </div>


            </div>
             <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline no-print" role="form"  method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                           {if $page > 0}
                             <a href="/exempt_outstanding/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/exempt_outstanding/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>
                           |{/if}
                             <label> Displaying {$resultsCount}</label>
                         </div>
                         {* <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button> *}


                     </form>
                     </li>

                 </ul>
            </div>

        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

<!-- NEW COMPANY MODAL -->
  <div class="modal" id="cancelModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-sm">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_cancel_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead"><span class="item_name"></span></h4>
              </div>
              <form id="cancel_form" name="cancel_form" method="post" action="/exempt_outstanding/list" class="form-horizontal" enctype="multipart/form-data">
	              <div class="modal-body">
	                 <div id="cancel_response"></div>


			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			                 <div class="panel-body form-group">
			                   <div class="row">

									   <div class="form-group">
									    <label class="col-md-12">Notes</label>
									    <div class="col-md-12">
									    <textarea id="notes" name="notes" class="form-control" rows="4"></textarea>
									    </div>
									  </div>

                    <div class="form-group">
                     <label class="col-md-12">Attachment</label>
                     <div class="col-md-12">
                     <input name="attachment" type="file" id="attachment" class="form-control" />
                     </div>

                     </div>
                   </div>

			                   </div>


			                 </div>

			             </div>

                   <div class="modal-footer">
                       <input type="hidden" name="item_id" value="" >
                       <input type="hidden" name="cancel" value="1" >
                       <input type="submit" name="cancel_submit" class="btn btn-primary item_submit" value="Submit">
                       <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                     </div>

	              </div>

              </form>

          </div>
      </div>
  </div>

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
