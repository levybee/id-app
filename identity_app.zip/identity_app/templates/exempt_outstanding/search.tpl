


<div id="search" class="panel panel-default" style="display: none; margin-top:15px;">

<div class="panel-body">
   <form id="form2" name="form2" class="form-inline"  method="post" action="/exempt_outstanding/list?search=1{if $filter_str}&{$filter_str}{/if}{if $search_str}&{$search_str}{/if}">

     <div class="form-group" style="margin-right:15px;">
     <label for="from_date" >Quote #</label>
      <input  type="text" class="form-control" style="display:block;"  name="quote_id"  value="{if $smarty.post.quote_id}{$smarty.post.quote_id}{/if}" >
    </div>

     <div class="form-group"  style="margin-right:15px;">
     <label for="ec_id">By Company</label>
     <br>
     	<select class="form-control select" id="group_id" name="group_id" style="display:block; width:200px;">
              <option value="">Please Select</option>
            {section name=group_list loop=$group_list}
            <option value="{$group_list[group_list].group_id}">{$group_list[group_list].group_company}</option>
            {/section}
          </select>


    </div>

    <div class="form-group" style="margin-right:15px;">
      <label>Sales Person</label><br>
      <select name="sales_user_id" style="display:block; width:160px;"   class="form-control select2">
      <option value="">Select..</option>
      {section name=users loop=$sales_users}
        <option value="{$sales_users[users].user_id}">{$sales_users[users].user_fname} {$sales_users[users].user_lname}</option>
      {/section}
      </select>

    </div>

    <div class="form-group" style="margin-right:15px;">
     <label for="from_date" >Date From:</label>
      <input  type="text" style="display:block;"  name="date_from"  class="form-control datepicker" value="{if $smarty.post.date_from}{$smarty.post.date_from|date_format:'%Y-%m-%d'}{else}{/if}" >
    </div>



     <div class="form-group"  style="margin-right:15px;">
     <label for="to_date">Date To:</label>
      <input type="text" class="form-control datepicker" style="display:block;"  name="date_to"  value="{if $smarty.post.date_to}{$smarty.post.date_to|date_format:'%Y-%m-%d'}{else}{/if}" >

    </div>

     <div class="form-group" style="margin-top:20px;">
       <input type="hidden" name="debug" value="{$smarty.get.debug}" >
       <button type="submit" class="btn btn-primary">Go</button>
     </div>


</form>


</div>



</div>
