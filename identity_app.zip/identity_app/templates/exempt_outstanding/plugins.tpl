<!-- PAGE PLUGINS -->
       <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
       <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
       <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>
       <script type="text/javascript" src="/js/plugins/star-rating/jquery.rating.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
       <script type="text/javascript" src="/js/jquery/jquery.livequery.min.js"></script>
       <script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>
       <script type="text/javascript" src="/js/jquery/relcopy.js"></script>
       <script type="text/javascript" src="/js/new_company_ajax.js"></script>


       <script type='text/javascript' src='/js/plugins/jquery-validation/jquery.validate.js'></script>




{literal}

<script type="text/javascript">

   $("#group_id").select2({
 placeholder: "Type to search...",
 minimumInputLength: 1,
 ajax: {
       url: "/ajax/customers_group.php",
       dataType: 'json',
       delay: 250,
       data: function (params) {

           return {
               q: params.term, // search term
           };
       },
       processResults: function (data) { // parse the results into the format expected by Select2.
           // since we are using custom formatting functions we do not need to alter the remote JSON data

           // Debug:
     console.log("Data: " + JSON.stringify(data) );

           return { results: data };
       },
       cache: true
   }

});

 $('.close_cancel_form').on('click', function(e){
   $('#cancelModal').modal('hide');
 });

 $('.cancel_item').on('click', function(e) {

   e.preventDefault();
   item_action($(this));

});


 item_action = function(obj){

   $('#cancelModal').modal('show');
   $('.item_name').text('Cancel Invoice #' + obj.data('ref'));
   $('input[name="item_id"]').val(obj.data('item-id'));

 }

//   $('#cancel_form').submit(function(e){

//         e.preventDefault();
//         var formData = new FormData(this);
//         submit_form('#cancel_form', 'cancel_submit', '#cancel_response', '#cancelModal', formData);

//   });


 submit_form = function(form_name, btn_name, response_element='', modal_element='', formData=''){

     console.log('form_name', form_name);
     console.log('btn_name', btn_name);


     $('input[name="'+ btn_name +'"]').val('Sending...').attr('disabled','disabled');


     var post_url = "/bills/list";
   //  var post_data = $(form_name).serialize();
     $.ajax({
       type: 'POST',
       url: post_url,
       data: formData,
       processData: false,
       contentType: false,
       success	:	function(data){

            var alert_class = (data.error == true)? 'danger' : 'success';

            var msg_html = "<ul>";
            $.each(data.msg, function(i, item) {
              msg_html += "<li>"+ data.msg[i] +"</li>";
           });
            msg_html += "</ul>";

            console.log(msg_html);
            console.log(alert_class);



            $('input[name="'+ btn_name +'"]').val('Submit').removeAttr('disabled');



              $(response_element).html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');


              if(data.error == false){

                $(form_name).reset();

                setTimeout(function(){

                   //$('.item_list').prop('checked', false);
                   $(modal_element).modal('hide');
                   location.reload();

               },5000);

              }


         },
         error : function(XMLHttpRequest, textStatus,
             errorThrown) {

           console.log("Status: " + textStatus);
           console.log("Error: " + errorThrown);

         }


     });



   }


   $(function () {


   var $table = $('.table-actions');
   if (!$table.length) return;

   var $thead = $table.find('thead');
   var $clone = $thead.clone();
   var action = '{/literal}{$action}{literal}';
    var $fixedHeader = '';
   if(action == 'list'){
     var $fixedHeader = $('<table class="table table-bordered table-actions floating-thead"></table>')
         .append($clone)
         .appendTo('body');
   }


   function syncWidths() {

       var tableOffset = $table.offset();

$fixedHeader.css({
   left: tableOffset.left,
   width: $table.outerWidth()
});

       $fixedHeader.find('th').each(function (i) {
           $(this).width($thead.find('th').eq(i).outerWidth());
       });
   }

   $(window).on('scroll resize', function () {
       var tableTop = $table.offset().top;
       var tableBottom = tableTop + $table.height();
       var scrollTop = $(window).scrollTop();

       if (scrollTop > tableTop && scrollTop < tableBottom) {
           $fixedHeader.show();
           syncWidths();
       } else {
           $fixedHeader.hide();
       }
   });
});


</script>
{/literal}


<!-- END PAGE PLUGINS -->
