<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Identity Promotions</title>
  <style>
   {include file="css/pdf.css"}
  </style>
</head>
<body>
  <!-- pdf-header  -->
  <header>
  <table class="table pdf-header" style="padding-top:0;">
    <tr>
      <td colspan="2">
        <h1>Employee Notice</h1>
      </td>
    </tr>
  </table>
  <!-- /.pdf-header -->
</header>
<footer>
  <table class="table footer-bottom">
    <tr>
      <td width="70%" class="">
        <p class="footer-text">
          Identity Promotions Ltd. | Corner ITV/Bagamoyo Rd, Mwenge, P.O. Box 38070, Dar es Salaam, Tanzania  | Phone No: 0769 785065 | hr@identitytz.com | identitytz.com
        </p>
      </td>
      <td width="30%" style="padding-left:30px;"><p class="footer-text">Ref #: IPL/HR/Notice/{$data.id|string_format:"%05d"}</p></td>
    </tr>
  </table>

</footer>

<div class="content-header">
    <table width="100%">
    <tr>
      <td width="50%">
        <table class="details">
          <tr>
            <td class="label20"><b>Ref #:</b></td><td>IPL/HR/Notice/{$data.id|string_format:"%05d"}</td>
          </tr>
          <tr>
            <td class="label20"><b>Subject:</b></td><td>{$data.reference}</td>
          </tr>
          <tr>
            <td class="label20"><b>To:</b></td><td>{$data.employee_name}</td>
          </tr>
          <tr>
            <td class="label20"><b>From:</b></td><td>Identity Promotions Ltd</td>
          </tr>
        </table>
      </td>
      <td width="50%">
        <table class="details">
          <tr>
            <td class="label20"><b>Department:</b></td><td class="value">{$data.department_name}</td>
          </tr>
          <tr>
            <td class="label20"><b>Position:</b></td><td class="value">{$data.position}</td>
          </tr>
          <tr>
            <td class="label20"><b>Date of Issue:</b></td><td class="value">{$data.date_created|date_format:"%d %b %Y"}</td>
          </tr>
          <tr>
            <td class="label20">&nbsp;</td><td class="value">&nbsp;</td>
          </tr>
        </table>
      </td>
      <td>
      </td>
    </tr>
  </table>
</div>    

<section class="content">
  {* if $data.remarks}
   <p>{$data.remarks}</p>
   <br>
  {else}
  <p>The company hereby issues this warning letter for the reasons stated below.</p>
  <br>
  {/if *}
  
{$data.tpl_content}

{if $data.remarks}
<p>{$data.remarks}</p>
{/if}
</section>

<table class="table" style="padding:25px 0 25px; width:70%;">
  <tr>
    <td width="20%" style="padding-left:0;">Issued By:</td><td width="30%"> {$data.user}</td><td></td><td width="40%" class="border-bottom">&nbsp;</td>
  </tr>
  <tr>
    <td></td><td></td><td></td><td></td>
  </tr>
</table>

<p>I have read acknowledge and accept the above.</p>
<p>Nimesoma, nimeelewa na nimekubali ya hapo juu.</p>
<table class="table" style="padding:15px 0 25px; width:70%;">
  <tr>
    <td width="20%" style="padding-left:0;">{$data.employee_name}</td><td width="10%">&nbsp;</td><td width="30%" class="border-bottom"></td><td>&nbsp;</td>
  </tr>
  <tr>
    <td></td><td></td><td></td><td></td>
  </tr>
</table>
  <!-- <div class="pagination"><center><span class='page-number'></span></center></div> -->
</body>
</html>
