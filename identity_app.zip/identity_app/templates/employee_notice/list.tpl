{if $privileges.employee_notice.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Employee Notice</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Employee Notice</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">

             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">

         {if $privileges.employee_notice.add}
           <a href="/employee_notice/add" class="btn btn-default">New Notice</a>
           <br><br>
         {/if}

         <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/employee_notice/list?page=1" class="btn btn-default">Clear</a> | Filter By Status: <a href="/employee_notice/list?page=1" class="btn {if !$smarty.get.notice_status }btn-success{/if} btn-flat btn-rad">All</a>

         <a href="/employee_notice/list?page=1&filter=1&notice_status=Draft" class="btn {if $smarty.get.notice_status  eq 'Draft'}btn-success{else}btn-default{/if}">Draft</a>

         <a href="/employee_notice/list?page=1&filter=1&notice_status=Approved" class="btn {if $smarty.get.notice_status  eq 'Approved'}btn-success{else}btn-default{/if}">Approved</a>
         <a href="/employee_notice/list?page=1&filter=1&notice_status=Issued" class="btn {if $smarty.get.notice_status  eq 'Issued'}btn-success{else}btn-default{/if}">Issued</a>

         <a href="/employee_notice/list?page=1&filter=1&notice_status=Closed" class="btn {if $smarty.get.notice_status  eq 'Closed'}btn-success{else}btn-default{/if}">Closed</a>

         <a href="/employee_notice/list?page=1&filter=1&notice_status=Cancelled" class="btn {if $smarty.get.notice_status  eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled</a>
         {include file="$section/search.tpl"}
      </div>

        <div class="panel panel-default">

            <div class="panel-heading">

              {if $smarty.get.notice_status  eq 'Drafts'}
              <label for="approve_selected" name="approve_selected" class="btn btn-danger">
                Approve Selected
              </label>
              {/if}

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/employee_notice/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/employee_notice/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}
								    <option value="1" selected>Page 1</option>
								  {/section}

							     </select>
                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>
                     </li>

                 </ul>
            </div>
            <div class="panel-body panel-body-table">

                <form method="post" action="">
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">
                    <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              {if $smarty.get.notice_status  eq 'Drafts'}
                                  <th width="40" class="text-center">
                                      <input type="checkbox" id="check_all_approved"/></th>
                              {/if}
                               <th class="text-center">#</th>
                               <th class="text-center">Date</th>
                               <th class="text-center">Employee</th>
                               <th class="text-center">Reference</th>
              								 <th class="text-center">Type</th>
                               <th class="text-center">Template</th>
                               <th class="text-center">Remarks</th>
                               <th class="text-center">Attachment</th>
                               <th class="text-center">Status</th>
              								 <th class="text-center">User</th>
              							   <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=notice_list loop=$notice_list}
						  <tr>
                {if $notice_list[notice_list].notice_status  eq 'Drafts' && $smarty.get.notice_status  eq 'Draft'}<td class="text-center">
                    <input type="checkbox" name="approved_check[]" class="approved_check" value="{$notice_list[notice_list].id}" /></td>{/if}

						    <td class="text-center">{$notice_list[notice_list].id}</td>
                <td class="text-center">{$notice_list[notice_list].date_created|date_format:"%d %b %Y"}</td>
                <td class="text-center">{$notice_list[notice_list].employee_name}</td>
                <td class="text-center">{$notice_list[notice_list].reference}</td>
                <td class="text-center">{$notice_list[notice_list].notice_type}</td>
                <td class="text-center">{$notice_list[notice_list].tpl_name}</td>
                <td><a href="#" data-toggle="popover" data-placement="top" data-content="{$notice_list[notice_list].remarks|strip_tags}">{$notice_list[notice_list].remarks|strip_tags|truncate:500}</a></td>
                <td class="text-center">
                <a href="/{$config.attachment_dir}{$notice_list[notice_list].attachment}" target = "_blank">{if $notice_list[notice_list].attachment}{$notice_list[notice_list].attachment}{else}-{/if}</a>
                </td>
                <td class="text-center">
                    <span class="{if $notice_list[notice_list].notice_status  eq 'Draft'}text-danger{elseif $notice_list[notice_list].notice_status  eq 'Closed'}text-info{elseif $notice_list[notice_list].notice_status  eq 'Cancelled'}text-default{else}text-success{/if}">{$notice_list[notice_list].notice_status}</span>
                    {* {if $notice_list[notice_list].notice_status  eq 'Approved'}by {$notice_list[notice_list].approval_user}{/if} *}
                </td>
						    <td class="text-center">{$notice_list[notice_list].user}</td>
						    <td class="text-center">
                   <a class="btn btn-default btn-rounded btn-condensed btn-sm"  title="View PDF" href="/employee_notice/print?id={$notice_list[notice_list].id}"  alt="View PDF" target = "_blank"><span class="fa fa-file-pdf-o"></span></a>
                   {if $notice_list[notice_list].notice_status  eq 'Issued'}
                      <a title="Close"
                     href="" class="btn btn-success btn-rounded btn-condensed btn-sm attach_btn"
                     data-id="{$notice_list[notice_list].id}"
                     data-employee="{$notice_list[notice_list].employee_name}"
                     data-attachment_path="{$notice_list[notice_list].attachment}"
                     ><span class="fa fa-check-circle"></span></a>
                   {/if}

                   {if $notice_list[notice_list].notice_status  eq 'Approved'}
                   {if $privileges.employee_notice.issue}
                   <a href="/employee_notice/list?actn=issue&id={$notice_list[notice_list].id}" class="btn btn-warning btn-rounded btn-condensed btn-sm" title="Issue" onclick="confirmAction('[Issue Notice] Are you sure?', this.href); return false;" ><span class="fa fa-arrow-circle-right"></span></a>
                   {/if}
                   {/if}

                   {if $notice_list[notice_list].notice_status  eq 'Draft'}
                   {if $privileges.employee_notice.approve}
                   <a href="/employee_notice/list?actn=approve&id={$notice_list[notice_list].id}" class="btn btn-info btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Notice] Are you sure?', this.href); return false;" ><span class="fa fa-check-circle"></span></a>
                   {/if}
                   <a href="/employee_notice/list?actn=cancel&id={$notice_list[notice_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Cancel" onclick="confirmAction('[Cancel Notice] Are you sure?', this.href); return false;" ><span class="fa fa-times"></span></a>
                   {/if}
                   <a href="/employee_notice/edit/?id={$notice_list[notice_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
						    </td>
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="11">No records found.</td>
						  </tr>
						  {/section}
                        </tbody>
                    </table>

                </div>
                </form>


            </div>

     {if $smarty.get.dbg}
     {$privileges.employee_notice|@print_r}
     {/if}

        </div>

 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

<div class="modal" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="defModalHead">Close Notice for <span class="item_name"></span></h4>
            </div>
            <form id="attachment_form" name="attachment_form" method="post" action="/employee_notice/list" class="form-horizontal" enctype="multipart/form-data">
              <div class="modal-body">
                 <div id="response"></div>


                 <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
                     <div class="panel-body form-group">
                       <div class="row">
                         <div class="form-group">
                             <label>Attachment</label>
                             <input name="attachment_file" type="file" id="attachment_file" class="form-control" style="width:50%;" />
                         </div>
                 </div>

              </div>



        </div>
    </div>
    <div class="modal-footer">
        <input type="hidden" name="notice_id" value="" >
        <input type="hidden" name="close" value="1" >
        <input type="hidden" name="attachment_path" value="" >
        <input type="submit" name="item_submit" class="btn btn-primary" value="Submit">
        {* <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button> *}
      </div>
      </form>
</div>

{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
