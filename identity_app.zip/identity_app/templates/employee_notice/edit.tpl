{if $privileges.employee_notice.edit || $privileges.employee_notice.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/employee_notice/list">Employee Notice</a></li>
     <li class="active"><a href="">{$action|capitalize} Employee Notice</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Employee Notice</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

         {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     {* <h3 class="panel-title"><strong>Request</strong> Form</h3> *}
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">

                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Employee</label>
                    <div class="col-md-6 col-xs-12">
                        <select name="employee_id" id="employee_id"  class="form-control" style="width:100%;">
                         </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Reference</label>
                    <div class="col-md-6 col-xs-12">
                       <input id="reference" name="reference" type="text" class="form-control" value="{if $edit_notice[0].reference}{$edit_notice[0].reference}{elseif $smarty.post.reference}{$smarty.post.reference}{/if}">
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Notice Type</label>
                    <div class="col-md-6 col-xs-12">
                         <select name="notice_type" id="notice_type" class="form-control">
                           <option value="">Select..</option>
                           <option value="Statutory"  {if $smarty.post.notice_type eq "Statutory" || $edit_notice[0].notice_type eq "Statutory"}selected{/if}>Statutory</option>
                           <option value="Contractual"  {if $smarty.post.notice_type eq  "Contractual" || $edit_notice[0].notice_type eq "Contractual"}selected{/if}>Contractual</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Template</label>
                    <div class="col-md-6 col-xs-12">
                        <select name="notice_tpl_id" class="form-control select">
                             <option value="">Select..</option>
                             {section name=notice_tpls loop=$notice_tpls}
                                     <option value="{$notice_tpls[notice_tpls].id}" {if $edit_notice[0].notice_tpl_id  eq $notice_tpls[notice_tpls].id}selected{/if}>{$notice_tpls[notice_tpls].tpl_name}</option>
                                 {/section}
                        </select>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Remarks</label>
                    <div class="col-md-8 col-xs-12">
                         <textarea name="remarks" rows="6" class="form-control summernote">
                         {if $edit_notice[0].remarks}{$edit_notice[0].remarks}{elseif $smarty.post.remarks}{$smarty.post.remarks}{/if}
                       </textarea>
                    </div>
                </div>
                 <!-- <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">Duration</label>
                     <div class="col-md-6 col-xs-12">
                         <p class="form-control-static duration">{$edit_notice[0].duration}</p>
                     </div>
                 </div> -->

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Notice</button>
                 </div>
             </div>
             </form>
            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized
	  </div>




</div>

</div>
{/if}
