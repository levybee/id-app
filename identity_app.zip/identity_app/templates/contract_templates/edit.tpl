{if $privileges.contract_templates.edit || $privileges.contract_templates.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/contract_templates/list">Contract Template</a></li>
     <li class="active"><a href="">{$action|capitalize} Contract Template</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Contract Template</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

         {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     {* <h3 class="panel-title"><strong>Request</strong> Form</h3> *}
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">
                   <div class="form-group">
                       <label class="col-md-3 col-xs-12 control-label">Template Name</label>
                       <div class="col-md-6 col-xs-12">
                           <input id="tpl_name" name="tpl_name" type="text" class="form-control" value="{if $edit_tpl[0].tpl_name}{$edit_tpl[0].tpl_name}{elseif $smarty.post.tpl_name}{$smarty.post.tpl_name}{else}{/if}">
                       </div>
                   </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Template Type</label>
                    <div class="col-md-6 col-xs-12">
                         <select name="tpl_type" id="tpl_type" class="form-control">
                         <option  value="">Select..</option>
                         <option value="Permanent"  {if $smarty.post.tpl_type eq "Permanent" || $edit_tpl[0].tpl_type eq "Permanent"}selected{/if}>Permanent</option>
                         <option value="Temporary"  {if $smarty.post.tpl_type eq "Temporary" || $edit_tpl[0].tpl_type eq "Temporary"}selected{/if}>Temporary</option>
                         <option value="Fixed-term"  {if $smarty.post.tpl_type eq  "Fixed-term" || $edit_tpl[0].tpl_type eq "Fixed-term"}selected{/if}>Fixed-term</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Content</label>
                    <div class="col-md-9 col-xs-12">
                         <textarea name="tpl_content" rows="15" class="form-control summernote">
                         {if $edit_tpl[0].tpl_content}{$edit_tpl[0].tpl_content}{/if}
                       </textarea>
                    </div>
                </div>

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Template</button>
                 </div>
             </div>
             </form>


            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
{else}
<div class="row">
    <div class="col-md-12">
       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>
</div>

</div>
{/if}
