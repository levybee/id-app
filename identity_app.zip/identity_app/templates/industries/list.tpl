{if $privileges.industries.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Industries</a></li>
     <li class="active"><a href="">List</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>Industries List</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
        <div class="panel panel-default">

            <div class="panel-heading">
                 <h3 class="panel-title">Industries Table</h3>  
                  <ul class="panel-controls panel-controls-title">                                        
                     <li>
                     
                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                             <label>Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">
                                                             
                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}
								  
								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}
								  
								    <option value="1" selected>Page 1</option>
								    
								    
								  {/section}
								
							     </select>
                            
                         </div>                                    
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>                      
                     </li>                                
                     
                 </ul>    
            </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>name</th>
                                <th width="120">actions</th>
                            </tr>
                        </thead>
                        <tbody>   
                           {section name=industry_list loop=$industry_list}                                 
                            <tr>
                                
                                <td class="text-center">{$start+$smarty.section.industry_list.rownum}</td>
                                <td>{$industry_list[industry_list].industry_name}</td>    
                                <td>
                                    <a href="/industries/edit/?id={$industry_list[industry_list].industry_id}" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>
                                    <a href="/industries/delete/?id={$industry_list[industry_list].industry_id}" class="btn btn-danger btn-rounded btn-condensed btn-sm"><span class="fa fa-times"></span></a>
                                </td>
                            </tr>
                           {/section}
                        </tbody>
                    </table>
                </div>                                

            </div>
        </div>                                                

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 

{*

<h1>Industries &gt; List</h1>
<form action="/{$section}/list{if $sort_str}{$sort_str}{/if}" method="post">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td><div align="left"><strong>Displaying {$resultsCount}</strong></div></td>
		<td>
			<div align="right">
			  <select name="page" id="page">
			  {section name=pagination loop=$numPages}
			    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
			  {sectionelse}
			    <option value="1" selected>Page 1</option>
			  {/section}
		      </select>
			  <input name="submit" type="submit" value="Go" class="input_button">
	      </div></td>
	</tr>
</table>
</form>
<br>
<table width="100%"  border="1" cellspacing="0" cellpadding="5" class="table" bordercolor="#000000">
  <tr class="header_row">
    <td width="50"><div align="center"><strong>#</strong></div></td>
    <td><div align="center"><strong>Industry</strong></div></td>
    <td width="100"><div align="center"><strong>Actions</strong></div></td>
  </tr>
  {section name=industry_list loop=$industry_list}
  <tr class="{cycle values='alternate_row_1,alternate_row_2'}">
    <td><div align="center">{$start+$smarty.section.industry_list.rownum}</div></td>
    <td><div align="center">{$industry_list[industry_list].industry_name}</div></td>
    <td><div align="center"><a href="/industries/edit/?id={$industry_list[industry_list].industry_id}"><img src="/images/edit.png" alt="Edit" width="16" height="16" border="0"></a> <a href="/industries/delete/?id={$industry_list[industry_list].industry_id}"><img src="/images/delete.png" alt="Delete" width="16" height="16" border="0"></a></div></td>
  </tr>
  {sectionelse}
  <tr>
  	<td colspan="3">No records available</td>
  </tr>
  {/section}
</table> *}

{/if}
