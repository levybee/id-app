{if $smarty.session.receipt_edit.receipt_type eq 'Quote'}
{include file='receipts/quote_items_edit.tpl'}
{/if}

{if $smarty.session.receipt_edit.receipt_type eq 'Invoice'}
{include file='receipts/invoice_items_edit.tpl'}
{/if}

{if $smarty.session.receipt_edit.receipt_type eq 'Allocation'}
{include file='receipts/allocation_items_edit.tpl'}
{/if}
