
<div id="response2"></div>

<form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Receipt Information</h3>
        </div>

        <div class="panel-body form-group">

            <div class="form-group">

                <label class="col-md-3 col-xs-12 control-label">Date</label>
                <div class="col-md-6 col-xs-12">
                    <div class="input-group">
                        <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                        <input name="receipt_date" type="text" class="form-control datepicker" value="{if $form_data.receipt_date != ''}{$form_data.receipt_date|date_format:'%Y-%m-%d'}{elseif $smarty.session.receipt.step_1.receipt_date}{$smarty.session.receipt.step_1.receipt_date}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" readonly="readonly">
                    </div>

                </div>
            </div>

            <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Company / Group</label>
                <div class="col-md-6 col-xs-12">

                    <select name="group_id" id="group_id"  class="form-control" required  {if $action eq 'edit'} disabled="disabled" {/if} >
                        {if $form_data.group_company != ''}
                            <option value="{$form_data.group_id}">
                                {$form_data.group_company}
                            </option>
                        {/if}
                    </select>

                </div>
            </div>

            <div class="form-group">
               <label class="col-md-3 col-xs-12 control-label">Type</label>
               <div class="col-md-6 col-xs-12">
                 <select name="receipt_type" id="receipt_type" class="form-control" {if $action eq 'edit'} disabled="disabled" {/if} required>
                     <option value="Invoice" {if $smarty.post.receipt_type eq 'Invoice' || $form_data.receipt_type eq 'Invoice' || $smarty.session.receipt.receipt_type eq 'Invoice' || !$smarty.get.type}selected{/if}>Receipt against Invoice</option>
                     <option value="Quote" {if $smarty.post.receipt_type eq 'Quote' || $form_data.receipt_type eq 'Quote' || $smarty.session.receipt.receipt_type eq 'Quote' || $smarty.get.type == 'quote'}selected{/if}>Receipt against Quote</option>
                     <option value="Misceleneous" {if $smarty.post.receipt_type eq 'Misceleneous' || $form_data.receipt_type eq 'Misceleneous' || $smarty.session.receipt.receipt_type eq 'Misceleneous' || $smarty.get.type == 'misc'}selected{/if}>Misceleneous Receipt</option>
                   {* <option value="Allocation" {if $smarty.post.receipt_type eq 'Allocation' || $smarty.session.receipt.receipt_type eq 'Allocation'}selected{/if}>Receipt allocation of advance</option> *}
                 </select>

               </div>
           </div>

              <div class="form-group" id="quote_field" style="{if $smarty.post.receipt_type eq 'Quote' || $form_data.receipt_type eq 'Quote' || $smarty.session.receipt.receipt_type eq 'Quote' || $smarty.get.type == 'quote'}{else}display:none;{/if}">
                   <label class="col-md-3 col-xs-12 control-label">Quote #</label>
                    <div class="col-md-6 col-xs-12">
                     <select name="quote_id" id="quote_id"  class="form-control" style="width:100%;">
                     </select>
                    </div>
               </div>

        

             <div class="form-group">
           <label class="col-md-3 col-xs-12 control-label">Received Via</label>
           <div class="col-md-6 col-xs-12">
               <select name="account_id" id="account_id" class="form-control select" style="width:100%" required>
                 <option value="">Select..</option>
                 {section name=accounts loop=$accounts}
                   <option value="{$accounts[accounts].id}" {if $form_data.account_id eq $accounts[accounts].id || $smarty.post.account_id eq $accounts[accounts].id}selected{/if} data-currency="{$accounts[accounts].currency}">{$accounts[accounts].name}</option>
                 {/section}
             </select>
             <input name="account_name" type="hidden" id="account_name" value="{$form_data.account_name}" />
           </div>
        </div>

            <input name="customer_id" type="hidden" id="customer_id" value="{$form_data.customer_id}" />
            {* <input name="currency" type="hidden" value="TZS" /> *}

             {* <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Customer</label>
                <div class="col-md-6 col-xs-12">

                   <select name="customer_id" id="customer_id" class="form-control">

                           <option value="0">Please Select..</option>

		           </select>



                </div>
            </div> *}

             


           <div class="amount_fields" style="display:none;">

              <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Currency</label>
                <div class="col-md-6 col-xs-12">
                     <select name="currency" id="currency" class="form-control">
				            <option value="TZS"  {if $form_data.receipt_currency eq "TZS" || $smarty.post.currency == 'TZS' || $smarty.session.receipt.step_1.receipt_currency eq "TZS"}selected{/if}>TZS</option>
				        	<option value="USD"  {if $form_data.receipt_currency eq "USD" || $smarty.post.currency == 'USD' || $smarty.session.receipt.step_1.receipt_currency eq "USD"}selected{/if}>USD</option>
				     </select>
                </div>
            </div>
            <div class="form-group contra">
                    <label class="col-md-3 control-label">Exchange Rate</label>
                    <div class="col-md-6">
                      <input type="number" name="exch_rate"  id="exch_rate" class="form-control" step="0.1"  value="{if $smarty.post.exch_rate}{$smarty.post.exch_rate}{else}{$form_data.exch_rate}{/if}" />
                    </div>
               </div>

              <div class="form-group wht">
             <label class="col-md-3 col-xs-12 control-label">WHT %</label>
             <div class="col-md-6 col-xs-12">
                  <select name="wht" id="wht" class="form-control">
                    <option value="">None</option> 
                    <option value="5"  {if $smarty.post.wht eq "5" || $form_data.wht eq "5"}selected{/if}>5%</option>
                   <option value="10"  {if $smarty.post.wht eq "10" || $form_data.wht eq "10"}selected{/if}>10%</option>
                 </select>
             </div>
         </div>  

             <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Amount</label>
                <div class="col-md-6 col-xs-12">

                   <input name="receipt_amount" type="text" class="form-control" value="{if $form_data.total_received}{$form_data.total_received}
{elseif $smarty.session.receipt.receipt_amount}{$smarty.session.receipt.receipt_amount}{else}{$smarty.post.receipt_amount}{/if}" >

                </div>
            </div>

            {* <div class="form-group">
               <label class="col-md-3 col-xs-12 control-label">Bank Account</label>
               <div class="col-md-6 col-xs-12">

                  <input name="bank_account" type="text" class="form-control" value="{if $form_data.bank_account != ''}{$form_data.bank_account}
{elseif $smarty.session.receipt.bank_account}{$smarty.session.receipt.bank_account}{else}{$smarty.post.bank_account}{/if}" >

               </div>
           </div> *}

           </div>


        </div>
        <div class="panel-footer">
            <input name="next_step" type="hidden" id="next_step" value="two" />
            <button type="submit" class="btn btn-primary pull-right">Go to Step 2</button>
        </div>


    </div>
 </form>


 {include file = 'quotes/new_company_modal.tpl'}
