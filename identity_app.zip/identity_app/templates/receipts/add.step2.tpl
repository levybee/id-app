{if $smarty.session.receipt.receipt_type eq 'Quote'}
{include file='receipts/quote_items.tpl'}
{/if}

{if $smarty.session.receipt.receipt_type eq 'Invoice'}
{include file='receipts/invoice_items.tpl'}
{/if}

{if $smarty.session.receipt.receipt_type eq 'Allocation'}
{include file='receipts/allocation_items.tpl'}
{/if}

{if $smarty.session.receipt.receipt_type eq 'Misceleneous'}
{include file='receipts/misc_items.tpl'}
{/if}
