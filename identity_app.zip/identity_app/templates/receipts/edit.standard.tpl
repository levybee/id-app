
{*<div id="summary" class="panel panel-default" style="display:none;">*}
          {**}
		{*<div class="panel-heading">*}
		        {*<h3 class="panel-title">Items</h3>   *}
		{*</div>*}
		{*<div class="panel-body panel-body-table">*}
        {*<div class="table-responsive">*}
                    {*<table class="table table-bordered table-striped table-actions">*}
                        {*<thead>*}
                            {*<tr>*}
                                {*<th width="40">item #</th>*}
                                {*<th>Qty</th>*}
							    {*<th>Description</th>*}
							    {*<th>Unit Price {if $quote_data.currency}({$quote_data.currency}){/if}</th>*}
							    {*<th>Amount {if $quote_data.currency}({$quote_data.currency}){/if}</th>*}
                                {*<th>Delivery Person Name</th>*}
                                {*<th>Delivery Person No.</th>*}
							    {*<th width="50">Actions</th>*}
                            {*</tr>*}
                        {*</thead>*}
                        {*<tbody>*}
                           {*{section name=dn_items loop=$dn_items_data}*}
						  {*<tr>*}
						    {*<td class="text-center">{$smarty.section.dn_items.rownum}</td>*}

						    {*<td>{$dn_items_data[dn_items].quantity}</td>*}

						    {*<td>*}
						    {*{$dn_items_data[dn_items].item_description}*}
						    {*</td>*}

						    {*<td>{$dn_items_data[dn_items].item_price|number_format:0:".":","} </td>*}

						    {*<td>{$dn_items_data[dn_items].item_amount|number_format:0:".":","}</td>*}

                              {*<td>{$dn_items_data[dn_items].delivery_person_name}</td>*}
                              {**}
                              {*<td>{$dn_items_data[dn_items].delivery_person_phone_number}</td>*}

						    {*<td>*}
						      {**}
			                   {*<a title="Delete Delivery Note Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/deliveries/edit/?id={$dn_data.dn_id}&subtask=delete&subid={$smarty.section.dn_items.rownum}"><span class="fa fa-times"></span></a>*}
						     {*</td>*}
						  {**}
						  {*</tr>*}
						  {**}
						  {*{sectionelse}*}
						  {*<tr>*}
						    {*<td colspan="6"><div>No Items have been added to this delivery note yet.</td>*}
						  {*</tr>*}
						  {*{/section}*}

						   {**}
                        {*</tbody>*}
                    {*</table>*}
                   {**}
                {*</div>  *}
	    {**}
  {*</div>*}
	{**}
      {**}
{*</div>*}

<form id="quotes-form" class="form-horizontal" method="post" action="/deliveries/edit?id={$smarty.get.id}&subtask=new">
  <div class="panel panel-default">
      <div class="panel-heading">
          <h3 class="panel-title">Edit Item</h3>
          
      </div>
     
      <div class="panel-body">


          <div class="row">
              <br /> <br />

              <div class="col-md-6">

                  <div class="form-group">
                      <label class="col-md-4 control-label">Delivery Person Name.<span class="asterisk">*</span></label>
                      <div class="col-md-8">

                          <input name="delivery_person_name" type="text" id="delivery_person_name" value="{$dn_data.delivery_person_name}" class="form-control" {if !$smarty.get.edit} disabled {/if}/>
                          {*<input type="hidden" name="item_price" value="{$dn_items[0].item_price}">*}
                          <input type="hidden" name="dn_id" value="{$dn_items[0].dn_id}">
                          <input type="hidden" name="dn_item_id" value="{$dn_items[0].dn_item_id}">

                      </div>
                  </div>


              </div>

          </div>

          <div class="row">
              {if $dn_data.delivery_person_name !== '' && !$smarty.get.edit}
                  <div class="col-md-6" style="float: right;">
                      <a href="/deliveries/edit?id={$smarty.get.id}&edit=true" class="btn btn-default text-center">
                          <i class="fa fa-pencil text-success"></i> Edit</a>
                  </div>
              {/if}
              <br /> <br />

              <div class="col-md-6">

                  <div class="form-group">
                      <label class="col-md-4 control-label">Delivery Person No.<span class="asterisk">*</span></label>
                      <div class="col-md-8">

                          <input name="delivery_person_phone_number" type="text" id="delivery_person_phone_number" value="{$dn_data.delivery_phone_number}" class="form-control" {if !$smarty.get.edit} disabled {/if}/>
                      </div>
                  </div>


              </div>

          </div>

          <div class="row">
              <br /> <br />

              <div class="col-md-6">

                  <div class="form-group">
                      <label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>
                      <div class="col-md-8">

                          <input name="item_quantity" type="text" id="item_quantity" value="{$dn_items[0].quantity|number_format}" class="form-control" />
                      </div>
                  </div>


              </div>

          </div>

         <div class="row">
             <br /> <br />
           
              <div class="col-md-12">
                <div class="form-group">                                        
                      <label class="col-md-2 control-label text-left">Descriptions <span class="asterisk">*</span></label>
                      <div class="col-md-9">
                       <textarea name="item_desc" id="item_notes" class="form-control"  rows="5">{$dn_items[0].description}</textarea>
                       </div>
                 </div>
                  
              </div>
              
              
         </div>

      </div>
      <div class="panel-footer"> 
      <input type="hidden" name="next_step" id="next_step" value="three" />
        <input type="submit" name="add_item" class="btn btn-primary pull-right" value="Save Changes" />
      <!-- <table>
  <tr>
    <td width="150"><label> <input type="hidden" name="next_step" id="next_step" value="three" />
      <input name="next_step_info" type="radio" id="next_step_info_0" value="three_a" checked="checked" />
      Add Another Item</label></td>
    <td width="150"><input type="radio" name="next_step_info" value="three_b" id="next_step_info_1" />
Add &amp; Print</td>
    <td width="150"><input type="radio" name="next_step_info" value="three_c" id="next_step_info_2" />
Ignore &amp; Print</td>
    <td><div align="center">
      <button type="submit" name="Submit" class="btn btn-primary pull-right">Proceed</button>
    </div></td>
  </tr>
</table>       -->               
          
      </div>
  </div>
  </form>