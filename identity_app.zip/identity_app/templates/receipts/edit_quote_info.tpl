<div class="panel panel-default">
          
       <div class="panel-heading">
            <h3 class="panel-title">Delivery note Information</h3>
			 </div>
			 <div class="panel-body panel-body-table">
			
			   <div class="table-responsive">
			     <table class="table table-striped">
			       <tr>
					    <td colspan="2"><div><strong>REF #</strong></div>
					     <div>{$dn_data.dn_date_created|substr:0:4}-{$dn_data.dn_date_created|substr:5:2}-{$dn_data.dn_id|leading_zero:5}</div>
					    </td>
					    
					  </tr>
					  <tr>
					    <td colspan="2"><div><strong>Delivery Date</strong></div>
					      <div>{$dn_data.dn_date_created|date_format:"%d/%m/%Y"}</div>
					    </td>
					    
					  </tr>
					  <tr>
					    <td colspan="2"><div><strong>Customer</strong></div>
					      <div>
						    {$dn_data.customer_fname} {$dn_data.customer_lname}<br />
						    {$dn_data.group_company}<br />
						    {$dn_data.customer_address}<br />
						    {$dn_data.customer_city},
								{$dn_data.customer_country}<br />
						    <br />
						    Phone: {$dn_data.customer_phone}<br />
						    Fax: {$dn_data.customer_fax}<br />
						    Mobile: {$dn_data.customer_mobile}<br />
						    Email: {$dn_data.customer_email}

					    </div>
					    
					    </td>

                     <tr>
                         <td colspan="2"><div><strong>Job #</strong></div>
                             <div>{$dn_data.job_id}</div>
                         </td>

                     </tr>

                     <tr>
                         <td colspan="2"><div><strong>Delivery Person Name</strong></div>
                             <div>{$dn_data.delivery_person_name}</div>
                         </td>

                     </tr>

                     <tr>
                         <td colspan="2"><div><strong>Phone Number</strong></div>
                             <div>{$dn_data.delivery_phone_number}</div>
                         </td>

                     </tr>
					    
					  </tr>
					  
			   {if $step neq 'two'}		  
			    <tr>
			    <td colspan="2"><div><strong>Show Details</strong>&nbsp;&nbsp;
			       <input type="checkbox" name="show_summary" id="show_summary" value="Y" onclick="show_summary(this);" checked />
			    </div>
			    </td>
			  </tr>
			 {/if} 
			  
             </table> 
             
             
             
                    
           </div>
          </div>     
      
</div>