{if $privileges.receipts.view}

    <!-- START BREADCRUMB -->

    <ul class="breadcrumb">

        <li><a href="/">Home</a></li>

<li><a href="/receipts/{if $receipt_info[0].receipt_type == 'Quote'}exempt{else}list{/if}">Receipts</a></li>

        <li class="active"><a href="#"> &nbsp; Receipt

                #{$receipt_info[0].receipt_date|substr:0:4}-{$receipt_info[0].receipt_date|substr:5:2}-{$receipt_info[0].receipt_id|leading_zero:5}</a></li>

    </ul>



    <!-- END BREADCRUMB -->

    <div class="page-title">

        <h2>
            <span class="fa fa-arrow-circle-o-left"></span>Receipt
            #{$receipt_info[0].receipt_date|substr:0:4}-{$receipt_info[0].receipt_date|substr:5:2}-{$receipt_info[0].receipt_id|leading_zero:5}

        </h2>

        <ul class="panel-controls fa panel-controls-title">
            {*<li class="btn btn-default btn-success"><a href="/receipts/add?id={$receipt_info[0].job_id}&d{$receipt_info[0].receipt_date|date_format:"%d-%m-%Y"}&co={$receipt_info[0].group_company}&cu={$receipt_info[0].customer_fname} {$receipt_info[0].customer_lname} {$receipt_info[0].customer_email}&dpno={$receipt_info[0].delivery_phone_number}&dpn={$receipt_info[0].delivery_person_name}&cid={$receipt_info[0].customer_id}" style="color: #fff;border:none;"> New Receipt</a></li>*}

             {if $receipt_info[0].status eq 'Valid'}
             <li><a class="btn btn-default" title="Edit" target="_blank" href="/receipts/print?id={$receipt_info[0].receipt_id}"><span class="fa fa-print text-success"></span><b>Print</b></a></li>
             <li><a class="btn btn-default" title="Edit" href="/receipts/edit?id={$receipt_info[0].receipt_id}"><span class="fa fa-pencil text-success"></span><b>Edit</b></a></li>
             <li><a class="btn btn-default" title="Cancel" href="/receipts/view?id={$receipt_info[0].receipt_id}&actn=cancel" onclick="confirmAction('Cancell  Receipt. Are you sure?', this.href); return false;"><span class="fa fa-times text-danger"></span><b>Cancel</b></a></li>

            {/if}

             {* <li><a class="btn btn-default" title="View PDF" href="/receipts/print?uid={$receipt_info[0].receipt_id}"  class="fa fa-file-pdf-o text"></span>PDF</a></li> *}


            {* <li><a class="delb btn btn-danger" onclick="return false;" title="Delete This Receipt Note" style="color:#fff;"   href="/receipts/view?delete&id={$receipt_info[0].receipt_id}"><span
                                class="fa fa-times"></span><b>Delete</b></a></li> *}
        </ul>

    </div>
    <!-- PAGE CONTENT WRAPPER -->



    <div class="page-content-wrap">

        <div class="row">
            {if $message}
                 <div class="col-md-12">
                     <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">

                        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>

                        {$message}

                    </div>

                 </div>

                {/if}

            <div class="col-md-3">


                <div class="panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">Receipt Information</h3>


                    </div>



                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">



                            <table class="table pad-10 table-striped">



                                <tr>

                                    <td colspan="2">


                                        <div><strong>Receipt #</strong></div>

                                        <div>{$receipt_info[0].receipt_date|substr:0:4}-{$receipt_info[0].receipt_date|substr:5:2}-{$receipt_info[0].receipt_id|leading_zero:5}</div>

                                    </td>

                                </tr>

                                <tr>



                                    <td colspan="2">

                                        <div><strong>Date</strong></div>

                                        <div>{$receipt_info[0].receipt_date|date_format:"%d %B %Y"}</div>

                                    </td>

                                </tr>

                                <tr>

                                    <td colspan="2"><div><strong>Customer</strong></div>

                                        <div>

                                            {if $receipt_info[0].customer_fname}{$receipt_info[0].customer_fname} {$receipt_info[0].customer_lname}<br />{/if}



                                            {if $receipt_info[0].group_company}{$receipt_info[0].group_company}<br />{/if}



                                            {if $receipt_info[0].customer_address}{$receipt_info[0].customer_address}<br />{/if}



                                            {if $receipt_info[0].customer_city}{$receipt_info[0].customer_city}, {/if}{if $receipt_info[0].customer_country}{$receipt_info[0].customer_country}{/if}<br />

                                            <br />


                                            {if $receipt_info[0].customer_phone}Phone: {$receipt_info[0].customer_phone}<br />{/if}



                                            {if $receipt_info[0].customer_fax}Fax: {$receipt_info[0].customer_fax}<br />{/if}



                                            {if $receipt_info[0].customer_mobile}Mobile: {$receipt_info[0].customer_mobile}<br />{/if}



                                            {if $receipt_info[0].customer_email}Email: {$receipt_info[0].customer_email}{/if}

                                        </div>

                                    </td>

                                </tr>




                                <tr>
                                    <td colspan="2"><div><strong>Amount Received</strong></div>
                                        <div>{$receipt_info[0].total_received|number_format:2:".":","} {$receipt_info[0].receipt_currency}</div>
                                    </td>
                                </tr>
                                 {if $receipt_info[0].wht}
                                <tr>
                                    <td colspan="2"><div><strong>WHT</strong></div>
                                        <div>{$receipt_info[0].wht}%</div>
                                    </td>
                                </tr>
                                <tr>
                                {/if}

                                {if $receipt_info[0].account_name}
                                <tr>
                                    <td colspan="2"><div><strong>Bank Account</strong></div>
                                        <div>{$receipt_info[0].account_name}</div>
                                    </td>
                                </tr>
                                <tr>
                                {/if}



                                    <td colspan="2">

                                        <div><strong>Status</strong></div>

                                        <div>{$receipt_info[0].status}</div>

                                    </td>

                                </tr>

                            </table>

                        </div>

                    </div>

                </div>


            </div>

            <div class="col-md-9">



                <div class="panel panel-default">

                    <div class="panel-heading">

                        <h3 class="panel-title">Items</h3>

                    </div>



                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">

                           {if $receipt_info[0].receipt_type != 'Misceleneous'}

                            <table class="table pad-10 table-bordered table-striped table-actions">



                                <thead>

                                <tr>

                                    <th width="40" class="text-center">{if $receipt_info[0].receipt_type == 'Invoice'}Inv # {else} Quote #{/if}</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center">Amount Paid</th>
                                    <th class="text-center">Balance</th>

                                </tr>

                                </thead>

                                <tbody>

                                {section name=items loop=$receipt_items}

                                    <tr>

                                        <td class="text-center">
                                          {if $receipt_info[0].receipt_type == 'Invoice'}
                                          TI/{$receipt_items[items].invoice_date|substr:0:4}/{$receipt_items[items].invoice_id}
                                          {else}
                                          {$receipt_items[items].quote_date|substr:0:4}-{$receipt_items[items].quote_date|substr:5:2}-{$receipt_items[items].quote_id|leading_zero:5}
                                          {/if}
                                        </td>
                                        <td class="text-right">
                                          {if $receipt_info[0].receipt_type == 'Invoice'}
                                        {$receipt_items[items].invoice_amount|number_format:2:".":","}
                                        {else}
                                        {$receipt_items[items].quote_amount|number_format:2:".":","}
                                        {/if}
                                      </td>
                                        <td class="text-right">{$receipt_items[items].item_amount|number_format:2:".":","}</td>
                                        <td class="text-right">{$receipt_items[items].balance|number_format:2:".":","}</td>

                                    </tr>


                                {/section}

                                <tr>

                                    <th class="text-left"><strong>Total</strong></th>
                                    <th class="text-right">{$receipt_info[0].receipt_currency}
                                    {if $receipt_info[0].receipt_type == 'Invoice'}
                                    {$invoice_amount_total|number_format:2:".":","}
                                    {else}
                                    {$quote_amount_total|number_format:2:".":","}
                                    {/if}
                                   </th>
                                    <th class="text-right">{$receipt_info[0].receipt_currency} {$receipt_amount_total|number_format:2:".":","}</th>
                                    <th class="text-center">&nbsp;</th>

                                </tr>
                                <tr>

                                    <th class="text-left" colspan="2"><strong>On Account</strong></th>
                                    <th class="text-right">{$receipt_info[0].receipt_currency} {$on_account|number_format:2:".":","}</th>
                                    <th class="text-center">&nbsp;</th>

                                </tr>

                                </tbody>

                            </table>
                            {else}
                            <table class="table table-bordered table-striped table-actions">
                                <thead>

                                    {* <tr>
                                        <th class="text-center" width="40"></th>
                                    </tr> *}

                                </thead>
                                <tbody>

                      <tr>
                        <td><div>No items available.</td>
                      </tr>

                                </tbody>
                            </table>
                            {/if}

                        </div>

                    </div>



                </div>




    </div>
    </div>

    </div>


    <!-- END PAGE CONTENT WRAPPER -->

    </div>



    <!-- END PAGE CONTENT -->


    </div>



    <!-- END PAGE CONTAINER -->



    {else}



    <div class="row">



        <div class="col-md-12">



            <div class="panel panel-default">





                <div class="alert alert-danger" role="alert">



                    <button type="button" class="close" data-dismiss="alert">



                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>



                    </button>



                    You are not authorized to view this section



                </div>





            </div>







        </div>





    </div>





{/if}
