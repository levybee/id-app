{if $privileges.receipts.exempt}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Receipts</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Exempt Receipts</h2>
</div>

    <a href="/receipts/add?type=quote" class="btn btn-default"  style="margin-left: 20px;"> New Exempt Receipt</a>
    <br></br>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

             <div class="col-md-12" style="margin-bottom:10px;">

               <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/receipts/exempt?page=1" class="btn btn-default">Clear</a>  | Filter By Status: <a href="/receipts/exempt?page=1{if $search_str}&{$search_str}{/if}" class="btn {if !$smarty.get.fby_param}btn-success{/if} btn-flat btn-rad">All</a>

                 <a href="/receipts/exempt?page=1&filter=1&fby=status&fby_param=Valid{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Valid'}btn-success{else}btn-default{/if}">Valid</a>

                 <a href="/receipts/exempt?page=1&filter=1&fby=status&fby_param=Cancelled{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled</a>

                 {include file='search/mini.receipt.tpl'}
     		</div>



        <div class="panel panel-default">

            <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/receipts/exempt{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/receipts/exempt{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                          {* if $privileges.jobs.listprint}
					         <a href="/receipts/print?popup=1&print=1&page=*{if $search_str}&{$search_str}{/if}" onClick="popupURL(this.href, 'QuotesList', 800, 500); return false;">
					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
					         </a>
					      {/if *}

                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">


                <div class="table-responsive">

                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th>Ref #</th>
							    <th class="text-center">Date</th>
							    <th class="text-center">Customer</th>
                  <th class="text-center">Received Via</th>
							    <th class="text-center">Quote Amount</th>
                  <th class="text-center">Amount Received</th>
							    <th class="text-center">Receipt Amount</th>
                  <th class="text-center">On Account</th>
                  <th class="text-center">Status</th>
							    <th width="50">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=receipt_list loop=$receipt_list}
						  <tr>
                            <td><a title="View Receipt" href="/receipts/view/?id={$receipt_list[receipt_list].receipt_id}"  alt="View Receipt">{$receipt_list[receipt_list].receipt_date|substr:0:4}-{$receipt_list[receipt_list].receipt_date|substr:5:2}-{$receipt_list[receipt_list].receipt_id|leading_zero:5}</a></td>

						    <td class="text-center">{$receipt_list[receipt_list].receipt_date|date_format:"%d %B %Y"}</td>

						    <td class="text-center">{$receipt_list[receipt_list].group_company}</td>
                <td class="text-center">{$receipt_list[receipt_list].account_name}
                  {if $receipt_list[receipt_list].account_no} - {$receipt_list[receipt_list].account_no}{/if}
                </td>
						    <td class="text-center">
                {$receipt_list[receipt_list].receipt_currency}
                {if $receipt_list[receipt_list].receipt_type == 'Invoice'}
                {$receipt_list[receipt_list].receipt_info.invoice_amount_total|number_format:2:".":"," }
                {else}
                {$receipt_list[receipt_list].receipt_info.quote_amount_total|number_format:2:".":"," }
                {/if}
              </td>
                <td class="text-center">{$receipt_list[receipt_list].receipt_currency} {$receipt_list[receipt_list].receipt_info.receipt_amount_total|number_format:2:".":"," }</td>
						    <td class="text-right">{$receipt_list[receipt_list].receipt_currency} {$receipt_list[receipt_list].total_received|number_format:2:".":"," }</td>
                <td class="text-right">{$receipt_list[receipt_list].receipt_currency} {$receipt_list[receipt_list].on_account|number_format:2:".":"," }</td>

                <td class="text-center {if $receipt_list[receipt_list].status eq 'Cancelled'}text-danger{else}text-success{/if}">{$receipt_list[receipt_list].status}</td>

						    <td class="text-center">

                                <a title="View Receipt" href="/receipts/view/?id={$receipt_list[receipt_list].receipt_id}"  alt="View Receipt" width="16" height="16" border="0" class="btn btn-success btn-flat btn-rad"> View</a>

                            </td>

						  </tr>

              <tr>
                <td colspan="10">
                   <table width="100%">
                     <tr>
                       <th>&nbsp;</th>
                       <th>Quote ID</th>
                       <th>Amount</th>
                       <th>Amount Paid</th>
                       <th>Balance</th>
                       <th>&nbsp;</th>
                     </tr>
                     {section name=items loop=$receipt_list[receipt_list].receipt_info.receipt_items}
                     <tr>
                      <td>&nbsp;</td>
                       <td>
                        {$receipt_list[receipt_list].receipt_info.receipt_items[items].quote_date|substr:0:4}-{$receipt_list[receipt_list].receipt_info.receipt_items[items].quote_date|substr:5:2}-{$receipt_list[receipt_list].receipt_info.receipt_items[items].quote_id|leading_zero:5}
                       </td>
                       <td>

                       {$receipt_list[receipt_list].receipt_info.receipt_items[items].quote_amount|number_format:2:".":","}

                     </td>
                       <td>{$receipt_list[receipt_list].receipt_info.receipt_items[items].total_received|number_format:2:".":","}</td>
                       <td>{$receipt_list[receipt_list].receipt_info.receipt_items[items].balance|number_format:2:".":","}</td>
                       <td>&nbsp;</td>
                     </tr>
                      {sectionelse}
                      <tr>
                        <td colspan="6">No items found</td>
                      </tr>
                     {/section}


                   </table>
                </td>
              </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="10"><div align="center">No records found.</td>
						  </tr>
						 {/section}
                        </tbody>
                    </table>

                    {if $smarty.get.debug eq 'rl'}
                    <pre>{$receipt_list|@print_r}</pre>
                    {/if}

                </div>


            </div>
             <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/receipts/exempt{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/receipts/exempt{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>

                 </ul>
            </div>

        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
