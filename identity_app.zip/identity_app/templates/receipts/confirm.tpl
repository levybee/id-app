 

{if $privileges.deliveries.confirm}

<ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/quotes/list">Quotes</a></li>
     <li class="active"><a href="">Confirm Quote</a></li>
	 </ul>
	 <!-- END BREADCRUMB -->
	 <div class="page-title">                    
	    <h2><span class="fa fa-arrow-circle-o-left"></span>Confirm Quote - Step {$step|capitalize}</h2>
	</div>

   
    <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
        {/if}
        	   
	    
	     <div class="col-md-3">
	     <div class="panel panel-default">
	       <div class="panel-body panel-body-table">
	       
	          <table border="0" width="100%" cellpadding="5" cellspacing="0" id="progress_bar">
	          <thead>
	          <tr>
	            <th width="50%"  class="step {if $step eq 'one'}current{/if}" >Step 1</th>
	            <th width="50%"  class="step {if $step eq 'two'}current{/if}" >Step 2</th>
	          </tr>
	         
	          </thead>
	          <tbody>
	            <tr>
		            <td class="progress_information">Add Details</td>
                    <td class="progress_information">Finish</td>
	            </tr>
	            
		          
	           </tbody>
	         </table>
	       </div>
	     
	     </div>
	     
	   </div>
	   
	   <div class="col-md-9">
	        {if $step eq 'one'}
				{include file='quotes/confirm.step1.tpl'}
			{/if}
			{if $step eq 'two'}
				{include file='quotes/confirm.step2.tpl'}
			{/if}
	   </div>                                           

    </div>
  </div>
 </div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{/if}