<div class="modal" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
            class="sr-only">Close</span></button>
        <h4 class="modal-title" id="defModalHead">Confirm Payout <span class="item_confirm_name"></span></h4>
      </div>
      <form id="confirm_form" name="confirm_form" method="post" action="" class="form-horizontal"
        enctype="multipart/form-data">
        <div class="modal-body">
          <div id="confirmResponse"></div>
          <div class="panel panel-default"
            style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
            <div class="panel-body form-group">
              <div class="row">
                <div class="form-group">
                  <label>Reference</label>
                  <textarea name="remarks" rows= "1" class="form-control" required></textarea>
                </div>
              </div>
            </div>
          </div>
          </div>
          <div class="modal-footer">
          <input type="hidden" name="confirm_ec_id" value="">
          <input type="submit" name="confirm_submit" class="btn btn-primary" value="Submit">
          </div>
      </form>

    </div>
  </div>
</div>
