<div class="panel panel-default">
	       <div class="panel-body">
	       {if !$error_message}
	         <h3>Saved!</h3>
			   <p>You have successfully created a new receipt. <br /> </p>


	       {else}
	         <div class="alert alert-danger" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$error_message}
             </div>

	        {/if}

	       </div>

	     </div>


{* include file='quotes/mail.tpl' *}
	     {**}
{*{if $dn_id}	     *}
{*<div class="panel panel-default">*}
 {*<div class="panel-body">	*}
   {*<iframe style="width:100%;" height="500" src="/deliveries/print?uid={$dn_id}"></iframe>     *}
 {*</div>*}
{*</div>*}
{*{/if} *}
