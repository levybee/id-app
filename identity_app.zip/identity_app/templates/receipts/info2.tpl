<div class="panel panel-default">

       <div class="panel-heading">
            <h3 class="panel-title">Receipt Information</h3>
			 </div>
			 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">
		     
			  <tr>
			    <td colspan="2"><div><strong>Customer</strong></div>

			     <div>{$data.customer_information.customer_fname} {$data.customer_information.customer_lname}<br />
			    {$data.customer_information.group_company}<br />
			    {$data.customer_information.customer_address}<br />
			    {$data.customer_information.customer_city},
					 {$data.customer_information.customer_country}<br />
			    <br />
			    Phone: {$data.customer_information.customer_phone}<br />
			    Fax: {$data.customer_information.customer_fax}<br />
			    Mobile: {$data.customer_information.customer_mobile}<br />
			    Email: {$data.customer_information.customer_email}</div>

			    </td>

			  </tr>


             </table>


           </div>
          </div>


</div>