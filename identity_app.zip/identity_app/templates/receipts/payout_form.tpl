<!-- NEW COMPANY MODAL -->
  <div class="modal" id="payoutModal"  role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Float Payout</h4>
              </div>
              <form id="payout_form" name="payout_form" method="post" action="/receipts/exempt_float" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="payoutResponse"></div>
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
			            <div class="panel-body form-group">
			              <div class="row">
			               <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Amount</label>
									    <div class="col-md-6 col-xs-12">
									     <input name="amount" type="text" value="" class="form-control" />
									    </div>
									  </div>
									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Paid To</label>
									    <div class="col-md-6 col-xs-12">
									    <input name="paid_to" type="text" value="" class="form-control" />
                      </div>
									    </div>

                      <div class="form-group">
  									    <label class="col-md-3 col-xs-12 control-label">Remarks</label>
  									    <div class="col-md-6 col-xs-12">
  									      <textarea name="remarks" rows="3" class="form-control"></textarea>
                        </div>
  									  </div>
									     </div>
                       </div>
			                 </div>
			             </div>
                     <div class="modal-footer">
                       <input type="hidden" name="payout" value="1" >
                       <input type="submit" name="payout_submit" class="btn btn-primary payout_submit" value="Submit">
                       <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                     </div>

	              </div>

              </form>

          </div>
      </div>
  </div>
