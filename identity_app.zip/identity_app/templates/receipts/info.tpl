<div class="panel panel-default">

       <div class="panel-heading">
          <h3 class="panel-title">Receipt Info</h3>
	 </div>
	 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">

			  <tr>
			    <td colspan="2"><div><strong>Customer</strong></div>

			     <div>{$smarty.session.receipt.customer_information.customer_fname} {$smarty.session.receipt.customer_information.customer_lname}<br />
			    {$smarty.session.receipt.customer_information.group_company}<br />
			    {$smarty.session.receipt.customer_information.customer_address}<br />
			    {$smarty.session.receipt.customer_information.customer_city}, {$smarty.session.receipt.customer_information.customer_country}<br />
			    <br />
			    Phone: {$smarty.session.receipt.customer_information.customer_phone}<br />
			    Fax: {$smarty.session.receipt.customer_information.customer_fax}<br />
			    Mobile: {$smarty.session.receipt.customer_information.customer_mobile}<br />
			    Email: {$smarty.session.receipt.customer_information.customer_email}</div>

			    </td>

			  </tr>

			    <tr>
			    <td colspan="2"><div><strong>Amount</strong></div>
			        <div>{$smarty.session.receipt.amount|number_format:2:".":","} {$smarty.session.receipt.receipt_currency}</div>
			    </td>

			  </tr>

			   {if $smarty.session.receipt.wht}
				 <tr>
					<td colspan="2"><div><strong>WHT</strong></div>
						<div>{$smarty.session.receipt.wht}%</div>
					</td>

				</tr>
              {/if}

			  {if $smarty.session.receipt.exch_rate}
				 <tr>
					<td colspan="2"><div><strong>Exchange Rate</strong></div>
						<div>{$smarty.session.receipt.exch_rate|number_format:2:".":","}</div>
					</td>

				</tr>
              {/if}

        <tr>
        <td colspan="2"><div><strong>Bank Account</strong></div>
            <div>{$smarty.session.receipt.bank_account}</div>
        </td>

      </tr>

			  <!-- <tr>
			    <td colspan="2"><div><strong>Show Details</strong>    <input type="checkbox" name="show_summary" id="show_summary" value="Y" checked="checked" onclick="show_summary(this);" /></div></td>
			  </tr> -->
             </table>

           </div>
       </div>


</div>
