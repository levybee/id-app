<form method="post" action="/receipts/edit?id={$smarty.get.id}" id="subm">

<div class="panel panel-default">

       <input type="hidden" id="receipt_type" value="$smarty.session.receipt_edit.receipt_type">

       <div class="panel-heading">
		        <h3 class="panel-title">Invoice Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table pad-7 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th class="text-center" width="40">Inv #</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Inv Total ({$smarty.session.receipt_edit.receipt_currency})</th>
							    <th class="text-center">Received ({$smarty.session.receipt_edit.receipt_currency})</th>
							    <th class="text-center">Balance ({$smarty.session.receipt_edit.receipt_currency})</th>
							    <th class="text-center">Allocation ({$smarty.session.receipt_edit.receipt_currency})</th>

                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.receipt_edit.invoice_items}
						  <tr>
						    <td class="text-center">TI/{$smarty.session.receipt_edit.invoice_items[items].invoice_date|substr:0:4}/{$smarty.session.receipt_edit.invoice_items[items].invoice_id}</td>
                <td class="text-right">{$smarty.session.receipt_edit.invoice_items[items].invoice_date|date_format:"%d/%m/%Y"}</td>
                <td class="text-right">{$smarty.session.receipt_edit.invoice_items[items].invoice_amount|number_format:2:".":","}</td>
						    <td class="text-right received{$smarty.section.items.rownum}">{$smarty.session.receipt_edit.invoice_items[items].amount_received|number_format:2:".":","}</td>

						    <td class="text-right balance{$smarty.section.items.rownum}">{$smarty.session.receipt_edit.invoice_items[items].balance|number_format:2:".":","}</td>
						    <td><input type="text" data-received-id="received{$smarty.section.items.rownum}"
                  data-balance-id="balance{$smarty.section.items.rownum}"
                  id="allocation_{$smarty.section.items.rownum}"
                  name="allocation[{$smarty.session.receipt_edit.invoice_items[items].invoice_id}]"
                  value="{if $smarty.session.receipt_edit.invoice_items[items].amount_received gt 0}{$smarty.session.receipt_edit.invoice_items[items].amount_received}{/if}"
                  class="form-control receipt_val">
                </td>
						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="7"><div>No Invoice items available.</td>
						  </tr>
						  {/section}

						  {if $smarty.session.receipt_edit.invoice_items|@count > 0}
						    <tr>
                                <th colspan="2" class="text-right"><strong>TOTAL</strong></th>
                                <th class="text-right"> <div id="invoice_total">{$smarty.session.receipt_edit.invoice_total|number_format:2:".":","}</div> </th>
                                <th class="text-right"> <div id="amount_received_total">{$smarty.session.receipt_edit.amount_received_total|number_format:2:".":","}</div> </th>
                                <th class="text-right"> <div id="balance_total">{$smarty.session.receipt_edit.balance_total|number_format:2:".":","}</div> </th>
                                <th class="text-right"> <div id="allocation_total">0</div> </th>
                                <input type="hidden" name="allocation_total" value="0" >
                            </tr>
						  {/if}

                        </tbody>
                    </table>

                    {if $smarty.get.debug eq 'lev'}
                     <pre> {$smarty.session.receipt_edit|@print_r}</pre>

                    {/if}

                </div>




  </div>
    <div class="panel-footer">
      <div class="row">

        <div class="form-group col-sm-6">

            {* <label class="col-sm-4 control-label">Receipt Amount</label>
            <div class="col-sm-6">
                <input type="text" name="total_received" class="form-control" value="{$smarty.session.receipt_edit.total_received}" />
            </div> *}
        </div>
        <div class="form-group col-sm-6">
          <input type="hidden" name="next_step" value="three" />
          <input type="submit" name="complete" value="Submit" class="btn btn-success pull-right"  />
        </div>

      </div>


    </div>



</div>

  </form>
