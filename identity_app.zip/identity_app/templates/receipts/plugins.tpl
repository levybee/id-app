<!-- PAGE PLUGINS -->
       <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
       <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
       <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>
       <script type="text/javascript" src="/js/plugins/star-rating/jquery.rating.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
       <script type="text/javascript" src="/js/jquery/jquery.livequery.min.js"></script>
       <script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>
       <script type="text/javascript" src="/js/jquery/relcopy.js"></script>
       <script type="text/javascript" src="/js/new_company_ajax.js"></script>


       <script type='text/javascript' src='/js/plugins/jquery-validation/jquery.validate.js'></script>




{literal}

<script type="text/javascript">


 // Add New Company Form
 $('.close_company_form').on('click', function(e){

   $('#new_company_form').modal('hide');

 });

 // Quote field
 $("#quote_id").select2({
   placeholder: "Type Quote ID to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/quotes.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

           var group_id = $('#group_id').val();
           var customer_id = $('#customer_id').val();

             return {
                 q: params.term, // search term
                 customer_id: customer_id,
               //  status: "'Approved','Confirmed'",
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       //console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $("#group_id").select2({
   placeholder: "Type to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/customers_group.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
     //	console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $('#group_id').on('change', function (e) {
    //console.log('Company Select: ' + $(this).val());

    if($(this).val() == -1){

      //$('#new_company_form').css('display','block');
      $('#new_company_form').modal('show');

    }

      if($(this).val() > 1){

      console.log('Company Select2....', $(this).select2('data'));
      var d = $(this).select2('data')[0],
        sel = d.cf_name+" "+d.cl_name+" ["+d.ce+"]";
        $("#customer_id").val(d.customer_id);

        if(d.credit_terms == 0){
          $('#receipt_type').val('Quote');
          $('#quote_field').show();
         }



      //    $("#job_no").removeAttr('disabled');

    //  $("#customer_id").val("<option value='"+d.customer_id+"' selected>"+sel+"</option>");


          // var newOption = new Option(d.job_info, d.job_id, true, true);
          // $("#job_no").append(newOption).trigger('change');

      }

 });


 // Receipts Type field
 amount_fields = function(type){

       if(type == 'Allocation'){

         $('.amount_fields').hide();
         $('#receipt_amount').val('');

   }else{

     $('.amount_fields').show();
   }

 }




 amount_fields($('#receipt_type').val());

 $('#receipt_type').on('change', function (e) {

   amount_fields($(this).val());
   if($(this).val() == 'Quote'){
     $('#quote_field').show();
   }else{
      $('#quote_field').hide();
   }

 });

 $('#account_id').on('change', function(e){

   var account_name = $('#account_id option:selected').text();
   $('#account_name').val(account_name);
   var currency = $(this).find(':selected').data('currency');
     $('#currency').val(currency);

 });


 allocation_submit = function(){


   // Totals are not return
       if(parseFloat($("input[name='receipts_total']").val()) != parseFloat($("input[name='allocation_total']").val())){

     alert('Allocation Total must be equal to Receipts Total');
         return false;

   }else{

     document.getElementById("allocation_form").submit();
   }


 }

 // Type "Receipt Allocation of Advance"

 var receipts_total = parseFloat($('#receipts_total').text());

 $('.receipts_check').on('change', function (e) {

   console.log('change', $(this).val());
   var checked_val = parseFloat($(this).val());

   if ( $(this).is(':checked') ) {

     receipts_total += checked_val;

   }else{

           if(receipts_total > 0){

             receipts_total -= checked_val;

     }
   }

   $('#receipts_total').text(formatNumber(receipts_total));
   $("input[name='receipts_total']").val(receipts_total);

 });

 calc_allocation_total();


 $(".receipt_val").keyup(function(){

   // Validate value - should be <= balance
   var balance_id = $(this).data('balance-id');
   var balance = parseFloat($('.'+balance_id).text().replace(/,/g, ''));

   var received_id = $(this).data('received-id');
   var received = parseFloat($('.'+received_id).text().replace(/,/g, ''));

   // if receipt_val > balance, reduce it
   var allocation = balance + received;
   if($(this).val() > allocation){

     alert('Allocation amount cannot be greater than the invoice amount');
     allocation_val = (received > 0)? received : balance ;
     $(this).val(allocation_val);

   }


   if(!isNaN($(this).val())){

   calc_allocation_total();

   }else{

     alert('Allocation amount must be a number');

     var  value =  $(this).val();
     $(this).val(
         function(index, value){
             return value.substr(0, value.length - 1);
     });
   }

   validate_totals();

 });

 function calc_allocation_total(){

   var allocation_total = 0;

   $('.receipt_val').each(function($index){

     if($(this).val() > 0){
       allocation_total += parseFloat($(this).val());
     }

   });

   $('#allocation_total').text(formatNumber(allocation_total));
   $("input[name='allocation_total']").val(allocation_total);
   validate_totals();


 }

 function validate_totals(){

       if(parseFloat($("input[name='receipts_total']").val()) != parseFloat($("input[name='allocation_total']").val())){

     $('#allocation_total').css('color', 'red');

   }else{

     $('#allocation_total').css('color', 'green');
   }

 }

 function formatNumber(num) {
   return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
 }


 // Exempt Float
 $('.reconcileBtn').on('click', function(e) {
   e.preventDefault();
   $('#reconcileModal').modal('show');
 });

 $('.payoutBtn').on('click', function(e) {
   e.preventDefault();
   $('#payoutModal').modal('show');
 });

 $('#payout_form').submit(function(e){
       e.preventDefault();
       submit_form('#payout_form', 'payout_submit', '#payoutResponse', '#payoutModal');
 });

 $('.confirmBtn').on('click', function(e) {

   e.preventDefault();
   $('#confirmModal').modal('show');
     $('.item_confirm_name').text(' #'+ $(this).data('item-id'));
     $('input[name="confirm_id"]').val($(this).data('item-id'));

 });

 $('#reconcile_form').submit(function(e){
       e.preventDefault();
       submit_form('#reconcile_form', 'reconcile_submit', '#reconcileResponse', '#reconcileModal');
 });

 var submit_form = function(form_name, btn_name, response_element='', modal_element=''){

   $('input[name="'+ btn_name +'"]').val('Sending...').attr('disabled','disabled');

   var post_url = $(form_name).attr('action');
   var post_data = $(form_name).serialize();
   $.ajax({
     type: 'POST',
     url: post_url,
     data: post_data,
     dataType:'json',
     success	:	function(data){

          var alert_class = (data.error == true)? 'danger' : 'success';

          var msg_html = "<ul>";
          $.each(data.msg, function(i, item) {
            msg_html += "<li>"+ data.msg[i] +"</li>";
         });
          msg_html += "</ul>";


          $('input[name="'+ btn_name +'"]').val('Submit').removeAttr('disabled');

            $(response_element).html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

            if(data.error == false){

              $(form_name).reset();

              setTimeout(function(){
                 $(modal_element).modal('hide');
                 location.reload();

             },5000);

            }

       },
       error : function(XMLHttpRequest, textStatus,
           errorThrown) {

         console.log("Status: " + textStatus);
         console.log("Error: " + errorThrown);

       }


   });



 }


</script>
{/literal}


<!-- END PAGE PLUGINS -->
