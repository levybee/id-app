<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Receipt</title>

<style>
{include file="css/print.css"}
</style>
</head>
<body>
 <!-- pdf-header  -->
  <header>
  <table class="table pdf-header" style="padding-top:0;">
    <tr>
      <td>
        <h1>Receipt of Payment</h1>
      </td>
    <tr>
    <td style="padding-top:25px;">
        <table class="head" width="100%">
         <thead>
          <tr>
            <th width="20%">Rcpt No</th>
            <th width="20%">Date</th>
            <th width="20%">From</th>
            <th width="20%">Amount</th>
          </tr>
         </thead>
            <tbody>
            <tr>
                <td>{$data.receipt[0].receipt_date|date_format:"%Y-%m"}-{$data.receipt[0].receipt_id|leading_zero:5}</td>
                <td>{$data.receipt[0].receipt_date|date_format:"%d/%m/%Y"}</td>
                <td>{if $data.receipt[0].customer_name}{$data.receipt[0].customer_name}{else}{$data.receipt[0].group_company}{/if}</td>
                <td>{$data.receipt[0].receipt_amount|number_format:2} {$data.receipt[0].receipt_currency}</td>
            </tr>
            </tbody>
        </table>
        </td>
    </tr>
  </table>
  <!-- /.pdf-header -->
  </header> 

  <footer>
  <table class="table sign">
      {if $data.receipt[0].account_name}
        <tr>
        <td class="label">Account</td><td class="field" style="background: none;">{$data.receipt[0].account_name}</td><td></td>
      </tr>
      {/if}
      <tr>
        <td class="label">Printed On</td><td class="field">{$smarty.now|date_format:"%d/%m/%Y %H:%M"}</td>
        <td>&nbsp;&nbsp;&nbsp;</td>
        <td class="label">Issued By</td><td class="field">{$data.receipt[0].user}</td>
      </tr>
      <tr>
        <td></td><td></td><td></td>
      </tr>
    </table>
</footer>

<!-- Invoice Allocation Table -->
<section class="content">
<table class="table table-striped items">
<thead>
<tr>
    <th width="15%">{if $data.receipt[0].receipt_type == 'Invoice'}Inv # {else} Quote #{/if}</th>
    <th width="25%" class="text-right">Amount</th>
    <th width="25%" class="text-right">Amount Paid</th>
    <th width="25%" class="text-right">Balance</th>
</tr>
</thead>

<tbody>

{foreach from=$data.receipt_items item=item}
<tr>
    <td class="text-left">
    {if $data.receipt[0].receipt_type == 'Invoice'}
                                          TI/{$item.invoice_date|substr:0:4}/{$item.invoice_id}
                                          {else}
                                          {$item.quote_date|substr:0:4}-{$item.quote_date|substr:5:2}-{$item.quote_id|leading_zero:5}
                                          {/if}
    </td>
    <td class="text-right">
         {if $data.receipt[0].receipt_type == 'Invoice'}
                                        {$item.invoice_amount|number_format:2:".":","}
                                        {else}
                                        {$item.quote_amount|number_format:2:".":","}
                                        {/if}
    </td>
    <td class="text-right">
        {$item.item_amount|number_format:2} 
    </td>
    <td class="text-right">
        {$item.balance|number_format:2}
    </td>
</tr>
{/foreach}
</tbody>
</table>
</section>
</body>
</html>
