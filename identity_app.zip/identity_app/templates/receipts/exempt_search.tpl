


<div id="search" class="panel panel-default" style="{if !$smarty.get.filter}display: none;{/if} margin-top:15px;">

  <div class="panel-body">
     <form id="form2" name="form2" class="form-inline"  method="post" action="/receipts/exempt_float?filter=1{if $search_str}{$search_str}{/if}">
       {* <div class="form-group" style="margin:0 15px 10px 0;">
       <label >Supplier:</label><br>
       <select id="supplier_id" name="supplier_id" class="form-control select2" style="width:200px;">
          <option value="">Please Select</option>
          {section name=supplier_list loop=$supplier_list}
              <option value="{$supplier_list[supplier_list].supplier_id}" {if $form_data.supplier_id == $supplier_list[supplier_list].supplier_id || $smarty.post.supplier_id == $supplier_list[supplier_list].supplier_id || $smarty.session.contractor.step_1.supplier_id == $supplier_list[supplier_list].supplier_id}selected{/if}>{if $supplier_list[supplier_list].supplier_company}{$supplier_list[supplier_list].supplier_company} -{/if} {$supplier_list[supplier_list].supplier_fname} {$supplier_list[supplier_list].supplier_lname}
              </option>
          {/section}
      </select>
       </div> *}

       {* <div class="form-group" style="margin:0 15px 10px 0;">
       <label >Job:</label><br>
        <select name="job_id" id="job_id"  class="form-control" style="width:100%;" ></select>
       </div> *}

       {* <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Category:</label>
       <select id="category_id" name="category_id" class="form-control select">
            <option value="">Select..</option>
            {section name=cats loop=$job_categories}
              <option value="{$job_categories[cats].id}" {if $smarty.post.category_id eq $job_categories[cats].id || $form_data.category_id eq $job_categories[cats].id}selected{/if}>{$job_categories[cats].tpl_name}</option>
            {/section}
       </select>
      </div> *}

      <div class="form-group"  style="margin:0 15px 10px 0;">
      <label for="to_date">Date From:</label>
       <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_from"  value="{if $smarty.post.date_from}{$smarty.post.date_from|date_format:'%Y-%m-%d'}{else}{/if}" >
     </div>

       <div class="form-group"  style="margin:0 15px 10px 0;">
       <label for="to_date">Date To:</label>
        <input type="text" autocomplete="off" class="form-control datepicker" style="display:block; width:130px;"  name="date_to"  value="{if $smarty.post.date_to}{$smarty.post.date_to|date_format:'%Y-%m-%d'}{else}{/if}" >
      </div>
       <div class="form-group" style="margin-top:10px;">
         <input type="hidden" name="debug" value="{$smarty.get.s_debug}" >
         <button type="submit" class="btn btn-primary">Go</button>
       </div>

  </form>

  </div>

  </div>
