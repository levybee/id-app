<div class="panel panel-default">

       <div class="panel-heading">
            <h3 class="panel-title">Receipt Information</h3>
			 </div>
			 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">

			  <tr>
			    <td colspan="2"><div><strong>Customer</strong></div>

			     <div>{$data.customer_fname} {$data.customer_lname}<br />
			    {$data.group_company}<br />
			    {$data.customer_address}<br />
			    {$data.customer_city},
					 {$data.customer_country}<br />
			    <br />
			    Phone: {$data.customer_phone}<br />
			    Fax: {$data.customer_fax}<br />
			    Mobile: {$data.customer_mobile}<br />
			    Email: {$data.customer_email}</div>

			    </td>

			  </tr>


             </table>


           </div>
          </div>


</div>
