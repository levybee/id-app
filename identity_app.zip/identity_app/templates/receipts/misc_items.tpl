<div class="panel panel-default">
      <form method="post" action="/receipts/add" id="subm">
       <div class="panel-heading">
		        <h3 class="panel-title">Receipt Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>

                            {* <tr>
                                <th class="text-center" width="40"></th>
                            </tr> *}

                        </thead>
                        <tbody>
            {section name=items loop=$smarty.session.receipt.items}

              <tr>
               <td class="text-center"></td>
             </tr>

						  {sectionelse}
						  <tr>
						    <td><div>No items available.</td>
						  </tr>
						  {/section}

                        </tbody>
                    </table>

                </div>

  </div>
    <div class="panel-footer">
          <input type="hidden" name="next_step" value="three" />
           <input type="submit" name="complete" value="Submit" class="btn btn-success pull-right"  />

      </div>

    </form>
</div>
