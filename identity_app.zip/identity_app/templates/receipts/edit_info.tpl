<div class="panel panel-default">

       <div class="panel-heading">
          <h3 class="panel-title">Receipt Info</h3>
	 </div>
	 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">

			  <tr>
			    <td colspan="2"><div><strong>Customer</strong></div>

			     <div>{$smarty.session.receipt_edit.customer_fname} {$smarty.session.receipt_edit.customer_lname}<br />
			    {$smarty.session.receipt_edit.group_company}<br />
			    {$smarty.session.receipt_edit.customer_address}<br />
			    {$smarty.session.receipt_edit.customer_city}, {$smarty.session.receipt_edit.customer_country}<br />
			    <br />
			    Phone: {$smarty.session.receipt_edit.customer_phone}<br />
			    Fax: {$smarty.session.receipt_edit.customer_fax}<br />
			    Mobile: {$smarty.session.receipt_edit.customer_mobile}<br />
			    Email: {$smarty.session.receipt_edit.customer_email}</div>

			    </td>

			  </tr>
			   <tr>
        <td colspan="2"><div><strong>Received Via</strong></div>
            <div>{$smarty.session.receipt_edit.account_name}</div>
        </td>

      </tr>

        <tr>
        <td colspan="2"><div><strong>Amount</strong></div>
            <div>{$smarty.session.receipt_edit.total_received|number_format:0:".":","} {$smarty.session.receipt_edit.receipt_currency}</div>
        </td>

		 {if $smarty.session.receipt_edit.exch_rate}
				 <tr>
					<td colspan="2"><div><strong>Exchange Rate</strong></div>
						<div>{$smarty.session.receipt_edit.exch_rate|number_format:2:".":","}</div>
					</td>

				</tr>
              {/if}

      </tr>

      </table>

     </div>
 </div>

</div>
