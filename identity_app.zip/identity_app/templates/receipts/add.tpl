{if $privileges.receipts.add}
	<script type="text/javascript" src="/js/quote.js"></script>
	<ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/receipts/list">Receipt</a></li>
     <li class="active"><a href="">Add Receipt</a></li>
	 </ul>
	 <!-- END BREADCRUMB -->
	 <div class="page-title">                    
	    <h2><span class="fa fa-arrow-circle-o-left"></span>New Receipt - Step {$step|capitalize}</h2>
	</div>

   
    <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
        {/if}
        
        {if $smarty.get.subtask eq 'edit'}
	        {include file='receipts/add.edit.subtask.tpl'}
	    {else}

			<div class="col-md-12">
	     <div class="panel panel-default">
	       <div class="panel-body panel-body-table">
	       
	          <table border="0" width="100%" cellpadding="5" cellspacing="0" id="progress_bar">
	          <thead>
	          <tr>
	            <th width="33%"  class="step {if $step eq 'one'}current{/if}" >Step 1</th>
	            <th width="33%"  class="step {if $step eq 'two'}current{/if}" >Step 2</th>
	            <th width="33%" class="step {if $step eq 'three'}current{/if}" >Step 3</th>
	          </tr>
	          </thead>
	          <tbody>
	            <tr>
		            <td class="progress_information">Prepare Receipt</td>
		            <td class="progress_information">Add Items</td>
		            <td class="progress_information">Save &amp; Print!</td>
	            </tr>
	         
	           </tbody>
	         </table>
	       </div>
	     
	     </div>
	     
	   </div> 
	   <div class="col-md-3">
	   {if $step eq 'two'}
	     {include file='receipts/info.tpl'}
	   {/if}
	   
	   {if $step eq 'three'}
	     {include file='receipts/info2.tpl'}
	   {/if}
	   
	   {if $step eq 'two'}
	    <div align="center" style="padding-bottom:5px;"><a class="btn btn-danger"  href="/receipts/add?cancel=1" {if $step eq 'one'} disabled="disabled" {/if}>Cancel &amp; Start Over</a></div>
	   {/if}
	 
	   {if $step eq 'two'}
		<div align="center" style="padding-bottom:15px;">
		 <form method="post" action="/receipts/add">
		   <input type="hidden" name="next_step" value="three" />
		   <input type="hidden" name="q" id="q" value="" />
		   <input type="hidden" name="balance" id="balance" value="" />
		   <!-- <input type="submit" name="complete" value="Complete" class="btn btn-success"  /> -->
		 </form>
		</div>
	   {/if}
	   
	  
	     
	   </div>
	   <div class="col-md-9">
	      {if $step eq 'one'}
            {include file='receipts/add.step1.tpl'}
          {elseif $step eq 'two'}
            {include file='receipts/add.step2.tpl'}
          {elseif $step eq 'three'}
            {include file='receipts/add.step3.tpl'}
          {else}
            {include file='receipts/add.step1.tpl'}
          {/if}
	   </div>   
	 
	        
	{/if}
                                            

    </div>
  </div>
 </div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 
   
{/if}
