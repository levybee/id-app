{if $privileges.receipts.exempt}

  <!-- START BREADCRUMB -->
   <ul class="breadcrumb">
       <li><a href="/">Home</a></li>
       <li><a href="/receipts/exempt_float">Exempt Float</a></li>
       <li class="active"><a href="">{$action|capitalize}</a></li>
   </ul>
   <!-- END BREADCRUMB -->
   <div class="page-title">
      <h2><span class="fa fa-arrow-circle-o-left"></span>Exempt Float</h2>
  </div>
   <!-- PAGE CONTENT WRAPPER -->
   <div class="page-content-wrap">

    <div class="row">
      <div class="col-md-12">
               {if $message || $msg}
               <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                   {$message}
                   {$msg}
               </div>
               {/if}


          <div class="col-md-12" style="margin-bottom:10px;">


           {if $privileges.receipts.exempt}
             <a href="#" class="btn btn-default payoutBtn">Payout</a>
             {* <a href="#" class="btn btn-default reconcileBtn">Reconcile</a> *}
             <a href="/receipts/add?type=quote" target="_blank" class="btn btn-default">Receive Against Quote</a>
             <a href="/receipts/add?type=misc" target="_blank" class="btn btn-default">Receive Misc</a>
             <br><br>
           {/if}

           {if $privileges.receipts.exempt}
           <div style="padding-bottom:15px;"> Current Balance: <span
                 class="badge badge-warning" style="font-size:18px;">{$cash_balance|number_format:0:".":","} TZS</span>
           </div>
           {/if}

           <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/receipts/exempt_float?page=1" class="btn btn-default">Clear</a>
           {include file="$section/exempt_search.tpl"}
        </div>

          <div class="panel panel-default">

              <div class="panel-heading">

                {* if $smarty.get.contract_status  eq 'Drafts'}
                <label for="approve_selected" name="approve_selected" class="btn btn-danger">
                  Approve Selected
                </label>
                {/if *}

                    <ul class="panel-controls panel-controls-title">
                       <li>

                       <form class="form-inline" role="form" method="post">
                           <div class="form-group">
                             </div>
                           <div class="form-group">
                               <a href="/receipts/exempt_float{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/receipts/exempt_float{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>
                               <label>| Displaying {$resultsCount}</label>
                           </div>
                           <div class="form-group">

                                   <select name="page" id="page" class="form-control">
                    {section name=pagination loop=$numPages}

                      <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                    {sectionelse}
                      <option value="1" selected>Page 1</option>
                    {/section}

                     </select>
                           </div>
                           <button name="submit" type="submit" class="btn btn-danger">Go</button>
                       </form>
                       </li>

                   </ul>
              </div>
              <div class="panel-body panel-body-table">

                  <form method="post" action="">
                      <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                  <div class="table-responsive">
                      <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                          <thead>
                              <tr>
                                {* if $smarty.get.contract_status  eq 'Drafts'}
                                    <th width="40" class="text-center">
                                        <input type="checkbox" id="check_all_approved"/></th>
                                {/if *}
                                 <th class="text-center">#</th>
                                 <th class="text-center">Date</th>
                                 <th class="text-center">Receipt #</th>
                                 <th class="text-center">Amount</th>
                                 <th class="text-center">Type</th>
                                 <th class="text-center">Remarks</th>
                                 <th class="text-center">Paid To</th>
                                 
                                 <th class="text-center">Status</th>
                                 <th class="text-center">User</th>
                                 <th class="text-center" width="100">Action</th>
                              </tr>
                          </thead>
                          <tbody>
                             {section name=row loop=$efa_list}
                <tr>
                  {* if $efa_list[row].contract_status  eq 'Drafts' && $smarty.get.contract_status  eq 'Draft'}<td class="text-center">
                      <input type="checkbox" name="approved_check[]" class="approved_check" value="{$efa_list[row].id}" /></td>{/if *}

                  <td class="text-center">{$efa_list[row].id}</td>
                  <td class="text-center">{$efa_list[row].date_created|date_format:"%d %b %Y"}</td>
                  <td class="text-center"><a title="View Receipt" target='_blank' href="/receipts/view/?id={$efa_list[row].receipt_id}"  alt="View Receipt">{$efa_list[row].receipt_id}</td>
                  <td class="text-center">{$efa_list[row].amount|number_format:0:".":","}</td>
                  <td class="text-center">{$efa_list[row].type}</td>
                  <td>
                  {if $efa_list[row].type == 'Bank Transfer'}
                    <a target="_blank" href="/petty_cash_mobile/list?filter=1&pc_id={$efa_list[row].id}" title="View Bank Transfer">{$efa_list[row].remarks}</a>
                  {else}  
                  {$efa_list[row].remarks}
                  {/if}
                  {if $efa_list[row].quote_ids}
                  {assign var=quoteIds value=","|explode:$efa_list[row].quote_ids}
                  {assign var=companies value=","|explode:$efa_list[row].companies}
                  {assign var=last value=$quoteIds|@end}
                  {foreach from=$quoteIds key=k item=quote_id}
                  <a title="View Quote" href="#" onclick="popupPDF('quote', {$quote_id});">Quote #:{$quote_id}</a>
                   - {$efa_list[row].group_company} [{$efa_list[row].quote_amount|number_format:2:".":","} {$efa_list[row].currency}]{if $quote_id != $last}, <br>{/if}
                  {/foreach}
                 {else}
                 {if $efa_list[row].group_company}Receipt from {$efa_list[row].group_company} {/if}
                 {/if}
                  </td>
                   
                  <td class="text-center">{if $efa_list[row].paid_to}{$efa_list[row].paid_to}{else}-{/if}</td>
                  <td class="text-center">
                  {if $efa_list[row].type == 'Payout'}{$efa_list[row].status}
                  {if $efa_list[row].confirm_remarks}
                  <br><i>Ref: {$efa_list[row].confirm_remarks}</i>
                  {/if}
                  {else}-{/if}
                  </td>
                  <td class="text-center">{$efa_list[row].user}</td>
                  <td class="text-center">
                    {if $efa_list[row].type == 'Payout' && $efa_list[row].status == 'Confirmed'}
                      <a href="/receipts/exempt_float?actn=approve&id={$efa_list[row].id}"
                        class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve"
                        onclick="confirmAction('[Approve Payout] Are you sure?', this.href); return false;"><span
                          class="fa fa-check"></span></a>
                       
                    {/if}

                    {if $efa_list[row].type == 'Payout' && $efa_list[row].status eq 'Pending'}
                      <a href="#"
                         data-item-id="{$efa_list[row].id}"
                        class="btn btn-info btn-rounded btn-condensed btn-sm confirmBtn" title="Confirm"
                        ><span
                          class="fa fa-check"></span></a>
                          <a href="/receipts/exempt_float?actn=cancel&id={$efa_list[row].id}"
                        class="btn btn-warning btn-rounded btn-condensed btn-sm" title="Cancel"
                        onclick="confirmAction('[Cancel Payout] Are you sure?', this.href); return false;"><span
                          class="fa fa-times"></span></a>    
                    {/if}
                  </td>
                </tr>
                {sectionelse}
                <tr>
                  <td colspan="8">No records found.</td>
                </tr>
                {/section}
                          </tbody>
                      </table>

                  </div>
                  </form>


              </div>

          </div>

   </div>

   {include file="$section/payout_form.tpl"}
   {include file="$section/reconcile_form.tpl"}
   {include file="$section/confirm_form.tpl"}

  </div>
   <!-- END PAGE CONTENT WRAPPER -->
   </div>
    <!-- END PAGE CONTENT -->
  </div>
  <!-- END PAGE CONTAINER -->

  {else}
  <div class="row">
      <div class="col-md-12">


         <div class="alert alert-danger" role="alert">
          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
          You are not authorized to view this section
      </div>




  </div>

  </div>
  {/if}
