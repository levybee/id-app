<form method="post" action="/receipts/add" id="allocation_form">

<div class="panel panel-default">

       <div class="panel-heading">
		        <h3 class="panel-title">Receipt Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">#</th>
							    <th class="text-center">Amount Received ({$smarty.session.receipt_edit.currency})</th>
							    <th class="text-center" width="50">Action</th>

                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.receipt_edit.receipt_items}
						  <tr>
						    <td class="text-center">{$smarty.section.items.rownum}</td>
						    <td class="text-right">{$smarty.session.receipt_edit.receipt_items[items].receipt_amount|number_format:0:".":","}</td>
						    <td class="text-center"><input type="checkbox" id="receipt_check{$smarty.section.items.rownum}" class="receipts_check" name="receipt_check[{$smarty.session.receipt_edit.receipt_items[items].receipt_id}]" value="{$smarty.session.receipt_edit.receipt_items[items].receipt_amount}"></td>

						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="6"><div>No receipt items available.</td>
						  </tr>
						  {/section}

						  {if $smarty.session.receipt_edit.receipt_items|@count > 0}
						    <tr>
                  <th colspan="2"><div class="pull-left">&nbsp;&nbsp;&nbsp;<strong>Receipts Total</strong></div> <div id="receipts_total" class="pull-right">0</div></th>
							    <th>&nbsp;</th>
							    <input type="hidden" name="receipts_total" value="0" >
                </tr>

						  {/if}

                        </tbody>
                    </table>

                    {if $smarty.get.debug eq 'lev'}
                     <pre> {$smarty.session.receipt_edit|@print_r}</pre>

                    {/if}

                </div>




  </div>
   <!--  <div class="panel-footer">
        <input type="hidden" name="next_step" value="three" />
        <input type="submit" name="complete" value="Submit" class="btn btn-success pull-right"  />
    </div>  -->
</div>

<div class="panel panel-default">

       <div class="panel-heading">
		        <h3 class="panel-title">Invoice Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">#</th>
                                <th class="text-center">Invoice Total ({$smarty.session.receipt_edit.currency})</th>
							    <th class="text-center">Amount Received ({$smarty.session.receipt_edit.currency})</th>
							    <th class="text-center">Balance ({$smarty.session.receipt_edit.currency})</th>
							    <th class="text-center">Amount Allocation ({$smarty.session.receipt_edit.currency})</th>

                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.receipt_edit.invoice_items}
						  <tr>
						    <td class="text-center">{$smarty.section.items.rownum}</td>
						    <td class="text-right">{$smarty.session.receipt_edit.invoice_items[items].invoice_total|number_format:0:".":","}</td>
						     <td class="text-right">{$smarty.session.receipt_edit.invoice_items[items].amount_received}</td>

						    <td class="text-right balance{$smarty.section.items.rownum}">{$smarty.session.receipt_edit.invoice_items[items].invoice_total|number_format:0:".":"," - $smarty.session.receipt_edit.invoice_items[items].amount_received}</td>
						    <td><input type="text" data-balance-id="balance{$smarty.section.items.rownum}" id="allocation_{$smarty.section.items.rownum}" name="allocation[{$smarty.session.receipt_edit.invoice_items[items].invoice_id}]" class="form-control receipt_val"></td>



						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="6"><div>No Invoice items available.</td>
						  </tr>
						  {/section}

						   {if $smarty.session.receipt_edit.invoice_items|@count > 0}
						    <tr>
                                <th colspan="4" class="text-right"><strong>Allocation Total</strong></th> <th> <div id="allocation_total">0</div> </th>
                                <input type="hidden" name="allocation_total" value="0" >
                            </tr>
						  {/if}

                        </tbody>
                    </table>


                </div>




  </div>
    <div class="panel-footer">
          <input type="hidden" name="next_step" value="three" />
           <input type="submit" name="complete" value="Submit" onclick="return allocation_submit();" class="btn btn-success pull-right"  />

      </div>


</div>

</form>
