<div class="panel panel-default">
      <form method="post" action="/receipts/add" id="subm">
       <div class="panel-heading">
		        <h3 class="panel-title">Quote Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>

                            <tr>
                                <th class="text-center" width="40">Quote #</th>
                                <th class="text-center">Date</th>
                                <th class="text-center">Quote Total ({$smarty.session.receipt.currency})</th>
							    <th class="text-center">Received ({$smarty.session.receipt.currency})</th>
							    <th class="text-center">Balance ({$smarty.session.receipt.currency})</th>
							    <th class="text-center">Allocation ({$smarty.session.receipt.currency})</th>

                            </tr>

                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.receipt.quote_items}

              <tr>
               <td class="text-center">
                 {$smarty.session.receipt.quote_items[items].quote_date|substr:0:4}-{$smarty.session.receipt.quote_items[items].quote_date|substr:5:2}-{$smarty.session.receipt.quote_items[items].quote_id|leading_zero:5}
               </td>
                <td class="text-right">{$smarty.session.receipt.quote_items[items].quote_date|date_format:"%d/%m/%Y"}</td>
                <td class="text-right">{$smarty.session.receipt.quote_items[items].quote_amount|number_format:2:".":","}</td>
               <td class="text-right">{$smarty.session.receipt.quote_items[items].amount_received|number_format:2:".":","}</td>

               <td class="text-right balance{$smarty.section.items.rownum}">
               {$smarty.session.receipt.quote_items[items].balance|number_format:2:".":","}
               <input type="hidden" name="balance[{$smarty.session.receipt.quote_items[items].quote_id}]" value="{$smarty.session.receipt.quote_items[items].balance}">
               </td>
               <td><input type="text" data-balance-id="balance{$smarty.section.items.rownum}" id="allocation_{$smarty.section.items.rownum}" name="allocation[{$smarty.session.receipt.quote_items[items].quote_id}]" value="{$smarty.session.receipt_edit.receipt_items.amount_received}" class="form-control receipt_val"></td>
             </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="6"><div>No Quote items available.</td>
						  </tr>
						  {/section}

						   {if $smarty.session.receipt.quote_items|@count > 0}

                            <tr>
                                            <th colspan="2" class="text-right"><strong>TOTAL</strong></th>
                                            <th class="text-right"> <div id="quote_total">{$smarty.session.receipt.quote_total|number_format:2:".":","}</div> </th>
                                            <th class="text-right"> <div id="amount_received_total">{$smarty.session.receipt.amount_received_total|number_format:2:".":","}</div> </th>
                                            <th class="text-right"> <div id="balance_total">{$smarty.session.receipt.balance_total|number_format:2:".":","}</div> </th>
                                            <th class="text-right"> <div id="allocation_total">0</div> </th>
                                            <input type="hidden" name="allocation_total" value="0" >
                                        </tr>

						  {/if}

                        </tbody>
                    </table>

                    {if $smarty.get.debug eq 'lev'}
                     <pre> {$smarty.session.receipt|@print_r}</pre>

                    {/if}

                </div>




  </div>
    <div class="panel-footer">
          <input type="hidden" name="next_step" value="three" />
           <input type="submit" name="complete" value="Submit" class="btn btn-success pull-right"  />

      </div>

    </form>
</div>
