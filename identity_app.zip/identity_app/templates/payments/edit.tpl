{if $privileges.payments.edit || $privileges.payments.add}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/payments/list">Payment Terms</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Payment Term</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
            {if !$hide_form}   
            <form class="form-horizontal" method="post" autocomplete='off' action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Term</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">
                      
                     
                    <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Payment Term</label>
                         <div class="col-md-6 col-xs-12">                                            
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                 <input type="text" Required  name="payment_term" placeholder="Payment Term" value="{if $smarty.post.payment_term}{$smarty.post.payment_term}{elseif $edit_payments[0].payment_term}{$edit_payments[0].payment_term}{/if}" class="form-control"/>
                             </div>                                            
                             
                         </div>

                    </div> 

                    <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Advance Required</label>
                         <div class="col-md-6 col-xs-12">                                            
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                  <select name="advance_required" class="form-control">
                                    <option value="">Choose...</option>
                                    <option value='Yes' {if $smarty.post.advance_required == "Yes" || $edit_payments[0].advance_required == 'Yes'} selected {/if}>Yes</option>
                                    <option value="No" {if $smarty.post.advance_required == "No" || $edit_payments[0].advance_required == 'No'} selected {/if}>No</option>
                                 </select>
                             </div>                                            
                         </div>
                    </div>  

                    <div class="form-group">
                        <label class="col-md-3 col-xs-12 control-label">Advance Percentage</label>
                         <div class="col-md-6 col-xs-12">                                            
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                 <select class="form-control" name="advance_percentage">
                                    <option value="">Choose...</option>
                                    <option value='0' {if $smarty.post.advance_percentage == "0" || $edit_payments[0].advance_percentage == "0"} selected {/if}>0</option>
                                    <option value='50' {if $smarty.post.advance_percentage == "50" || $edit_payments[0].advance_percentage == "50"} selected {/if}>50</option>
                                    <option value="100" {if $smarty.post.advance_percentage == "100" || $edit_payments[0].advance_percentage == "100"} selected {/if}>100</option>
                                 </select>
                             </div>                                            
                         </div>
                    </div>

                    <div class="form-group">
                        <label class="col-md-3 col-xs-12 control-label">Payment on Delivery</label>
                         <div class="col-md-6 col-xs-12">                                            
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                 <select class="form-control" name="payment_on_delivery">
                                    <option value="">Choose...</option>
                                    <option value='Yes' {if $smarty.post.payment_on_delivery == "Yes" || $edit_payments[0].payment_on_delivery == 'Yes'} selected {/if}>Yes</option>
                                    <option value="No" {if $smarty.post.payment_on_delivery == "No" || $edit_payments[0].payment_on_delivery == 'No'} selected {/if}>No</option>
                                 </select>
                             </div>                                            
                         </div>
                    </div>

                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>                                    
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Payment Term</button>
                 </div>
             </div>
            </form>                                                                  
            {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 
{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">
       
       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>
      
    </div>

  
</div>            
  
</div> 

{/if}