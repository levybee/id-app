{if $privileges.product_items.list}



<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/products/list">Products</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>Products List</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

             <a href="/products/add" class="btn btn-default">New Product</a>
             <br><br>
        <div class="panel panel-default">

            <div class="panel-heading">
                 <h3 class="panel-title">Product Table</h3> 
                  <ul class="panel-controls panel-controls-title">                                        
                     <li>
                     
                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                             <label>Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">
                                                             
                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}
								  
								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}
								  
								    <option value="1" selected>Page 1</option>
								    
								    
								  {/section}
								
							     </select>
                            
                         </div>                                    
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>                      
                     </li>                                
                     
                 </ul>         
            </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>item</th>
                                <th>Category</th>
                                <th>type</th>
                                <th>Reference</th>
                                <th>By Pass Sample QC</th>
                                <th>Sort</th>
                                <th width="120">actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=product_list loop=$product_list}
                            <tr>

                                <td class="text-center">{$start+$smarty.section.product_list.rownum}</td>
                                <td>{$product_list[product_list].product_name}</td>
                                <td>{$product_list[product_list].category_name}</td>
                                <td>{$product_list[product_list].product_type}</td>
                                <td>{$product_list[product_list].product_ref}</td>
                                <td>{if $product_list[product_list].bypass_sample_qc}Yes{else}No{/if}</td>
                                <td>{$product_list[product_list].product_sort}</td>

                                <td>
                                    <a href="/products/edit/?id={$product_list[product_list].product_id}" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>
                                    <a href="/products/delete/?id={$product_list[product_list].product_id}" class="btn btn-danger btn-rounded btn-condensed btn-sm"><span class="fa fa-times"></span></a>
                                </td>
                            </tr>
                           {/section}
                        </tbody>
                    </table>
                </div>                                

            </div>
        </div>                                                      

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 


{/if}