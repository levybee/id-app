{if $privileges.product_items.edit || $privileges.product_items.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/products/list">Products</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Product</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
        {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Product</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">


                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Item</label>
                         <div class="col-md-6 col-xs-12">
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                 <input type="text" name="product_name" value="{if $smarty.post.product_name}{$smarty.post.product_name}{elseif $edit_product[0].product_name}{$edit_product[0].product_name}{/if}" class="form-control"/>
                             </div>

                         </div>
                     </div>
                      <div class="form-group">
                          <label class="col-md-3 col-xs-12 control-label">Category</label>
                          <div class="col-md-6 col-xs-12">
                            <select name="category_id" id="category_id" class="form-control">
                             <option value="">Please Select</option>
                            {foreach from=$categories item=cat}
                             <option value="{$cat.id}" {if $smarty.post.category_id == $cat.id || $edit_product[0].category_id == $cat.id}selected{/if}>{$cat.category_name}</option>
                           {/foreach}
                           </select>
                          </div>
                      </div>
                      <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Type</label>
                         <div class="col-md-6 col-xs-12">
                             <select name="product_type" class="form-control select">
                                  <option value="Standard" {if $smarty.post.product_type eq 'Standard' || $edit_product[0].product_type eq 'Standard'}selected{/if}>Standard</option>
                                  <option value="Paper" {if $smarty.post.product_type eq 'Paper' || $edit_product[0].product_type eq 'Paper'}selected{/if}>Paper</option>
                                  <option value="Books" {if $smarty.post.product_type eq 'Books' || $edit_product[0].product_type eq 'Books'}selected{/if}>Books</option>
                             </select>

                         </div>
                     </div>

                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Reference</label>
					    <div class="col-md-6 col-xs-12">
					        <div class="input-group">
					            <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
					            <input type="text" name="product_ref" value="{if $smarty.post.product_ref}{$smarty.post.product_ref}{elseif $edit_product[0].product_ref}{$edit_product[0].product_ref}{/if}" class="form-control"/>
					        </div>

					    </div>
					</div>

          <div class="form-group">
   <label class="col-md-3 col-xs-12 control-label">Specifications</label>
   <div class="col-md-6 col-xs-12">
       <div class="input-group">
           <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
           <textarea  name="product_specifications" rows="5" class="form-control"/>{if $smarty.post.product_specifications}{$smarty.post.product_specifications}{elseif $edit_product[0].product_specifications}{$edit_product[0].product_specifications}{/if}</textarea>
       </div>

   </div>
</div>

<div class="form-group">
<label class="col-md-3 col-xs-12 control-label">By Pass Sample QC?</label>
<div class="col-md-6 col-xs-12">


 <label class="control-label"><input type="checkbox" name="bypass_sample_qc" value="1" {if $smarty.post.bypass_sample_qc eq '1' || $edit_product[0].bypass_sample_qc eq '1'}checked{/if}></label>


</div>
</div>

                    <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Sort</label>
					    <div class="col-md-6 col-xs-12">
					        <div class="input-group">
					            <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
					            <input type="text" name="product_sort" value="{if $smarty.post.product_sort}{$smarty.post.product_sort}{elseif $edit_product[0].product_sort}{$edit_product[0].product_sort}{/if}" class="form-control"/>
					        </div>

					    </div>
					</div>
                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Product</button>
                 </div>
             </div>
            </form>
           {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->


{/if}
