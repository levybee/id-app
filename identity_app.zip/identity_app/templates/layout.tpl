        
        {if $logged_in}

        {if $section != 'chat'}        
        {include file="header.tpl"}
        {include file="$section/$action.tpl"}
        {include file="footer.tpl"}
        {/if}
        
        {else}
        
       
        {include file="main/login.tpl"} 
      
        
        {/if}