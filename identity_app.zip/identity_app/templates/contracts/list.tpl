{if $privileges.contracts.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/contracts/list">Contracts</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Contracts</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">

             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">

         {if $privileges.contracts.add}
           <a href="/contracts/add" class="btn btn-default">New Contract</a>
           <br><br>
         {/if}

         <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/contracts/list?page=1" class="btn btn-default">Clear</a> | Filter By Status: <a href="/contracts/list?page=1" class="btn {if !$smarty.get.contract_status }btn-success{/if} btn-flat btn-rad">All</a>

         <a href="/contracts/list?page=1&filter=1&contract_status=Draft" class="btn {if $smarty.get.contract_status  eq 'Draft'}btn-success{else}btn-default{/if}">Draft</a>

         <a href="/contracts/list?page=1&filter=1&contract_status=Approved" class="btn {if $smarty.get.contract_status  eq 'Approved'}btn-success{else}btn-default{/if}">Approved</a>
         <a href="/contracts/list?page=1&filter=1&contract_status=Issued" class="btn {if $smarty.get.contract_status  eq 'Issued'}btn-success{else}btn-default{/if}">Issued</a>

         <a href="/contracts/list?page=1&filter=1&contract_status=Closed" class="btn {if $smarty.get.contract_status  eq 'Closed'}btn-success{else}btn-default{/if}">Closed</a>

         <a href="/contracts/list?page=1&filter=1&contract_status=Cancelled" class="btn {if $smarty.get.contract_status  eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled</a>
         {include file="$section/search.tpl"}
      </div>

        <div class="panel panel-default">

            <div class="panel-heading">

              {if $smarty.get.contract_status  eq 'Drafts'}
              <label for="approve_selected" name="approve_selected" class="btn btn-danger">
                Approve Selected
              </label>
              {/if}

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/contracts/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/contracts/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}
								    <option value="1" selected>Page 1</option>
								  {/section}

							     </select>
                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>
                     </li>

                 </ul>
            </div>
            <div class="panel-body panel-body-table">

                <form method="post" action="">
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">
                    <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              {if $smarty.get.contract_status  eq 'Drafts'}
                                  <th width="40" class="text-center">
                                      <input type="checkbox" id="check_all_approved"/></th>
                              {/if}
                               <th class="text-center">#</th>
                               <th class="text-center">Employee</th>
              				   <th class="text-center">Type</th>
              				   <th class="text-center">Position</th>
              				   <th class="text-center">Salary A</th>
                               <th class="text-center">Salary B</th>
                               <th class="text-center">Contract Type</th>
                               <th class="text-center">Start Date</th>
                               <th class="text-center">End Date</th>
                               <th class="text-center">Attachment</th>
                               <th class="text-center">Status</th>
              				   <th class="text-center">User</th>
              				   <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=contracts_list loop=$contracts_list}
						  <tr>
                {if $contracts_list[contracts_list].contract_status  eq 'Drafts' && $smarty.get.contract_status  eq 'Draft'}<td class="text-center">
                    <input type="checkbox" name="approved_check[]" class="approved_check" value="{$contracts_list[contracts_list].id}" /></td>{/if}

						    <td class="text-center">{$contracts_list[contracts_list].id}</td>
                <td class="text-center"><a target="_blank" href="/employees/view/?id={$contracts_list[contracts_list].employee_id}">{$contracts_list[contracts_list].employee_name}</a></td>
                <td class="text-center">{$contracts_list[contracts_list].contract_type}</td>
                <td class="text-center">{$contracts_list[contracts_list].position}</td>
                <td class="text-center">{if $contracts_list[contracts_list].salary_a > 0}{$contracts_list[contracts_list].salary_a|number_format:0:".":","}{else}-{/if}</td>
                <td class="text-center">{if $contracts_list[contracts_list].salary_b > 0}{$contracts_list[contracts_list].salary_b|number_format:0:".":","}{else}-{/if}</td>
                <td class="text-center">{$contracts_list[contracts_list].tpl_name}</td>
						    <td class="text-center">{$contracts_list[contracts_list].contract_start_date|date_format:"%d %b %Y"}</td>
                <td class="text-center">{$contracts_list[contracts_list].contract_end_date|date_format:"%d %b %Y"}</td>
                <td class="text-center">
                <a href="/{$config.attachment_dir}{$contracts_list[contracts_list].attachment}" target = "_blank">{if $contracts_list[contracts_list].attachment}{$contracts_list[contracts_list].attachment}{else}-{/if}</a>
                </td>
                <td class="text-center">
                    <span class="{if $contracts_list[contracts_list].contract_status  eq 'Draft'}text-danger{elseif $contracts_list[contracts_list].contract_status  eq 'Approved'}text-info{elseif $contracts_list[contracts_list].contract_status  eq 'Cancelled'}text-default{else}text-success{/if}">{$contracts_list[contracts_list].contract_status}</span>
                    {* {if $contracts_list[contracts_list].contract_status  eq 'Approved'}by {$contracts_list[contracts_list].approval_user}{/if} *}
                </td>
						    <td class="text-center">{$contracts_list[contracts_list].user}</td>
						    <td class="text-center">
				   {if $contracts_list[contracts_list].contract_status  != 'Draft' && $contracts_list[contracts_list].contract_status  != 'Cancelled' && $contracts_list[contracts_list].contract_status  != 'Approved'}
                   <a class="btn btn-default btn-rounded btn-condensed btn-sm"  title="View PDF" href="/contracts/print?id={$contracts_list[contracts_list].id}"  alt="View PDF" target = "_blank"><span class="fa fa-file-pdf-o"></span></a>
                   {/if}
                   {if $contracts_list[contracts_list].contract_status  eq 'Issued'}
                      <a title="Close"
                     href="" class="btn btn-success btn-rounded btn-condensed btn-sm attach_btn"
                     data-id="{$contracts_list[contracts_list].id}"
                     data-employee="{$contracts_list[contracts_list].employee_name}"
                     data-attachment_path="{$contracts_list[contracts_list].attachment}"
                     ><span class="fa fa-check-circle"></span></a>
                   {/if}

                   {if $contracts_list[contracts_list].contract_status  eq 'Approved'}
                   {if $privileges.contracts.issue}
                   <a href="/contracts/list?actn=issue&id={$contracts_list[contracts_list].id}" class="btn btn-warning btn-rounded btn-condensed btn-sm" title="Issue" onclick="confirmAction('[Issue Contract] Are you sure?', this.href); return false;" ><span class="fa fa-arrow-circle-right"></span></a>
                   {/if}
                   {/if}

                   {if $contracts_list[contracts_list].contract_status  eq 'Draft' && $privileges.contracts.approve}
                   <a href="/contracts/list?actn=approve&id={$contracts_list[contracts_list].id}" class="btn btn-info btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Contract] Are you sure?', this.href); return false;" ><span class="fa fa-check-circle"></span></a>
                   {/if}
                   {if $contracts_list[contracts_list].contract_status  != 'Closed' && $contracts_list[contracts_list].contract_status != 'Cancelled'}
                    <a href="/contracts/list?actn=cancel&id={$contracts_list[contracts_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Cancel" onclick="confirmAction('[Cancel Contract] Are you sure?', this.href); return false;" ><span class="fa fa-times"></span></a>
                   {/if}
                   <a href="/contracts/edit/?id={$contracts_list[contracts_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
						    </td>
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="11">No records found.</td>
						  </tr>
						  {/section}
                        </tbody>
                    </table>

                </div>
                </form>


            </div>

     {if $smarty.get.dbg}
     {$privileges.contracts|@print_r}
     {/if}

        </div>

 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

<div class="modal" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="defModalHead">Close Contract for <span class="item_name"></span></h4>
            </div>
            <form id="attachment_form" name="attachment_form" method="post" action="/contracts/list" class="form-horizontal" enctype="multipart/form-data">
              <div class="modal-body">
                 <div id="response"></div>


                 <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
                     <div class="panel-body form-group">
                       <div class="row">
                         <div class="form-group">
                             <label>Attachment</label>
                             <input name="attachment_file" type="file" id="attachment_file" class="form-control" style="width:50%;" />
                         </div>
                 </div>

              </div>



        </div>
    </div>
    <div class="modal-footer">
        <input type="hidden" name="contract_id" value="" >
        <input type="hidden" name="close" value="1" >
        <input type="hidden" name="attachment_path" value="" >
        <input type="submit" name="item_submit" class="btn btn-primary" value="Submit">
        {* <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button> *}
      </div>
      </form>
</div>

{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
