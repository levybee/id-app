{if $privileges.contracts.edit || $privileges.contracts.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/contracts/list">Contract</a></li>
     <li class="active"><a href="">{$action|capitalize} Contract</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Contract</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

         {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     {* <h3 class="panel-title"><strong>Request</strong> Form</h3> *}
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">

                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Employee</label>
                    <div class="col-md-6 col-xs-12">
                        <select name="employee_id" id="employee_id"  class="form-control" style="width:100%;">
                         </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Contract Type</label>
                    <div class="col-md-6 col-xs-12">
                         <select name="contract_type" id="contract_type" class="form-control">
                           <option value="">Select..</option>
                           <option value="Permanent"  {if $smarty.post.contract_type eq "Permanent" || $edit_contract[0].contract_type eq "Permanent"}selected{/if}>Permanent</option>
                           <option value="Temporary"  {if $smarty.post.contract_type eq  "Temporary" || $edit_contract[0].contract_type eq "Temporary"}selected{/if}>Temporary</option>
                           <option value="Fixed-term"  {if $smarty.post.contract_type eq  "Fixed-term" || $edit_contract[0].contract_type eq "Fixed-term"}selected{/if}>Fixed-term</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Template</label>
                    <div class="col-md-6 col-xs-12">
                        <select name="contract_tpl_id" class="form-control select">
                             <option value="">Select..</option>
                             {section name=contract_tpls loop=$contract_tpls}
                                     <option value="{$contract_tpls[contract_tpls].id}" {if $edit_contract[0].contract_tpl_id  eq $contract_tpls[contract_tpls].id}selected{/if}>{$contract_tpls[contract_tpls].tpl_name}</option>
                                 {/section}
                        </select>

                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Start Date</label>
                    <div class="col-md-6 col-xs-12">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                            <input id="start_date" name="start_date" type="text" class="form-control datepicker" value="{if $edit_contract[0].contract_start_date}{$edit_contract[0].contract_start_date}{elseif $smarty.post.contract_start_date}{$smarty.post.contract_start_date}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" style="width:140px;" readonly="readonly">
                        </div>

                    </div>
                </div>

                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">End Date</label>
                    <div class="col-md-6 col-xs-12">
                        <div class="input-group">
                            <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                            <input id="end_date" name="end_date" type="text" class="form-control datepicker" value="{if $edit_contract[0].contract_end_date}{$edit_contract[0].contract_end_date}{elseif $smarty.post.contract_end_date}{$smarty.post.contract_end_date}{else}{/if}" style="width:140px;" readonly="readonly">

                        </div>

                    </div>
                </div>
                 <!-- <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">Duration</label>
                     <div class="col-md-6 col-xs-12">
                         <p class="form-control-static duration">{$edit_contract[0].duration}</p>
                     </div>
                 </div> -->

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Contract</button>
                 </div>
             </div>
             </form>


            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
