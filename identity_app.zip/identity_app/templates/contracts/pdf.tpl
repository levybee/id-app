<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Identity Promotions</title>
  <style>
   {include file="css/pdf.css"}
  </style>
</head>
<body>
  <!-- pdf-header  -->
  <header>
  <table class="table pdf-header" style="padding-top:0;">
    <tr>
      <td width="49%">
        <h1>Employment Contract</h1>
        <h1 class='second'>Mkataba Wa Ajira</h1>
      </td>
      <td style="padding-top:60%">&nbsp;<b>Date Issued:</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{$data.date_created|date_format:"%d %b %Y"}</td>
    </tr>
  </table>
  <!-- /.pdf-header -->
</header>
<footer>
  <table class="table footer-bottom">
    <tr>
      <td width="70%" class="">
        <p class="footer-text">
          Identity Promotions Ltd. | Corner ITV/Bagamoyo Rd, Mwenge, P.O. Box 38070, Dar es Salaam, Tanzania | Phone No: 0769 785065 | hr@identitytz.com | identitytz.com
        </p>
      </td>
      <td width="30%" style="padding-left:30px;"><p class="footer-text">Ref #: IPL/HR/C/{$data.id|string_format:"%05d"} </p></td>
    </tr>
  </table>

</footer>

<div class="content-header">
  <table width="100%">
    <tr>
      <td width="50%">
        <table class="details">
          <tr>
            <td class="label"><b>Ref #:</b></td><td class="value">IPL/HR/C/{$data.id|string_format:"%05d"}</td>
          </tr>
          <tr>
            <td class="label"><b>Employeer Name:</b></td><td class="value">Identity Promotions Ltd</td>
          </tr>
          <tr>
            <td class="label"><b>Employee Name:</b></td><td class="value">{$data.employee_name}</td>
          </tr>
          <tr>
            <td class="label"><b>Date of Birth:</b></td><td class="value">{$data.dob|date_format:"%d %b %Y"}</td>
          </tr>
          <tr>
            <td><b>Contract Type:</b></td><td class="value">{$data.contract_type}</td>
          </tr>
          <tr>
            <td class="label"><b>Start Date:</b></td><td class="value">{$data.contract_start_date|date_format:"%d %b %Y"}</td>
          </tr>
          <tr>
            <td class="label"><b>End Date:</b></td><td class="value">{$data.contract_end_date|date_format:"%d %b %Y"}</td>
          </tr>

        </table>
      </td>
      <td width="50%">
        <table class="details">
          <tr>
            <td><b>Department:</b></td><td class="value">{$data.department_name}</td>
          </tr>
          <tr>
            <td class="label"><b>Position:</b></td><td class="value">{$data.position}</td>
          </tr>
          <tr>
            <td class="label"><b>Phone No:</b></td><td class="value">{$data.mobile_no}</td>
          </tr>
          <tr>
            <td class="label"><b>Gross Pay</b></td><td class="value">{$data.salary_a|number_format:2:".":","} TZS</td>
          </tr>
          <tr>
            <td class="label"><b>Other Benefit:</b></td><td class="value">{$data.benefit_type}{if $data.benefit_description}: {$data.benefit_description}{/if}</td>
          </tr>
          <tr>
            <td class="label"><b>Benefit Amount:</b></td><td class="value">{if $data.benefit_amount > 0}{$data.benefit_amount|number_format:2:".":","}{else} - {/if}</td>
          </tr>
          <tr>
            <td class="label">&nbsp;</td><td class="value">&nbsp;</td>
          </tr>
        </table>
      </td>
      <td>
      </td>
    </tr>
  </table>

</div>

</div>

<section class="content">


{$data.tpl_content}
</section>
{* <table class="table sign" style="margin-top:50px;">
  <tr>
    <td colspan="3" class="title">Order Confirmation</td>
  </tr>
  <tr>
    <td class="label">By:</td><td class="field"></td><td></td>
  </tr>
  <tr>
    <td class="label">Date:</td><td class="field"></td><td></td>
  </tr>
  <tr>
    <td class="label">Sign:</td><td class="field"></td><td></td>
  </tr>
  <tr>
    <td></td><td></td><td></td>
  </tr>
</table> *}
<table class="table sign" style="margin-top:25px;">
  <tr>
    <td colspan="5" class="title"><b>SIGNED</b></td>
  </tr>
  <tr>
    <td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td class="border-bottom"></td><td></td><td></td><td class="border-bottom"></td><td></td>
  </tr>
  <tr>
    <td style="padding-top:5px;">HR MANAGER</td><td></td><td></td><td style="padding-top:5px;">DATE</td><td></td>
  </tr>
  <tr>
    <td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td class="border-bottom"></td><td></td><td></td><td class="border-bottom"></td><td></td>
  </tr>
  <tr>
    <td style="padding-top:5px;">FINANCE MANAGER</td><td></td><td></td><td style="padding-top:5px;">DATE</td><td></td>
  </tr>
  <tr>
    <td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td class="border-bottom"></td><td></td><td></td><td class="border-bottom"></td><td></td>
  </tr>
  <tr>
    <td style="padding-top:5px;">DIRECTOR</td><td></td><td></td><td style="padding-top:5px;">DATE</td><td></td>
  </tr>
  <tr>
    <td></td><td></td><td></td><td></td><td></td>
  </tr>
  <tr>
    <td class="border-bottom"></td><td></td><td></td><td class="border-bottom"></td><td></td>
  </tr>
  <tr>
    <td style="padding-top:5px;">EMPLOYEE: {$data.employee_name}</td><td></td><td></td><td style="padding-top:5px;">DATE</td><td></td>
  </tr>
</table>
  <!-- <div class="pagination"><center><span class='page-number'></span></center></div> -->
</body>
</html>
