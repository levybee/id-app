<!-- PAGE PLUGINS -->
<script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="/js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>

{literal}
<script type="text/javascript">

$(document).ready(function(){


    var page_action =  '{/literal}{$action}{literal}';

    if(page_action == 'edit'){

    var employee_id = '{/literal}{$edit_contract[0].employee_id}{literal}';
    var employee = '{/literal}{$edit_contract[0].employee_name}{literal}';
    console.log(employee);

    if(employee_id){
      var job_option = new Option(employee , employee_id, true, true);
      $("#employee_id").append(job_option).trigger('change');

    }

  }

$("#employee_id").select2({
   placeholder: "Type to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/employees.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       //console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });


 $('.attach_btn').on('click', function(e) {

    e.preventDefault();

    id = $(this).data('id');
    employee = $(this).data('employee');

    $('#attachmentModal').modal('show');

    $('.item_name').text(employee);
    $('input[name="contract_id"]').val(id);
    $('input[name="attachment_path"]').val($(this).data('attachment_path'));

 });

 var submit_form = function(form_name, btn_name, response_element='', modal_element=''){


   $('input[name="'+ btn_name +'"]').val('Sending...').attr('disabled','disabled');


   var post_url = $(form_name).attr('action');;
   var post_data = $(form_name).serialize();
   $.ajax({
     type: 'POST',
     url: post_url,
     data: post_data,
     dataType:'json',
     success	:	function(data){

       console.log(data);

          var alert_class = (data.error == true)? 'danger' : 'success';

          var msg_html = "<ul>";
          $.each(data.msg, function(i, item) {
            msg_html += "<li>"+ data.msg[i] +"</li>";
         });
          msg_html += "</ul>";


          $('input[name="'+ btn_name +'"]').val('Submit').removeAttr('disabled');

            $(response_element).html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

            if(!data.error){

             // $(form_name)[0].reset();

              setTimeout(function(){

                 //$('.item_list').prop('checked', false);
                 $(modal_element).modal('hide');
                 location.reload();

             },5000);

            }



       },
       error : function(XMLHttpRequest, textStatus,
           errorThrown) {

         console.log("Status: " + textStatus);
         console.log("Error: " + errorThrown);

       }


   });



 }

 });

</script>
{/literal}

<!-- END PAGE PLUGINS -->
