
        <!-- MESSAGE BOX-->
        <div class="message-box animated fadeIn" data-sound="alert" id="mb-signout">
            <div class="mb-container">
                <div class="mb-middle">
                    <div class="mb-title"><span class="fa fa-sign-out"></span> Log <strong>Out</strong> ?</div>
                    <div class="mb-content">
                        <p>Are you sure you want to log out?</p>
                        <p>Press No if you want to continue work. Press Yes to logout current user.</p>
                    </div>
                    <div class="mb-footer">
                        <div class="pull-right">
                            <a href="/logout" class="btn btn-success btn-lg">Yes</a>
                            <button class="btn btn-default btn-lg mb-control-close">No</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END MESSAGE BOX-->


        <!-- chat -->
         <button class="chat-btn no-print">
          <span class="fa fa-comments"></span>
          <div class="informer informer-danger active"></div>
        </button>
{*
         <div class="chat-popup">
            <iframe id='chatFrame' src="/chat" frameborder="0" scrolling="no" width="800" height="700"></iframe>
        </div>   *}
        <!-- /chat -->


        <!-- START PRELOADS -->
        <audio id="audio-alert" src="/audio/alert.mp3" preload="auto"></audio>
        <audio id="audio-fail" src="/audio/fail.mp3" preload="auto"></audio>
        <!-- END PRELOADS -->

    <!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="/js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="/js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap.min.js"></script>
        <script type="text/javascript" src="/js/js.cookie.js"></script>
        <!-- END PLUGINS -->


        {if $page_plugins}
          {include file="$page_plugins"}
        {/if}

        <!-- START TEMPLATE -->
        <!-- <script type="text/javascript" src="/js/settings.js"></script> -->

        <script type="text/javascript" src="/js/plugins.js"></script>
        <script type="text/javascript" src="/js/actions.js"></script>
        <script type="text/javascript" src="/js/custom.js"></script>
        <script type="text/javascript" src="/js/general.js"></script>
        <script type="text/javascript" src="/js/lpo.js"></script>

        <script type="text/javascript" src="/js/demo_dashboard.js"></script>
        <!-- END TEMPLATE -->

        <script type="text/javascript" src="/js/chat/chat-pop.js"></script>
    <!-- END SCRIPTS -->

       <!-- START CHAT SCRIPT -->
        {literal}
        <script type="text/javascript">

        var user_id = {/literal}'{$smarty.session.user_data[0].user_id}'{literal};
        console.log('user_id', user_id);
        var wsVar = (window.location.protocol == 'https:')? 'wss' : 'ws';
        var hostname = window.location.hostname;
        var base = wsVar+'://'+hostname+':8082';
        var url = base+'?user_id='+user_id;
        var ws;  // WebSocket instance

        ws = new WebSocket(url);

        ws.onopen = function() {
            console.log("WebSocket connection established - parent.");
        };

        ws.onclose = function(event) {
            console.log("WebSocket connection closed - parent", event);
        };

        ws.onerror = function(event) {
            console.error("WebSocket error observed - parent:", event);
        };

        ws.onmessage = function(event)
        {
            var data = JSON.parse(event.data);
            console.log('ws onmessage - parent', data);

            let informerHtml = $('.chat-btn .informer').html();
            let unread = 0;
            if(data.receiver_userid > 0 || data.to_group_id > 0){

                if(data.userId != user_id && data.receiver_userid == user_id){ // Login user is not the sender of msg
              if(informerHtml != ''){
                unread = parseInt(informerHtml);
                if(data.to_group_id > 0){
                  unread++;
                }else{
                  if(unread > 0){
                    unread++;
                  }else{
                    unread = data.all_unread_count;
                  }
                }

              }else{
                unread = 1;
              }

              if(unread > 0){
                $('.chat-btn .informer').html(unread);
              }else{
                $('.chat-btn .informer').html('');
              }


              // Browser Notifications
              const popBut = document.getElementsByClassName('chat-btn')[0];
              if(!popBut.classList.contains('popped')){

              if(data.receiver_userid == user_id){
                if(data.msg){
                  showNotification(data);
                }else{
                  if(data.attachment){
                    var pieces = data.attachment.split('\/');
                    var filename = pieces[pieces.length-1];
                    data['msg'] = filename;
                    showNotification(data);
                  }
                }
              }

              }

            }else{
              $('.chat-btn .informer').html('');
            }

            }

            if(data.privateUnreadCount != undefined && data.user_id == user_id){

              if(data.privateUnreadCount > 0){
                 unread += parseInt(data.privateUnreadCount);
              }

              if(data.groupUnreadCount > 0){
                 unread += parseInt(data.groupUnreadCount);
              }

              if(unread > 0){
              $('.chat-btn .informer').html(unread);
            }else{
              $('.chat-btn .informer').html('');
            }

            }

            console.log('unread-- ', unread)


        }

        // Browser Notifications
        function showNotification(data) {

            if ('Notification' in window && Notification.permission === 'granted') {
                new Notification(`New Message from ${data.from_user_name}`, {
                    body: data.msg, // The content of the message
                  //  icon: 'path/to/icon.png', // Optional icon
                    tag: 'message' // Ensure only one notification per message
                });
            }
        }

        function requestNotificationPermission() {
            if ('Notification' in window && navigator.serviceWorker) {
                Notification.requestPermission().then(function(permission) {
                    if (permission === 'granted') {
                        console.log('Notification permission granted.');
                    } else {
                        console.log('Notification permission denied.');
                    }
                });
            }
        }

        requestNotificationPermission();


        </script>
        {/literal}
        <!-- END CHAT SCRIPT -->
    </body>
</html>
