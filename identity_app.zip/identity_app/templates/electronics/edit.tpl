{if $privileges.electronics.edit || $privileges.electronics.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/electronics/list">Electronic Equipments</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Electronic Equipment</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
        {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Equipment</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">



                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Name</label>
                         <div class="col-md-6 col-xs-12">

                                 <input type="text" name="name" value="{if $smarty.post.name}{$smarty.post.name}{elseif $edit_electronics[0].name}{$edit_electronics[0].name}{/if}" class="form-control"/>
                          </div>
                     </div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Make</label>
                         <div class="col-md-6 col-xs-12">

                                 <input type="text" name="make" value="{if $smarty.post.make}{$smarty.post.make}{elseif $edit_electronics[0].make}{$edit_electronics[0].make}{/if}" class="form-control"/>
                          </div>
                     </div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Model</label>
                         <div class="col-md-6 col-xs-12">

                                 <input type="text" name="model" value="{if $smarty.post.model}{$smarty.post.model}{elseif $edit_electronics[0].model}{$edit_electronics[0].model}{/if}" class="form-control"/>

                         </div>
                     </div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Year</label>
                         <div class="col-md-6 col-xs-12">

                                 <input type="text" name="year" value="{if $smarty.post.year}{$smarty.post.year}{elseif $edit_electronics[0].year}{$edit_electronics[0].year}{/if}" class="form-control"/>

                         </div>
                     </div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Serial</label>
                         <div class="col-md-6 col-xs-12">

                                 <input type="text" name="serial" value="{if $smarty.post.serial}{$smarty.post.serial}{elseif $edit_electronics[0].serial}{$edit_electronics[0].serial}{/if}" class="form-control"/>

                         </div>
                     </div>

                     <div class="form-group">
                       <label class="col-md-3 col-xs-12 control-label">Department</label>
                       <div class="col-md-6 col-xs-12">
                           <select name="department_id" class="form-control select">
                                <option value="">Select..</option>
                                {section name=departments_list loop=$departments_list}
                                  <option value="{$departments_list[departments_list].department_id}" {if $smarty.post.department_id eq $departments_list[departments_list].department_id || $edit_electronics[0].department_id eq $departments_list[departments_list].department_id}selected{/if}>{$departments_list[departments_list].department_name}</option>
                                {/section}
                           </select>

                       </div>
                    </div>





                   {if $action eq 'edit'}
                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Status</label>
                         <div class="col-md-6 col-xs-12">
                             <select name="status" class="form-control select">
                                  <option value="Active" {if $edit_electronics[0].status eq 'Active'}selected{/if}>Active</option>
                                  <option value="Inactive" {if $edit_electronics[0].status eq 'Inactive'}selected{/if}>Inactive</option>
                             </select>

                         </div>
                     </div>
            {/if}

                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Equipment</button>
                 </div>
             </div>
             </form>
             {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{/if}
