{if $privileges.electronics.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/electronics">Electronic Equipments</a></li>
     <li class="active"><a href="#">List</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Electronic Equipments</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

             {if $privileges.electronics.add}

               <a href="/electronics/add" class="btn btn-default">New Electronic Equipment</a>

               <br><br>

             {/if}
        <div class="panel panel-default">

            <div class="panel-heading">
                 <h3 class="panel-title">Electronic Equipments Table</h3>
                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                             <label>Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th class="text-center">Name</th>
                                <th class="text-center">Make</th>
                                <th class="text-center">Model</th>
                                <th class="text-center">Serial</th>
                                <th class="text-center">Year</th>
                                
                                <th class="text-center">Status</th>
                                <th width="120" class="text-center">actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=electronics_list loop=$electronics_list}
                            <tr>

                                <td class="text-center">{$start+$smarty.section.electronics_list.rownum}</td>

                                <td>{$electronics_list[electronics_list].name}</td>
                                <td>{$electronics_list[electronics_list].make}</td>
                                <td>{$electronics_list[electronics_list].model}</td>
                                <td>{$electronics_list[electronics_list].serial}</td>
                                <td>{$electronics_list[electronics_list].year}</td>
                                
                                <td class="text-center">{$electronics_list[electronics_list].status}</td>
                                <td>
                                    <a href="/electronics/edit/?id={$electronics_list[electronics_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>
                                    <a href="/electronics/delete/?id={$electronics_list[electronics_list].id}" class="btn btn-danger btn-rounded btn-condensed btn-sm" onclick="confirmAction('[Delete Record] Are you sure?', this.href); return false;"><span class="fa fa-times"></span></a>
                                </td>
                            </tr>
                           {sectionelse}
              						  <tr>
              						    <td colspan="5">No Records Found</td>
              						  </tr>
              						  {/section}
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
