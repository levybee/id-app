<!-- PAGE PLUGINS -->
<script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>



{literal}

<script type="text/javascript">



$(document).ready(function(){


$.fn.reset = function () {
$(this).each (function() { this.reset(); });
}

var page_action =  '{/literal}{$action}{literal}';
if(page_action == 'edit'){

var stock_id = '{/literal}{$edit_requisition[0].stock_id}{literal}';
var stock_name = '{/literal}{$edit_requisition[0].stock_name}{literal}';
var item_unit = '{/literal}{$edit_requisition[0].units}{literal}';

var job_id = '{/literal}{$edit_requisition[0].job_id}{literal}';
var job_reference = '{/literal}{$edit_requisition[0].job_reference}{literal}';
var product_name = '{/literal}{$edit_requisition[0].product_name}{literal}';

}

console.log('inside the script..');

$("#stock_id").select2({
placeholder: "Type to search...",
minimumInputLength: 1,
ajax: {
  url: "/ajax/stock.php?add_item=1",
  dataType: 'json',
  delay: 250,
  data: function (params) {

      return {
          q: params.term, // search term
      };
  },
  processResults: function (data) { // parse the results into the format expected by Select2.
      // since we are using custom formatting functions we do not need to alter the remote JSON data

      // Debug:
console.log("Data: " + JSON.stringify(data) );

      return { results: data };
  },
  cache: true
}

});


$('#stock_id').change(function() {


/* console.log('Selected:' + JSON.stringify($(this).select2('data')));
console.log('Unit:' + $(this).select2('data')[0].unit); */

console.log('Selected Value: '+ $(this).val());

$('#item_description').val($(this).text());
$('#item_unit').val($(this).select2('data')[0].unit);
$('.unit').text($(this).select2('data')[0].unit);

if($(this).val() == -1){

$('#item_description2').show();

}else{

$('#item_description2').hide();
}

});

if(page_action == 'edit'){

var stock_option = new Option(stock_name, stock_id, true, true);
$("#stock_id").append(stock_option).trigger('change');
//$('#stock_id').val(stock_id).trigger('change.select2');

if(job_id){

var job_text = job_id + ': ' + job_reference + ' - ' + product_name;
var job_option = new Option(job_text , job_id, true, true);
$("#job_no").append(job_option).trigger('change');

console.log(job_text);
}


}


$("#job_no").select2({
placeholder: "Type Job ID to search...",
minimumInputLength: 1,
ajax: {
  url: "/ajax/jobs.php",
  dataType: 'json',
  delay: 250,
  data: function (params) {

      return {
          q: params.term, // search term
          status: 'In Production',
         // no_sample: 1
      };
  },
  processResults: function (data) { // parse the results into the format expected by Select2.
      // since we are using custom formatting functions we do not need to alter the remote JSON data

      // Debug:
console.log("Data: " + JSON.stringify(data) );

      return { results: data };
  },
  cache: true
}

});



$('input[name="requisition_for"]').on('change', function(e){


if($(this).val() == 'Job' || $(this).val() == 'Stock Return'){

$('#job_field').show();
$('#stock_field').show();
$('#item_description2').hide();

}else if($(this).val() == 'Stock' || $(this).val() == 'Stock Refill'){

$('#job_field').hide();
$('#item_description2').hide();
$('#stock_field').show();

}

});

if($('input[name="sample"]').is(":checked")){
  $('.sample_image').show();
}else{
  $('.sample_image').hide();
}

$('input[name="sample"]').on('change', function(e){
  if($(this).is(":checked")){
    $('.sample_image').show();
  }else{
    $('.sample_image').hide();
  }
})

$('.item_list').on('change', function() {

$('input[type="checkbox"]').not(this).prop('checked', false);

if ($('.item_list:checked').length > 0){
item_action($(this));

/* $('html, body').animate({
  scrollTop: $(".balance_qty").offset().top
}, 1000); */

}else{

$('#item_form').reset();
$('#item_form').modal('hide');
//$('#item_action_form').hide();
}


});



item_action = function(obj){


$('#item_form').modal('show');

$('.item_name').text(obj.data('item-name'));
$('.item_qty').text(obj.data('item-qty'));
$('.balance_qty').text(obj.data('balance-qty'));
$('.item_unit').text(obj.data('item-unit'));
$('input[name="item_id"]').val(obj.val())

}

get_balance_qty = function(new_issued){



if($.isNumeric(new_issued)){

var balance_qty = parseFloat($('.item_list:checked').data('balance-qty'));
var item_qty = parseFloat($('.item_list:checked').data('item-qty'));
var issued_qty = parseFloat($('.item_list:checked').data('issued-qty'));
var total_issued = 0;
var new_balance = 0;


total_issued = issued_qty + parseFloat(new_issued);
new_balance = item_qty - total_issued;

if(new_balance < 0){
  $('.balance_txt').css('color','red');
}else{
  $('.balance_txt').css('color','#22262e');
}

$('.balance_qty').text(new_balance);
$('input[name="balance_qty"]').val(new_balance);
}

}


$('.item_list').each(function (index) {

if($(this).is(":checked")){
console.log('checked..');
item_action($(this));
}

});

var new_issued = $('input[name="issued_qty"]').val();

get_balance_qty(new_issued);

$('input[name="issued_qty"]').on('blur', function(){

var issued = $('input[name="issued_qty"]').val();
get_balance_qty(issued);


});

$('.close_item_form').on('click', function(e){

$('.item_list').prop('checked', false);
$('#item_action_form').reset();
$('#item_form').modal('hide');

});


$('.cancelReq').on('click', function(e) {
e.preventDefault();
req_id = $(this).data("requisition_id");
$('.modal-title').html('Cancel Requisition #'+req_id);
$('#cancel_form').attr('action', $(this).attr('href'));
$('#cancelModal').modal('show');
});

cancelSelected = function(e){
  e.preventDefault();
  console.log('cancelled..');
  return;
}

$('.cancel_selected').on('click', function(e) {
  e.preventDefault();
  reqCancelUri = "/requisitions/list?cancel_multi=1";
  $('.confirmed_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      reqCancelUri += `&id[]=${id}`;
    }

  });

  $('.modal-title').html('Cancel Requisitions');
  $('#cancel_form').attr('action', reqCancelUri);
  $('#cancelModal').modal('show');

});


$('#item_action_form').submit(function(e){


e.preventDefault();

$('input[name="item_submit"]').val('Sending...').attr('disabled','disabled');


var post_url = "/requisitions/";
var post_data = $(this).serialize();
$.ajax({
type: 'POST',
url: post_url,
data: post_data,
dataType:'json',
success	:	function(data){

   var alert_class = (data.error == true)? 'danger' : 'success';

   var msg_html = "<ul>";
   $.each(data.msg, function(i, item) {
     msg_html += "<li>"+ data.msg[i] +"</li>";
  });
   msg_html += "</ul>";

   $('#response').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

   $('input[name="item_submit"]').val('Submit').removeAttr('disabled');

   if(data.gin_id){

     $('#item_action_form').reset();

     setTimeout(function(){

        $('.item_list').prop('checked', false);
        $('#item_form').modal('hide');

    },5000);

   //  location.reload();
   popupPDF('gin', data.gin_id, 0, true);

   }

},
error : function(XMLHttpRequest, textStatus,
    errorThrown) {

  console.log("Status: " + textStatus);
  console.log("Error: " + errorThrown);

}


});


});


// Returns
$('.item_list_returns').on('change', function() {

$('input[type="checkbox"]').not(this).prop('checked', false);

if ($('.item_list_returns:checked').length > 0){
item_action_returns($(this));

}else{

$('#item_form_returns').reset();
$('#item_form_returns').modal('hide');

}


});

$('#item_action_form_returns').submit(function(e){


e.preventDefault();

$('input[name="item_submit_returns"]').val('Sending...').attr('disabled','disabled');


var post_url = "/requisitions/";
var post_data = $(this).serialize();
$.ajax({
type: 'POST',
url: post_url,
data: post_data,
dataType:'json',
success	:	function(data){


   var alert_class = (data.error == true)? 'danger' : 'success';
   console.log('alert_class', alert_class);

   var msg_html = "<ul>";
   $.each(data.msg, function(i, item) {
     msg_html += "<li>"+ data.msg[i] +"</li>";
  });
   msg_html += "</ul>";

   $('#response_returns').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

   $('input[name="item_submit_returns"]').val('Submit').removeAttr('disabled');

   if(data.error == false){

     $('#item_action_form_returns').reset();

     setTimeout(function(){

        $('.item_list_returns').prop('checked', false);
        $('#item_form_returns').modal('hide');
        location.reload();

    },5000);


   }

},
error : function(XMLHttpRequest, textStatus,
    errorThrown) {

  console.log("Status: " + textStatus);
  console.log("Error: " + errorThrown);

}


});


});

item_action_returns = function(obj){

console.log('item_action_returns..');


$('#item_form_returns').modal('show');

$('.item_name_returns').text(obj.data('item-name'));
$('.item_unit_returns').text(obj.data('item-unit'));
$('input[name="item_id_returns"]').val(obj.val());
$('.issued_qty').text(obj.data('issued-qty'));


if(parseInt(obj.data('job-id')) > 0){

$('.job_id_label').text(obj.data('job-id'));
$('input[name="job_id"]').hide();
$('.job_id_label').show();

}else{
$('input[name="job_id"]').show();
  $('.job_id_label').hide();
}

}

$('.item_list_returns').each(function (index) {

if($(this).is(":checked")){
item_action_returns($(this));
}

});

$('.close_item_form_returns').on('click', function(e){

$('.item_list_returns').prop('checked', false);
$('#item_action_form_returns').reset();
$('#item_form_returns').modal('hide');

});





/*  $('input[name="item_submit"]').on('click', function(e) {

e.preventDefault();

var balance = parseFloat($('.balance_qty').text());

if(balance < 0){

 alert('Issued quantity cannot be more than the required item qunatity');

}else{

 $("#item_action_form").submit();
}

});
*/



});

</script>

{/literal}

<!-- END PAGE PLUGINS -->
