<!-- NEW COMPANY MODAL -->
  <div class="modal" id="item_form" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Item: <span class="item_name"></span></h4>
              </div>
              <form id="item_action_form" name="item_action_form" method="post" action="/requisitions" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="response"></div>


			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			                 <div class="panel-body form-group">
			                   <div class="row">


			                       <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Quantity</label>
									    <div class="col-md-6 col-xs-12">
									     <div style="display:inline-block; padding-right:3px;"><p class="form-control-static item_qty"></p></div><div style="display:inline-block;"><span class="item_unit"></span> </div>
									    </div>
									  </div>

									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Issued Quantity</label>
									    <div class="col-md-4 col-xs-12">
									    <div class="col-xs-5" style="padding:0;"><input name="issued_qty" type="text" value="{if $smarty.post.issued_qty}{$smarty.post.issued_qty}{/if}" class="form-control" /></div><div class="col-xs-3" style="padding-top:5px;"><span class="item_unit"></span></div>

									    </div>
									  </div>

									   <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Issued To</label>
									    <div class="col-md-4 col-xs-12">
									    <div class="col-xs-5" style="padding:0;"><input name="issued_to" type="text" value="{if $smarty.post.issued_to}{$smarty.post.issued_to}{/if}" class="form-control" required /></div>

									    </div>
									  </div>

									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Balance Quantity</label>
									    <div class="col-md-6 col-xs-12 balance_txt">
									     <div style="display:inline-block; padding-right:3px;"><p class="form-control-static balance_qty"></p></div><div style="display:inline-block;"><span class="item_unit"></span> </div>
									    </div>
									  </div>
                    <div class="form-group">
                         <label class="col-md-3 control-label">Location</label>
                         <div class="col-md-4">
                           <select name="issued_location" id="issued_location" class="form-control" required>
                             <option value="">Please select..</option>
                            <option value="Office"  {if $smarty.post.issued_location eq "Office"}selected{/if}>Office</option>
                            <option value="Site"  {if $smarty.post.issued_location eq "Site"}selected{/if}>Site</option>
                         </select>
                      </div>
                    </div>



			                   </div>


			                 </div>

			             </div>

	              </div>
	              <div class="modal-footer">
	                  <input type="hidden" name="item_id" value="" >
					  <input type="hidden" name="balance_qty" value="" >
					  <input type="hidden" name="add_item_ajax" value="1" >
	                  <input type="submit" name="item_submit" class="btn btn-primary" value="Submit">
	                  <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                  </div>
              </form>

          </div>
      </div>
  </div>
