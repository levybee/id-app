<!-- Return form Modal -->        
  <div class="modal" id="item_form_returns" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Return Item: <span class="item_name_returns"></span></h4>
              </div>
              <form id="item_action_form_returns" name="item_action_form_returns" method="post" action="/requisitions" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="response_returns"></div>
	                 
	                 
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
			                 
			                
			                 <div class="panel-body form-group">
			                   <div class="row">
			                 
			                     
			                       <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Job #</label>
									    <div class="col-md-6 col-xs-12">        
									     <p class="form-control-static job_id_label"></p>
									     <input name="job_id" type="text" value="" class="form-control" style="display:none;" />
									    </div>
									  </div>
									   
									 
									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Issued Quantity</label>
									    <div class="col-md-6 col-xs-12">        
									     <div style="display:inline-block; padding-right:3px;"><p class="form-control-static issued_qty"></p></div><div style="display:inline-block;"><span class="item_unit_returns"></span> </div>
									    </div>
									  </div>
									  
									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Return Quantity</label>
									    <div class="col-md-6 col-xs-12"> 
									    <div class="col-xs-5" style="padding:0;"><input name="return_qty" type="text" value="" class="form-control" /></div><div class="col-xs-3" style="padding-top:5px;"><span class="item_unit_returns"></span></div>          
									      
									    </div>
									  </div>
									  
									  <!-- 
									   <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Issued To</label>
									    <div class="col-md-4 col-xs-12"> 
									    <div class="col-xs-5" style="padding:0;"><input name="issued_to" type="text" value="{if $smarty.post.issued_to}{$smarty.post.issued_to}{/if}" class="form-control" /></div>         
									      
									    </div>
									  </div>
									  
									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Balance Quantity</label>
									    <div class="col-md-6 col-xs-12 balance_txt">        
									     <div style="display:inline-block; padding-right:3px;"><p class="form-control-static balance_qty"></p></div><div style="display:inline-block;"><span class="item_unit"></span> </div>
									    </div>
									  </div> 
									   -->
									 
			                     
			                   </div>
			               
			
			                 </div>
			                 
			             </div>
	              
	              </div>
	              <div class="modal-footer">
	                  <input type="hidden" name="item_id_returns" value="" >
					  <input type="hidden" name="item_ajax_returns" value="1" >
	                  <input type="submit" name="item_submit_returns" class="btn btn-primary" value="Submit">
	                  <button type="button" class="btn btn-default close_item_form_returns" data-dismiss="modal">Close</button>
                  </div>
              </form>
              
          </div>
      </div>
  </div>