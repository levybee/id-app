{if $privileges.requisitions.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Issued Stock</a></li>
     <li class="active"><a href="">List</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Issued Stock</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">

             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}



        <div class="col-md-12" style="margin-bottom:10px;">
             {* <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> *}
            {include file="search/mini.issued_stock.tpl"}

        <div class="panel panel-default">

            <div class="panel-heading">


                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post" action="/requisitions/issued_stock{if $search_str}?{$search_str}{/if}">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/requisitions/issued_stock{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisitions/issued_stock{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>
                     <li>

                      <form class="form-inline" role="form" method="post" action="/requisitions/issued_stock{if $search_str}?{$search_str}{/if}" style="padding-left:5px;">

                         <input type="hidden" name="export_csv" value="1" >
                         <button name="submit" type="submit" class="btn btn-success">CSV Export</button>

                     </form>
                     </li>

                 </ul>
            </div>




            <div class="panel-body panel-body-table">

                <form method="post" action="">
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">
                    <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th class="text-center">SI No</th>

                								 <th class="text-center">Date Created</th>
                                 <th class="text-center">Stock Name</th>
                								 <th class="text-center">Issued Qty</th>
                                 <th class="text-center">Issued To</th>
                                 <th class="text-center">Issued Location</th>
                								 <th class="text-center">Issued By</th>
                                 <th class="text-center">Actions</th>

                            </tr>
                        </thead>
                        <tbody>
                           {section name=is_list loop=$is_list}
              						  <tr>
              						    <td class="text-center">{$is_list[is_list].issued_stock_id}</td>
              						    <td class="text-center">{$is_list[is_list].date_created|date_format:"%d %b %Y"} <br>  ({$is_list[is_list].date_created|date_format:"%H:%M:%S"})</td>
                              <td class="text-center">{$is_list[is_list].stock_name}</td>
              						    {* <td class="text-center">{if $is_list[is_list].job_id}<a style="text-decoration:none;" href="/jobs/progress?id={$is_list[is_list].job_id}" target="_blank">{$is_list[is_list].job_id}: </a>{$is_list[is_list].job_reference}{/if}</td> *}

              						    <td class="text-center">{$is_list[is_list].issued_qty} {$is_list[is_list].units} </td>
                              <td class="text-center">{$is_list[is_list].issued_to}</td>
                              <td class="text-center">{$is_list[is_list].issued_location}</td>
              						    <td class="text-center">{$is_list[is_list].user}</td>
                              {if !$smarty.get.print}
                              <td class="text-center" style="padding:20px 5px">
                                <a class="btn btn-default btn-rounded btn-condensed btn-sm" title="View GIN" href="#" onclick="popupPDF('gin', {if $is_list[is_list].issued_stock_id}{$is_list[is_list].issued_stock_id}{else}0{/if});" ><span class="fa fa-file-pdf-o"></span></a>
                              </td>
                              {/if}
              						  </tr>
              						  {sectionelse}
              						  <tr>
              						    <td colspan="5">No records found.</td>
              						  </tr>
              						{/section}
                        </tbody>
                    </table>

                </div>
                </form>


            </div>
            <div class="panel-heading">


                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/requisitions/issued_stock{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisitions/issued_stock{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>
                     <li>

                      <form class="form-inline" role="form" method="post" action="/requisitions/issued_stock" style="padding-left:5px;">

                         <input type="hidden" name="export_csv" value="1" >
                         <button name="submit" type="submit" class="btn btn-success">CSV Export</button>

                     </form>
                     </li>

                 </ul>
            </div>



        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
