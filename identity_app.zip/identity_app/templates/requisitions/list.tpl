{if $privileges.requisitions.list}
<script type="text/javascript" src="/js/quote.js"></script>

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Requisitions</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Requisitions</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">

             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

             {if $smarty.get.msg_n}
	            <div class="alert alert-success" role="alert">
	             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	             New requisition request created
	             </div>
	         {/if}



        <div class="col-md-12" style="margin-bottom:10px;">

         {if $privileges.requisitions.add && !$smarty.get.print}

           <a href="/requisitions/add" class="btn btn-default">New Request</a>
           <br><br>


         {/if}


         <!-- <div class="col-md-12" style="margin-bottom:10px;">
           Filter By Department:

            {section name=departments_list loop=$departments_list}

              <a href="/requisitions/list?page=1&filter=1&fby=department&fby_param={$departments_list[departments_list].department_id}{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq $departments_list[departments_list].department_id}btn-success{else}btn-default{/if}"><strong>{$departments_list[departments_list].department_name}</strong>  <span class="badge">{$departments_list[departments_list].no_requisitions}</span></a>

            {/section}


        </div>  -->

        {if !$smarty.get.print}
         Filter By Status: <a href="/requisitions" class="btn {if !$smarty.get.fby_param}btn-success{/if} btn-flat btn-rad">All</a> <a href="/requisitions/list?page=1&filter=1&fby=status&fby_param=Draft{if $smarty.get.fby_param eq 'Refill'}&type=Refill{/if}" class="btn {if $smarty.get.fby_param eq 'Draft' OR $smarty.get.status eq 'Draft'}btn-success{else}btn-default{/if}">Draft <span class="badge">{$draft[0].no}</span></a> <a href="/requisitions/list?page=1&filter=1&fby=status&fby_param=Approved{if $smarty.get.fby_param eq 'Refill'}&type=Refill{/if}" class="btn {if $smarty.get.fby_param eq 'Approved'}btn-success{else}btn-default{/if}">Approved <span class="badge">{$approved[0].no}</span></a> <a href="/requisitions/list?page=1&filter=1&fby=status&fby_param=Complete{if $smarty.get.fby_param eq 'Refill'}&type=Refill{/if}" class="btn {if $smarty.get.fby_param eq 'Complete'}btn-success{else}btn-default{/if}">Complete <span class="badge">{$complete[0].no}</span></a> <a href="/requisitions/list?page=1&filter=1&fby=status&fby_param=Cancelled" class="btn {if $smarty.get.fby_param eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled <span class="badge">{$cancelled[0].no}</span></a>

         &nbsp;&nbsp;&nbsp;
         Filter By Location: <a href="/requisitions/list?page=1&filter=1&fby=location&fby_param=IPL1" class="btn {if $smarty.get.fby_param eq 'IPL1'}btn-success{else}btn-default{/if}">IPL1</a>
         <a href="/requisitions/list?page=1&filter=1&fby=location&fby_param=IPL2" class="btn {if $smarty.get.fby_param eq 'IPL2'}btn-success{else}btn-default{/if}">IPL2</a>

         <br><br>

         Filter By Type: <a href="/requisitions/list?page=1&filter=1&fby=type&fby_param=Refill{if $smarty.get.fby eq 'status'}&status={$smarty.get.fby_param}{/if}" class="btn {if $smarty.get.fby_param eq 'Refill' OR $smarty.get.type eq 'Refill'}btn-success{else}btn-default{/if}">Stock Refill</a>
         <a href="/requisitions/list?page=1&filter=1&fby=type&fby_param=NonRefill{if $smarty.get.fby eq 'status'}&status={$smarty.get.fby_param}{/if}" class="btn {if $smarty.get.fby_param eq 'NonRefill' OR $smarty.get.type eq 'NonRefill'}btn-success{else}btn-default{/if}">Non Stock Refill</a>
         <a href="/requisitions/list?page=1&filter=1&fby=type&fby_param=InCompleteRefill{if $smarty.get.fby eq 'status'}&status={$smarty.get.fby_param}{/if}" class="btn {if $smarty.get.fby_param eq 'InCompleteRefill' OR $smarty.get.type eq 'InCompleteRefill'}btn-success{else}btn-default{/if}">InComplete Stock Refill</a>
         <a href="/requisitions/list?page=1&filter=1&fby=type&fby_param=CompleteRefill{if $smarty.get.fby eq 'status'}&status={$smarty.get.fby_param}{/if}" class="btn {if $smarty.get.fby_param eq 'CompleteRefill' OR $smarty.get.type eq 'CompleteRefill'}btn-success{else}btn-default{/if}">Completed Stock Refill</a>
         <a href="/requisitions/list?page=1&filter=1&fby=type&fby_param=Sample{if $smarty.get.fby eq 'status'}&status={$smarty.get.fby_param}{/if}" class="btn {if $smarty.get.fby_param eq 'Sample' OR $smarty.get.type eq 'Sample'}btn-success{else}btn-default{/if}">Sample</a>

         {/if}

        <div class="panel panel-default">

            <div class="panel-heading">


                {if $smarty.get.fby_param eq 'Draft' || $smarty.get.fby_param eq 'Refill'}
                <label for="approve_selected" name="approve_selected" class="btn btn-success" onclick="return confirm('Are you sure you want to approve selected items?')">
                  {if $smarty.get.fby_param eq 'Draft'}Approve Selected{/if}
                  {if $smarty.get.fby_param eq 'Refill'}Create LPOs on Selected{/if}
                </label>
                {if $smarty.get.fby_param eq 'Draft'}
                <label for="cancel_selected" name="cancel_selected" class="btn btn-danger cancel_selected">
                  Cancel Selected
                </label>
                {/if}

                {else}
                 <h3 class="panel-title">Requests Table</h3>
                {/if}


                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">

                         {if !$smarty.get.print}
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/requisitions/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisitions/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                         {/if}
                         {if $smarty.get.print}
                         <div class="form-group">
                           <a href="/requisitions/list/?page=1&popup=1&print=1&{$search_str}" onClick="this.style.display = 'none'; window.print(); this.style.display = ''; return false;">
                      <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
                     </a>
                         </div>
                    {else}

                         <a href="/requisitions/list?popup=1&print=1&page=1{if $search_str}&{$search_str}{/if}" onClick="popupURL(this.href, 'RequisitionList', 800, 500); return false;">
      					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
      					         </a>
                     {/if}

                     </form>


                     </li>


                 </ul>
            </div>




            <div class="panel-body panel-body-table">

                <form method="post" action="">
                    {if $privileges.requisitions.approve}
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                    {/if}
                    <input type="submit" name="cancel_selected" id="cancel_selected" class="hidden" />

                <div class="table-responsive">
                    <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                              {if $smarty.get.fby_param eq 'Draft' || $smarty.get.fby_param eq 'Refill'}
                                  <th width="40" class="text-center">
                                      <input type="checkbox" id="check_all_confirmed"/></th>{/if}
                 <th>ID</th>
                 <th>Date</th>
                 <!-- <th>Date Required</th> -->
								 <th>Item</th>
								 <th>Job Reference</th>
								 <th>Department</th>
								 <th>Required Qty</th>
								 <th>Issued Qty</th>
								 <th>Balance Qty</th>
								 <th>Qty in Stock</th>
                 <th>Qty Ordered</th>
								 <th>Status</th>
								 <th>User</th>
                 {if !$smarty.get.print}
							    <th class="text-center">Action</th>
                  {/if}
                            </tr>
                        </thead>
                        <tbody>
                           {section name=requisition_list loop=$requisition_list}
						  <tr>
                {if $requisition_list[requisition_list].status eq 'Draft' && $smarty.get.fby_param eq 'Draft'}<td class="text-center">
                    <input type="checkbox" name="confirmed_check[]" class="confirmed_check" value="{$requisition_list[requisition_list].requisition_id}" /></td>{/if}

                    {if $requisition_list[requisition_list].requisition_for eq 'Stock Refill' && $smarty.get.fby_param eq 'Refill'}<td class="text-center">
                        <input type="checkbox" name="lpo_check[]" class="confirmed_check" value="{$requisition_list[requisition_list].requisition_id}" /></td>{/if}

						    {* <td class="text-center">{$start+$smarty.section.requisition_list.rownum}</td> *}
                <td class="text-center">{$requisition_list[requisition_list].requisition_id}</td>
						    <td>{$requisition_list[requisition_list].requisition_date|date_format:"%d %b %Y"} <br>  ({$requisition_list[requisition_list].requisition_date|date_format:"%H:%M:%S"})</td>
               {* <td class="text-center">{if $requisition_list[requisition_list].date_required neq '0000-00-00'}{$requisition_list[requisition_list].date_required|date_format:"%d %b %Y"}{else}-{/if}</td> *}

                <td {if $requisition_list[requisition_list].requisition_for eq 'Stock Refill'}class="text-info"{/if}>{if $requisition_list[requisition_list].stock_id eq 0}{$requisition_list[requisition_list].item_description}{else}{$requisition_list[requisition_list].stock_name}{/if} {if $requisition_list[requisition_list].requisition_for eq 'Stock Refill'}<br> - Stock Refill {/if}
						      {if $requisition_list[requisition_list].remarks} <p style="width:14em; text-overflow: ellipsis; overflow:hidden; white-space: nowrap;"><a style="text-decoration:none;" href="#" title="{$requisition_list[requisition_list].remarks}">{$requisition_list[requisition_list].remarks}</a></p> {/if}

                    {if $requisition_list[requisition_list].sample}
                      <div></div><i><b>Sample</b></i>
                      {if $requisition_list[requisition_list].sample_image}
                        <i> : <a title="Sample Image" href="/{$config.attachment_dir}{$requisition_list[requisition_list].sample_image}" target = "_blank">{$requisition_list[requisition_list].sample_image}</a></i>
                      {/if}
                      </div>
                   {/if}

                </td>
						    <td class="text-center">

                {if $requisition_list[requisition_list].job_id}<a style="text-decoration:none;" href="/jobs/progress?id={$requisition_list[requisition_list].job_id}" target="_blank">
                {$requisition_list[requisition_list].job_id}: </a>{$requisition_list[requisition_list].job_reference} - {$requisition_list[requisition_list].group_company}{elseif $requisition_list[requisition_list].requisition_for eq 'Stock Refill'}Stock Refill{else}-{/if}
                {if $requisition_list[requisition_list].requisition_for eq 'Stock Return'}<br> - <i>Stock Return </i>{/if}
              </td>

                <td class="text-center">
                {if $requisition_list[requisition_list].department_name}{$requisition_list[requisition_list].department_name}{else}-{/if}
                {if $requisition_list[requisition_list].location}<br/>{$requisition_list[requisition_list].location}{/if}
                </td>
						    <td>{$requisition_list[requisition_list].quantity} {$requisition_list[requisition_list].units}</td>
						    <td>{$requisition_list[requisition_list].issued_qty} {$requisition_list[requisition_list].units} </td>
						    <td>
						     {$requisition_list[requisition_list].balance_qty} {$requisition_list[requisition_list].units}
						    </td>
						    <td>{$requisition_list[requisition_list].stock_qty} {$requisition_list[requisition_list].units}</td>
                <td>{if $requisition_list[requisition_list].qty_ordered gt 0}
                {$requisition_list[requisition_list].qty_ordered} {$requisition_list[requisition_list].units}
                {if $requisition_list[requisition_list].lpo}<br><a title="View lpo" href="#" onclick="popupPDF('lpo', {$requisition_list[requisition_list].lpo});" >LPO #{$requisition_list[requisition_list].lpo}</a>{/if}
                {/if}</td>
						    <td>
                  <span class="{if $requisition_list[requisition_list].status eq 'Draft'}text-danger{elseif $requisition_list[requisition_list].status eq 'Approved'}text-info{elseif $requisition_list[requisition_list].status eq 'Complete'}text-success{else}text-default{/if}">{$requisition_list[requisition_list].status}
                  {if $requisition_list[requisition_list].status eq 'Complete' && $requisition_list[requisition_list].issued_to} - Issued to {$requisition_list[requisition_list].issued_to}{/if}
                  {* if $requisition_list[requisition_list].status eq 'Complete'}
                  {assign var=issued_stock_ids value=","|explode:$requisition_list[requisition_list].issued_stock_ids}
                  <br><span class="text-primary">GIN:
                  {foreach from=$issued_stock_ids item=id}
                    <a href="#" onclick="popupPDF('gin', {$id});" >{$id}</a>{if $id != $issued_stock_ids|@end}, {/if}
                  {/foreach}
                </span>
                  {/if *}
              </span>
              {if $requisition_list[requisition_list].status eq 'Approved' && $requisition_list[requisition_list].approval_user_id gt 0}
              <br><i>by {$requisition_list[requisition_list].approval_user}</i>
              <br><i>on {$requisition_list[requisition_list].approval_date|date_format:"%d %b %Y"}
              <br>  ({$requisition_list[requisition_list].approval_date|date_format:"%H:%M:%S"})
              </i>
              {/if}
              {if $requisition_list[requisition_list].status eq 'Complete' && $requisition_list[requisition_list].requisition_for eq 'Stock Return'} <br><i>by {$requisition_list[requisition_list].approval_user}</i>{/if}
              {if $requisition_list[requisition_list].cancel_remarks}
              <br>
              <i>{$requisition_list[requisition_list].cancel_remarks}</i>
              {/if}
               </td>
						    <td>{$requisition_list[requisition_list].user}</td>
                {if !$smarty.get.print}
						    <td>
						      {if $requisition_list[requisition_list].status eq 'Draft' || $requisition_list[requisition_list].status eq 'Approved'}
                   {* {if $requisition_list[requisition_list].status eq 'Approved' && $smarty.session.role_is_admin eq 'Yes'} *}
						       <a href="/requisitions/edit/?id={$requisition_list[requisition_list].requisition_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
                   {* {/if} *}
                   {* {if $requisition_list[requisition_list].status eq 'Draft' && $privileges.requisitions.edit}
						       <a href="/requisitions/edit/?id={$requisition_list[requisition_list].requisition_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
                   {/if} *}
                    {* <a href="/requisitions?actn=cancel&id={$requisition_list[requisition_list].requisition_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Cancel" onclick="confirmAction('[Cancel Requisition Item] Are you sure?', this.href); return false;"><span class="fa fa-times"></span></a> *}

                   <a class="btn btn-default btn-rounded btn-condensed btn-sm cancelReq"
                   data-requisition_id="{$requisition_list[requisition_list].requisition_id}"
                   title="Cancel Requisition" href="/requisitions?actn=cancel&id={$requisition_list[requisition_list].requisition_id}"
                   onclick="return false;"><span class="fa fa-times"></span></a>
						      {/if}
						       <a href="/requisitions/delete/?id={$requisition_list[requisition_list].requisition_id}" class="btn btn-danger btn-rounded btn-condensed btn-sm" title="Delete" onclick="confirmAction('[Delete Requisition Item] Deleting will permanently remove the Requisition from the system. Are you sure?', this.href); return false;"><span class="fa fa-times"></span></a>
						       {if $requisition_list[requisition_list].status eq 'Draft' && $privileges.requisitions.approve}
						       <a href="/requisitions/?actn=approve&id={$requisition_list[requisition_list].requisition_id}" class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Requisition Item] Are you sure?', this.href); return false;" ><span class="fa fa-check"></span></a>
						       {/if}

						       {if $requisition_list[requisition_list].stock_id > 0}<a href="/stock/log?filter=1&stock_id={$requisition_list[requisition_list].stock_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" target="_blank" title="View History"><span class="fa fa-history"></span></a>{/if}
						       {if $requisition_list[requisition_list].balance_qty > 0 && $requisition_list[requisition_list].status eq 'Approved'}

						      <label class="fancy-checkbox">
							    <input type="checkbox" name="selected_item[]" value="{$requisition_list[requisition_list].requisition_id}"  data-item-name="{if $requisition_list[requisition_list].stock_id eq 0}{$requisition_list[requisition_list].item_description}{else}{$requisition_list[requisition_list].stock_name}{/if}" data-item-qty="{$requisition_list[requisition_list].quantity}" data-balance-qty="{$requisition_list[requisition_list].balance_qty}" data-issued-qty="{$requisition_list[requisition_list].issued_qty}" data-item-unit="{$requisition_list[requisition_list].units}" class="item_list form-control" {if $smarty.post.item_id eq $requisition_list[requisition_list].requisition_id && $is_error}checked{/if}  />
							    <i class="fa fa-fw fa-arrow-circle-o-right unchecked" title="Issue Item"></i>
							    <i class="fa fa-fw fa-arrow-circle-right checked"></i>
							  </label>
						       {/if}

						       {if $requisition_list[requisition_list].issued_qty > 0}
						         <label class="fancy-checkbox text-info">
								    <input type="checkbox" name="selected_item_returns[]" value="{$requisition_list[requisition_list].requisition_id}"
								    data-item-name="{if $requisition_list[requisition_list].stock_id eq 0}{$requisition_list[requisition_list].item_description}{else}{$requisition_list[requisition_list].stock_name}{/if}"
								    data-item-qty="{$requisition_list[requisition_list].quantity}"
								    data-balance-qty="{$requisition_list[requisition_list].balance_qty}"
								    data-issued-qty="{$requisition_list[requisition_list].issued_qty}"
								    data-item-unit="{$requisition_list[requisition_list].units}"
								    data-job-id="{$requisition_list[requisition_list].job_id}"
								    class="item_list_returns form-control" {if $smarty.post.item_id eq $requisition_list[requisition_list].requisition_id && $is_error}checked{/if}  />
								    <i class="fa fa-fw fa-arrow-circle-o-left unchecked" title="Return Item"></i>
								    <i class="fa fa-fw fa-arrow-circle-left checked"></i>
								  </label>
						       {/if}
						    </td>
                {/if}
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="7">No records found.</td>
						  </tr>
						  {/section}
                        </tbody>
                    </table>

                </div>
                </form>


            </div>

            <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         {if !$smarty.get.print}
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/requisitions/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/requisitions/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
                  {section name=pagination loop=$numPages}

                    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                  {sectionelse}

                    <option value="1" selected>Page 1</option>


                  {/section}

                   </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                {/if}
                         {if $smarty.get.print}
                         <div class="form-group">
                           <a href="/requisitions/list/?page=1&popup=1&print=1&{$search_str}" onClick="this.style.display = 'none'; window.print(); this.style.display = ''; return false;">
                      <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
                     </a>
                         </div>
                    {else}

                         <a href="/requisitions/list?popup=1&print=1&page=1{if $search_str}&{$search_str}{/if}" onClick="popupURL(this.href, 'RequisitionList', 800, 500); return false;">
      					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
      					         </a>
                     {/if}

                     </form>
                     </li>

                 </ul>
            </div>

     {if $smarty.get.dbg}
     {$privileges.requisitions|@print_r}
     {/if}

        </div>



        {include file="$section/item_form.tpl"}
        {include file="$section/return_form.tpl"}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

  {include file="$section/cancel_form.tpl"}

{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
