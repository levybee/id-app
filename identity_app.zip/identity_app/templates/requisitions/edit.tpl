{if $privileges.requisitions.edit || $privileges.requisitions.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/requisitions/list">Requisitions</a></li>
     <li class="active"><a href="">Request</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Request Requisition</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

         {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}" enctype="multipart/form-data">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Request</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">


                     <div class="form-group">
                        <label class="col-md-3 col-xs-12 control-label">For</label>
                        <div class="col-md-6 col-xs-12">
                        {* <div class="col-md-3">
                          <label class="check"><input type="radio" class="iradio" name="requisition_for"  value="Stock" {if $edit_requisition[0].requisition_for eq 'Stock' || $smarty.post.requisition_for eq 'Stock'} checked="checked"{elseif !$edit_requisition[0].requisition_for} checked="checked"  {/if} /> Gen Stock </label>
                        </div> *}
                        <div class="col-md-4">
                          <label class="check"><input type="radio" class="iradio" name="requisition_for"  value="Job" {if $edit_requisition[0].requisition_for eq 'Job' || $smarty.post.requisition_for eq 'Job'} checked="checked"{/if} /> Job Specific</label>
                        </div>
                         <div class="col-md-4">
                          <label class="check"><input type="radio" class="iradio" name="requisition_for"  value="Stock Refill" {if $edit_requisition[0].requisition_for eq 'Stock Refill' || $smarty.post.requisition_for eq 'Stock Refill'} checked="checked"{/if} /> Stock Refill</label>
                        </div>
                        <div class="col-md-4">
                         <label class="check"><input type="radio" class="iradio" name="requisition_for"  value="Stock Return" {if $edit_requisition[0].requisition_for eq 'Stock Return' || $smarty.post.requisition_for eq 'Stock Return'} checked="checked"{/if} /> Stock Return</label>
                       </div>
                       </div>
                    </div>

                    <div class="form-group" id="job_field" {if $edit_requisition[0].requisition_for eq 'Job' || $smarty.post.requisition_for eq 'Job' || $edit_requisition[0].requisition_for eq 'Stock Return' || $smarty.post.requisition_for eq 'Stock Return'}{else}style="display:none;"{/if}>
                         <label class="col-md-3 col-xs-12 control-label">Job #</label>
                          <div class="col-md-6 col-xs-12">

		                    <select name="job_no" id="job_no"  class="form-control" style="width:100%;" ></select>


		                   </div>

                     </div>



                     <div class="form-group" id="stock_field">
		                <label class="col-md-3 col-xs-12 control-label">Item</label>
		                <div class="col-md-6 col-xs-12">

		                    <select name="stock_id" id="stock_id"  class="form-control" ></select>
		                    <input type="hidden" name="item_description" id="item_description" value="" >
		                    <input type="hidden" name="item_unit" id="item_unit" value="" >

		                </div>
		            </div>

                    {if $smarty.session.role_name eq 'Super Sales' || $smarty.session.role_name eq 'Sales - Remote Office' || $smarty.session.role_name eq 'Sales' || $smarty.session.role_name eq 'Administrator'}
                     <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">Sample?</label>
                        <div class="col-md-6 col-xs-12">
                                <label class="control-label"><input type="checkbox"  id="sample" name="sample" value="1" {if $smarty.post.sample eq '1' || $edit_requisition[0].sample eq '1'}checked{/if}></label>
                        </div>
                    </div>


                    <div class="form-group sample_image">
                      <label class="col-md-3 control-label">Sample Image </label>
                      <div class="col-md-6">

                          {if $edit_requisition[0].sample_image}
                          <div>
                            <a title="Sample Image" href="/{$config.attachment_dir}{$edit_requisition[0].sample_image}"
                            target = "_blank">{$config.attachment_dir}{$edit_requisition[0].sample_image}</a>
                            <input type="hidden" name="attachment_path" value="{$edit_requisition[0].sample_image}" />
                          </div>
                          {/if}
                          <input name="sample_image" type="file"  class="form-control" />
                      </div>
                  </div>

                   {/if}

                   <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Location</label>
					    <div class="col-md-6 col-xs-12">
					        <select name="location" id="location" class="form-control select">
						        <option value="">Please Select</option>
						        <option value="IPL1" {if $edit_requisition[0].location eq 'IPL1' || $smarty.post.location eq 'IPL1'}selected{/if}>IPL1</option>
						        <option value="IPL2" {if $edit_requisition[0].location eq 'IPL2' || $smarty.post.location eq 'IPL2'}selected{/if}>IPL2</option>
						    </select>
					    </div>
					</div>


                     <div class="form-group" id="item_description2" {if $edit_requisition[0].stock_id eq '0' || $smarty.post.item_description2}{else}style="display:none;"{/if}>
                         <label class="col-md-3 col-xs-12 control-label">Item Description</label>
                         <div class="col-md-6 col-xs-12">
                             <input name="item_description2" type="text" value="{if $smarty.post.item_description2}{$smarty.post.item_description2}{else}{$edit_requisition[0].item_description2}{/if}" class="form-control" />

                         </div>
                     </div>


                   <!--  <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Category</label>
					    <div class="col-md-6 col-xs-12">
					        <select name="category" id="category" class="form-control select">
						        <option value="">Please Select</option>
						        <option value="Offset Paper" {if $edit_stock[0].category eq 'Offset Paper'}selected{/if}>Offset Paper</option>
						        <option value="Offset Consumables" {if $edit_stock[0].category eq 'Offset Consumables'}selected{/if}>Offset Consumables</option>
						        <option value="Wide Format" {if $edit_stock[0].category eq 'Wide Format'}selected{/if}>Wide Format</option>
						        <option value="Promotional" {if $edit_stock[0].category eq 'Promotional'}selected{/if}>Promotional</option>
						        <option value="T-Shirt" {if $edit_stock[0].category eq 'T-Shirt'}selected{/if}>T-Shirt</option>
						        <option value="Signage" {if $edit_stock[0].category eq 'Signage'}selected{/if}>Signage</option>
						        <option value="Screen Printing Consumables" {if $edit_stock[0].category eq 'Screen Printing Consumables'}selected{/if}>'Screen Printing Consumables</option>

						    </select>
					    </div>
					</div> -->

					<!-- <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Item</label>
					    <div class="col-md-6 col-xs-12">

					          <select name="paper_id" id="paper_id" class="form-control select">
					    		<option value="0" {if !$edit_requisition[0].paper_id}selected="selected"{/if}>Please Select</option>
						        {section name=paper_types loop=$paper_types}
						        	<option value="{$paper_types[paper_types].paper_id}" {if $edit_requisition[0].paper_id eq $paper_types[paper_types].paper_id || $smarty.post.paper_id eq $paper_types[paper_types].paper_id}selected{/if}>{$paper_types[paper_types].paper_name}</option>
						        {/section}
						    </select>


					    </div>
					</div> -->


					 <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Quantity</label>
                         <div class="col-md-3">
	                         <div class="col-xs-9" style="padding:0;">
	                             <input name="quantity" type="text" id="quantity" value="{if $smarty.post.quantity}{$smarty.post.quantity}{else}{$edit_requisition[0].quantity}{/if}" class="form-control" />

	                         </div>
	                         <div class="col-xs-3" style="padding-top:5px;">
			                        <span class="unit">{$edit_requisition[0].units}</span>
			                 </div>
		                 </div>

                     </div>
                   {*  <div class="form-group">
                       <label class="col-md-3 control-label">Date Required</label>
                       <div class="col-md-2">
                            <input name="date_required" type="text" id="date_required" value="{if $smarty.post.date_required}{$smarty.post.date_required|date_format:'%Y-%m-%d'}{elseif $edit_requisition[0].date_required}{$edit_requisition[0].date_required}{/if}" class="form-control datepicker" readonly="true">
                       </div>
                     </div> *}


                      <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Remarks</label>
					    <div class="col-md-6 col-xs-12">

					        <textarea name="remarks" class="form-control" rows="8">{if $smarty.post.remarks}{$smarty.post.remarks}{else}{$edit_requisition[0].remarks}{/if}</textarea>


					    </div>
					</div>

                    <!--
                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Size</label>
					    <div class="col-md-6 col-xs-12">
					        <select name="size_id" id="size_id" class="form-control select">
						        <option value="0" {if !$edit_requisition[0].size_id}selected="selected"{/if}>Please Select</option>
						    {section name=paper_sizes loop=$paper_sizes}
						        <option value="{$paper_sizes[paper_sizes].size_id}" {if $edit_requisition[0].size_id eq $paper_sizes[paper_sizes].size_id}selected{/if}>{$paper_sizes[paper_sizes].paper_size}</option>
						    {/section}
						    </select>
					    </div>
					</div> -->

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Request</button>
                 </div>
             </div>
             </form>


            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->


{/if}
