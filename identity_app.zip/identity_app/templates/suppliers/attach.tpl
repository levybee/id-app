{if $privileges.suppliers.attach}

<ul class="breadcrumb">
   <li><a href="/">Home</a></li>
   <li><a href="/suppliers/list">Suppliers</a></li>
   <li class="active"><a href="">Documents</a></li>
</ul>
<!-- END BREADCRUMB -->
<div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>Suppliers &gt; Documents</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
        {/if}
        
        {if $show_custom_error} 
		 <div class="alert alert-danger" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             An error has occurred. Please ensure you click on the attachments icon on a <a href="/suppliers">Companies / Group</a> page.
         </div>
		
		{else}
		
		
		<div class="col-md-6">
		    
		    
		    	<div class="panel panel-default">
		  <div class="panel-heading">
	            <h3 class="panel-title">Supplier Information</h3>
	        </div>
		  <div class="panel-body panel-body-table">
            <div class="table-responsive">
               <table class="table table-striped">
		          <tr>
		            <td width="140" class="header_row"><div align="right"><strong>Type</strong></div></td>
		            <td>{$supplier_info[0].supplier_type}</td>
		          </tr>
		          
		          <tr>
		            <td class="header_row"><div align="right"><strong>Contact</strong></div></td>
		            <td>{$supplier_info[0].supplier_fname} {$supplier_info[0].supplier_lname}</td>
		          </tr>
		          
		          <tr>
		            <td class="header_row"><div align="right"><strong>Company</strong></div></td>
		            <td>{$supplier_info[0].supplier_company}</td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>Tel #</strong></div></td>
		            <td>{$supplier_info[0].supplier_phone}</td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>Fax #</strong></div></td>
		            <td>{$supplier_info[0].supplier_fax}</td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>Mobile #</strong></div></td>
		            <td>{$supplier_info[0].supplier_mobile}</td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>Email Address</strong></div></td>
		            <td>{$supplier_info[0].supplier_email}</td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>Address</strong></div></td>
		            <td>{$supplier_info[0].supplier_address}</td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>City</strong></div></td>
		            <td>{$supplier_info[0].supplier_city}</td>
		          </tr>
		          <tr>
		            <td class="header_row"><div align="right"><strong>Country</strong></div></td>
		            <td>{$supplier_info[0].supplier_country}</td>
		        </table>
             
            </div>
		  </div>          
		
		</div>
		
		
		
		</div>
		
		<div class="col-md-6">
		   
		   
		   
	    <form action="/suppliers/attach?id={$supplier_id}" method="post" class="form-horizontal" enctype="multipart/form-data" name="form1">
	       
	       <div class="panel panel-default">
		        <div class="panel-heading">
		            <h3 class="panel-title">Attach Documents</h3>
		        </div>
		        <div class="panel-body">
		            <p></p>
		        </div>
		        <div class="panel-body form-group">
		             <div class="form-group">                                        
		                <label class="col-md-3 col-xs-12 control-label">Attachment</label>
		                <div class="col-md-6 col-xs-12">
		                  <input name="attachment_file" type="file" id="attachment_file" class="form-control" />
		                </div>
		            </div>
		            <div class="form-group">
		                <label class="col-md-3 col-xs-12 control-label">Description</label>
		                <div class="col-md-6 col-xs-12">                                                                                            
					    <input name="attachment_name" type="text" id="attachment_name" class="form-control" />
		                   
		                </div>
		            </div>
		            <div class="form-group">
		                <button type="submit" name="Submit" class="btn btn-primary pull-right">Submit</button>
		            </div>
		        </div>
		        
		    </div>   
		</form>
		
		
		<div class="panel panel-default">
		        <div class="panel-heading">
		            <h3 class="panel-title">Manage Documents</h3>
		        </div>
		        <div class="panel-body panel-body-table">
		            <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>Description</th>
							    <th width="50">Actions</th>
							    
                            </tr>
                        </thead>
                        <tbody>  
                          {section name=attachment_list loop=$attachment_list}
						  <tr>
						    <td class="text-center">{$start+$smarty.section.attachment_list.rownum}</td>
						    <td><a href="{$config.supplier_attachment_dir}{$attachment_list[attachment_list].attachment_path}">{$attachment_list[attachment_list].attachment_name}</a></td>
						    <td class="text-center"><a href="/suppliers/attach?id={$supplier_id}&attachment={$attachment_list[attachment_list].attachment_id}&task=delete"  class="btn btn-danger btn-rounded btn-condensed btn-sm"><span class="fa fa-times"></span></a></td>
						   
						  </tr>
						  {sectionelse}
						  <tr>
						  	<td colspan="3">No attachments found</td>
						  </tr>
						  {/section}
						  
						
                        </tbody>
                    </table>
              
                </div>  
		        </div>
		        
		    </div>
		
		
		
		</div>
		
		
	
        
		    
		    {/if}
	                         

    </div>
  </div>
 </div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 




{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">
       
       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>
      
    </div>

  
</div>            
  
</div> 
{/if}