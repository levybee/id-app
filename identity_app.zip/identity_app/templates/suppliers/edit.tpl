{if $privileges.suppliers.edit || $privileges.suppliers.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/suppliers/list">Suppliers</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Supplier</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

        {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Suppliers</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">

                   <div class="form-group">
                       <label class="col-md-3 col-xs-12 control-label">Category</label>
                       <div class="col-md-6 col-xs-12">
                              <select name="supplier_category" class="form-control select">
                    <option value="">Please select..</option>
                    <option value="Supplier" {if $edit_supplier[0].supplier_category eq 'Supplier' || $smarty.post.supplier_category == 'Supplier'}selected{/if}>Supplier</option>
                    <option value="Contractor" {if $edit_supplier[0].supplier_category eq 'Contractor' || $smarty.post.supplier_category == 'Contractor'}selected{/if}>Contractor</option>
                  </select>
                       </div>
                   </div>

                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">First Name</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_fname" value="{if $smarty.post.supplier_fname}{$smarty.post.supplier_fname}{elseif $edit_supplier[0].supplier_fname}{$edit_supplier[0].supplier_fname}{/if}" class="form-control"/>

					    </div>
					</div>
					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Last Name</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_lname" value="{if $smarty.post.supplier_lname}{$smarty.post.supplier_lname}{elseif $edit_supplier[0].supplier_lname}{$edit_supplier[0].supplier_lname}{/if}" class="form-control"/>


					    </div>
					</div>


					 <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Company</label>
                         <div class="col-md-6 col-xs-12">
                             <input name="supplier_company" type="text" id="supplier_company" value="{$edit_supplier[0].supplier_company}" class="form-control" />

                         </div>
                     </div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Type</label>
                         <div class="col-md-6 col-xs-12">
                                <select name="supplier_type" class="form-control select">
                      <option value="">Please select..</option>
						        	<option value="Local Supplier" {if $edit_supplier[0].supplier_type eq 'Local Supplier' || $smarty.post.supplier_type == 'Local Supplier'}selected{/if}>Local Supplier</option>
                      <option value="Overseas Supplier" {if $edit_supplier[0].supplier_type eq 'Overseas Supplier' || $smarty.post.supplier_type == 'Overseas Supplier'}selected{/if}>Overseas Supplier</option>
                      {* <option value="Casual" {if $edit_supplier[0].supplier_type eq 'Casual' || $smarty.post.supplier_type == 'Casual'}selected{/if}>Casual</option> *}

						        </select>
                         </div>
                     </div>


                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Tel</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_phone" value="{if $smarty.post.supplier_phone}{$smarty.post.supplier_phone}{elseif $edit_supplier[0].supplier_phone}{$edit_supplier[0].supplier_phone}{/if}" class="form-control"/>


					    </div>
					</div>
                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Fax</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_fax" value="{if $smarty.post.supplier_fax}{$smarty.post.supplier_fax}{elseif $edit_supplier[0].supplier_fax}{$edit_supplier[0].supplier_fax}{/if}" class="form-control"/>


					    </div>
					</div>
                    <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Mobile</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_mobile" value="{if $smarty.post.supplier_mobile}{$smarty.post.supplier_mobile}{elseif $edit_supplier[0].supplier_mobile}{$edit_supplier[0].supplier_mobile}{/if}" class="form-control"/>

					    </div>
					</div>
					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Email Address</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_email" value="{if $smarty.post.supplier_email}{$smarty.post.supplier_email}{elseif $edit_supplier[0].supplier_email}{$edit_supplier[0].supplier_email}{/if}" class="form-control"/>


					    </div>
					</div>
                    <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Address</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_address" value="{if $smarty.post.supplier_address}{$smarty.post.supplier_address}{elseif $edit_supplier[0].supplier_address}{$edit_supplier[0].supplier_address}{/if}" class="form-control"/>


					    </div>
					</div>
					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">City</label>
					    <div class="col-md-6 col-xs-12">

					            <input type="text" name="supplier_city" value="{if $smarty.post.supplier_city}{$smarty.post.supplier_city}{elseif $edit_supplier[0].supplier_city}{$edit_supplier[0].supplier_city}{/if}" class="form-control"/>


					    </div>
					</div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Country</label>
                         <div class="col-md-6 col-xs-12">
                                <select name="supplier_country" class="form-control select">
						        {section name=countries loop=$countries}
						        	<option value="{$countries[countries]}" {if $edit_supplier[0].supplier_country eq $countries[countries]}selected{/if}{if !$edit_supplier[0].supplier_country && $config.default_country eq $countries[countries]}selected{/if}>{$countries[countries]}</option>
						        {/section}
						        </select>
                         </div>
                     </div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">TIN</label>
                         <div class="col-md-6 col-xs-12">
                             <input type="text" autocomplete='off' name="supplier_tin" value="{if $smarty.post.supplier_tin}{$smarty.post.supplier_tin}{elseif $edit_supplier[0].supplier_tin}{$edit_supplier[0].supplier_tin}{/if}" class="form-control"/>
                         </div>
                     </div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">VRN</label>
                         <div class="col-md-6 col-xs-12">
                             <input type="text" autocomplete='off' name="supplier_vrn" value="{if $smarty.post.supplier_vrn}{$smarty.post.supplier_vrn}{elseif $edit_supplier[0].supplier_vrn}{$edit_supplier[0].supplier_vrn}{/if}" class="form-control"/>
                         </div>
                     </div>
                     <div class="form-group">
                             <label class="col-md-3 control-label">Payment Terms</label>
                             <div class="col-md-6">

                   					   <select name="payment_id" id="payment_id" class="form-control" required>
                   				      <option value="">Please Select</option>

                   				      {section name=item_payment_terms loop=$item_payment_terms}

                   				       <option value="{$item_payment_terms[item_payment_terms].payment_id}" {if $item_payment_terms[item_payment_terms].payment_id eq $smarty.post.payment_id || $edit_supplier[0].payment_id eq $item_payment_terms[item_payment_terms].payment_id}selected{/if}>{$item_payment_terms[item_payment_terms].payment_term}</option>

                   				      {/section}

                   				     </select>
                   					 </div>
                         </div>

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Supplier</button>
                 </div>
             </div>
             </form>

             {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->


{/if}
