<div class="panel panel-default">
      <form method="post" action="/petty_cash_mobile/add" id="subm">
       <div class="panel-heading">
		        <div class="col-sm-6"><h3 class="panel-title">Bank Transfer Items</h3></div>
            <div class="col-sm-6">
                {if $smarty.session.pcm.item_type == 'LPO' && $smarty.session.pcm.supplier.supplier_type == 'Casual'}
                {else}
            <button type="submit" class="btn btn-default pull-right all_overdue">Check All Overdue</button>
             {/if}
            </div>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table pad-6 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th class="text-center" width="40">{$smarty.session.pcm.item_type}</th>
                                <th class="text-center" width="40">Date</th>
                                {if $smarty.session.pcm.item_type == 'GRN'}<th class="text-center" width="40">Invoice No.</th>{/if}
                                {if $smarty.session.pcm.item_type == 'LPO' && $smarty.session.pcm.supplier.supplier_type == 'Casual'}<th class="text-center" width="40">Remarks</th>{/if}
                                <th class="text-center" width="40">Days Overdue</th>
                                <th class="text-center">Total ({$smarty.session.pcm.currency})</th>
              							    <th class="text-center">Upaid ({$smarty.session.pcm.currency})</th>
              							    <th class="text-center">Items {if $smarty.session.pcm.item_type == 'LPO'}Amount{/if}</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.pcm.pc_items}

                            {if $smarty.session.pcm.pc_items[items].balance > 0}
						  <tr>
						    <td class="text-center">
                  {if $smarty.session.pcm.item_type == 'LPO'}
                   LPO-{$smarty.session.pcm.pc_items[items].lpo_date|substr:0:4}-{$smarty.session.pcm.pc_items[items].lpo_id|leading_zero:5}
                  {/if}
                  {if $smarty.session.pcm.item_type == 'GRN'}
                  GRN-{$smarty.session.pcm.pc_items[items].grn_date|substr:0:4}-{$smarty.session.pcm.pc_items[items].grn_id|leading_zero:5}
                  {/if}
                </td>
                <td class="text-center">
                    {if $smarty.session.pcm.item_type == 'GRN'}
                {$smarty.session.pcm.pc_items[items].grn_date|date_format:"%d/%m/%Y"}
                {else}
                {$smarty.session.pcm.pc_items[items].lpo_date|date_format:"%d/%m/%Y"}
                {/if}
                    </td>
                {if $smarty.session.pcm.item_type == 'GRN'}<td class="text-center">{$smarty.session.pcm.pc_items[items].invoice_no}</td>{/if}
                {if $smarty.session.pcm.item_type == 'LPO' && $smarty.session.pcm.supplier.supplier_type == 'Casual'}<td>{$smarty.session.pcm.pc_items[items].comments}</td>{/if}
                <td class="text-center">{if $smarty.session.pcm.pc_items[items].overdue}{$smarty.session.pcm.pc_items[items].days_overdue}{else}-{/if}</td>
                <td class="text-right">{$smarty.session.pcm.pc_items[items].total_amount|number_format:2:".":","}</td>
						    <td class="text-right balance{$smarty.section.items.rownum}">{$smarty.session.pcm.pc_items[items].balance|number_format:2:".":","}</td>
						    <td class="text-center">
					{if $smarty.session.pcm.item_type == 'LPO'}
					<input  type="text" data-balance-id="balance{$smarty.section.items.rownum}"
					id="allocation_{$smarty.section.items.rownum}"
					name="allocation[{if $smarty.session.pcm.pc_items[items].grn_id > 0}{$smarty.session.pcm.pc_items[items].grn_id}{else}{$smarty.session.pcm.pc_items[items].lpo_id}{/if}]"
					value="{$smarty.session.pcm_edit.pc_items.amount_paid}" class="form-control pc_val text-right">
					{else}
					<input type="checkbox"
                id="allocation_{$smarty.section.items.rownum}"
                data-overdue="{$smarty.session.pcm.pc_items[items].overdue}"
                name="allocation[{if $smarty.session.pcm.pc_items[items].grn_id > 0}{$smarty.session.pcm.pc_items[items].grn_id}{else}{$smarty.session.pcm.pc_items[items].lpo_id}{/if}]"
                value="{if $smarty.session.pcm.pc_items[items].balance}{$smarty.session.pcm.pc_items[items].balance}{else}{/if}" 
                class="pc_val">
					{/if}

                </td>
						  </tr>
                {/if}

						  {sectionelse}
						  <tr>
						    <td colspan="5"><div>No items available.</td>
						  </tr>
						  {/section}

						  {if $smarty.session.pcm.pc_items|@count > 0}
						    <tr>
                    <th  class="text-right" colspan="{if $smarty.session.pcm.item_type == 'LPO' && $smarty.session.pcm.supplier.supplier_type != 'Casual'}3{else}4{/if}"><strong>TOTAL</strong></th>
                    <th class="text-right"> <div id="pc_total">{$smarty.session.pcm.pc_total|number_format:2:".":","}</div> </th>
                    <th class="text-right"> <div id="balance_total">{$smarty.session.pcm.balance_total|number_format:2:".":","}</div> </th>
                    <th class="text-right"> <div id="allocation_total">0</div> </th>
                    <input type="hidden" name="allocation_total" value="0" >
                    <input type="hidden" name="pc_total" value="{$smarty.session.pcm.pc_total}">
                </tr>
						  {/if}

                  </tbody>
              </table>
                {if $smarty.get.debugs eq 'lev'}
                 <pre> {$smarty.session.pcm|@print_r}</pre>
                {/if}
              </div>

  </div>
    <div class="panel-footer">
          <input type="hidden" name="next_step" value="three" />
          <input type="hidden" name="complete" value="1" />
          <input type="submit" name="submit" value="Submit" class="btn btn-success pull-right" {if $smarty.session.pcm.balance_total == 0}disabled{/if} />
    </div>
  </form>
</div>
