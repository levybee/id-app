<!-- PAGE PLUGINS -->
       <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
       <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
       <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>



{literal}

<script type="text/javascript">

$(document).ready(function(){

$('.select2').select2();

 $.fn.reset = function () {
   $(this).each (function() { this.reset(); });
 }

   var page_action =  '{/literal}{$action}{literal}';
   var contractor_job_id = '{/literal}{$contractor_job_id}{literal}';
  if(page_action == 'edit' || contractor_job_id){

    var job_id = '{/literal}{$pc_data.job_id}{literal}';
    var job_reference = '{/literal}{$pc_data.job_reference}{literal}';

    if(contractor_job_id){
      job_id = contractor_job_id;
      var job_reference = '{/literal}{$job_reference}{literal}';
    }
    console.log('job_id', job_id);
    // var product_name = '{/literal}{$edit_petty_cash_mobile[0].product_name}{literal}';

    var lpo_id = '{/literal}{$pc_data.lpo_id}{literal}';
    var supplier_company = '{/literal}{$pc_data.supplier_company}{literal}';
    console.log('supplier_company', supplier_company);

    if(job_id){

      var job_text = job_id + ': ' + job_reference; //+ ' - ' + product_name;
      var job_option = new Option(job_text , job_id, true, true);
      $("#job_id").append(job_option).trigger('change');

      console.log(job_text);
    }

    if(lpo_id){

      var lpo_text = lpo_id + ': ' + supplier_company; //+ ' - ' + product_name;
      var lpo_option = new Option(lpo_text , lpo_id, true, true);
      $("#lpo_id").append(lpo_option).trigger('change');

      console.log(lpo_text);
    }

     var group_id = '{/literal}{$pc_data.group_id}{literal}';
      if(group_id){

        var group_text = group_id + ': ' + '{/literal}{$pc_data.group_company}{literal}';
        var group_option = new Option(group_text , group_id, true, true);
        $("#group_id").append(group_option).trigger('change');

        console.log(group_text);
      }
    var job_reference = '{/literal}{$pc_data.job_reference}{literal}';

    var lpo_amount = '{/literal}{$edit_petty_cash_mobile[0].lpo_amount}{literal}';
    var amount_paid = '{/literal}{$edit_petty_cash_mobile[0].amount_paid}{literal}';
    var balance = '{/literal}{$edit_petty_cash_mobile[0].lpo_balance}{literal}';

    $('.lpo_balances').show();
    $('.lpo_amount').html(addCommas(lpo_amount));
    $('.amount_paid').html(addCommas(amount_paid));
    $('.balance').html(addCommas(balance));
    $('#balance').val(balance);


 }

 var supplier_type = '{/literal}{$smarty.session.pcm.supplier.supplier_type}{literal}';
 var item_type = '{/literal}{$smarty.session.pcm.item_type}{literal}';

 $("#expense_id").select2({
   placeholder: "Type to search..."
 });


 $("#job_id").select2({
   placeholder: "Type Job ID to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/jobs.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
                 status: 'not_pending'
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $("#lpo_id").select2({
  placeholder: "Type LPO ID to search...",
  minimumInputLength: 1,
  ajax: {
        url: "/ajax/lpo.php",
        dataType: 'json',
        delay: 250,
        data: function (params) {

            return {
                q: params.term, // search term
                customer_id: "",
                status: "Approved",

            };
        },
        processResults: function (data) { // parse the results into the format expected by Select2.
            // since we are using custom formatting functions we do not need to alter the remote JSON data

            // Debug:
      //console.log("Data: " + JSON.stringify(data) );

            return { results: data };
        },
        cache: true
    }

 });

 $("#group_id").select2({
   placeholder: "Type to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/customers_group.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $('#lpo_id').on('change', function (e) {

   var lpo_amount = $(this).select2('data')[0].lpo_amount;
   var amount_paid = $(this).select2('data')[0].amount_paid;
   var balance = $(this).select2('data')[0].lpo_balance;

   $('.lpo_balances').show();
   $('.lpo_amount').html(addCommas(lpo_amount));
   $('.amount_paid').html(addCommas(amount_paid));
   $('.balance').html(addCommas(balance));
   $('#balance').val(balance);

 });



 $('#supplier_id').on('change', function (e){

   var paymentTerms = $(this).find(':selected').attr('data-payment-terms');
   console.log('pt', paymentTerms);
   console.log('val', $(this).val());

 });

 $('#account_id').on('change', function (e){
   var account_name = $(this).find(':selected').text();
   $('#account_name').val(account_name);

   if($('input[name="type"]:checked').val() == 'Contra'){
     var currency = $(this).find(':selected').data('currency');
     $('#currency').val(currency);
   }

 });

  var pay_type = $('input[name="type"]:checked').val();
  if(pay_type){
    toggleFormFields(pay_type);
  }
//  if(pay_type == 'Direct'){
//    $('.direct_field').show();
//    $('.sup_field').hide();
//  }else{
//    $('.direct_field').hide();
//    $('.sup_field').show();
//  }

  $('input[name="type"]').on('change', function(e){
    console.log('this change', $(this).val());
    toggleFormFields($(this).val());

  });

function toggleFormFields($type){
   console.log('type', $type);
   contractor_id = '{/literal}{$smarty.get.contractor_id}{literal}';
    if($type == 'Direct'){
      $('.sup_field').hide();
      $('.currency').hide();
      $('.account_to').hide();
      $('.trans_field').show();
      $('.gepg').hide();
      $('.customer').hide();
      $('.amount').show();
      $('.remarks').show();
      $('.direct_field').show();
    }else if($type == 'Contra'){
      $('.direct_field').hide();
      $('.sup_field').hide();
      $('.trans_field').hide();
      $('.gepg').hide();
      $('.customer').hide();
      $('.contra').show();
    }else if($type == 'GEPG Payment'){
      $('.direct_field').hide();
      $('.sup_field').hide();
      $('.trans_field').hide();
      $('.contra').hide();
      $('.customer').hide();
      $('.amount').show();
      $('.gepg').show();
     }else if($type == 'Customer'){
      $('.direct_field').hide();
      $('.sup_field').hide();
      $('.trans_field').hide();
      $('.contra').hide();
      $('.amount').show();
      $('.remarks').show();
      $('.customer').show();

    }else{
      console.log('type', $type);
      $('.direct_field').hide();
      $('.sup_field').show();
      $('.currency').hide();
      $('.account_to').hide();
      $('.gepg').hide();
      $('.customer').hide();
      $('.trans_field').hide();
      $('.remarks').show();
      $('.wht').show();
      if(contractor_id){
        $('.expense').show(); 
      }
     // $('.amount').show();
    }

    if($type == 'GEPG Payment'){
      $('.attach').text('Attachment');
    }else{
     $('.attach').text('Approval Attachment');
    }


}  


$('#wht_tax').on('change', function(e){

  if($(this).val() == 'Taxable'){
    $('.wht_percent').show();
  }else{
    $('.wht_percent').hide();
  }

});

// GRN/LPO Items
var pc_total = parseFloat($('#pc_total').text());

calc_allocation_total();

$('.pc_val').on('change', function() {

if(! $(this).val() > 0){
  $(this).prop('checked', false);
}else{
  calc_allocation_total();
}

// $('input[type="checkbox"]').not(this).prop('checked', false);

});

// Overdue
$('.all_overdue').on('click', function(e) {

    e.preventDefault();
    $('.pc_val').each(function($index){

      if($(this).data('overdue') == 1){
        $(this).prop('checked', true);
      }

   });

   calc_allocation_total();

 });

$(".pc_val").keyup(function(){

  // Validate value - should be <= balance
  var balance_id = $(this).data('balance-id');
  var balance = parseFloat($('.'+balance_id).text().replace(/,/g, ''));

  // var received_id = $(this).data('received-id');
  // var received = parseFloat($('.'+received_id).text().replace(/,/g, ''));

  // if receipt_val > balance, reduce it
  var allocation = balance;
  if($(this).val() > allocation){
    alert('Amount to pay cannot be greater than the total amount');
    allocation_val =  balance ;
    $(this).val(allocation_val);

  }


  if(!isNaN($(this).val())){

  calc_allocation_total();

  }else{

    alert('Amount to pay must be numeric');
    var  value =  $(this).val();
    $(this).val(
        function(index, value){
            return value.substr(0, value.length - 1);
    });
  }

  validate_totals();

});

$('input[name="amount"]').on('change', function(e){

  calculateAmountTotal();

});

$('input[name="taxed_amount"]').on('change', function(e){

  calculateAmountTotal();

});

function calculateAmountTotal(){

 var amount = $('input[name="amount"]').val();
 var taxed_amount = $('input[name="taxed_amount"]').val();
 if(`${amount}` == ''){
   amount = 0;
 }
 if(`${taxed_amount}` == ''){
   taxed_amount = 0;
 }
 $('.total_amount').text(formatNumber(parseFloat(amount) + parseFloat(taxed_amount)));  

}

function calc_allocation_total(){

  var allocation_total = 0;
  console.log('item_type', item_type);

  $('.pc_val').each(function($index){

      if(page_action == 'edit' ||  item_type == 'LPO'){
          if($(this).val() > 0){
      allocation_total += parseFloat($(this).val());
    }
      }else{

          if($(this).val() > 0 && $(this).is(':checked')){
      allocation_total += parseFloat($(this).val());
    }

      }



  });

  $('#allocation_total').text(formatNumber(allocation_total));
  $("input[name='allocation_total']").val(allocation_total);
  validate_totals();

}

function validate_totals(){

      if(parseFloat($("input[name='pc_total']").val()) != parseFloat($("input[name='allocation_total']").val())){

    $('#allocation_total').css('color', 'red');

  }else{

    $('#allocation_total').css('color', 'green');
  }

}

$('#allocation_form').submit(function(e){

  if(parseFloat($("input[name='pc_total']").val()) != parseFloat($("input[name='allocation_total']").val())){

    // e.preventDefault();
    // alert('Amount to Pay must be equal to Total');
    // return false;

  }else{

    // $(this).submit();
  }

});


function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
}

  $('.item_list').on('click', function(e) {

    e.preventDefault();
    item_action($(this));

 });


 $('.return_list').on('click', function(e) {

   e.preventDefault();
   return_action($(this));

});

$('.edit_list').on('click', function(e) {

  e.preventDefault();
  edit_action($(this));

});



  item_action = function(obj){


    $('#item_form').modal('show');
    var itemModal = '#item_action_form';

      $('.item_name').text('Issue Transfer: '+ obj.data('ref'));
      $('.item_amount').text(obj.data('item-amount'));
      $('input[name="item_id"]').val(obj.data('item-id'));

  }

  edit_action = function(obj){


    $('#itemEditModal').modal('show');
    $('.item_edit_name').text('Edit PVC #'+ obj.data('ref'));
    $('input[name="edit_item_id"]').val(obj.data('item-id'));
    $('#edit_employee_id').val(obj.data('employee-id'));
    console.log('employee-id', obj.data('employee-id'));

  }

  return_action = function(obj){


    $('#returnModal').modal('show');
    var itemModal = '#return_action_form';

      $('.return_name').text('Return Cash for PVC #'+ obj.data('ref'));
      $('.return_item_amount').text(obj.data('item-amount'));
      $('input[name="item_id"]').val(obj.data('item-id'));

  }

   $('.close_item_form').on('click', function(e){

     $('.item_list').prop('checked', false);
     $('#item_action_form').reset();
     $('#item_form').modal('hide');

 });

 $('.add_cash_btn').on('click', function(e){
  e.preventDefault();
   var itemModal = '#account_form';
   $('#accountModal').modal('show');

});

$('.cancelBtn').on('click', function(e) {

  e.preventDefault();
  $('#cancelModal').modal('show');
    $('.item_cancel_name').text(' #'+ $(this).data('item-id'));
    $('input[name="cancel_pc_id"]').val($(this).data('item-id'));

});

$('#cancel_form').submit(function(e){

      e.preventDefault();
      submit_form('#cancel_form', 'cancel_submit', '#cancelResponse', '#cancelModal');

});

$('.attach_btn').on('click', function(e) {

   e.preventDefault();

   id = $(this).data('id');
   ref = $(this).data('ref');

   $('#attachmentModal').modal('show');

   $('.item_name').text(ref);
   $('input[name="id"]').val(id);
   $('input[name="attachment_path"]').val($(this).data('attachment_path'));

});

$('#item_action_form').submit(function(e){

      e.preventDefault();
      submit_form('#item_action_form', 'item_submit', '#response_item', '#item_form');

});

$('#item_edit_form').submit(function(e){

      e.preventDefault();
      submit_form('#item_edit_form', 'item_edit_submit', '#response_edit_item', '#itemEditModal');

});

$('#account_form').submit(function(e){

      e.preventDefault();
      submit_form('#account_form', 'account_submit');

});

$('#return_action_form').submit(function(e){

      e.preventDefault();
      submit_form('#return_action_form', 'return_submit', '#response_return', '#returnModal');

});


$("#check_all_approved").on('change',function () {
    $(".pc_check").prop('checked', $(this).prop("checked"));
    if($('.pc_check:checked').length > 0){
      $('.approve_pc_btn').show();
      $('.cancel_pc_btn').show();
      approve_multi_pc_uri();
    }else{
      $('.approve_pc_btn').hide();
      $('.cancel_pc_btn').hide();
    }

});

$('.pc_check').on('change', function($index){

  console.log($(this).val());
  if($('.pc_check:checked').length > 0){
    $('.approve_pc_btn').show();
    $('.cancel_pc_btn').show();
    approve_multi_pc_uri();
  }else{
    $('.approve_pc_btn').hide();
    $('.cancel_pc_btn').hide();
  }

});

$("#check_all_process").on('change',function () {
    $(".process_check").prop('checked', $(this).prop("checked"));
    if($('.process_check:checked').length > 0){
      $('.process_pc_btn').show();
    }else{
      $('.process_pc_btn').hide();
    }
});

$('.process_check').on('change', function($index){

  console.log($(this).val());
  if($('.process_check:checked').length > 0){
    $('.process_pc_btn').show();
  }else{
    $('.process_pc_btn').hide();
  }

});

approve_multi_pc_uri = function(){


  let pcCancelUri = "/petty_cash_mobile/list?actn=cancel&multi=1";
  $('.pc_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      pcCancelUri += `&id[]=${id}`;
    }

  });

  $('.cancel_pc_btn').attr('href', pcCancelUri);

}


  var submit_form = function(form_name, btn_name, response_element='', modal_element=''){

    console.log('form_name', form_name);
    console.log('btn_name', btn_name);


    $('input[name="'+ btn_name +'"]').val('Sending...').attr('disabled','disabled');


    var post_url = "/petty_cash_mobile/list";
    var post_data = $(form_name).serialize();

    console.log('post_url', post_url);
    console.log('post_data', post_data);
    $.ajax({
      type: 'POST',
      url: post_url,
      data: post_data,
      dataType:'json',
      success	:	function(data){

           var alert_class = (data.error == true)? 'danger' : 'success';

           var msg_html = "<ul>";
           $.each(data.msg, function(i, item) {
             msg_html += "<li>"+ data.msg[i] +"</li>";
          });
           msg_html += "</ul>";


           $('input[name="'+ btn_name +'"]').val('Submit').removeAttr('disabled');

           if(data.id){

             $(response_element).html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

             if(data.error == false){

               $(form_name).reset();

               setTimeout(function(){

                  //$('.item_list').prop('checked', false);
                  $(modal_element).modal('hide');
                  if(data.action == 'issue'){
                   // popupPDF('pcvm', data.id, 0, true);
                  }
                  location.reload();

              },5000);

             }

           }

           if(data.account){

             $('#response_account').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

             if(data.error == false){

               $('#account_form').reset();

               setTimeout(function(){

                  $('#accountModal').modal('hide');

              },5000);

             }

           }

        },
        error : function(XMLHttpRequest, textStatus,
            errorThrown) {

          console.log("Status: " + textStatus);
          console.log("Error: " + errorThrown);

        }


    });



  }

  //lev: Ajax post with file upload - yeiiii!!
$("#attachment_form").submit(function(e) {

    e.preventDefault();

      $('input[name="item_submit"]').val('Sending...').attr('disabled','disabled');
      ajaxurl = '/petty_cash_mobile/list';
      var formData = new FormData(this);

    $.ajax({
        url:  ajaxurl,
        type: 'POST',
        data: formData,
        success: function (response) {

          console.log('response', response);
          let data  = JSON.parse(response);
          console.log('data', data);
          var alert_class = (data.error == true)? 'danger' : 'success';

          var msg_html = "<ul>";
          $.each(data.msg, function(i, item) {
            msg_html += "<li>"+ data.msg[i] +"</li>";
         });
          msg_html += "</ul>";


          $('input[name="item_submit"]').val('Submit').removeAttr('disabled');

          if(data.id){

            $('#AttachResponse').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

          }

        },
        cache: false,
        contentType: false,
        processData: false
    });
});


});

function addCommas(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

</script>

{/literal}

<!-- END PAGE PLUGINS -->
