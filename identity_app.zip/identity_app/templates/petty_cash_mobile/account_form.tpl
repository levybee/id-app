<!-- NEW COMPANY MODAL -->
  <div class="modal" id="accountModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Add Cash</h4>
              </div>
              <form id="account_form" name="account_form" method="post" action="/petty_cash_mobile/list" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="response_account"></div>


			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


	                 <div class="panel-body form-group">
	                   <div class="row">
			               <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Amount</label>
									    <div class="col-md-6 col-xs-12">
									     <input name="amount" type="text" value="{if $smarty.post.recipient}{$smarty.post.amount}{/if}" class="form-control" />
									    </div>
									  </div>

									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Received From</label>
									    <div class="col-md-6 col-xs-12">
									    <input name="recipient" type="text" value="{if $smarty.post.recipient}{$smarty.post.recipient}{/if}" class="form-control" />
                      </div>

									  </div>
									  </div>

			             </div>


			                 </div>

			             </div>

                   <div class="modal-footer">
                       <input type="hidden" name="post_item_ajax" value="1" >
                       <input type="hidden" name="add_cash" value="1" >
                       <input type="submit" name="account_submit" class="btn btn-primary" value="Submit">
                       <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                     </div>

	              </div>

              </form>

          </div>
      </div>
  </div>
