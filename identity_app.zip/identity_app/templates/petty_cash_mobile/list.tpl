{if $privileges.petty_cash_mobile.list}

  <!-- START BREADCRUMB -->
   <ul class="breadcrumb">
       <li><a href="/">Home</a></li>
       <li><a href="#">Bank Transfer</a></li>
       <li class="active"><a href="">{$action|capitalize}</a></li>
   </ul>
   <!-- END BREADCRUMB -->
   <div class="page-title">
      <h2><span class="fa fa-arrow-circle-o-left"></span>Bank Transfer</h2>
  </div>
   <!-- PAGE CONTENT WRAPPER -->
   <div class="page-content-wrap">

    <div class="row">
      <div class="col-md-12">

               {if $message}
               <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                   {$message}
               </div>
               {/if}


          <div class="col-md-12" style="margin-bottom:10px;">

           {if $privileges.petty_cash_mobile.add}

             <a href="/petty_cash_mobile/add" class="btn btn-default">New Request</a>
             {* <a href="" class="btn btn-default add_cash_btn">Add Cash</a> *}
             <br><br>


           {/if}

           {if $privileges.petty_cash_mobile.balances}<div style="padding-bottom:15px;"> Current Balance: <span class="badge badge-warning" style="font-size:18px;">{$cash_balance|number_format:0:".":","} TZS</span> </div>{/if}

           <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> {* <a href="/petty_cash_mobile/list?page=1" class="btn btn-default">Clear</a> *} | By Status: <a href="/petty_cash_mobile/list?page=1" class="btn {if !$smarty.get.status}btn-success{/if} btn-flat btn-rad">All</a>

           <a href="/petty_cash_mobile/list?page=1&filter=1&status=Pending" class="btn {if $smarty.get.status eq 'Pending'}btn-success{else}btn-default{/if}">Pending <span class="badge"> {$status_nos.Pending}</span> <span class="badge" style="background-color:#fea223;"> {$amount_statuses.Pending|number_format:0:".":","}</span></a>

           <a href="/petty_cash_mobile/list?page=1&filter=1&status=Approved" class="btn {if $smarty.get.status eq 'Approved'}btn-success{else}btn-default{/if}">Approved <span class="badge"> {$status_nos.Approved}</span> <span class="badge badge-info" style="background-color:#fea223;"> {$amount_statuses.Approved|number_format:0:".":","}</span></a>

           <a href="/petty_cash_mobile/list?page=1&filter=1&status=Issued" class="btn {if $smarty.get.status eq 'Issued'}btn-success{else}btn-default{/if}">Issued <span class="badge"> {$status_nos.Issued}</span> <span class="badge badge-info" style="background-color:#fea223;"> {$amount_statuses.Issued|number_format:0:".":","}</span></a>

           <a href="/petty_cash_mobile/list?page=1&filter=1&status=Processed" class="btn {if $smarty.get.status eq 'Processed'}btn-success{else}btn-default{/if}">Processed <span class="badge"> {$status_nos.Processed}</span> <span class="badge badge-info" style="background-color:#fea223;"> {$amount_statuses.Processed|number_format:0:".":","}</span></a>

           <a href="/petty_cash_mobile/list?page=1&filter=1&status=Closed" class="btn {if $smarty.get.status eq 'Closed'}btn-success{else}btn-default{/if}">Closed <span class="badge"> {$status_nos.Closed}</span> </a>

           <a href="/petty_cash_mobile/list?page=1&filter=1&status=Cancelled" class="btn {if $smarty.get.status eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled <span class="badge"> {$status_nos.Cancelled}</span> </a>
            {include file='search/mini.pc_mobile.tpl'}
        </div>

          <div class="panel panel-default">

              <div class="panel-heading">
                    {if $smarty.get.status eq 'Pending'}
                    <label for="approve_selected" name="approve_selected" class="btn btn-success approve_pc_btn" style="display:none;">
                      Approve Selected
                    </label>
                    <a href=""  class="btn btn-warning cancel_pc_btn" style="display:none;">Cancel Selected</a>
                    {/if}
                    {if $smarty.get.status eq 'Issued'}
                      <label for="process_selected" name="process_selected" class="btn btn-success process_pc_btn" style="display:none;">
                        Process Selected
                      </label>
                      {/if}
                    <ul class="panel-controls panel-controls-title">
                       <li>

                       <form class="form-inline" role="form" method="post">
                           <div class="form-group">
                             </div>
                           <div class="form-group">
                               <a href="/petty_cash_mobile/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/petty_cash_mobile/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                               <label>| Displaying {$resultsCount}</label>
                           </div>
                           <div class="form-group">

                                   <select name="page" id="page" class="form-control">
                    {section name=pagination loop=$numPages}

                      <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
                    {sectionelse}

                      <option value="1" selected>Page 1</option>


                    {/section}

                     </select>

                           </div>
                           <button name="submit" type="submit" class="btn btn-danger">Go</button>


                       </form>
                       </li>

                   </ul>
              </div>




              <div class="panel-body panel-body-table">

                  <form method="post" action="">
                      <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                      <input type="submit" name="process_selected" id="process_selected" class="hidden" />
                  <div class="table-responsive">
                      <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                          <thead>
                              <tr>
                                {if $smarty.get.status eq 'Pending'}
                                    <th width="40" class="text-center">
                                        <input type="checkbox" id="check_all_approved"/></th>{/if}
                                  {if $smarty.get.status eq 'Issued'}
                                    <th width="40" class="text-center">
                                        <input type="checkbox" id="check_all_process"/></th>{/if}
                                 <th class="text-center">Ref</th>
                                 <th class="text-center">Date</th>
                                 <th class="text-center">Type</th>
                                 {* <th class="text-center">LPO #</th> *}
                                 <th class="text-center">Expense Type</th>
                                 <th class="text-center">Net Amount</th>
                                 {* <th class="text-center">Tax Amount</th>
                                 <th class="text-center">WHT Amount</th> *}
                                 <th class="text-center">Paid Via</th> 
                                 <th class="text-center">Job Reference</th>
                                 <th class="text-center">Issued To</th>
                                 {* <th class="text-center">Attachment</th> *}
                                 <th class="text-center">Bank Ref</th>
                                 <th class="text-center">Remarks</th>
                                 <th class="text-center">Status</th>
                                 <th class="text-center">User</th>
                                  <th class="text-center">Action</th>
                              </tr>
                          </thead>
                          <tbody>
                             {section name=pc_list loop=$pc_list}
                <tr>
                  {if $pc_list[pc_list].status eq 'Pending' && $smarty.get.status eq 'Pending'}<td class="text-center">
                      <input type="checkbox" name="approved_check[]" class="approved_check pc_check" value="{$pc_list[pc_list].id}" /></td>
                  {/if}
                  {if $pc_list[pc_list].status eq 'Issued' && $smarty.get.status eq 'Issued'}<td class="text-center">
                    <input type="checkbox" name="processed_check[]" class="processed_check process_check" value="{$pc_list[pc_list].id}" /></td>
                  {/if}
                  {* <td class="text-center">{$start+$smarty.section.pc_list.rownum}</td> *}
                  <td class="text-center">{if $pc_list[pc_list].reference}{$pc_list[pc_list].reference|leading_zero:5}{else}-{/if}</td>

                  <td class="text-center">{$pc_list[pc_list].date_created|date_format:"%d %b %Y"} <br>  ({$pc_list[pc_list].date_created|date_format:"%H:%M:%S"})</td>
                  <td class="text-center">
                   {$pc_list[pc_list].type}
                   {if $pc_list[pc_list].type == 'Supplier' || $pc_list[pc_list].contractor_id > 0}
                   <br>
                   {if $pc_list[pc_list].contractor_id > 0}
                   <a title="View Contractor" href="/casual_contractors/view?id={$pc_list[pc_list].contractor_id}" target="_blank"><i>{$pc_list[pc_list].supplier_name}</i></a>
                   <br><i> (Contractor #{$pc_list[pc_list].contractor_id})</i>
                   {else}
                   <i>{$pc_list[pc_list].supplier_name}</i>
                   {/if}
                   
                   {/if}
                   {if $pc_list[pc_list].group_id > 0}
                    <br><i>{$pc_list[pc_list].group_company_pc} - {$pc_list[pc_list].payment_type}</i>
                   {/if} 
                  </td>
                  {* <td class="text-center">
                  {if $pc_list[pc_list].lpo_id}<a title="View LPO" href="#" onclick="popupPDF('lpo', {if $pc_list[pc_list].lpo_id}{$pc_list[pc_list].lpo_id}{else}0{/if});" >{$pc_list[pc_list].lpo_id}</a> - {$pc_list[pc_list].supplier_company}
                   <br><strong>Amount Paid:</strong> {$pc_list[pc_list].amount_paid|number_format:0:".":","} TZS<br>
                   <strong>Total Balance:</strong> {$pc_list[pc_list].lpo_balance|number_format:0:".":","} TZS
                   {else}
                    {if $pc_list[pc_list].items[0].lpo_id > 0}
                      <br><strong>Amount Paid:</strong> {$pc_list[pc_list].lpos_amount_paid|number_format:0:".":","} TZS<br>
                      <strong>Total Balance:</strong> {$pc_list[pc_list].lpos_balance|number_format:0:".":","} TZS
                      {else}
                        -
                      {/if}
                  {/if}
                </td> *}
                  <td class="text-center">
                   {$pc_list[pc_list].expense_name}
                  </td>
                   {if $pc_list[pc_list].items_amount > 0}
                    {assign var=net_amount value=$pc_list[pc_list].items_amount-$pc_list[pc_list].wht_amount+$pc_list[pc_list].taxed_amount}
                   {else} 
                  {assign var=net_amount value=$pc_list[pc_list].net_amount-$pc_list[pc_list].wht_amount+$pc_list[pc_list].taxed_amount}
                   {/if}
                  {assign var=net_amount_usd value=$pc_list[pc_list].net_amount_usd-$pc_list[pc_list].wht_amount}
                  <td class="text-center">
                  {$net_amount|number_format:0:".":","} {if $pc_list[pc_list].currency != 'USD' || $net_amount_usd > 0} TZS{else}USD{/if}
                  {if $net_amount_usd > 0}<br> {$net_amount_usd|number_format:2:".":","} USD {/if}
                   
                
                  </td>
                  <td class="text-center">
                    {$pc_list[pc_list].account_name}{if $pc_list[pc_list].description} - {$pc_list[pc_list].description}{/if}
                    {if $pc_list[pc_list].to_account_name} <br> To: {$pc_list[pc_list].to_account_name}{if $pc_list[pc_list].to_description} - {$pc_list[pc_list].to_description}{/if}{/if}
                    </td>
                  <td class="text-center">{if $pc_list[pc_list].job_id}<a style="text-decoration:none;" href="/jobs/progress?id={$pc_list[pc_list].job_id}" target="_blank">{$pc_list[pc_list].job_id}: </a>{$pc_list[pc_list].job_reference} - {$pc_list[pc_list].group_company}
                  {else}
                  {if $pc_list[pc_list].job_id_lpo}<a style="text-decoration:none;" href="/jobs/progress?id={$pc_list[pc_list].job_id_lpo}" target="_blank">{$pc_list[pc_list].job_id_lpo}: </a>{$pc_list[pc_list].job_reference_lpo} - {$pc_list[pc_list].group_company_lpo}{/if}
                  {/if}</td>
                  <td class="text-center">{if $pc_list[pc_list].status eq 'Issued'}{$pc_list[pc_list].employee_name}{else}-{/if}</td>
                   {* <td class="text-center">
                  <a href="/{$config.attachment_dir}{$pc_list[pc_list].attachment}" target = "_blank">{if $pc_list[pc_list].attachment}{$pc_list[pc_list].attachment}{else}-{/if}</a>
                  </td> *}
                  <td class="text-center">
                  {$pc_list[pc_list].issue_reference}
                  </td>
                  <td class="text-center">
                  {$pc_list[pc_list].remarks}
                  {if $pc_list[pc_list].control_number}
                  <br><i>{$pc_list[pc_list].gepg_type} - Control Number: {$pc_list[pc_list].control_number}</i>
                  {/if}

                   {if $pc_list[pc_list].approval_attachment}
                    <br>
                   <i>{if $pc_list[pc_list].type == 'Direct'}Approval {/if}Attachment:<br>
                            <a href="/uploads/bank_transfer/{$pc_list[pc_list].approval_attachment}"
                              target="_blank">{$pc_list[pc_list].approval_attachment|truncate:60:"..."}</a>
                          </i>
                          {/if}
                  </td>

                  <td class="text-center">
                      <span class="{if $pc_list[pc_list].status eq 'Pending'}text-danger{elseif $pc_list[pc_list].status eq 'Approved'}text-info{elseif $pc_list[pc_list].status eq 'Cancelled'}text-default{elseif $pc_list[pc_list].status eq 'Issued'}text-warning{else}text-success{/if}">{$pc_list[pc_list].status}</span>
                      {if $pc_list[pc_list].status eq 'Approved'}by {$pc_list[pc_list].approval_user} at {$pc_list[pc_list].date_approved|date_format:"%H:%M:%S"} {/if}
                        {if $pc_list[pc_list].status eq 'Issued'}
                        <br> <i>{$pc_list[pc_list].issue_type}
                      {if $pc_list[pc_list].issue_reference} - Ref:  {$pc_list[pc_list].issue_reference} {/if}
                        </i>
                      {if $pc_list[pc_list].issued_user}<br> <i>by {$pc_list[pc_list].issued_user}</i>{/if}
                      {/if}

                      {if $pc_list[pc_list].status eq 'Processed' && $pc_list[pc_list].processed_user}
                      <br> <i>by {$pc_list[pc_list].processed_user} at {$pc_list[pc_list].date_processed|date_format:"%H:%M:%S"} </i>
                      {/if}
                  </td>
                  {* <td class="text-center"><span class="{if $pc_list[pc_list].status eq 'Pending'}text-danger{elseif $pc_list[pc_list].status eq 'Approved'}text-default{else}text-success{/if}">{$pc_list[pc_list].status} {if $pc_list[pc_list].status eq 'Closed' && $pc_list[pc_list].issued_to} - Issued to {$pc_list[pc_list].issued_to}{/if}{if $pc_list[pc_list].status eq 'Approved'} <br><i>by {$pc_list[pc_list].approval_user}</i>{/if}</span></td> *}
                  <td class="text-center">{$pc_list[pc_list].user}</td>
                  <td class="text-center">


                     {* <a href="/petty_cash_mobile/edit/?id={$pc_list[pc_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a> *}

                       {* <a href="/petty_cash_mobile/delete/?id={$pc_list[pc_list].id}" class="btn btn-danger btn-rounded btn-condensed btn-sm" title="Delete" onclick="confirmAction('[Delete Bank Transfer Record] Deleting will permanently remove the Requisition from the system. Are you sure?', this.href); return false;"><span class="fa fa-times"></span></a> *}
                     {if $pc_list[pc_list].status eq 'Pending' && $privileges.petty_cash_mobile.approve}
                     <a href="/petty_cash_mobile/list?actn=approve&id={$pc_list[pc_list].id}" class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Bank Transfer Record] Are you sure?', this.href); return false;" ><span class="fa fa-check"></span></a>
                     {/if}

                     {* {if $pc_list[pc_list].stock_id > 0}<a href="/stock/log?filter=1&stock_id={$pc_list[pc_list].stock_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" target="_blank" title="View History"><span class="fa fa-history"></span></a>{/if} *}
                     {if $pc_list[pc_list].status eq 'Approved'}
                     {* <a href="/petty_cash_mobile/list?actn=issue&id={$pc_list[pc_list].id}"
                    onclick="confirmAction('[Issue Bank Transfer] Are you sure?', this.href); return false;"
                     class="btn btn-success btn-rounded btn-condensed btn-sm" title="Issue" >
                       <span class="fa fa-arrow-circle-right"></span>
                     </a> *}

                     <a href="#"
                     data-item-id="{$pc_list[pc_list].id}"
                     data-ref="{if $pc_list[pc_list].supplier_id > 0}{$pc_list[pc_list].supplier_name}{else}{$pc_list[pc_list].supplier_company}{/if}"
                     data-item-amount='{if $pc_list[pc_list].supplier_id > 0 && $pc_list[pc_list].items_amount > 0}{$pc_list[pc_list].items_amount|number_format:0:".":","}{else}{$pc_list[pc_list].amount|number_format:0:".":","} TZS{/if}'
                     class="btn btn-success btn-rounded btn-condensed btn-sm item_list" title="Issue" >
                       <span class="fa fa-arrow-circle-right"></span>
                     </a>

                     {/if}

                     {if $pc_list[pc_list].status eq 'Issued'}
                       {if $privileges.petty_cash_mobile.unissue && $pc_list[pc_list].type != 'Contra'}
                       {* <a href="/petty_cash_mobile/list?actn=unissue&id={$pc_list[pc_list].id}" class="btn btn-danger btn-rounded btn-condensed btn-sm" title="Return" onclick="confirmAction('[Return Bank Transfer Record] Are you sure?', this.href); return false;" ><span class="fa fa-arrow-circle-left"></span></a> *}
                       <a href="#"
                       data-item-id="{$pc_list[pc_list].id}"
                       data-ref="{$pc_list[pc_list].reference|leading_zero:5}"
                       data-item-amount='{if $pc_list[pc_list].items_amount}{$pc_list[pc_list].items_amount}{else}{$pc_list[pc_list].amount|number_format:0:".":","} TZS{/if}'
                       class="btn btn-danger btn-rounded btn-condensed btn-sm return_list" title="Return Cash" >
                         <span class="fa fa-arrow-circle-left"></span>
                       </a>
                       {/if}
                       <a title="Attachment"
                       href="" class="btn btn-default btn-rounded btn-condensed btn-sm attach_btn"
                       data-id="{$pc_list[pc_list].id}"
                       data-ref="PCV #{$pc_list[pc_list].reference|leading_zero:5}"
                       data-attachment_path="{$pc_list[pc_list].attachment_path}"
                       ><span class="fa fa-paperclip"></span></a>
                      {/if}

                       {if $pc_list[pc_list].status eq 'Processed'}
                       {if $privileges.petty_cash_mobile.close}
                       <a href="/petty_cash_mobile/list?actn=confirm&id={$pc_list[pc_list].id}" class="btn btn-info btn-rounded btn-condensed btn-sm" title="Close" onclick="confirmAction('[Close Bank Transfer Record] Are you sure?', this.href); return false;" ><span class="fa fa-check-circle"></span></a>
                       {/if}

                       {* if $privileges.petty_cash_mobile.edit}
                       <a href="#"
                       data-item-id="{$pc_list[pc_list].id}"
                       data-employee-id="{$pc_list[pc_list].employee_id}"
                       data-ref="{$pc_list[pc_list].reference|leading_zero:5}"
                       class="btn btn-default btn-rounded btn-condensed btn-sm edit_list" title="Edit" >
                         <span class="fa fa-pencil"></span>
                       </a>
                       {/if *}

                     {/if}

                     {if $pc_list[pc_list].status eq 'Issued' || $pc_list[pc_list].status eq 'Processed' || $pc_list[pc_list].status eq 'Closed' || $pc_list[pc_list].status eq 'Approved'}
                     <a class="btn btn-default btn-rounded btn-condensed btn-sm" title="View PCV" href="#" onclick="popupPDF('pcvm', {if $pc_list[pc_list].id}{$pc_list[pc_list].id}{else}0{/if});" ><span class="fa fa-file-pdf-o"></span></a>
                     {/if}

                     {if $pc_list[pc_list].status == 'Pending' || $pc_list[pc_list].status == 'Approved' || (($pc_list[pc_list].status == 'Processed'  || $pc_list[pc_list].status == 'Issued' || $pc_list[pc_list].status == 'Closed'))}
                     <a href="/petty_cash_mobile/edit/?id={$pc_list[pc_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
                     {/if}

                     {if $pc_list[pc_list].status eq 'Approved' || $pc_list[pc_list].status eq 'Pending' || $pc_list[pc_list].status eq 'Issued' || $pc_list[pc_list].status eq 'Processed'}

                     <a href="/petty_cash_mobile/list?actn=cancel&id={$pc_list[pc_list].id}"
                                 data-item-id="{$pc_list[pc_list].id}"
                                class="btn btn-default btn-rounded btn-condensed btn-sm cancelBtn" title="Cancel"
                                ><span
                                  class="fa fa-times"></span></a>
                     {/if}

                     {if $privileges.petty_cash.open && $pc_list[pc_list].status eq 'Cancelled' && $pc_list[pc_list].type != 'Contra'}
                      <a title="Open Bank Transfer" href="/petty_cash_mobile/list?act=open&id={$pc_list[pc_list].id}"
                      onclick="confirmAction('Open Bank Transfer. Are you sure?', this.href); return false;"
                      class="btn btn-warning btn-rounded btn-condensed btn-sm">
                      <span class="fa fa-folder-open"></span></a>
                     {/if}

                  </td>
                </tr>
                {if $pc_list[pc_list].items[0]}
               <tr>
                 <td colspan="15">
                    <table width="100%">
                      <tr>
                        <th>&nbsp;</th>
                        <th>
                          {if $pc_list[pc_list].items[0].lpo_id > 0}
                          LPO
                          {else}
                          GRN
                          {/if}
                        </th>
                        <th>Date</th>
                        <th>Invoice No</th>
                        <th>Amount</th>
                        <th>Amount Paid</th>
                        <th>&nbsp;</th>
                      </tr>
                      {section name=items loop=$pc_list[pc_list].items}
                      <tr>
                       <td>&nbsp;</td>
                        <td>
                          {if $pc_list[pc_list].items[0].lpo_id > 0}
                          <a title="View LPO" href="#" onclick="popupPDF('lpo', {$pc_list[pc_list].items[items].lpo_id});">
                           LPO-{$pc_list[pc_list].items[items].lpo_date|substr:0:4}-{$pc_list[pc_list].items[items].lpo_id|leading_zero:5}
                         </a>
                          {/if}
                          {if $pc_list[pc_list].items[0].grn_id > 0}
                          <a title="View GRN" href="#" onclick="popupPDF('grn', {$pc_list[pc_list].items[items].grn_id});" >
                          GRN-{$pc_list[pc_list].items[items].grn_date|substr:0:4}-{$pc_list[pc_list].items[items].grn_id|leading_zero:5}
                          </a>
                          {/if}
                        </td>
                        <td>{if $pc_list[pc_list].items[items].grn_date}{$pc_list[pc_list].items[items].grn_date|date_format:"%d %b %Y"}{else}{$pc_list[pc_list].items[items].lpo_date|date_format:"%d %b %Y"}{/if}</td>
                        <td>{if $pc_list[pc_list].items[items].invoice_no}{$pc_list[pc_list].items[items].invoice_no}{else}-{/if}</td>
                        <td>
                          {if $pc_list[pc_list].items[0].lpo_id > 0}
                          {$pc_list[pc_list].items[items].lpo_amount|number_format:0:".":","}
                          {if $pc_list[pc_list].items[items].lpo_amount_usd > 0}
                            | {$pc_list[pc_list].items[items].lpo_amount_usd|number_format:2:".":","} USD
                          {/if}
                          {else}
                          {$pc_list[pc_list].items[items].amount|number_format:2:".":","}
                          {/if}
                        </td>
                        <td>
                        {if $pc_list[pc_list].items[0].lpo_id > 0}
                        {$pc_list[pc_list].items[items].amount_paid|number_format:0:".":","}
                        {if $pc_list[pc_list].items[items].amount_paid_usd > 0}
                            | {$pc_list[pc_list].items[items].amount_paid_usd|number_format:2:".":","} USD
                          {/if}
                        {else}
                         {$pc_list[pc_list].items[items].grn_amount_paid|number_format:2:".":","}
                        {/if}
                        </td>
                        <td>&nbsp;</td>
                      </tr>
                      {/section}
                    </table>
                 </td>
               </tr>
               {/if}
               <tr>
                 <td colspan="15" style="padding:1px 0 !important; background:#ccc;"></td>
               </tr>
                {sectionelse}
                <tr>
                  <td colspan="15">No records found.</td>
                </tr>
                {/section}
                          </tbody>
                      </table>

                  </div>
                  </form>


              </div>

       {if $smarty.get.dbg}
       {$privileges.petty_cash_mobile|@print_r}
       {/if}

          </div>



          {include file="$section/item_form.tpl"}
          {include file="$section/edit_form.tpl"}
          {include file="$section/account_form.tpl"}
          {include file="$section/return_form.tpl"}




   </div>
  </div>
   <!-- END PAGE CONTENT WRAPPER -->
   </div>
    <!-- END PAGE CONTENT -->
  </div>
  <!-- END PAGE CONTAINER -->

  <div class="modal" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Attachment for <span class="item_name"></span></h4>
              </div>
              <form id="attachment_form" name="attachment_form" method="post" action="/petty_cash_mobile/list" class="form-horizontal" enctype="multipart/form-data">
                <div class="modal-body">
                   <div id="AttachResponse"></div>


                   <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


                       <div class="panel-body form-group">
                         <div class="row">


                           <div class="form-group">
                               <label>Attachment</label>
                               <input name="attachment_file" type="file" id="attachment_file" class="form-control" style="width:50%;" />
                           </div>

                   </div>

                </div>
                <div class="modal-footer">
                    <input type="hidden" name="id" value="" >
                    <input type="hidden" name="attachment_path" value="" >
                    <input type="submit" name="item_submit" class="btn btn-primary" value="Submit">
                    <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                  </div>
              </form>

          </div>
      </div>
     </div>
   </div>
  </div>

  <div class="modal" id="cancelModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-sm">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
                class="sr-only">Close</span></button>
            <h4 class="modal-title" id="defModalHead">Cancel Transfer <span class="item_cancel_name"></span></h4>
          </div>
          <form id="cancel_form" name="cancel_form" method="post" action="" class="form-horizontal"
            enctype="multipart/form-data">
            <div class="modal-body">
              <div id="cancelResponse"></div>
              <div class="panel panel-default"
                style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
                <div class="panel-body form-group">
                  <div class="row">
                    <div class="form-group">
                      <label>Remarks</label>
                      <textarea name="remarks" rows= "5" class="form-control"></textarea>
                    </div>
                  </div>
                </div>
              </div>
              </div>
              <div class="modal-footer">
              <input type="hidden" name="cancelAjax" value="1">
              <input type="hidden" name="cancel_pc_id" value="">
              <input type="submit" name="cancel_submit" class="btn btn-primary" value="Submit">
              </div>
          </form>

        </div>
      </div>
    </div>

  {else}
  <div class="row">
      <div class="col-md-12">


         <div class="alert alert-danger" role="alert">
          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
          You are not authorized to view this section
      </div>




  </div>

  </div>
  {/if}
