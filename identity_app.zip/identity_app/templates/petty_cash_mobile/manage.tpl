{if $privileges.stock.manage}
<script type="text/javascript" src="/js/quote.js"></script>

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/stock/list">Stock</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Stock</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}">
             <div class="panel panel-default">
                 
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">
                     
                    
                    
                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Date</label>
					    <div class="col-md-6 col-xs-12">                                            
					  
					           <input name="log_date" type="text" class="form-control datepicker" value="{$smarty.now|date_format:'%Y-%m-%d'}" readonly="readonly">                      
					    </div>
					</div>
					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Job #</label>
					    <div class="col-md-6 col-xs-12">                                            
					       
					          <input name="log_job_id" type="text" id="log_job_id" class="form-control" />                     
					        
					    </div>
					</div>
					
                     
					 <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Stock</label>
                         <div class="col-md-6 col-xs-12">                                                                                            
                          <input type="hidden" name="stock_id" id="stock_id" value="0" tabindex="110" /><a href="#" onclick="issueStock(); return false;"><span id="stock_info">Stock Selector</span></a>
                            
                         </div>
                     </div>
                     
                    
                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Movement</label>
					    <div class="col-md-6 col-xs-12">                                            
					        <select name="log_movement" id="log_movement" class="form-control select">
						      <option value="In" {if $smarty.post.log_movement eq "In"}selected="selected"{/if}>In (Increase Stock)</option>
						      <option value="Out" {if $smarty.post.log_movement eq "Out"}selected="selected"{/if}>Out (Decrease Stock)</option>
						    </select>
					    </div>
					</div>
                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Quantity</label>
					    <div class="col-md-6 col-xs-12">                                            
					        <input name="log_quantity" type="text" id="log_quantity" class="form-control" placeholder="in Sheets" />                             
					        
					    </div>
					</div>
             
                  
                 </div>
                 <div class="panel-footer">
                     <button type="submit" name="Submit" class="btn btn-primary pull-right">Update Stock</button>
                 </div>
             </div>
             </form>                                           

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 



{/if}