{if $action == 'edit'}
{include file='petty_cash_mobile/pc_items.edit.tpl'}
{/if}

{if $action == 'add'}
{include file='petty_cash_mobile/pc_items.tpl'}
{/if}
