{if $privileges.petty_cash_mobile.edit || $privileges.petty_cash_mobile.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/petty_cash_mobile/list">Bank Transfer</a></li>
     <li class="active"><a href="">{if $action eq 'add'}Request{else}Edit{/if}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{if $action eq 'add'}Request{else}Edit{/if} Bank Transfer</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

         {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     {* <h3 class="panel-title"><strong>Request</strong> Form</h3> *}
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">


                     <div class="form-group">
                        <label class="col-md-3 col-xs-12 control-label">For</label>
                        <div class="col-md-2">
                          <label class="check"><input type="radio" class="iradio" name="type"  value="Miscellaneous" {if $edit_petty_cash_mobile[0].type eq 'Miscellaneous' || $smarty.post.type eq 'Miscellaneous'} checked="checked"{elseif !$edit_petty_cash_mobile[0].type} checked="checked"  {/if} /> Miscellaneous </label>
                        </div>
                        <div class="col-md-2">
                          <label class="check"><input type="radio" class="iradio" name="type"  value="Job" {if $edit_petty_cash_mobile[0].type eq 'Job' || $smarty.post.type eq 'Job'} checked="checked"{/if} /> Job Specific</label>
                        </div>
                    </div>

                    <div class="form-group" id="job_field" {if $edit_petty_cash_mobile[0].type eq 'Job' || $smarty.post.type eq 'Job'}{else}style="display:none;"{/if}>
                         <label class="col-md-3 col-xs-12 control-label">Job #</label>
                          <div class="col-md-6 col-xs-12">
		                      <select name="job_id" id="job_id"  class="form-control" style="width:100%;" ></select>
	                   </div>
                   </div>

                  <div class="form-group">
      					    <label class="col-md-3 col-xs-12 control-label">Type of Expense</label>
      					    <div class="col-md-6 col-xs-12">
      					        <select name="expense_id" id="expense_id" class="form-control select">
                          <option value="">Select..</option>
                          {section name=expenses loop=$expenses}
                            <option value="{$expenses[expenses].expense_id}" {if $edit_petty_cash_mobile[0].expense_id eq $expenses[expenses].expense_id || $smarty.post.expense_id eq $expenses[expenses].expense_id}selected{/if}>{$expenses[expenses].expense_code}: {$expenses[expenses].expense_name}</option>
                          {/section}

                      </select>
      					    </div>
      					</div>

                <div class="form-group">
                    <label class="col-md-3 col-xs-12 control-label">LPO #</label>
                    <div class="col-md-6 col-xs-12">
                        <select name="lpo_id" id="lpo_id"  class="form-control" style="width:100%;">
                         </select>
                         <div class="lpo_balances" style="padding-top:8px;display:none;">
                           <strong>LPO Amount:</strong> <span class='lpo_amount'></span>
                           &nbsp;&nbsp;
                           <strong>Amount Paid:</strong> <span class='amount_paid'></span>
                           &nbsp;&nbsp;
                           <strong>Balance:</strong> <span class='balance'></span>
                         </div>
                    </div>
                    <input type="hidden" name="lpo_balance" id="balance" value="">


                </div>




                 <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">Amount</label>
                     <div class="col-md-6 col-xs-12">
                         <input name="amount" type="text" value="{if $smarty.post.amount}{$smarty.post.amount}{else}{$edit_petty_cash_mobile[0].amount}{/if}" class="form-control" required />
                     </div>
                 </div>
                 <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">Tax</label>
                     <div class="col-md-6 col-xs-12">
                          <select name="tax" id="tax" class="form-control">
                        <option value="Taxable"  {if $smarty.post.tax eq "Taxable" || $edit_petty_cash_mobile[0].tax eq "Taxable"}selected{/if}>Taxable</option>
                      <option value="Exempt"  {if $smarty.post.tax eq "Exempt" || $edit_petty_cash_mobile[0].tax eq "Exempt"}selected{/if}>Exempt</option>
                 </select>
                     </div>
                 </div>

                 <div class="form-group">
                     <label class="col-md-3 col-xs-12 control-label">WHT</label>
                     <div class="col-md-6 col-xs-12">
                          <select name="wht_tax" id="wht_tax" class="form-control">
                        <option value="Taxable"  {if $smarty.post.wht_tax eq "Taxable" || $edit_petty_cash_mobile[0].wht_tax eq "Taxable"}selected{/if}>Taxable</option>
                      <option value="Exempt"  {if $smarty.post.wht_tax eq "Exempt" || $edit_petty_cash_mobile[0].wht_tax eq "Exempt"}selected{/if}>Exempt</option>
                 </select>
                     </div>
                 </div>

                 <div class="form-group">
          					    <label class="col-md-3 col-xs-12 control-label">Remarks</label>
          					    <div class="col-md-6 col-xs-12">
          					       <textarea name="remarks" class="form-control" rows="8">{if $smarty.post.remarks}{$smarty.post.remarks}{else}{$edit_petty_cash_mobile[0].remarks}{/if}</textarea>
          					    </div>
          					</div>


                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Petty Cash</button>
                 </div>
             </div>
             </form>


            {/if}

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->


{/if}
