<!-- NEW COMPANY MODAL -->
<div class="modal" id="item_form" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <h4 class="modal-title" id="defModalHead"><span class="item_name"></span></h4>
        </div>
        <form id="item_action_form" name="item_action_form" method="post" action="/petty_cash_mobile/list" class="form-horizontal">
          <div class="modal-body">
             <div id="response_item"></div>


             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


                 <div class="panel-body form-group">
                   <div class="row">


              <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Type</label>
                <div class="col-md-6 col-xs-12">
                  <label class="control-label"><input type="radio"  name="issue_type" id="bank_transfer" value="Bank Transfer"> Bank Transfer</label>&nbsp;
                  <label class="control-label"><input type="radio"  name="issue_type" id="cheque" value="Cheque"> Cheque</label><br>
                </div>
              </div>

              <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Reference</label>
                <div class="col-md-6 col-xs-12">
              <input name="issue_reference" type="text" value="" class="form-control" />
                </div>
              </div>
              </div>
               </div>
             </div>

             

          </div>
          <div class="modal-footer">
                 <input type="hidden" name="item_id" value="" >
                 <input type="hidden" name="issue_item_ajax" value="1" >
                 <input type="submit" name="item_submit" class="btn btn-primary item_edit" value="Submit">
                 <button type="button" class="btn btn-default clos_item_form" data-dismiss="modal">Close</button>
               </div>

        </form>

    </div>
</div>
</div>
