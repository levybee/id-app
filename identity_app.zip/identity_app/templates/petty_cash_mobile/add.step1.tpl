
<div id="response2"></div>

<form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}{if $smarty.get.contractor_id}?contractor_id={$smarty.get.contractor_id}{/if}{if $smarty.get.advance}&advance=1{/if}" enctype="multipart/form-data">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Bank Transfer Information</h3>
        </div>

        <div class="panel-body">

            <div class="form-group trasfer_type">
               <label class="col-md-3 col-xs-12 control-label">For</label>
               <div class="col-md-2">
                 <label class="check"><input type="radio" class="iradio" name="type"  value="Supplier" {if $pc_data.type eq 'Supplier' || $smarty.post.type eq 'Supplier' || ($smarty.get.contractor_id && !$smarty.get.advance)} checked="checked"{/if} {if $action == 'edit' || $smarty.get.advance}disabled{/if} /> Supplier </label>
               </div>
               <div class="col-md-1">
                 <label class="check"><input type="radio" class="iradio" name="type"  value="Direct" {if $pc_data.type eq 'Direct' || $smarty.post.type eq 'Direct' || $smarty.get.advance} checked="checked"{/if} {if $action == 'edit' || ($smarty.get.contractor_id && !$smarty.get.advance)}disabled{/if} /> Direct</label>
               </div>
               <div class="col-md-2">
                 <label class="check"><input type="radio" class="iradio" name="type"  value="GEPG Payment" {if $pc_data.type eq 'GEPG Payment' || $smarty.post.type eq 'GEPG Payment'} checked="checked"{/if} {if $action == 'edit' || ($smarty.get.contractor_id && !$smarty.get.advance)}disabled{/if} /> GEPG Payment</label>
               </div>
               <div class="col-md-1">
                 <label class="check"><input type="radio" class="iradio" name="type"  value="Contra" {if $pc_data.type eq 'Contra' || $smarty.post.type eq 'Contra'} checked="checked"{/if} {if $action == 'edit' || $smarty.get.contractor_id}disabled{/if} /> Contra</label>
               </div>
               <div class="col-md-2">
                 <label class="check"><input type="radio" class="iradio" name="type"  value="Customer" {if $pc_data.type eq 'Customer' || $smarty.post.type eq 'Customer'} checked="checked"{/if} {if $action == 'edit' || $smarty.get.contractor_id}disabled{/if} /> Customer</label>
               </div>
               {if $action == 'edit'}
               <input name="type" type="hidden"  value="{$pc_data.type}" />
               {/if}
           </div>

            <div class="form-group">

                <label class="col-md-3 col-xs-12 control-label">Date</label>
                <div class="col-md-6 col-xs-12">
                    <div class="input-group">
                        <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                        <input name="date_created" type="text" class="form-control datepicker" value="{if $pc_data.date_created != ''}{$pc_data.date_created|date_format:'%Y-%m-%d'}{elseif $smarty.session.receipt.step_1.date_created}{$smarty.session.receipt.step_1.date_created}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" readonly="readonly">
                    </div>

                </div>
            </div>
          <div  class="form-group sup_field" {if $pc_data.type neq 'Direct' || $smarty.post.type neq 'Direct'}{else}style="display:none;"{/if}>
             <label class="col-md-3 control-label">Select Supplier</label>
             <div class="col-md-6">
            <select id="supplier_id" name="supplier_id" class="form-control select2">
               <option value="">Please Select</option>
               {section name=supplier_list loop=$supplier_list}
                   <option value="{$supplier_list[supplier_list].supplier_id}" {if $pc_data.supplier_id == $supplier_list[supplier_list].supplier_id || $smarty.post.supplier_id == $supplier_list[supplier_list].supplier_id || $contractor.supplier_id == $supplier_list[supplier_list].supplier_id}selected{/if}>{if $supplier_list[supplier_list].supplier_company}{$supplier_list[supplier_list].supplier_company} -{/if} {$supplier_list[supplier_list].supplier_fname} {$supplier_list[supplier_list].supplier_lname}</option>
               {/section}
               </select>
             </div>
         </div>

         <div  class="form-group customer" {if $pc_data.type == 'Customer' || $smarty.post.type == 'Customer'}{else}style="display:none;"{/if}>
             <label class="col-md-3 control-label">Select Customer</label>
             <div class="col-md-6">
              <select name="group_id" id="group_id"  class="form-control" style="width: 100%;"></select>
             </div>
         </div>

           {if $smarty.get.contractor_id && !$smarty.get.advance}
         <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Apply Advance?</label>
                 <div class="col-md-6 col-xs-12">
                   <label class="check"><input name="apply_advance" type="checkbox" id="apply_advance" value="1" />
                    &nbsp;<i>Deduct advance paid from total balance</i>
                   </label>
            </div>
          </div>
         {/if}
       
         <div class="form-group trans_field" {if $smarty.get.contractor_id || $pc_data.type eq 'Supplier' || $smarty.post.type eq 'Supplier'}style="display:none;"{/if}>
                <label class="col-md-3 col-xs-12 control-label">Job #</label>
                 <div class="col-md-6 col-xs-12">
                 <select name="job_id" id="job_id"  class="form-control" style="width:100%;" ></select>
            </div>
          </div>

          <div class="form-group customer" {if $pc_data.type eq 'Customer' || $smarty.post.type eq 'Customer'}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">Payment Type</label>
             <div class="col-md-6 col-xs-12">
              <select name="payment_type" id="payment_type" class="form-control">
                <option value="">Select..</option>
                <option value="Quote"  {if $smarty.post.payment_type eq "Quote" || $pc_data.payment_type eq "Quote"}selected{/if}>Quote</option>
                <option value="Receipt"  {if $smarty.post.payment_type eq "Receipt" || $pc_data.payment_type eq "Receipt"}selected{/if}>Receipt </option>
              </select>
             </div>
         </div>

         <div class="form-group direct_field expense gepg" {if $pc_data.type eq 'Direct' || $smarty.post.type eq 'Direct' || $smarty.get.contractor_id || $smarty.get.advance}{else}style="display:none;"{/if}>
           <label class="col-md-3 col-xs-12 control-label">Type of Expense</label>
           <div class="col-md-6 col-xs-12">
               <select name="expense_id" id="expense_id" class="form-control select" style="width:100%">
                 <option value="">Select..</option>
                 {section name=expenses loop=$expenses}
                   <option value="{$expenses[expenses].expense_id}" {if $pc_data.expense_id eq $expenses[expenses].expense_id || $smarty.post.expense_id eq $expenses[expenses].expense_id}selected{/if}>{$expenses[expenses].expense_code}: {$expenses[expenses].expense_name}</option>
                 {/section}

             </select>
           </div>
        </div>

        

        <div class="form-group direct_fields" {if $pc_data.type eq 'Directs' || $smarty.post.type eq 'Directs'}{else}style="display:none;"{/if}>
            <label class="col-md-3 col-xs-12 control-label">LPO #</label>
            <div class="col-md-6 col-xs-12">
                <select name="lpo_id" id="lpo_id"  class="form-control" style="width:100%;">
                 </select>
                 <div class="lpo_balances" style="padding-top:8px;display:none;">
                   <strong>LPO Amount:</strong> <span class='lpo_amount'></span>
                   &nbsp;&nbsp;
                   <strong>Amount Paid:</strong> <span class='amount_paid'></span>
                   &nbsp;&nbsp;
                   <strong>Balance:</strong> <span class='balance'></span>
                 </div>
            </div>
            <input type="hidden" name="lpo_balance" id="balance" value="">
        </div>
         <div class="form-group direct_field amount contra" {if $pc_data.type eq 'Direct' || $smarty.post.type eq 'Direct' || $smarty.get.advance}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label"><span class="gepg" {if $pc_data.type eq 'GEPG Payment' || $smarty.post.type eq 'GEPG Payment'}{else}style="display:none;"{/if}>Non VAT </span>Amount</label>
             <div class="col-md-6 col-xs-12">
                 <input name="amount" type="text" value="{if $smarty.post.amount}{$smarty.post.amount}{else}{$pc_data.amount}{/if}{if $advance_amount}{$advance_amount}{/if}" class="form-control" />
             </div>
         </div>
          <div class="form-group gepg" {if $pc_data.type eq 'GEPG Payment' || $smarty.post.type eq 'GEPG Payment'}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">VAT Amount</label>
             <div class="col-md-6 col-xs-12">
                 <input name="taxed_amount" type="text" value="{if $smarty.post.taxed_amount}{$smarty.post.taxed_amount}{else}{$pc_data.taxed_amount}{/if}" class="form-control" />
             </div>
         </div>
          <div class="form-group gepg" {if $pc_data.type eq 'GEPG Payment' || $smarty.post.type eq 'GEPG Payment'}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">Total Amount</label>
             <div class="col-md-6 col-xs-12">
                 {assign var="total_amount" value=$pc_data.amount+$pc_data.taxed_amount}
                 <p class="form-control-static total_amount">{$total_amount}</p>
             </div>
         </div>
          <div class="form-group currency contra customer" style="display: none;">
                <label class="col-md-3 col-xs-12 control-label">Currency</label>
                <div class="col-md-6 col-xs-12">
                     <select name="currency" id="currency" class="form-control">
                    <option value="">Select..</option> 
				            <option value="TZS"  {if $smarty.post.currency eq "TZS" || $pc_data.currency eq "TZS"}selected{/if}>TZS</option>
				        	  <option value="USD"  {if $smarty.post.currency eq "USD" || $pc_data.currency eq "USD"}selected{/if}>USD</option>
				    	</select>
                </div>
            </div> 
        
          <div class="form-group">
           <label class="col-md-3 col-xs-12 control-label">Account From</label>
           <div class="col-md-6 col-xs-12">
               <select name="account_id" id="account_id" class="form-control select" style="width:100%">
                 <option value="">Select..</option>
                 {section name=accounts loop=$accounts}
                   <option value="{$accounts[accounts].id}" {if $pc_data.account_id eq $accounts[accounts].id || $smarty.post.account_id eq $accounts[accounts].id}selected{/if} data-currency="{$accounts[accounts].currency}">{$accounts[accounts].name}</option>
                 {/section}
             </select>
             <input type="hidden" name="account_name" id="account_name" value="{if $smarty.post.account_name}{$smarty.post.account_name}{else}{$pc_data.account_name}{/if}" />
           </div>
        </div>
         
         <div class="form-group account_to contra" style="display: none;">
           <label class="col-md-3 col-xs-12 control-label">Account To</label>
           <div class="col-md-6 col-xs-12">
               <select name="to_account_id" id="to_account_id" class="form-control select" style="width:100%">
                 <option value="">Select..</option>
                 {section name=accounts loop=$accounts}
                   <option value="{$accounts[accounts].id}" {if $pc_data.to_account_id eq $accounts[accounts].id || $smarty.post.to_account_id eq $accounts[accounts].id}selected{/if}>{$accounts[accounts].name}</option>
                 {/section}
             </select>
           </div>
        </div>
         
            <div class="form-group contra customer" style="display: none;">
                    <label class="col-md-3 control-label">Exchange Rate</label>
                    <div class="col-md-6">
                      <input type="number" name="exch_rate"  id="exch_rate" class="form-control" step="0.1"  value="{if $smarty.post.exch_rate}{$smarty.post.exch_rate}{else}{$pc_data.exch_rate}{/if}" />
                    </div>
               </div>
         <div class="form-group direct_fields" {if $pc_data.type eq 'Directs' || $smarty.post.type eq 'Directs' || $smarty.get.advance}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">Tax</label>
             <div class="col-md-6 col-xs-12">
              <select name="tax" id="tax" class="form-control">
                <option value="Taxable"  {if $smarty.post.tax eq "Taxable" || $pc_data.tax eq "Taxable"}selected{/if}>Taxable</option>
                <option value="Exempt"  {if $smarty.post.tax eq "Exempt" || $pc_data.tax eq "Exempt"}selected{/if}>Exempt</option>
              </select>
             </div>
         </div>
         <div class="form-group wht direct_field" {if $pc_data.type eq 'Direct' || $smarty.post.type eq 'Direct'  || $smarty.get.advance}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">WHT</label>
             <div class="col-md-6 col-xs-12">
                  <select name="wht_tax" id="wht_tax" class="form-control">
                    <option value="Exempt"  {if $smarty.post.wht_tax eq "Exempt" || $pc_data.wht_tax eq "Exempt"}selected{/if}>Exempt</option>
                   <option value="Taxable"  {if $smarty.post.wht_tax eq "Taxable" || $pc_data.wht_tax eq "Taxable"}selected{/if}>Taxable</option>
                 </select>
             </div>
         </div>
         
         <div class="form-group wht_percent" {if $pc_data.wht_percent > 0  || $smarty.post.wht_tax eq "Taxable"}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">WHT %</label>
             <div class="col-md-6 col-xs-12">
                  <select name="wht_percent" id="wht_percent" class="form-control">
                    <option value="">Select..</option>
                    <option value="5"  {if $smarty.post.wht_percent eq "5" || $pc_data.wht_percent eq "5"}selected{/if}>5%</option>
                   <option value="10"  {if $smarty.post.wht_percent eq "10" || $pc_data.wht_percent eq "10"}selected{/if}>10%</option>
                 </select>
             </div>
         </div>

          <div class="form-group gepg" {if $pc_data.type eq 'GEPG Payment' || $smarty.post.type eq 'GEPG Payment'}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">Control Number</label>
             <div class="col-md-6 col-xs-12">
                 <input name="control_number" type="text" value="{if $smarty.post.control_number}{$smarty.post.control_number}{else}{$pc_data.control_number}{/if}" class="form-control" />
             </div>
         </div>
          {* <div class="form-group gepg" {if $pc_data.type eq 'GEPG Payment' || $smarty.post.type eq 'GEPG Payment'}{else}style="display:none;"{/if}>
            <label class="col-md-3 col-xs-12 control-label">GEPG Type</label>
            <div class="col-md-6 col-xs-12">
              {assign var="gepg_types" value=["Import Duties","Statutory","TBS","Luku","Other"]}
              <select name="gepg_type" id="gepg_type" class="form-control">
                <option value="">Select..</option>
                {foreach from=$gepg_types item=type}
                  <option value="{$type}" {if $smarty.post.gepg_type eq $type || $pc_data.gepg_type eq $type}selected{/if}>{$type}</option>
                {/foreach}
              </select>
            </div>
          </div> *}
         <div class="form-group remarks contra gepg customer">
            <label class="col-md-3 col-xs-12 control-label">Remarks</label>
            <div class="col-md-6 col-xs-12">
               <textarea name="remarks" class="form-control" rows="4">{if $smarty.post.remarks}{$smarty.post.remarks}{else}{$pc_data.remarks}{/if}</textarea>
            </div>
        </div>
         <div class="form-group sup_field">
                <label class="col-md-3 col-xs-12 control-label">Adjustment</label>
                <div class="col-md-6 col-xs-12">
                    <label class="checkbox">
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        <input name="adjustment" type="checkbox" id="adjustment" value="1" />
                    </label>
                </div>
            </div>
         <div class="form-group direct_field gepg customer">
          <label class="col-md-3 col-xs-12 control-label attach">Approval Attachment</label>
          <div class="col-md-6 col-xs-12">
            <input name="approval_attachment" type="file" id="approval_attachment" class="form-control" />
          </div>

        </div>

        </div>
        <div class="panel-footer">
            <input name="next_step" type="hidden" id="next_step" value="two" />
            <button type="submit" class="btn btn-primary pull-right">Continue</button>
        </div>
 </form>
