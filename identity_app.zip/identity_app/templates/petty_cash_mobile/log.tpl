{if $privileges.petty_cash_mobile.log}
<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/petty_cash_mobile/list">Bank Transfer</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->



<div class="page-title">
    <h2>Bank Transfer Log Book</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
         {/if}


           {* Filter By Category:

            {section name=petty_cash_mobile_categories_list loop=$petty_cash_mobile_categories_list}

              {if $petty_cash_mobile_categories_list[petty_cash_mobile_categories_list].category neq ''}<a href="/petty_cash_mobile/log?page=1&filter=1&fby=category&fby_param={$petty_cash_mobile_categories_list[petty_cash_mobile_categories_list].category}" class="btn {if $smarty.get.fby_param eq $petty_cash_mobile_categories_list[petty_cash_mobile_categories_list].category}btn-success{else}btn-default{/if}">{$petty_cash_mobile_categories_list[petty_cash_mobile_categories_list].category}</a> {/if}

            {/section}



         <br>
         <br>

         <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a>  |  Filter By petty_cash_mobile Movement: <a href="/petty_cash_mobile/log?page=1&filter=1&fby=movement&fby_param=In" class="btn {if $smarty.get.fby_param eq 'In'}btn-success{else}btn-default{/if}">Movement In</a> <a href="/petty_cash_mobile/log?page=1&filter=1&fby=movement&fby_param=Out" class="btn {if $smarty.get.fby_param eq 'Out'}btn-success{else}btn-default{/if}">Movement Out</a>
          <br>
         {include file="search/mini.log.tpl"}

         <br> *}
        <div class="panel panel-default">

         <div class="panel-heading">
             {* <h3 class="panel-title">Log Table</h3> *}
           <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post" action="/{$section}/log?{if $smarty.request.select}select=1&popup=1&{/if}{if $search_str}{$search_str}{/if}">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/petty_cash_mobile/log{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/petty_cash_mobile/log{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>

                 </ul>
         </div>



            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table print table-bordered table-striped table-actions">
                        <thead>
                          <tr>
                          <th width="25">#</th>
  				                <th>Date</th>
                          <th>Type</th>
                          <th>Source</th>
        							    <th>Amount</th>
        							    <th>Balance</th>

        							    <th>PCV Ref</th>
        							    <th>Issued to</th>
        							    <th>User</th>

                          </tr>
                        </thead>
                        <tbody>
                           {section name=log_list loop=$log_list}
                            <tr>

                                <td>{$start+$smarty.section.log_list.rownum}</td>
							    <td>{$log_list[log_list].date_created|date_format:"%d %b %Y"} ({$log_list[log_list].date_created|date_format:"%H:%M:%S"})</td>
							    <td>{$log_list[log_list].action}</td>
                  <td>{$log_list[log_list].received_from}</td>
                  <td>{$log_list[log_list].amount|number_format:0:".":","} TZS</td>
                  <td>{$log_list[log_list].account_amount|number_format:0:".":","} TZS</td>
							    <td>{if $log_list[log_list].reference}
                    <a title="View PVC" href="#" onclick="popupPDF('pcvm', {$log_list[log_list].petty_cash_id});" >{$log_list[log_list].reference|leading_zero:5}</a>
                    {else}-{/if}
                	<td class="text-center">{if $log_list[log_list].status eq 'Issued'}{$log_list[log_list].employee_name}{else}-{/if}</td>
							    <td>{$log_list[log_list].user}</td>


                            </tr>
                            {sectionelse}
                            <tr>

                                <td colspan="9">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                        </tbody>
                    </table>

                </div>

            </div>
        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{/if}
