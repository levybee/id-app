<div class="panel panel-default">
      <form id="allocation_form" method="post" action="/petty_cash_mobile/edit?id={$smarty.get.id}">
       <div class="panel-heading">
		        <h3 class="panel-title">Bank Transfer Items</h3>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table pad-6 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th class="text-center" width="40">{$smarty.session.pc_edit.item_type}</th>
                                <th class="text-center" width="40">Date</th>
                                <th class="text-center" width="40">Invoice No.</th>
                                <th class="text-center" width="40">Days Overdue</th>
                                <th class="text-center">Total ({$smarty.session.pc_edit.currency})</th>
              							    <th class="text-center">Upaid ({$smarty.session.pc_edit.currency})</th>
              							    <th class="text-center">Amount to Pay ({$smarty.session.pc_edit.currency})</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.pc_edit.pc_items}
						  <tr>
						    <td class="text-center">
                  {if $smarty.session.pc_edit.item_type == 'LPO'}
                   LPO-{$smarty.session.pc_edit.pc_items[items].lpo_date|substr:0:4}-{$smarty.session.pc_edit.pc_items[items].lpo_id|leading_zero:5}
                  {/if}
                  {if $smarty.session.pc_edit.item_type == 'GRN'}
                  GRN-{$smarty.session.pc_edit.pc_items[items].grn_date|substr:0:4}-{$smarty.session.pc_edit.pc_items[items].grn_id|leading_zero:5}
                  {/if}
                </td>
                	<td class="text-center">{$smarty.session.pc_edit.pc_items[items].grn_date|date_format:"%d/%m/%Y"}</td>
                    <td class="text-center">{$smarty.session.pc_edit.pc_items[items].invoice_no}</td>	  
                    <td class="text-center">{if $smarty.session.pc_edit.pc_items[items].overdue}{$smarty.session.pc_edit.pc_items[items].days_overdue}{else}-{/if}</td>
                <td class="text-right">{$smarty.session.pc_edit.pc_items[items].total_amount|number_format:2:".":","}</td>
						    <td class="text-right balance{$smarty.section.items.rownum}">{$smarty.session.pc_edit.pc_items[items].balance|number_format:2:".":","}</td>
						    <td><input  type="text" data-balance-id="balance{$smarty.section.items.rownum}" id="allocation_{$smarty.section.items.rownum}" name="allocation[{if $smarty.session.pc_edit.pc_items[items].grn_id > 0}{$smarty.session.pc_edit.pc_items[items].grn_id}{else}{$smarty.session.pc_edit.pc_items[items].lpo_id}{/if}]" value="{$smarty.session.pc_edit.pc_items[items].amount_paid}" class="form-control pc_val text-right"></td>
						    
						  
						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="7"><div>No items available.</td>
						  </tr>
						  {/section}

						  {if $smarty.session.pc_edit.pc_items|@count > 0}
						    <tr>
				
                    <th  class="text-right" colspan="4"><strong>TOTAL</strong></th>
                    <th class="text-right"> <div id="pc_total">{$smarty.session.pc_edit.pc_total|number_format:2:".":","}</div> </th>
                    <th class="text-right"> <div id="balance_total">{$smarty.session.pc_edit.balance_total|number_format:2:".":","}</div> </th>
                    <th class="text-right"> <div id="allocation_total">0</div> </th>
                    <input type="hidden" name="allocation_total" value="0" >
                    <input type="hidden" name="pc_total" value="{$smarty.session.pc_edit.pc_total}" >
                </tr>
						  {/if}

                  </tbody>
              </table>
                {if $smarty.get.debug eq 'lev'}
                 <pre> {$smarty.session.pc_edit|@print_r}</pre>
                {/if}
              </div>

  </div>
    <div class="panel-footer">
          <input type="hidden" name="next_step" value="three" />
          <input type="hidden" name="complete" value="1" />
          <input type="submit" name="submit" value="Submit" class="btn btn-success pull-right"  />
    </div>
  </form>
</div>
