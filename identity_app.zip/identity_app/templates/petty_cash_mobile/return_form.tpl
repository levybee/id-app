<!-- NEW COMPANY MODAL -->
  <div class="modal" id="returnModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead"><span class="return_name"></span></h4>
              </div>
              <form id="return_action_form" name="return_action_form" method="post" action="/petty_cash_mobile/list" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="response_return"></div>


			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			                 <div class="panel-body form-group">
			                   <div class="row">


			               <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">PCV Amount</label>
									    <div class="col-md-6 col-xs-12">
									     <div style="display:inline-block; padding-right:3px;"><p class="form-control-static return_item_amount"></p></div><div style="display:inline-block;"></div>
									    </div>
									  </div>
                    <div class="form-group">
                       <label class="col-md-3 col-xs-12 control-label">Amount to Return</label>
                       <div class="col-md-6 col-xs-12">
                        <input name="return_amount" type="text" value="" class="form-control" />
                       </div>
                     </div>

			                   </div>


			                 </div>

			             </div>

                   <div class="modal-footer">
                       <input type="hidden" name="item_id" value="" >
                       <input type="hidden" name="return_item_ajax" value="1" >
                       <input type="submit" name="return_submit" class="btn btn-primary return_submit" value="Submit">
                       <button type="button" class="btn btn-default close_return_form" data-dismiss="modal">Close</button>
                     </div>

	              </div>

              </form>

          </div>
      </div>
  </div>
