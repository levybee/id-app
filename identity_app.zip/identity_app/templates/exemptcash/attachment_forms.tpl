<div class="modal" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
              class="sr-only">Close</span></button>
          <h4 class="modal-title" id="defModalHead">Attachment for <span class="item_name"></span></h4>
        </div>
        <form id="attachment_form" name="attachment_form" method="post" action="/exemptcash/list" class="form-horizontal"
          enctype="multipart/form-data">
          <div class="modal-body">
            <div id="AttachResponse"></div>


            <div class="panel panel-default"
              style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


              <div class="panel-body form-group">
                <div class="row">


                  <div class="form-group">
                    <label>Attachment</label>
                    <input name="attachment_file" type="file" id="attachment_file" class="form-control"
                      style="width:50%;" />
                  </div>

                </div>

              </div>
            </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" name="attach_ec_id" value="">
            <input type="hidden" name="attachment_path" value="">
            <input type="submit" name="item_submit" class="btn btn-primary" value="Submit">
            <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
          </div>
        </form>

      </div>
    </div>
  </div>

  <div class="modal" id="closeAttachModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
              class="sr-only">Close</span></button>
          <h4 class="modal-title" id="defModalHead">Close Selected Records</h4>
        </div>
        <form id="close_attach_form" name="close_attach_form" method="post" action="" class="form-horizontal"
          enctype="multipart/form-data">
          <div class="modal-body">
            <div id="closeAttachResponse"></div>


            <div class="panel panel-default"
              style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


              <div class="panel-body form-group">
                <div class="row">


                  <div class="form-group">
                    <label>Attachment</label>
                    <input name="attachment_file" type="file" id="attachment_file" class="form-control"
                      style="width:50%;" />
                  </div>

                </div>

              </div>
            </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" name="close_attach" value="1">
            <input type="submit" name="close_attach_submit" class="btn btn-primary" value="Submit">
          </div>
        </form>

      </div>
    </div>
  </div>