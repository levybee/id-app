<!-- PAGE PLUGINS -->
       <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
       <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
       <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>



{literal}

<script type="text/javascript">



$(document).ready(function(){

$('.select2').select2();

 $.fn.reset = function () {
   $(this).each (function() { this.reset(); });
 }

   var page_action =  '{/literal}{$action}{literal}';
   var contractor_job_id = '{/literal}{$contractor_job_id}{literal}';
   if(page_action == 'edit'){


       var job_id = '{/literal}{$ec_data.job_id}{literal}';
       var job_reference = '{/literal}{$ec_data.job_reference}{literal}';

       if(contractor_job_id){
         job_id = contractor_job_id;
         var job_reference = '{/literal}{$job_reference}{literal}';
       }

       console.log('job_id', job_id);
       var supplier_company = '{/literal}{$ec_data.supplier_company}{literal}';

   }


    if(job_id){

      var job_text = job_id + ': ' + job_reference; //+ ' - ' + product_name;
      var job_option = new Option(job_text , job_id, true, true);
      $("#job_id").append(job_option).trigger('change');

      console.log(job_text);
    }


  var supplier_type = '{/literal}{$smarty.session.exemptcash.supplier.supplier_type}{literal}';
  var item_type = '{/literal}{$smarty.session.exemptcash.type}{literal}';
    console.log('supplier_type', supplier_type);
    console.log('item_type', item_type);
    
 $("#expense_id").select2({
   placeholder: "Type to search..."
 });


 $("#job_id").select2({
   placeholder: "Type Job ID to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/jobs.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
                 status: 'not_pending'
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $("#lpo_id").select2({
  placeholder: "Type LPO ID to search...",
  minimumInputLength: 1,
  ajax: {
        url: "/ajax/lpo.php",
        dataType: 'json',
        delay: 250,
        data: function (params) {

            return {
                q: params.term, // search term
                customer_id: "",
                status: "Approved"

            };
        },
        processResults: function (data) { // parse the results into the format expected by Select2.
            // since we are using custom formatting functions we do not need to alter the remote JSON data

            // Debug:
      //console.log("Data: " + JSON.stringify(data) );

            return { results: data };
        },
        cache: true
    }

 });

 $('#lpo_id').on('change', function (e) {

   var lpo_amount = $(this).select2('data')[0].lpo_amount;
   var amount_paid = $(this).select2('data')[0].amount_paid;
   var balance = $(this).select2('data')[0].lpo_balance;

   $('.lpo_balances').show();
   $('.lpo_amount').html(addCommas(lpo_amount));
   $('.amount_paid').html(addCommas(amount_paid));
   $('.balance').html(addCommas(balance));
   $('#balance').val(balance);

 });

//  var type = $('input[name="type"]').val();
//  if(type == 'Payout'){
//   $('.payout_field').show();
//   $('.sup_field').hide();
//  }else{
//   $('.payout_field').hide();
//   $('.sup_field').show();
//  }

 $('#supplier_id').on('change', function (e){

   var paymentTerms = $(this).find(':selected').attr('data-payment-terms');
   console.log('pt', paymentTerms);
   console.log('val', $(this).val());

 });

  var pay_type = $('input[name="type"]:checked').val();
  if(pay_type){
    toggleFormFields(pay_type);
  }

  $('input[name="type"]').on('change', function(e){
    toggleFormFields($(this).val());
  });

function toggleFormFields($type){
   console.log('type', $type);
    if($type == 'Payout'){
      $('.sup_field').hide();
      $('.payout_field').show();
    }else{
      $('.payout_field').hide();
      $('.sup_field').show();
    }

}  

// GRN/LPO Items
var ec_total = parseFloat($('#ec_total').text());

calc_allocation_total();

$('.ec_val').on('change', function() {

if(! $(this).val() > 0){
  $(this).prop('checked', false);
}else{
  calc_allocation_total();
}

// $('input[type="checkbox"]').not(this).prop('checked', false);

});


// Overdue
$('.all_overdue').on('click', function(e) {

    e.preventDefault();
    $('.ec_val').each(function($index){

      if($(this).data('overdue') == 1){
        $(this).prop('checked', true);
      }

   });

   calc_allocation_total();

 });

$(".ec_val").keyup(function(){

console.log('val', $(this).val());

  // Validate value - should be <= balance
  var balance_id = $(this).data('balance-id');
  var balance = parseFloat($('.'+balance_id).text().replace(/,/g, ''));

  // var received_id = $(this).data('received-id');
  // var received = parseFloat($('.'+received_id).text().replace(/,/g, ''));

  // if receipt_val > balance, reduce it
  var allocation = balance;
  if($(this).val() > allocation){
    alert('Amount to pay cannot be greater than the total amount');
    allocation_val =  balance ;
    $(this).val(allocation_val);

  }


  if(!isNaN($(this).val())){

  calc_allocation_total();

  }else{

    alert('Amount to pay must be numeric');
    var  value =  $(this).val();
    $(this).val(
        function(index, value){
            return value.substr(0, value.length - 1);
    });
  }

  validate_totals();

});

function calc_allocation_total(){
  console.log('calc total..');
  var allocation_total = 0;

  $('.ec_val').each(function($index){

  if(page_action == 'edit' ||  item_type == 'LPO'){
          if($(this).val() > 0){
      allocation_total += parseFloat($(this).val());
    }
      }else{

          if($(this).val() > 0 && $(this).is(':checked')){
      allocation_total += parseFloat($(this).val());
    }

      }

  });

  console.log('allocation_total', allocation_total);

  $('#allocation_total').text(formatNumber(allocation_total));
  $("input[name='allocation_total']").val(allocation_total);
  validate_totals();

}

function validate_totals(){

      if(parseFloat($("input[name='ec_total']").val()) != parseFloat($("input[name='allocation_total']").val())){

    $('#allocation_total').css('color', 'red');

  }else{

    $('#allocation_total').css('color', 'green');
  }

}

$('#allocation_form').submit(function(e){

  if(parseFloat($("input[name='ec_total']").val()) != parseFloat($("input[name='allocation_total']").val())){

    // e.preventDefault();
    // alert('Amount to Pay must be equal to Total');
    // return false;

  }else{

    // $(this).submit();
  }

});


function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
}




  $('.item_list').on('click', function(e) {
    e.preventDefault();
    item_action($(this));
 });


 $('.return_list').on('click', function(e) {

   e.preventDefault();
   return_action($(this));

});

$('.edit_list').on('click', function(e) {

  e.preventDefault();
  edit_action($(this));

});



  item_action = function(obj){


    $('#item_form').modal('show');
    var itemModal = '#item_action_form';

    console.log('obj', obj.data('ref'));

      $('.item_name').text('Issue E-PVC');
      $('.item_amount').text(obj.data('item-amount'));
      $('input[name="issue_ec_id"]').val(obj.data('item-id'));

  }

  edit_action = function(obj){


    $('#itemEditModal').modal('show');
    $('.item_edit_name').text('Edit PVC #'+ obj.data('ref'));
    $('input[name="edit_item_id"]').val(obj.data('item-id'));
    $('#edit_employee_id').val(obj.data('employee-id'));
    console.log('employee-id', obj.data('employee-id'));

  }

  return_action = function(obj){


    $('#returnModal').modal('show');
    var itemModal = '#return_action_form';

      $('.return_name').text('Return Cash for PVC #'+ obj.data('ref'));
      $('.return_item_amount').text(obj.data('item-amount'));
      $('input[name="item_id"]').val(obj.data('item-id'));

  }

   $('.close_item_form').on('click', function(e){

     $('.item_list').prop('checked', false);
     $('#item_action_form').reset();
     $('#item_form').modal('hide');

 });

 $('.add_cash_btn').on('click', function(e){
  e.preventDefault();
   var itemModal = '#account_form';
   $('#accountModal').modal('show');

});

$('.cancelBtn').on('click', function(e) {

  e.preventDefault();
  $('#cancelModal').modal('show');
    $('.item_cancel_name').text(' #'+ $(this).data('item-id'));
    $('input[name="cancel_ec_id"]').val($(this).data('item-id'));

});

$('#cancel_form').submit(function(e){

      e.preventDefault();
      submit_form('#cancel_form', 'cancel_submit', '#cancelResponse', '#cancelModal');

});

$('.confirmBtn').on('click', function(e) {

  e.preventDefault();
  $('#confirmModal').modal('show');
    $('.item_confirm_name').text(' #'+ $(this).data('item-id'));
    $('input[name="confirm_ec_id"]').val($(this).data('item-id'));

});

$('.attach_btn').on('click', function(e) {

   e.preventDefault();

   id = $(this).data('id');
   ref = $(this).data('ref');

   $('#attachmentModal').modal('show');

   $('.item_name').text(ref);
   $('input[name="attach_ec_id"]').val(id);
   $('input[name="attachment_path"]').val($(this).data('attachment_path'));

});

$('#item_action_form').submit(function(e){

      e.preventDefault();
      submit_form('#item_action_form', 'item_submit', '#response_item', '#item_form');

});

$('#item_edit_form').submit(function(e){

      e.preventDefault();
      submit_form('#item_edit_form', 'item_edit_submit', '#response_edit_item', '#itemEditModal');

});

$('#account_form').submit(function(e){

      e.preventDefault();
      submit_form('#account_form', 'account_submit');

});

$('#return_action_form').submit(function(e){

    e.preventDefault();
    submit_form('#return_action_form', 'return_submit', '#response_return', '#returnModal');

});


$("#check_all_confirmed").on('change',function () {
    $(".confirmed_check").prop('checked', $(this).prop("checked"));
    if($('.confirmed_check:checked').length > 0){
      $('.confirm_pc_btn').show();
      $('.cancel_pc_btn').show();
      $('.approve_pc_btn').hide();
      approve_multi_pc_uri();
    }else{
      $('.confirm_pc_btn').hide();
      $('.cancel_pc_btn').hide();
    }

});

$("#check_all_approved").on('change',function () {
    $(".approved_check").prop('checked', $(this).prop("checked"));
    if($('.approved_check:checked').length > 0){
      $('.approve_pc_btn').show();
    }else{
      $('.approve_pc_btn').hide();
    }
});

$('.confirmed_check').on('change', function($index){

  console.log($(this).val());
  if($('.confirmed_check:checked').length > 0){
    $('.confirm_pc_btn').show();
    $('.cancel_pc_btn').show();
    approve_multi_pc_uri();
  }else{
    $('.confirm_pc_btn').hide();
    $('.cancel_pc_btn').hide();
  }

});

$('.approved_check').on('change', function($index){
  console.log($(this).val());
  if($('.approved_check:checked').length > 0){
    $('.approve_pc_btn').show();
  }else{
    $('.approve_pc_btn').hide();
  }
});


approve_multi_pc_uri = function(){


  let pcCancelUri = "/exemptcash/list?actn=cancel";
  $('.confirmed_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      pcCancelUri += `&cancel_ec_id[]=${id}`;
    }

  });

  $('.cancel_pc_btn').attr('href', pcCancelUri);

}

$("#check_all_issued").on('change',function () {
    $(".issued_check").prop('checked', $(this).prop("checked"));
    if($('.issued_check:checked').length > 0){
      $('#close_selected_btn').show();
      close_multi_pc_uri();
    }else{
      $('#close_selected_btn').hide();
    }
});



  $('.issued_check').on('change', function($index){

  if($('.issued_check:checked').length > 0){
    $('#close_selected_btn').show();
    close_multi_pc_uri();
  }else{
    $('#close_selected_btn').hide();
  }

});


close_multi_pc_uri = function(){
  let pcCloseUri = "/exemptcash/list?actn=close_attach";
  $('.issued_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      pcCloseUri += `&close_ec_id[]=${id}`;
    }
  });
  $('#close_selected_btn').attr('href', pcCloseUri);
}

$('#close_selected_btn').on('click', function(e) {
console.log('selected..')
   e.preventDefault();
   uri = $(this).attr('href');
   $('#close_attach_form').attr('action', uri);
   $('#closeAttachModal').modal('show');

});


  var submit_form = function(form_name, btn_name, response_element='', modal_element=''){

    console.log('form_name', form_name);
    console.log('btn_name', btn_name);
    console.log('response_element', response_element);
    console.log('modal_element', modal_element);


    $('input[name="'+ btn_name +'"]').val('Sending...').attr('disabled','disabled');


    var post_url = "/exemptcash/list";
    var post_data = $(form_name).serialize();
    $.ajax({
      type: 'POST',
      url: post_url,
      data: post_data,
      dataType:'json',
      success	:	function(data){

      console.log('data', data);

           var alert_class = (data.error == true)? 'danger' : 'success';

          
            msg_html = data.msg;


           $('input[name="'+ btn_name +'"]').val('Submit').removeAttr('disabled');

          

             $(response_element).html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');


             if(data.error == false){

               $(form_name).reset();

               setTimeout(function(){

                  //$('.item_list').prop('checked', false);
                  $(modal_element).modal('hide');
                  if(data.action == 'issue'){
                   popupPDF('exemptcash', data.id, 0, true);
                  }
                  location.reload();

              },5000);

             }

          

           if(data.account){

             $('#response_account').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

             if(data.error == false){

               $('#account_form').reset();

               setTimeout(function(){

                  $('#accountModal').modal('hide');

              },5000);

             }

           }

        },
        error : function(XMLHttpRequest, textStatus,
            errorThrown) {

          console.log("Status: " + textStatus);
          console.log("Error: " + errorThrown);

        }


    });



  }

  //lev: cat ajax with image upload
$("#close_attach_form").submit(function(e) {

    e.preventDefault();

      $('input[name="close_attach_submit"]').val('Sending...').attr('disabled','disabled');
      ajaxurl = $(this).attr('action');
      var formData = new FormData(this);

    $.ajax({
        url:  ajaxurl,
        type: 'POST',
        data: formData,
        success: function (response) {

          console.log('response', response);
          let data  = JSON.parse(response);
          console.log('data', data);
          var alert_class = (data.error == true)? 'danger' : 'success';
            msg_html = data.msg;
    
          $('input[name="close_attach_submit"]').val('Submit').removeAttr('disabled');

          $('#closeAttachResponse').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

           if(data.error == false){
            setTimeout(function(){
              $('#closeAttachModal').modal('hide');
              location.reload();
            }, 5000)
           }

        },
        cache: false,
        contentType: false,
        processData: false
    });
});


// Close with Attch
$("#attachment_form").submit(function(e) {

    e.preventDefault();

      $('input[name="item_submit"]').val('Sending...').attr('disabled','disabled');
      ajaxurl = '/exemptcash/list';
      var formData = new FormData(this);

    $.ajax({
        url:  ajaxurl,
        type: 'POST',
        data: formData,
        success: function (response) {

          console.log('response', response);
          let data  = JSON.parse(response);
          console.log('data', data);
          var alert_class = (data.error == true)? 'danger' : 'success';

          var msg_html = "<ul>";
          $.each(data.msg, function(i, item) {
            msg_html += "<li>"+ data.msg[i] +"</li>";
         });
          msg_html += "</ul>";


          $('input[name="item_submit"]').val('Submit').removeAttr('disabled');

          if(data.id){

            $('#AttachResponse').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');
            if(data.error == false){
            setTimeout(function(){
              $('#attachmentModal').modal('hide');
              location.reload();
            }, 5000)
            }
          }

        },
        cache: false,
        contentType: false,
        processData: false
    });
});


});

function addCommas(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
}

</script>

{/literal}

<!-- END PAGE PLUGINS -->
