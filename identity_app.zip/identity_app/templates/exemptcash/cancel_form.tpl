 <div class="modal" id="cancelModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span
              class="sr-only">Close</span></button>
          <h4 class="modal-title" id="defModalHead">Cancel Exempt Cash <span class="item_cancel_name"></span></h4>
        </div>
        <form id="cancel_form" name="cancel_form" method="post" action="" class="form-horizontal"
          enctype="multipart/form-data">
          <div class="modal-body">
            <div id="cancelResponse"></div>
            <div class="panel panel-default"
              style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
              <div class="panel-body form-group">
                <div class="row">
                  <div class="form-group">
                    <label>Remarks</label>
                    <textarea name="remarks" rows="5" class="form-control"></textarea>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <input type="hidden" name="cancelAjax" value="1">
            <input type="hidden" name="cancel_ec_id" value="">
            <input type="submit" name="cancel_submit" class="btn btn-primary" value="Submit">
          </div>
        </form>

      </div>
    </div>
  </div>
