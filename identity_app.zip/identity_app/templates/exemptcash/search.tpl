

<div id="search" class="panel panel-default" style="display: none; margin-top:15px;">

<div class="panel-body">
   <form id="form2" name="form2" class="form-inline"  method="post" action="/exemptcash/list?filter=1{if $search_str}&{$search_str}{/if}">

    <div class="form-group" style="margin-right:15px;">
     <label for="from_date" >Date From:</label>
      <input  type="text" style="display:block;"  name="date_from"  class="form-control datepicker" value="{if $smarty.post.invoice_date_from}{$smarty.post.invoice_date_from|date_format:'%Y-%m-%d'}{else}{/if}" >
    </div>



     <div class="form-group"  style="margin-right:15px;">
     <label for="to_date">Date To:</label>
      <input type="text" class="form-control datepicker" style="display:block;"  name="date_to"  value="{if $smarty.post.invoice_date_to}{$smarty.post.invoice_date_to|date_format:'%Y-%m-%d'}{else}{/if}" >

    </div>
    
    <div class="form-group"  style="margin-right:15px;">
     <label for="ec_id">Supplier:</label>

      <select name="supplier_id" class="form-control select2" style="display:block !important; width:150px !important; position: relative !important;">
            <option value="">Please Select</option>
            {section name=supplier_list loop=$supplier_list}
                <option value="{$supplier_list[supplier_list].supplier_id}">{$supplier_list[supplier_list].supplier_company} - {$supplier_list[supplier_list].supplier_fname} {$supplier_list[supplier_list].supplier_lname}</option>
            {/section}
      </select>


    </div>

    <div class="form-group" style="margin-right:15px;">
    <label for="from_date" >LPO #:</label>
     <input  type="text" class="form-control" style="display:block; width:100px;"  name="lpo_id"  value="{if $smarty.post.lpo_id}{$smarty.post.lpo_id}{/if}" >
   </div>

   <div class="form-group" style="margin-right:15px;">
    <label for="from_date" >Reference #:</label>
     <input  type="text" class="form-control" style="display:block; width:100px;"  name="reference"  value="{if $smarty.post.reference}{$smarty.post.reference}{/if}" >
   </div>

   {* <div class="form-group" style="margin-right:15px;">
   <label >Expense Type</label>
   <select name="expense_id" style="display:block;"  class="form-control select">
     <option value="">Select..</option>
     {section name=expenses loop=$expenses}
       <option value="{$expenses[expenses].expense_id}" {if $edit_petty_cash[0].expense_id eq $expenses[expenses].expense_id || $smarty.post.expense_id eq $expenses[expenses].expense_id}selected{/if}>{$expenses[expenses].expense_code}: {$expenses[expenses].expense_name}</option>
     {/section}

 </select>
</div> *}

<div class="form-group" style="margin-right:15px;">
<label >Issued To:</label><br>
<select name="employee_id" style="display:block; width:150px;"   class="form-control select2">
<option value="">Select..</option>
  {section name=employees loop=$employees}
  <option value="{$employees[employees].id}" {if $smarty.post.employee_id eq $employees[employees].id || $edit_schedule[0].employee_id eq $employees[employees].id}selected{/if}>{$employees[employees].first_name} {$employees[employees].last_name}</option>
  {/section}
</select>

</div>

{* <div class="form-group" style="margin-right:15px;">
<label >WHT</label>
<select name="wht_tax" style="display:block;"  class="form-control select">
  <option value="">Select..</option>
  <option value="Taxable" $smarty.post.wht_tax eq 'Taxable'>Taxable</option>
  <option value="Exempt" $smarty.post.wht_tax eq 'Exempt'>Exempt</option>
</select>
</div> *}

     <div class="form-group" style="margin-top:20px;">
       <button type="submit" class="btn btn-primary">Go</button>
     </div>


</form>


</div>



</div>
