{if $privileges.exempt_cash.list}

  <!-- START BREADCRUMB -->
  <ul class="breadcrumb">
    <li><a href="/">Home</a></li>
    <li><a href="#">Exempt Cash</a></li>
    <li class="active"><a href="">{$action|capitalize}</a></li>
  </ul>
  <!-- END BREADCRUMB -->
  <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Exempt Cash</h2>
  </div>
  <!-- PAGE CONTENT WRAPPER -->
  <div class="page-content-wrap">

    <div class="row">
      <div class="col-md-12">

        {if $message || $msg}
          <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
            <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span
                class="sr-only">Close</span></button>
            {$message}
            {$msg}
          </div>
        {/if}


        <div class="col-md-12" style="margin-bottom:10px;">

          {if $privileges.exempt_cash.payout}
            <a href="/exemptcash/add" class="btn btn-default">New Payout</a>
          {/if}
          <a href="/receipts/add?type=quote" target="_blank" class="btn btn-default">Receive Against Quote</a>
          <a href="/receipts/add?type=misc" target="_blank" class="btn btn-default">Receive Misc</a>
          <br><br>

          <div style="padding-bottom:15px;"> Current Balance: <span class="badge badge-warning"
              style="font-size:18px;">{$cash_balance|number_format:0:".":","} TZS</span>
          </div>

          <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a
            href="/exemptcash/list?page=1" class="btn btn-default">Clear</a> | Filter By Status: <a
            href="/exemptcash/list?page=1" class="btn {if !$smarty.get.status}btn-success{/if} btn-flat btn-rad">All</a>

            <a href="/exemptcash/list?page=1&filter=1&status=Pending"
            class="btn {if $smarty.get.status eq 'Pending'}btn-success{else}btn-default{/if}">Pending <span class="badge">
              {$status_nos.Pending}</span> <span class="badge" style="background-color:#fea223;">
              {$amount_statuses.Pending|number_format:0:".":","}</span></a>

              <a href="/exemptcash/list?page=1&filter=1&status=Confirmed"
                class="btn {if $smarty.get.status eq 'Confirmed'}btn-success{else}btn-default{/if}">Confirmed <span class="badge">
                  {$status_nos.Confirmed}</span> <span class="badge" style="background-color:#fea223;">
                  {$amount_statuses.Confirmed|number_format:0:".":","}</span></a>

          <a href="/exemptcash/list?page=1&filter=1&status=Approved"
            class="btn {if $smarty.get.status eq 'Approved'}btn-success{else}btn-default{/if}">Approved <span
              class="badge"> {$status_nos.Approved}</span> <span class="badge badge-info"
              style="background-color:#fea223;"> {$amount_statuses.Approved|number_format:0:".":","}</span></a>

          <a href="/exemptcash/list?page=1&filter=1&status=Issued"
            class="btn {if $smarty.get.status eq 'Issued'}btn-success{else}btn-default{/if}">Issued <span class="badge">
              {$status_nos.Issued}</span> <span class="badge badge-info" style="background-color:#fea223;">
              {$amount_statuses.Issued|number_format:0:".":","}</span></a>

          <a href="/exemptcash/list?page=1&filter=1&status=Closed"
            class="btn {if $smarty.get.status eq 'Closed'}btn-success{else}btn-default{/if}">Closed <span class="badge">
              {$status_nos.Closed}</span></a>

         
          <a href="/exemptcash/list?page=1&filter=1&status=Cancelled"
            class="btn {if $smarty.get.status eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled</a>
          {include file='exemptcash/search.tpl'}
        </div>

        <div class="panel panel-default">

          <div class="panel-heading">

            {if $smarty.get.status eq 'Pending'}
              <label for="confirm_selected" name="confirm_selected" class="btn btn-success confirm_pc_btn"
                style="display:none;">
                Confirm Selected
              </label>
              <a href="" class="btn btn-warning cancel_pc_btn" style="display:none;">Cancel Selected</a>
            {/if}

            {if $smarty.get.status eq 'Confirmed'}
              <label for="approve_selected" name="approve_selected" class="btn btn-success approve_pc_btn"
                style="display:none;">
                Approve Selected
              </label>
            {/if}

            {if $smarty.get.status eq 'Issued'}
              <a href="" id="close_selected_btn" class="btn btn-info" style="display:none;">
                Close Selected
              </a>
            {/if}

            <ul class="panel-controls panel-controls-title">
              <li>

                <form class="form-inline" role="form" method="post">
                  <div class="form-group">
                  </div>
                  <div class="form-group">
                    <a href="/exemptcash/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt;
                      Previous Page</a> | <a
                      href="/exemptcash/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next
                      Page &gt;</a>

                    <label>| Displaying {$resultsCount}</label>
                  </div>
                  <div class="form-group">

                    <select name="page" id="page" class="form-control">
                      {section name=pagination loop=$numPages}

                        <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page
                          {$numPages[pagination]}</option>
                        {sectionelse}

                        <option value="1" selected>Page 1</option>


                      {/section}

                    </select>

                  </div>
                  <button name="submit" type="submit" class="btn btn-danger">Go</button>


                </form>
              </li>

            </ul>
          </div>




          <div class="panel-body panel-body-table">

            <form method="post" action="">
              <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
              <input type="submit" name="confirm_selected" id="confirm_selected" class="hidden" />
              {* filepath: /Users/levy/Documents/Lev/ws/id/app/templates/exemptcash/list.tpl *}
              {* ...existing code... *}

              <div class="table-responsive">
                <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                  <thead>
                    <tr>
                       {if $smarty.get.status eq 'Confirmed'}
                        <th width="40" class="text-center">
                          <input type="checkbox" id="check_all_approved" />
                      </th>
                      {/if}
                      {if $smarty.get.status eq 'Pending'}
                        <th width="40" class="text-center">
                          <input type="checkbox" id="check_all_confirmed" />
                      </th>
                      {/if}
                      {if $smarty.get.status eq 'Issued'}
                        <th width="40" class="text-center">
                          <input type="checkbox" id="check_all_issued" />
                      </th>{/if}
                      <th class="text-center" width="90">Ref #</th>
                      <th class="text-center">Date</th>
                      <th class="text-center">Type</th>
                      <th class="text-center">Paid To</th>
                      <th class="text-center">Expense</th>
                      <th class="text-center">Amount</th>
                      <th class="text-center">Attachment</th>
                      <th class="text-center">Remarks</th>
                      <th class="text-center">Status</th>
                      <th class="text-center">User</th>
                      <th class="text-center no-print">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {section name=pc_list loop=$pc_list}
                      <tr>
                        {if $pc_list[pc_list].status eq 'Pending' && $smarty.get.status eq 'Pending'}<td
                            class="text-center">
                            <input type="checkbox" name="confirm_ec_id[]" class="confirmed_check"
                              value="{$pc_list[pc_list].id}" />
                        </td>{/if}

                        {if $pc_list[pc_list].status eq 'Confirmed' && $smarty.get.status eq 'Confirmed'}<td
                            class="text-center">
                            <input type="checkbox" name="approve_ec_id[]" class="approved_check"
                              value="{$pc_list[pc_list].id}" />
                        </td>{/if}

                        {if $pc_list[pc_list].status eq 'Issued' && $smarty.get.status eq 'Issued'}<td class="text-center">
                            <input type="checkbox" name="issue_ec_id[]" class="issued_check"
                              value="{$pc_list[pc_list].id}" />
                        </td>{/if}
                        <td class="text-center">
                          {if $pc_list[pc_list].type == 'Receipt'}
                            <a title="View Receipt" target='_blank' href="/receipts/view/?id={$pc_list[pc_list].id}"
                              alt="View Receipt">Rct #{$pc_list[pc_list].id}</a>
                          {else}
                            {if $pc_list[pc_list].reference}{$pc_list[pc_list].reference|leading_zero:5}{else}-{/if}
                          {/if}
                        </td>
                        <td class="text-center">
                          {$pc_list[pc_list].date_created|date_format:"%d/%m/%Y"}<br>
                          {* ({$pc_list[pc_list].date_created|date_format:"%H:%M:%S"}) *}
                        </td>
                        <td class="text-center">{$pc_list[pc_list].type}</td>
                        <td class="text-center">
                          {if $pc_list[pc_list].supplier_company}{$pc_list[pc_list].supplier_company}
                          {elseif $pc_list[pc_list].paid_to}{$pc_list[pc_list].paid_to}
                          {elseif $pc_list[pc_list].employee_name}{$pc_list[pc_list].employee_name}
                          {else}-
                          {/if}
                        </td>
                        <td class="text-center">{if $pc_list[pc_list].expense_name}{$pc_list[pc_list].expense_name}{else}-{/if}</td>
                        <td class="text-right">
                          {if $pc_list[pc_list].amount > 0}{$pc_list[pc_list].amount|number_format:2:".":","}{else}{$pc_list[pc_list].items_amount|number_format:2:".":","}{/if}
                        </td>
                        {* <td class="text-center">{if $pc_list[pc_list].recipient}{$pc_list[pc_list].recipient}{else}-{/if}</td> *}
                        <td class="text-center">
                          {if $pc_list[pc_list].attachment}
                            <a href="/uploads/exemptcash/{$pc_list[pc_list].attachment}"
                              target="_blank">{$pc_list[pc_list].attachment}</a>
                          {/if}
                           {if $pc_list[pc_list].close_attachment}
                            <br><a href="/uploads/exemptcash/{$pc_list[pc_list].close_attachment}"
                              target="_blank">{$pc_list[pc_list].close_attachment}</a>
                          {/if}
                        </td>
                        <td>
                          {$pc_list[pc_list].remarks}
                           {if $pc_list[pc_list].confirm_remarks}
                            <br><i>Confirm Remarks: {$pc_list[pc_list].confirm_remarks}</i>
                           {/if}

                          {if $pc_list[pc_list].quote_ids}
                            {assign var=quoteIds value=","|explode:$pc_list[pc_list].quote_ids}
                            {assign var=last value=$quoteIds|@end}
                            {foreach from=$quoteIds key=k item=quote_id}
                              <a title="View Quote" href="#" onclick="popupPDF('quote', {$quote_id});">Quote #:{$quote_id}</a>
                              - {$pc_list[pc_list].group_company}
                              [{$pc_list[pc_list].items_amount|number_format:2:".":","}]{if $quote_id != $last}, <br>{/if}
                            {/foreach}
                          {else}
                            {if $pc_list[pc_list].group_company}Receipt from {$pc_list[pc_list].group_company} {/if}
                          {/if}


                        </td>
                        <td class="text-center">
                           <span
                            class="{if $pc_list[pc_list].status eq 'Pending'}text-danger{elseif $pc_list[pc_list].status eq 'Confirmed'}text-warning{elseif $pc_list[pc_list].status eq 'Approved'}text-info{elseif $pc_list[pc_list].status eq 'Cancelled'}text-default{else}text-success{/if}">{$pc_list[pc_list].status}</span>
                          {* {if $pc_list[pc_list].status eq 'Issued'}
                            <br> <i>Ref: {$pc_list[pc_list].other_remarks}</i>
                          {/if} *}
                          {if $pc_list[pc_list].status eq 'Cancelled'}
                            <br> <i>{$pc_list[pc_list].other_remarks}</i>
                          {/if}
                          {* {if $pc_list[pc_list].approval_user_name}<br><small>Approved by {$pc_list[pc_list].approval_user_name}</small>{/if} *}
                        </td>
                        <td class="text-center">
                          {$pc_list[pc_list].user_name|default:'-'}
                        </td>
                        <td class="text-center no-print">

                          {if ($pc_list[pc_list].type eq 'Payout' || $pc_list[pc_list].type eq 'Supplier')}
                           
                           
                            {if $pc_list[pc_list].status eq 'Pending'}
                               <a href="#" data-item-id="{$pc_list[pc_list].id}"
                              class="btn btn-info btn-rounded btn-condensed btn-sm confirmBtn" title="Confirm"><span
                                class="fa fa-check"></span></a>
                            <a href="/exemptcash/edit?id={$pc_list[pc_list].id}"
                              class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit"><span
                                class="fa fa-pencil"></span></a>
                            {/if}
                             {if $pc_list[pc_list].status eq 'Pending' || ($pc_list[pc_list].status eq 'Confirmed' && ($smarty.session.role_name == 'Administrator' || $smarty.session.user_id == '298'))}    
                            <a href="#" data-item-id="{$pc_list[pc_list].id}"
                              class="btn btn-default btn-rounded btn-condensed btn-sm cancelBtn" title="Cancel"><span
                                class="fa fa-times"></span></a>
                            {/if}
                          {/if}
                           {if $pc_list[pc_list].status eq 'Confirmed' && $privileges.exempt_cash.approve}
                            <a href="/exemptcash/list?approve_ec_id={$pc_list[pc_list].id}"
                              class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve"
                              onclick="confirmAction('[Approve Exempt Cash Record] Are you sure?', this.href); return false;"><span
                                class="fa fa-check"></span></a>
                          {/if}
                          {if $pc_list[pc_list].status eq 'Approved'}

                            <a href="#"
                              data-item-id="{$pc_list[pc_list].id}"
                              data-item-amount='{if $pc_list[pc_list].supplier_id > 0 && $pc_list[pc_list].items_amount > 0}{$pc_list[pc_list].items_amount|number_format:0:".":","}{else}{$pc_list[pc_list].amount|number_format:0:".":","} TZS{/if}'
                              class="btn btn-success btn-rounded btn-condensed btn-sm item_list" title="Issue">
                              <span class="fa fa-arrow-circle-right"></span>
                            </a>

                          {/if}
                          {if $pc_list[pc_list].status eq 'Issued'}
                             <a title="Attachment" href="" class="btn btn-default btn-rounded btn-condensed btn-sm attach_btn"
                              data-id="{$pc_list[pc_list].id}" data-ref="EPCV #{$pc_list[pc_list].reference|leading_zero:5}"
                              data-attachment_path="{$pc_list[pc_list].attachment_path}"><span
                                class="fa fa-paperclip"></span></a>
                            {if $privileges.exempt_cash.close}
                              <a href="/exemptcash/list?close_ec_id={$pc_list[pc_list].id}"
                                class="btn btn-info btn-rounded btn-condensed btn-sm" title="Close"
                                onclick="confirmAction('[Close Exempt Cash Record] Are you sure?', this.href); return false;"><span
                                  class="fa fa-check-circle"></span></a>
                            {/if}
                          {/if}
                           {if $pc_list[pc_list].status != 'Pending' && $pc_list[pc_list].status != 'Cancelled' && $pc_list[pc_list].type != 'Receipt'} 
                           <a class="btn btn-default btn-rounded btn-condensed btn-sm" title="View E-PCV" 
                           href="/exemptcash/print?id={$pc_list[pc_list].id}" target="_blank"
                              ><span
                                class="fa fa-file-pdf-o"></span></a> 
                          {/if}

                        </td>
                      </tr>

                      {if $pc_list[pc_list].items[0]}
                        <tr>
                          <td colspan="11">
                            <table width="100%">
                              <tr>
                                <th width="20">&nbsp;</th>
                                <th>
                                  {if $pc_list[pc_list].items[0].lpo_id > 0}
                                    LPO
                                  {else}
                                    GRN
                                  {/if}
                                </th>
                                <th>Date</th>
                                <th>Invoice No</th>
                                <th>Amount</th>
                                <th>Amount Paid</th>
                                <th>&nbsp;</th>
                              </tr>
                              {section name=items loop=$pc_list[pc_list].items}
                                <tr>
                                  <td style="padding:2px 4px;">&nbsp;</td>
                                  <td style="padding:2px 4px;">
                                    {if $pc_list[pc_list].items[items].item_type eq 'LPO'}
                                      <a href="#"
                                        onclick="popupPDF('lpo', {$pc_list[pc_list].items[items].item_ref_id}); return false;">
                                        LPO-{$pc_list[pc_list].items[items].lpo_date|substr:0:4}-{$pc_list[pc_list].items[items].lpo_id|leading_zero:5}
                                      </a>
                                    {else}
                                      <a href="#"
                                        onclick="popupPDF('grn', {$pc_list[pc_list].items[items].item_ref_id}); return false;">
                                        GRN-{$pc_list[pc_list].items[items].grn_date|substr:0:4}-{$pc_list[pc_list].items[items].grn_id|leading_zero:5}
                                      </a>
                                    {/if}
                                  </td>
                                  <td style="padding:2px 4px;">{$pc_list[pc_list].items[items].item_date|date_format:"%d %b %Y"}
                                  </td>
                                  <td style="padding:2px 4px;">
                                    {$pc_list[pc_list].items[items].invoice_no|default:'-'}
                                  </td>
                                  <td style="padding:2px 4px;">
                                    {if $pc_list[pc_list].items[items].item_type eq 'LPO'}
                                      {$pc_list[pc_list].items[items].lpo_amount|number_format:2:".":","}
                                    {else}
                                      {$pc_list[pc_list].items[items].grn_amount|number_format:2:".":","}
                                    {/if} TZS
                                  </td>
                                  <td style="padding:2px 4px;">
                                    {if $pc_list[pc_list].items[items].item_type eq 'LPO'}  
                      {$pc_list[pc_list].items[items].lpo_amount_paid|number_format:2:".":","}
                    {else}
                      {$pc_list[pc_list].items[items].grn_amount_paid|number_format:2:".":","}
                    {/if} TZS

                                    {* {$pc_list[pc_list].items[items].item_amount|number_format:2:".":","} *}
                                    
                                  </td>
                                  <td style="padding:2px 4px;">&nbsp;</td>
                                </tr>
                              {/section}
                            </table>
                          </td>
                        </tr>
                      {/if}
                      <tr>
                        <td colspan="11" style="padding:1px 0 !important; background:#ccc;"></td>
                      </tr>

                      {sectionelse}
                      <tr>
                        <td colspan="11">No records found.</td>
                      </tr>
                    {/section}
                  </tbody>
                </table>
              </div>
            </form>


          </div>

          {if $smarty.get.dbg}
            {$privileges.exemptcash|@print_r}
          {/if}

        </div>

        {include file="$section/item_form.tpl"}
        {include file="$section/edit_form.tpl"}
        {include file="$section/return_form.tpl"}
        {include file="$section/confirm_form.tpl"}
        {include file="$section/attachment_forms.tpl"}
        {include file="$section/cancel_form.tpl"}


      </div>
    </div>
    <!-- END PAGE CONTENT WRAPPER -->
  </div>
  <!-- END PAGE CONTENT -->
  </div>
  <!-- END PAGE CONTAINER -->

{else}
  <div class="row">
    <div class="col-md-12">
      <div class="alert alert-danger" role="alert">
        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span
            class="sr-only">Close</span></button>
        You are not authorized to view this section
      </div>

    </div>

  </div>
{/if}