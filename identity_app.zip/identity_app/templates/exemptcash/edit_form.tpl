<!-- NEW COMPANY MODAL -->
  <div class="modal" id="itemEditModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead"><span class="item_edit_name"></span></h4>
              </div>
              <form id="item_edit_form" name="item_edit_form" method="post" action="/petty_cash/list" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="response_edit_item"></div>


			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			                 <div class="panel-body form-group">
			                   <div class="row">




                    <div class="form-group">
          				    <label class="col-md-3 col-xs-12 control-label">Recipient Name</label>
          				    <div class="col-md-6 col-xs-12">
                        <select name="employee_id" id="edit_employee_id"  class="form-control select2">
                        <option value="">Select..</option>
                          {section name=employees loop=$employees}
                          <option value="{$employees[employees].id}" {if $smarty.post.employee_id eq $employees[employees].id || $edit_schedule[0].employee_id eq $employees[employees].id}selected{/if}>{$employees[employees].first_name} {$employees[employees].last_name}</option>
                          {/section}
                        </select>
          				    </div>
          				  </div>

									  {* <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Recipient Name</label>
									    <div class="col-md-6 col-xs-12">
									    <input name="recipient" type="text" value="{if $smarty.post.recipient}{$smarty.post.recipient}{/if}" class="form-control" />
                      </div>

									    </div>
									  </div> *}

			                   </div>


			                 </div>

			             </div>

                   <div class="modal-footer">
                       <input type="hidden" name="edit_item_id" value="" >
                       <input type="hidden" name="edit_item_ajax" value="1" >
                       <input type="submit" name="item_edit_submit" class="btn btn-primary item_edit_submit" value="Submit">
                       <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                     </div>

	              </div>

              </form>

          </div>
      </div>
  </div>
