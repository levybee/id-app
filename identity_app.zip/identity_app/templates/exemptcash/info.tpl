<div class="panel panel-default">

       <div class="panel-heading">
          <h3 class="panel-title">Exempt Cash Info</h3>
	 </div>
	 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">

			  <tr>
			    <td colspan="2"><div><strong>Supplier</strong></div>

            <div>{$smarty.session.exemptcash.supplier.supplier_fname} {$smarty.session.exemptcash.supplier.supplier_lname}<br />
            {if $smarty.session.exemptcash.supplier.supplier_company}{$smarty.session.exemptcash.supplier.supplier_company}<br />{/if}
            {if $smarty.session.exemptcash.supplier.supplier_address}{$smarty.session.exemptcash.supplier.supplier_address}<br />{/if}
            {$smarty.session.exemptcash.supplier.supplier_city}, {$smarty.session.exemptcash.supplier.supplier_country}<br />
            <br />
            Phone: {$smarty.session.exemptcash.supplier.supplier_phone}<br />
            {if $smarty.session.exemptcash.supplier.supplier_fax}Fax: {$smarty.session.exemptcash.supplier.supplier_fax}<br />{/if}
            {if $smarty.session.exemptcash.supplier.supplier_mobile}Mobile: {$smarty.session.exemptcash.supplier.supplier_mobile}<br />{/if}
            Email: {$smarty.session.exemptcash.supplier.supplier_email}
            {if $smarty.session.exemptcash.supplier.supplier_tin}TIN: {$smarty.session.exemptcash.supplier.supplier_tin}<br />{/if}
            {if $smarty.session.exemptcash.supplier.supplier_vrn}VRN: {$smarty.session.exemptcash.supplier.supplier_vrn}<br />{/if}

          </div>

			    </td>

			  </tr>
			    {* <tr>
			    <td colspan="2"><div><strong>Expense</strong></div>
			        <div>{$smarty.session.exemptcash.expense.expense_code}: {$smarty.session.exemptcash.expense.expense_name}</div>
			    </td>

			  </tr> *}

        {* <tr>
        <td colspan="2"><div><strong>Tax</strong></div>
            <div>{$smarty.session.exemptcash.tax}</div>
        </td>
        </tr>
        <tr>
        <td colspan="2"><div><strong>WHT Tax</strong></div>
            <div>{$smarty.session.exemptcash.wht_tax}</div>
        </td>
      </tr> *}
      {if $smarty.session.exemptcash.job_id}
      <tr>
        <td colspan="2"><div><strong>Job</strong></div>
            <div>#{$smarty.session.exemptcash.job_id}</div>
        </td>
      </tr>
      {/if}
      <tr>
        <td colspan="2"><div><strong>Remarks</strong></div>
            <div>{$smarty.session.exemptcash.remarks}</div>
        </td>
      </tr>

			  <!-- <tr>
			    <td colspan="2"><div><strong>Show Details</strong>    <input type="checkbox" name="show_summary" id="show_summary" value="Y" checked="checked" onclick="show_summary(this);" /></div></td>
			  </tr> -->
             </table>

           </div>
       </div>


</div>
