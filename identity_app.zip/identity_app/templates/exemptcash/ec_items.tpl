<div class="panel panel-default">
      <form method="post" action="/exemptcash/add" id="subm">
       <div class="panel-heading">
            <div class="col-sm-6"><h3 class="panel-title">Exempt Cash Items</h3></div>
            <div class="col-sm-6">
            {if $smarty.session.exemptcash.item_type == 'LPO'}{else}<button type="submit" class="btn btn-default pull-right all_overdue">Check All Overdue</button>{/if}
            </div>
		</div>
		<div class="panel-body panel-body-table">

		   <div class="table-responsive">
                    <table class="table pad-6 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th class="text-center" width="40">{$smarty.session.exemptcash.item_type}</th>
                                <th class="text-center" width="40">Date</th>
                                {if $smarty.session.exemptcash.item_type == 'GRN'}<th class="text-center" width="40">Invoice No.</th>{/if}
                                {if $smarty.session.exemptcash.item_type == 'LPO' && $smarty.session.exemptcash.supplier.supplier_type == 'Casual'}<th class="text-center">Remarks</th>{/if}
                                <th class="text-center" width="40">Days Overdue</th>
                                <th class="text-center">Total ({$smarty.session.exemptcash.currency})</th>
              							    <th class="text-center">Upaid ({$smarty.session.exemptcash.currency})</th>
              							    <th class="text-center">Items {if $smarty.session.exemptcash.item_type == 'LPO'}Amount{/if}</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=items loop=$smarty.session.exemptcash.ec_items}
						  <tr>
						    <td class="text-center">
                  {if $smarty.session.exemptcash.item_type == 'LPO'}
                   LPO-{$smarty.session.exemptcash.ec_items[items].lpo_date|substr:0:4}-{$smarty.session.exemptcash.ec_items[items].lpo_id|leading_zero:5}
                  {/if}
                  {if $smarty.session.exemptcash.item_type == 'GRN'}
                  GRN-{$smarty.session.exemptcash.ec_items[items].grn_date|substr:0:4}-{$smarty.session.exemptcash.ec_items[items].grn_id|leading_zero:5}
                  {/if}
                </td>
                <td class="text-center">
                {if $smarty.session.exemptcash.item_type == 'GRN'}
                {$smarty.session.exemptcash.ec_items[items].grn_date|date_format:"%d/%m/%Y"}
                {else}
                {$smarty.session.exemptcash.ec_items[items].lpo_date|date_format:"%d/%m/%Y"}
                {/if}</td>
                {if $smarty.session.exemptcash.item_type == 'GRN'}<td class="text-center">{$smarty.session.exemptcash.ec_items[items].invoice_no}</td>{/if}
                {if $smarty.session.exemptcash.item_type == 'LPO' && $smarty.session.exemptcash.supplier.supplier_type == 'Casual'}<td>{$smarty.session.exemptcash.ec_items[items].comments}</td>{/if}
              <td class="text-center">{if $smarty.session.exemptcash.ec_items[items].overdue}{$smarty.session.exemptcash.ec_items[items].days_overdue}{else}-{/if}</td>
                <td class="text-right">{$smarty.session.exemptcash.ec_items[items].total_amount|number_format:2:".":","}</td>
						    <td class="text-right balance{$smarty.section.items.rownum}">{$smarty.session.exemptcash.ec_items[items].balance|number_format:2:".":","}</td>
						    <td class="text-center">
						 {if $smarty.session.exemptcash.item_type == 'LPO'}
						 <input  type="text"
						 data-balance-id="balance{$smarty.section.items.rownum}"
						 id="allocation_{$smarty.section.items.rownum}"
						 name="allocation[{if $smarty.session.exemptcash.ec_items[items].grn_id > 0}{$smarty.session.exemptcash.ec_items[items].grn_id}{else}{$smarty.session.exemptcash.ec_items[items].lpo_id}{/if}]"
						 value="{if $smarty.session.exemptcash_edit.ec_items.amount_paid}{$smarty.session.exemptcash_edit.ec_items.amount_paid}{else}{/if}"
						 class="form-control ec_val text-right">
						 {else}
						 <input type="checkbox"
                id="allocation_{$smarty.section.items.rownum}"
                data-overdue="{$smarty.session.exemptcash.ec_items[items].overdue}"
                name="allocation[{if $smarty.session.exemptcash.ec_items[items].grn_id > 0}{$smarty.session.exemptcash.ec_items[items].grn_id}{else}{$smarty.session.exemptcash.ec_items[items].lpo_id}{/if}]"
                value="{$smarty.session.exemptcash.ec_items[items].balance}"
                class="ec_val">
						 {/if}


                         </td>
						  </tr>

						  {sectionelse}
						  <tr>
						    <td colspan="{if $smarty.session.exemptcash.item_type == 'LPO' && $smarty.session.exemptcash.supplier.supplier_type != 'Casual'}5{else}6{/if}"><div>No items available.</td>
						  </tr>
						  {/section}

						  {if $smarty.session.exemptcash.ec_items|@count > 0}
						    <tr>
                    <th  class="text-right" colspan="{if $smarty.session.exemptcash.item_type == 'LPO' && $smarty.session.exemptcash.supplier.supplier_type != 'Casual'}3{else}4{/if}"><strong>TOTAL</strong></th>
                    <th class="text-right"> <div id="ec_total">{$smarty.session.exemptcash.ec_total|number_format:2:".":","}</div> </th>
                    <th class="text-right"> <div id="balance_total">{$smarty.session.exemptcash.balance_total|number_format:2:".":","}</div> </th>
                    <th class="text-right"> <div id="allocation_total">0</div> </th>
                    <input type="hidden" name="allocation_total" value="0" >
                    <input type="hidden" name="ec_total" value="{$smarty.session.exemptcash.ec_total}">
                </tr>
						  {/if}

                  </tbody>
              </table>
                {if $smarty.get.debug eq 'lev'}
                 <pre> {$smarty.session.exemptcash|@print_r}</pre>
                {/if}
              </div>

  </div>
    <div class="panel-footer">
          <input type="hidden" name="next_step" value="three" />
          <input type="hidden" name="complete" value="1" />
          <input type="submit" name="submit" value="Submit" class="btn btn-success pull-right"  />
    </div>
  </form>
</div>
