
{if $action == 'edit'}
{include file='exemptcash/ec_items.edit.tpl'}
{/if}

{if $action == 'add'}
{include file='exemptcash/ec_items.tpl'}
{/if}
