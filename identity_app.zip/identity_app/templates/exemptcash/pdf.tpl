<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Identity Promotions</title>
  <style>
    {include file="css/epcv-pdf.css"}
  </style>
</head>

<body>
  <!-- pdf-header  -->
  <header>
    <table class="table pdf-header" style="padding-top:0;">
      <tr>
        <td width="60%">
          <h1>E-PCV</h1>
        </td>
        <td width="40%" valign="right" style="text-align: right; padding-top:25px;">
          <table width="100%">
            <tr>
              <td>
                <table class="details">
                  <tr>
                    <td class="label">
                      <strong>Date:</strong>
                    </td>
                    <td class="value">{$data[0].date_created|date_format:"%d/%m/%Y"}</td>
                  </tr>
                  <tr>
                    <td class="label">
                      <strong>E-PCV #:</strong>
                    </td>
                    <td class="value">
                      {$data[0].reference|leading_zero:5}
                    </td>
                  </tr>
            </tr>
            {if $data.gmr.job_id > 0}
              <tr>
                <td class="label">
                  <strong>Job:</strong>
                </td>
                <td class="value">#{$data.gmr.job_id}: {$data.gmr.job_reference}</td>
              </tr>
            {/if}
           
          </table>
        </td>
        <td>
        </td>
      </tr>
    </table>
    </td>
    </tr>
    </table>

    <table class="table" style="padding-top:30px;">
      <tr>
        <td width="60%">
          <table class="details">
            <tr>
              <td class="label">
                <strong>Job Order Ref:</strong>
              </td>
              <td class="value">
               {if $data[0].job_id > 0} #{$data[0].job_id}: {$data[0].group_company}{else} - {/if}
              </td>
            </tr>
            <tr>
              <td class="label">
                <strong>LPO Ref:</strong>
              </td>
              <td class="value">
                {if $data[0].lpo_ref} {$data[0].lpo_ref}{else} - {/if}
              </td>
            </tr>
            <tr>
              <td class="label">
                <strong>Expense Type:</strong>
              </td>
              <td class="value" style="font-size:12px;">
                {if $data[0].expense_name} {$data[0].expense_name}{else} {$data[0].remarks|substr:0:30}{/if}
              </td>
            </tr>
    </table>
    </td>
    <td width="40%">
    <table class="details">  
            <tr>
              <td class="label">
                <strong>Requester:</strong>
              </td>
              <td class="value">
                {$data[0].user_name}
              </td>
            </tr>
            <tr>
              <td class="label">
                <strong>Approver:</strong>
              </td>
              <td class="value">
                {$data[0].approval_user_name}
              </td>
            </tr>
    </table>
    </td>

    </tr>
    </table>

    <!-- /.pdf-header -->
  </header>
  <footer>
   <table class="table">
   <tr>
    <td width="70%">
    <table class="table">
     <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td><strong>Issued To:</strong></td>
        <td>{if $data[0].employee_name}{$data[0].employee_name}{else}{$data[0].paid_to}{/if}</td>
          <td></td>
        <td></td>
      </tr>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td class="label-light text-muted">Printed By:</td>
        <td class="field-light">{$user_data[0]['user_fname']}  {$user_data[0]['user_lname']}</td>
        <td class="label-light text-muted">Timestamp:</td>
        <td class="field-light">{$smarty.now|date_format:"%H:%M:%S"}</td>
      </tr>
    </table>
    </td>
   <td width="30%">
    <table class="table">
      <tr>
        <td style="border:1px solid #ccc; padding:8px; width:100%; height:80px;">
          Received By / Sign
        </td>
       </tr>
     </table>
   <td>
   </tr>
   </table>
    
    <table class="table footer-bottom">
      <tr>
        <td width="90%" class="">
           <p class="footer-text">
            {* Identity Promotions Ltd. | Corner ITV/Bagamoyo Rd, Mwenge, P.O. Box 38070, Dar es Salaam, Tanzania | Phone
            No: 0769 785065 | hr@identitytz.com | identitytz.com *}
          </p> 
        </td>
        <td width="20%" style="padding-left:30px;">
          {* <p class="footer-text"></p> *}
        </td>
      </tr>
    </table>

  </footer>

  <section class="content">
   <table class="table" style="padding: 10px 10px;">
   <tr>
    <td style="border:1px solid #ccc; padding:8px; height:80px; font-size:12px;">
       {$data[0].remarks}
       {if $data[0].confirm_remarks}
        <br>
        {$data[0].confirm_remarks}
       {/if}
    </td>
   </tr>
   <tr><td></td></tr>
   <tr>
    <td style="border:1px solid #ccc; padding:8px;">
      <strong>Amount: </strong>{if $data[0].amount > 0} {$data[0].amount|number_format:2:".":","}{else}{$data[0].items_amount|number_format:2:".":","} TZS{/if}
    </td>
   </tr>
   </table>
  </section>

  <!-- <div class="pagination"><center><span class='page-number'></span></center></div> -->
</body>

</html>