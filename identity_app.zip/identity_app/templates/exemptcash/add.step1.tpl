
<div id="response2"></div>

<form class="form-horizontal" method="post"
action="/{$section}/{$action}{if $action eq 'edit'}?id={$smarty.get.id}{/if}{if $smarty.get.contractor_id}?contractor_id={$smarty.get.contractor_id}{/if}"
enctype="multipart/form-data"
>
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Exempt Cash Information</h3>
        </div>

        <div class="panel-body form-group">

            <div class="form-group">
               <label class="col-md-3 col-xs-12 control-label">For</label>
               <div class="col-md-2">
                 <label class="check"><input type="radio" class="iradio" name="type"  value="Payout" {if $ec_data.type eq 'Payout' || $smarty.post.type eq 'Payout' || $smarty.get.advance} checked="checked"{/if} {if $action == 'edit' || ($smarty.get.contractor_id && !$smarty.get.advance)}disabled{/if} /> Payout</label>
               </div>
               <div class="col-md-2">
                 <label class="check"><input type="radio" class="iradio" name="type"  value="Supplier" {if $ec_data.type eq 'Supplier' || $smarty.post.type eq 'Supplier' || ($smarty.get.contractor_id && !$smarty.get.advance)} checked="checked"{elseif !$ec_data.type} checked="checked"  {/if} {if $action == 'edit'}disabled{/if} /> Supplier </label>
               </div>
               {if $action == 'edit'}
               <input name="type" type="hidden"  value="{$ec_data.type}" />
               {/if}
           </div>



          <div  class="form-group sup_field" {if $ec_data.type eq 'Supplier' || $smarty.post.type eq 'Supplier'}{else}style="display:none;"{/if}>
             <label class="col-md-3 control-label">Select Supplier</label>
             <div class="col-md-6">
            <select id="supplier_id" name="supplier_id" class="form-control select2" style="width: 100%;">
               <option value="">Please Select</option>
               {section name=supplier_list loop=$supplier_list}
                   <option value="{$supplier_list[supplier_list].supplier_id}" {if $ec_data.supplier_id == $supplier_list[supplier_list].supplier_id || $smarty.post.supplier_id == $supplier_list[supplier_list].supplier_id || $contractor.supplier_id == $supplier_list[supplier_list].supplier_id}selected{/if}>{if $supplier_list[supplier_list].supplier_company}{$supplier_list[supplier_list].supplier_company} -{/if} {$supplier_list[supplier_list].supplier_fname} {$supplier_list[supplier_list].supplier_lname}</option>
               {/section}
               </select>

             </div>
         </div>
       
         <div class="form-group sup_field" {if $ec_data.type eq 'Supplier' || $smarty.post.type eq 'Supplier'}{else}style="display:none;"{/if}>
                <label class="col-md-3 col-xs-12 control-label">Job #</label>
                 <div class="col-md-6 col-xs-12">
                 <select name="job_id" id="job_id"  class="form-control" style="width:100%;" ></select>
            </div>
          </div>
         

          {if $smarty.get.contractor_id && !$smarty.get.advance}
          <div class="form-group">
                 <label class="col-md-3 col-xs-12 control-label">Apply Advance?</label>
                  <div class="col-md-6 col-xs-12">
                    <label class="check"><input name="apply_advance" type="checkbox" id="apply_advance" value="1" /></label>
             </div>
           </div>
          {/if}

         <div class="form-group payout_field" {if $ec_data.type eq 'Payout' || $smarty.post.type eq 'Payout' || $smarty.get.advance}{else}style="display:none;"{/if}>
           <label class="col-md-3 col-xs-12 control-label">Type of Expense</label>
           <div class="col-md-6 col-xs-12">
               <select name="expense_id" id="expense_id" class="form-control select" style="width:100%">
                 <option value="">Select..</option>
                 {section name=expenses loop=$expenses}
                   <option value="{$expenses[expenses].expense_id}" {if $ec_data.expense_id eq $expenses[expenses].expense_id || $smarty.post.expense_id eq $expenses[expenses].expense_id}selected{/if}>{$expenses[expenses].expense_code}: {$expenses[expenses].expense_name}</option>
                 {/section}

             </select>
           </div>
        </div> 

         <div class="form-group payout_field" {if $ec_data.type eq 'Payout' || $smarty.post.type eq 'Payout' || $smarty.get.advance}{else}style="display:none;"{/if}>
            <label class="col-md-3 col-xs-12 control-label">Paid To </label>
            <div class="col-md-6 col-xs-12">
              <select name="employee_id" id="employee_id"  class="form-control select2" style="width:100%;">
              <option value="">Select..</option>
                {section name=employees loop=$employees}
                <option value="{$employees[employees].id}" {if $smarty.post.employee_id eq $employees[employees].id || $ec_data.employee_id eq $employees[employees].id}selected{/if}>{$employees[employees].first_name} {$employees[employees].last_name}</option>
                {/section}
              </select>
            </div>
          </div>

         <div class="form-group payout_field" {if $ec_data.type eq 'Payout' || $smarty.post.type eq 'Payout' || $smarty.get.advance}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">Amount</label>
             <div class="col-md-6 col-xs-12">
                 <input name="amount" type="text" value="{if $smarty.post.amount}{$smarty.post.amount}{else}{$ec_data.amount}{/if}{if $advance_amount}{$advance_amount}{/if}" class="form-control" />
             </div>
         </div>
         {* <div class="form-group payout_fields" {if $ec_data.type eq 'Payouts' || $smarty.post.type eq 'Payouts'}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">Tax</label>
             <div class="col-md-6 col-xs-12">
              <select name="tax" id="tax" class="form-control">
                <option value="Taxable"  {if $smarty.post.tax eq "Taxable" || $ec_data.tax eq "Taxable"}selected{/if}>Taxable</option>
                <option value="Exempt"  {if $smarty.post.tax eq "Exempt" || $ec_data.tax eq "Exempt"}selected{/if}>Exempt</option>
              </select>
             </div>
         </div> *}
         {* <div class="form-group payout_field" {if $ec_data.type eq 'Payout' || $smarty.post.type eq 'Payout' || $smarty.get.advance}{else}style="display:none;"{/if}>
             <label class="col-md-3 col-xs-12 control-label">WHT</label>
             <div class="col-md-6 col-xs-12">
                  <select name="wht_tax" id="wht_tax" class="form-control">
                <option value="Taxable"  {if $smarty.post.wht_tax eq "Taxable" || $ec_data.wht_tax eq "Taxable"}selected{/if}>Taxable</option>
              <option value="Exempt"  {if $smarty.post.wht_tax eq "Exempt" || $ec_data.wht_tax eq "Exempt"}selected{/if}>Exempt</option>
         </select>
             </div>
         </div> *}
         <div class="form-group">
            <label class="col-md-3 col-xs-12 control-label">Remarks</label>
            <div class="col-md-6 col-xs-12">
               <textarea name="remarks" class="form-control" rows="4">{if $smarty.post.remarks}{$smarty.post.remarks}{else}{$ec_data.remarks}{/if}</textarea>
            </div>
        </div>
        <div class="form-group payout_field">
          <label class="col-md-3 col-xs-12 control-label">Attachment</label>
          <div class="col-md-6 col-xs-12">
            <input name="attachment" type="file" id="attachment" class="form-control" />
          </div>
        </div>

        </div>
        <div class="panel-footer">
            <input name="next_step" type="hidden" id="next_step" value="two" />
            <button type="submit" class="btn btn-primary pull-right">Continue</button>
        </div>
 </form>
