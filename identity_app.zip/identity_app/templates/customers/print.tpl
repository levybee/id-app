{if $privileges.customers.list}
 <div class="page-title">                    
    <h2>Customers List</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
       
         
        <div class="col-md-12" style="margin-bottom:10px;">
            {if $smarty.get.print}
			<div align="right">
			    <a href="/customers/list?popup=1&print=1" onClick="this.style.display = 'none'; window.print(); this.style.display = ''; return false;">
			        <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
			    </a>
			</div>
			{else}
			
			  <div align="center" style="margin-bottom:10px;"><a href="/customers">ALL</a> &nbsp; <a href="?page=1&filter=1&fstart=A">A</a> &nbsp; <a href="?page=1&filter=1&fstart=B">B</a> &nbsp; <a href="?page=1&filter=1&fstart=C">C</a> &nbsp; <a href="?page=1&filter=1&fstart=D">D</a> &nbsp; <a href="?page=1&filter=1&fstart=E">E</a> &nbsp; <a href="?page=1&filter=1&fstart=F">F</a> &nbsp; <a href="?page=1&filter=1&fstart=G">G</a> &nbsp; <a href="?page=1&filter=1&fstart=H">H</a> &nbsp; <a href="?page=1&filter=1&fstart=I">I</a> &nbsp; <a href="?page=1&filter=1&fstart=J">J</a> &nbsp; <a href="?page=1&filter=1&fstart=K">K</a> &nbsp; <a href="?page=1&filter=1&fstart=L">L</a> &nbsp; <a href="?page=1&filter=1&fstart=M">M</a> &nbsp; <a href="?page=1&filter=1&fstart=N">N</a> &nbsp; <a href="?page=1&filter=1&fstart=O">O</a> &nbsp; <a href="?page=1&filter=1&fstart=P">P</a> &nbsp; <a href="?page=1&filter=1&fstart=Q">Q</a> &nbsp; <a href="?page=1&filter=1&fstart=R">R</a> &nbsp; <a href="?page=1&filter=1&fstart=S">S</a> &nbsp; <a href="?page=1&filter=1&fstart=T">T</a> &nbsp; <a href="?page=1&filter=1&fstart=U">U</a> &nbsp; <a href="?page=1&filter=1&fstart=V">V</a> &nbsp; <a href="?page=1&filter=1&fstart=W">W</a> &nbsp; <a href="?page=1&filter=1&fstart=X">X</a> &nbsp; <a href="?page=1&filter=1&fstart=Y">Y</a> &nbsp; <a href="?page=1&filter=1&fstart=Z">Z</a></div>
		
			<br />
			 <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/customers/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/customers/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a> 
                         
                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">
                                                             
                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}
								  
								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}
								  
								    <option value="1" selected>Page 1</option>
								    
								    
								  {/section}
								
							     </select>
                            
                         </div>                                    
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                        
					         <a href="/customers/print?popup=1&print=1&page=*" onClick="popupURL(this.href, 'customersList', 800, 500); return false;">
					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />   	
					                </a>
					    
                         
                   </form>    
	        {/if}
		</div>
        <div class="panel panel-default">

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table print table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="20">#</th>
                                <th>Full Name</th>
							    <th>Telephone</th>
							    <th>Fax</th>
							    <th>Email Address</th>
							    <th>Mobile</th>
							    <th>Address</th>
							    <th>Location</th>
							    <th>Type</th>
							  
                            </tr>
                        </thead>
                        <tbody>   
                           {section name=customer_list loop=$customer_list}                                 
                            <tr>
                                
                                <td class="text-center">{$start+$smarty.section.users_list.rownum}</td>
                                <td>{$customer_list[customer_list].customer_fname} {$customer_list[customer_list].customer_lname}</td>
							    <td>{$customer_list[customer_list].customer_phone}</td>
							    <td>{$customer_list[customer_list].customer_fax}</td>
							    <td>{$customer_list[customer_list].customer_email}</td>
							    <td>{$customer_list[customer_list].customer_mobile}</td>
							    <td>{$customer_list[customer_list].customer_address}</td>
							    <td>{$customer_list[customer_list].customer_city}, {$customer_list[customer_list].customer_country}</td>
							    <td>{$customer_list[customer_list].customer_type}</td>
                             
                              
                            </tr>
                            {sectionelse}
                            <tr>
                                
                                <td colspan="9">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                        </tbody>
                    </table>
                </div>                                

            </div>
        </div>                                                      

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 
{/if}
