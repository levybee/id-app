 <!-- PAGE PLUGINS -->
        <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
        <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
        <script type="text/javascript" src="/js/plugins/star-rating/jquery.rating.js"></script>
        {literal}
        <script>
		        
		        
		         $(function(){
		             $('.auto-submit-star').rating({
		              callback: function(value, link){
		               
		               document.getElementById('group_rating').value = value;
		               
		               // To submit the form automatically:
		               //this.form.submit();
		               
		              }
		             });
		            });
		        
        
        </script>
        {/literal}
        
        
<!-- END PAGE PLUGINS --> 