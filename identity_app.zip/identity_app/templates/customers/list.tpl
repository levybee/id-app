
{if $privileges.customers.list}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Customers</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>Customers List</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
             
         
        <div class="col-md-12" style="margin-bottom:10px;">
          {if $privileges.customers.add}

           <a href="/customers/add{if $smarty.get.select}?select=1&popup=1{/if}" class="btn btn-default">Add a new customer</a>
         {/if}
		  <div align="center"><a href="/customers_group">ALL</a> &nbsp; <a href="?page=1&filter=1&fstart=A">A</a> &nbsp; <a href="?page=1&filter=1&fstart=B">B</a> &nbsp; <a href="?page=1&filter=1&fstart=C">C</a> &nbsp; <a href="?page=1&filter=1&fstart=D">D</a> &nbsp; <a href="?page=1&filter=1&fstart=E">E</a> &nbsp; <a href="?page=1&filter=1&fstart=F">F</a> &nbsp; <a href="?page=1&filter=1&fstart=G">G</a> &nbsp; <a href="?page=1&filter=1&fstart=H">H</a> &nbsp; <a href="?page=1&filter=1&fstart=I">I</a> &nbsp; <a href="?page=1&filter=1&fstart=J">J</a> &nbsp; <a href="?page=1&filter=1&fstart=K">K</a> &nbsp; <a href="?page=1&filter=1&fstart=L">L</a> &nbsp; <a href="?page=1&filter=1&fstart=M">M</a> &nbsp; <a href="?page=1&filter=1&fstart=N">N</a> &nbsp; <a href="?page=1&filter=1&fstart=O">O</a> &nbsp; <a href="?page=1&filter=1&fstart=P">P</a> &nbsp; <a href="?page=1&filter=1&fstart=Q">Q</a> &nbsp; <a href="?page=1&filter=1&fstart=R">R</a> &nbsp; <a href="?page=1&filter=1&fstart=S">S</a> &nbsp; <a href="?page=1&filter=1&fstart=T">T</a> &nbsp; <a href="?page=1&filter=1&fstart=U">U</a> &nbsp; <a href="?page=1&filter=1&fstart=V">V</a> &nbsp; <a href="?page=1&filter=1&fstart=W">W</a> &nbsp; <a href="?page=1&filter=1&fstart=X">X</a> &nbsp; <a href="?page=1&filter=1&fstart=Y">Y</a> &nbsp; <a href="?page=1&filter=1&fstart=Z">Z</a></div>
		</div>
        <div class="panel panel-default">
            
            <div class="panel-heading">
                 <h3 class="panel-title">Customers Table</h3> 
                  <ul class="panel-controls panel-controls-title">                                        
                     <li>
                     
                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/customers/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/customers/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a> 
                         
                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">
                                                             
                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}
								  
								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}
								  
								    <option value="1" selected>Page 1</option>
								    
								    
								  {/section}
								
							     </select>
                            
                         </div>                                    
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                          {if $role_data[0].role_is_admin eq 'Yes'}
					         <a href="/customers/print?popup=1&print=1&page=*" onClick="popupURL(this.href, 'customersList', 800, 500); return false;">
					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />   	
					                </a>
					        {/if}    
                         
                     </form>                      
                     </li>                                
                     
                 </ul>         
            </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">#</th>
                                <th>Company</th>
                                <th>Full Name</th>
							    <th>Telephone</th>
							    <th>Fax</th>
							    <th>Email Address</th>
							    <th>Mobile</th>
							    <th>Address</th>
							    <th>Location</th>
							    <th>Type</th>
							    <th width="120">Actions</th>
                            </tr>
                        </thead>
                        <tbody>   
                           {section name=customer_list loop=$customer_list}                                 
                            <tr>
                                
                                <td class="text-center">{$start+$smarty.section.customer_list.rownum}</td>
                                <td><a href="/customers_group/edit/?id={$customer_list[customer_list].group_id}">{$customer_list[customer_list].group_company}</a></td>
                                <td>{$customer_list[customer_list].customer_fname} {$customer_list[customer_list].customer_lname}</td>
							    <td>{$customer_list[customer_list].customer_phone}</td>
							    <td>{$customer_list[customer_list].customer_fax}</td>
							    <td><a href="mailto:{$customer_list[customer_list].customer_email}">{$customer_list[customer_list].customer_email}</a></td>
							    <td>{$customer_list[customer_list].customer_mobile}</td>
							    <td>{$customer_list[customer_list].customer_address}</td>
							    <td>{$customer_list[customer_list].customer_city}, {$customer_list[customer_list].customer_country}</td>
							    <td>{$customer_list[customer_list].customer_type}</td>
                             
                                <td style="padding:16px 8px">
                                    {if $smarty.request.select}
						            <a href="#" onclick='selectCustomer({$customer_list[customer_list].customer_id}, "{$customer_list[customer_list].group_company} - {$customer_list[customer_list].customer_fname} {$customer_list[customer_list].customer_lname}");'><img src="/images/success.png" alt="Select" width="16" height="16" border="0"></a>
						            {/if}
                                    <a title="edit" href="/customers/edit/?id={$customer_list[customer_list].customer_id}" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>
                                    <a title="delete" href="/customers/delete/?id={$customer_list[customer_list].customer_id}" class="btn btn-danger btn-rounded btn-condensed btn-sm"><span class="fa fa-times"></span></a>
                                
                                </td>
                            </tr>
                            {sectionelse}
                            <tr>
                                
                                <td colspan="10">
                                 <p>No records found.</p>
                                </td>
                            </tr>
                           {/section}
                        </tbody>
                    </table>
                </div>                                

            </div>
        </div>                                                      

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">
       
       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>
      
    </div>

  
</div>            
  
</div> 
{/if}