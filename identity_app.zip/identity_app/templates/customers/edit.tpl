{if $privileges.customers.edit || $privileges.customers.add}



<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/customers/list">Customers</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Customers</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

        {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Customers</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">



                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">First Name</label>
					    <div class="col-md-6 col-xs-12">
					       <input type="text" name="customer_fname" value="{if $smarty.post.customer_fname}{$smarty.post.customer_fname}{elseif $edit_customer[0].customer_fname}{$edit_customer[0].customer_fname}{/if}" class="form-control"/>


					    </div>
					</div>
					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Last Name</label>
					    <div class="col-md-6 col-xs-12">
					       <input type="text" name="customer_lname" value="{if $smarty.post.customer_lname}{$smarty.post.customer_lname}{elseif $edit_customer[0].customer_lname}{$edit_customer[0].customer_lname}{/if}" class="form-control"/>


					    </div>
					</div>


					 <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Company</label>
                         <div class="col-md-6 col-xs-12">
                             <select name="group_id" class="form-control select">
                                  {section name=customers_group loop=$customers_group}
							        	<option value="{$customers_group[customers_group].group_id}" {if $edit_customer[0].group_id eq $customers_group[customers_group].group_id}selected{/if}>{$customers_group[customers_group].group_company}</option>
							        {/section}
                             </select>

                         </div>
                     </div>


                     {* <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Tel</label>
					    <div class="col-md-6 col-xs-12">
					         <input type="text" name="customer_phone" value="{if $smarty.post.customer_phone}{$smarty.post.customer_phone}{elseif $edit_customer[0].customer_phone}{$edit_customer[0].customer_phone}{/if}" class="form-control"/>


					    </div>
					</div>
                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Fax</label>
					    <div class="col-md-6 col-xs-12">
					       <input type="text" name="customer_fax" value="{if $smarty.post.customer_fax}{$smarty.post.customer_fax}{elseif $edit_customer[0].customer_fax}{$edit_customer[0].customer_fax}{/if}" class="form-control"/>


					    </div>
					</div> *}
                    <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Mobile</label>
					    <div class="col-md-6 col-xs-12">
					        <input type="text" name="customer_mobile" value="{if $smarty.post.customer_mobile}{$smarty.post.customer_mobile}{elseif $edit_customer[0].customer_mobile}{$edit_customer[0].customer_mobile}{/if}" class="form-control"/>

					    </div>
					</div>
					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Email Address</label>
					    <div class="col-md-6 col-xs-12">
					         <input type="text" name="customer_email" value="{if $smarty.post.customer_email}{$smarty.post.customer_email}{elseif $edit_customer[0].customer_email}{$edit_customer[0].customer_email}{/if}" class="form-control"/>


					    </div>
					</div>
                    {* <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Address</label>
					    <div class="col-md-6 col-xs-12">
					       <input type="text" name="customer_address" value="{if $smarty.post.customer_address}{$smarty.post.customer_address}{elseif $edit_customer[0].customer_address}{$edit_customer[0].customer_address}{/if}" class="form-control"/>


					    </div>
					</div>
					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">City</label>
					    <div class="col-md-6 col-xs-12">
					         <input type="text" name="customer_city" value="{if $smarty.post.customer_city}{$smarty.post.customer_city}{elseif $edit_customer[0].customer_city}{$edit_customer[0].customer_city}{/if}" class="form-control"/>


					    </div>
					</div>

                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Country</label>
                         <div class="col-md-6 col-xs-12">
                             <select name="customer_country" class="form-control select">
						      {section name=countries loop=$countries}
						        	<option value="{$countries[countries]}" {if $edit_customer[0].customer_country eq $countries[countries]}selected{/if}{if !$edit_customer[0].customer_country && $config.default_country eq $countries[countries]}selected{/if}>{$countries[countries]}</option>
						        {/section}
						        </select>
                         </div>
                     </div> *}

                     {* <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">TIN</label>
					    <div class="col-md-6 col-xs-12">
					        <input type="text" name="customer_tin" value="{if $smarty.post.customer_tin}{$smarty.post.customer_tin}{elseif $edit_customer[0].customer_tin}{$edit_customer[0].customer_tin}{/if}" class="form-control"/>

					    </div>
					</div>

					<div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">VRN</label>
					    <div class="col-md-6 col-xs-12">
					        <input type="text" name="customer_vrn" value="{if $smarty.post.customer_vrn}{$smarty.post.customer_vrn}{elseif $edit_customer[0].customer_vrn}{$edit_customer[0].customer_vrn}{/if}" class="form-control"/>

					    </div>
					</div> *}

                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Customer</button>
                 </div>
             </div>
             </form>
             {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
 {/if}
