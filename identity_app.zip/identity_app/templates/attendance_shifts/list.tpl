{if $privileges.attendance_shifts.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Shifts</a></li>
     <li class="active"><a href="#">List</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Shifts</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}

             {if $privileges.attendance_shifts.add}

               <a href="/attendance_shifts/add" class="btn btn-default">New Shift</a>

               <br><br>

             {/if}
        <div class="panel panel-default">

            <div class="panel-heading">
                 <h3 class="panel-title">Shifts Table</h3>
                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                             <label>Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">

                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="50">#</th>
                                <th>Name</th>
                                <th>Start</th>
                                <th>End</th>
                                <th>Schedule Start</th>
                                <th>Schedule Close</th>
                                <th>Late Period</th>
                                <th width="120">actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=shift_list loop=$shift_list}
                            <tr>

                                <td class="text-center">{$start+$smarty.section.shift_list.rownum}</td>

                                <td>{$shift_list[shift_list].name}</td>
                                <td>{$shift_list[shift_list].start_time}</td>
                                <td>{$shift_list[shift_list].end_time}</td>
                                <td>{$shift_list[shift_list].schedule_start_time}</td>
                                <td>{$shift_list[shift_list].schedule_end_time}</td>
                                <td>{$shift_list[shift_list].late_time_period} Minutes</td>
                                <td>
                                    <a href="/attendance_shifts/edit/?id={$shift_list[shift_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm"><span class="fa fa-pencil"></span></a>
                                </td>
                            </tr>
                           {sectionelse}
						  <tr>
						    <td colspan="3">No Records Found</td>
						  </tr>
						  {/section}
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
