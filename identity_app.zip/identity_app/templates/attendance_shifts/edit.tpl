{if $privileges.attendance_shifts.edit || $privileges.attendance_shifts.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/attendance_shifts/list">Shifts</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Shift</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
        {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Shift</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">

                   <div class="row">

                         <div class="form-group">
                             <label class="col-md-3 col-xs-12 control-label">Shift Name</label>
                             <div class="col-md-6 col-xs-12">
                               <select name="name" class="form-control select" {if $action eq 'edit'}disabled{/if}>
                                    <option value="Day" {if $edit_shift[0].name eq 'Day'}selected{/if}>Day</option>
                                    <option value="Night" {if $edit_shift[0].name eq 'Night'}selected{/if}>Night</option>
                               </select>
                            </div>
                         </div>

                         <div class="form-group">
                            <label class="col-md-3 control-label">Start Time</label>
                            <div class="col-md-3 col-xs-12">
                                {html_select_time prefix="start_time_" display_seconds=false use_24_hours=true minute_interval=15 time=$edit_shift[0].start_time}
                            </div>

                            <div class="form-group col-md-6">
                               <label class="col-md-3 control-label">End Time</label>
                               <div class="col-md-6 col-xs-12">
                                   {html_select_time prefix="end_time_" display_seconds=false use_24_hours=true minute_interval=15 time=$edit_shift[0].end_time}
                               </div>
                            </div>

                         </div>

                         <div class="form-group">
                            <label class="col-md-3 control-label">Schedule Start Time</label>
                            <div class="col-md-3 col-xs-12">
                                {html_select_time prefix="sch_start_time_" display_seconds=false use_24_hours=true minute_interval=15 time=$edit_shift[0].schedule_start_time}
                            </div>

                            <div class="form-group col-md-6">
                               <label class="col-md-3 control-label">Schedule End Time</label>
                               <div class="col-md-6 col-xs-12">
                                   {html_select_time prefix="sch_end_time_" display_seconds=false use_24_hours=true minute_interval=15 time=$edit_shift[0].schedule_end_time}
                               </div>
                            </div>

                         </div>

                         <div class="form-group">
                            <label class="col-md-3 control-label">Late Time Period</label>
                            <div class="col-md-6 col-xs-12">
                                {html_select_time prefix="late_period_" display_seconds=false display_hours=false use_24_hours=true minute_interval=5 time=$edit_shift[0].late_time_period} Minutes
                            </div>
                         </div>

                  </div>
                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Shift</button>
                 </div>
             </div>
             </form>
             {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{/if}
