{if $privileges.pending_approvals.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Dashboard</a></li>
     <li class="active"><a href="">Pending Approvals</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Pending Approvals</h2>
</div>

 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">

   <div class="col-md-12">
     {if $message || $msg}
     <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
         <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
         {$message}
         {$msg}
     </div>
     {/if}
   </div>

   <div class="col-md-12">

     <div class="panel panel-default">
         <div class="panel-heading">
             <h3 class="panel-title lpo_title">LPOs</h3>
             <a href=""  class="btn btn-success approve_lpos_btn" style="display:none;">Approve Selected</a>&nbsp;&nbsp;
             <a href=""  class="btn btn-warning cancel_lpos_btn" style="display:none;">Cancel Selected</a>
         </div>

         <div class="panel-body panel-body-table">
             <form id="lpo_form" method="post" action="">
                 <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
             <div class="table-responsive">
                 <table class="table pad-10 table-bordered table-striped table-actions">
                     <thead>
                         <tr>
                             <th width="40"> <input type="checkbox" id="approve_lpos_check"/></th>
                             <th>Ref #</th>
                             <th>Date</th>
                             <th width="20%">Supplier</th>
                             {* <th>Payment Type</th> *}
                             <th>Destination</th>
                             <th>Items #</th>
                             <th>Comments</th>
               {* <th>Delivery Qty</th> *}
               {* <th>Items Description</th>
               <th>Amount</th> *}
                             <th>User</th>

                            <th width="50" style="padding:16px 20px !important;">Actions</th>

                         </tr>
                     </thead>
                     <tbody>
                        {section name=lpo_list loop=$lpo_list}
                       <tr>
                          <td class="text-center">
                               <input type="checkbox" name="confirmed_check[]" class="lpos_check" value="{$lpo_list[lpo_list].lpo_info.lpo_id}" />
                         </td>

                         <td>LPO-{$lpo_list[lpo_list].lpo_info.lpo_date|substr:0:4}-{$lpo_list[lpo_list].lpo_info.lpo_id|leading_zero:5}</td>
                         <td>{$lpo_list[lpo_list].lpo_info.lpo_date|date_format:"%d %b %Y"} {if $lpo_list[lpo_list].lpo_info.date_created}<br />({$lpo_list[lpo_list].lpo_info.date_created|date_format:"%H:%M:%S"}){/if}</td>
                         <td>{if $lpo_list[lpo_list].lpo_info.supplier_id eq 0 || $lpo_list[lpo_list].lpo_info.supplier_id eq ''}{$lpo_list[lpo_list].lpo_info.supplier}{else}{$lpo_list[lpo_list].lpo_info.supplier_company} - {$lpo_list[lpo_list].lpo_info.supplier_fname} {$lpo_list[lpo_list].lpo_info.supplier_lname}{/if}</td>
                         {* <td>{$lpo_list[lpo_list].lpo_info.payment_type}</td> *}
                         <td>{$lpo_list[lpo_list].lpo_info.lpo_destination}</td>
                         <td>{$lpo_list[lpo_list].lpo_info.lpo_items_num}</td>
                         <td>{$lpo_list[lpo_list].lpo_info.comments}</td>
             {*<td>{if $lpo_list[lpo_list].lpo_info.qty_remaining gt 0 && $lpo_list[lpo_list].lpo_info.lpo_status eq 'Approved'}{$lpo_list[lpo_list].lpo_info.qty_remaining}{else}-{/if}</td>*}
             {* <td>{$lpo_list[lpo_list].lpo_info.items_description}</td>
             <td>{$lpo_list[lpo_list].lpo_info.lpo_amount|number_format:0:".":","} {$lpo_list[lpo_list].lpo_info.lpo_currency}</td> *}
             {* <td class="text-center">
             <a href="/{$config.attachment_dir}{$lpo_list[lpo_list].lpo_info.attachment}" target = "_blank">{if $lpo_list[lpo_list].lpo_info.attachment}{$lpo_list[lpo_list].lpo_info.attachment}{else}-{/if}</a>
            </td> *}

                         <td>{$lpo_list[lpo_list].lpo_info.user_fname} {$lpo_list[lpo_list].lpo_info.user_lname}</td>

                         <td style="padding:20px 5px">

                           <a target="_blank" class="btn btn-warning btn-rounded btn-condensed btn-sm" title="Approve" href="/lpo/approve/?id={$lpo_list[lpo_list].lpo_info.lpo_id}" ><span class="fa fa-check"></span></a>
                           <a target="_blank" class="btn btn-default btn-rounded btn-condensed btn-sm"
               data-lpo_id="{$lpo_list[lpo_list].lpo_info.lpo_id}"
               title="Cancel lpo" href="/lpo/cancel/?id={$lpo_list[lpo_list].lpo_info.lpo_id}"
               onclick="return false;"><span class="fa fa-times"></span></a>
                           <a target="_blank" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit lpo" href="/lpo/edit/?id={$lpo_list[lpo_list].lpo_info.lpo_id}"><span class="fa fa-pencil"></span></a>

                          </td>

                       </tr>
                       {sectionelse}
                       <tr>
                         <td colspan="9"><div align="center">No records found.</td>
                       </tr>
                       {/section}
                     </tbody>
                 </table>


             </div>
             </form>
         </div>

     </div>

 </div>
</div>

<div class="col-md-12">

  <div class="panel panel-default">

      <div class="panel-heading">
        <h3 class="panel-title transfers_title">Transfers</h3>
        <a href=""  class="btn btn-success approve_transfers_btn" style="display:none;">Approve Selected</a>&nbsp;&nbsp;
        <a href=""  class="btn btn-warning cancel_transfers_btn" style="display:none;">Cancel Selected</a>

      </div>




      <div class="panel-body panel-body-table">

          <form method="post" action="">
              <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
          <div class="table-responsive">
              <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                  <thead>
                      <tr>

                            <th width="40" class="text-center">
                                <input type="checkbox" id="approve_transfers_check"/></th>
                         <th class="text-center">Reference</th>
                         <th class="text-center">Date</th>
                         <th class="text-center">Type</th>
                         <th class="text-center">LPO #</th>
                         <th class="text-center">Expense Type</th>
                         <th class="text-center">Net Amount</th>
                         <th class="text-center">Tax Amount</th>
                         <th class="text-center">WHT Amount</th>
                         <th class="text-center">Job Reference</th>
                         <th class="text-center">Issued To</th>
                         <th class="text-center">Remarks</th>
                         <th class="text-center">User</th>
                          <th class="text-center">Action</th>
                      </tr>
                  </thead>
                  <tbody>
                     {section name=transfers loop=$transfers}
        <tr>
             <td class="text-center">
              <input type="checkbox" name="approved_check[]" class="transfers_check" value="{$transfers[transfers].id}" />
            </td>

          <td class="text-center">{if $transfers[transfers].reference}{$transfers[transfers].reference|leading_zero:5}{else}-{/if}</td>

          <td class="text-center">{$transfers[transfers].date_created|date_format:"%d %b %Y"} <br>  ({$transfers[transfers].date_created|date_format:"%H:%M:%S"})</td>
          <td class="text-center">
           {$transfers[transfers].type}
           {if $transfers[transfers].type == 'Supplier'}
           <br><i>{$transfers[transfers].supplier_name}</i>
           {/if}
          </td>
          <td class="text-center">
          {if $transfers[transfers].lpo_id}<a title="View LPO" href="#" onclick="popupPDF('lpo', {if $transfers[transfers].lpo_id}{$transfers[transfers].lpo_id}{else}0{/if});" >{$transfers[transfers].lpo_id}</a> - {$transfers[transfers].supplier_company}
           <br><strong>Amount Paid:</strong> {$transfers[transfers].amount_paid|number_format:0:".":","} TZS<br>
           <strong>Total Balance:</strong> {$transfers[transfers].lpo_balance|number_format:0:".":","} TZS
           {else}
            {if $transfers[transfers].items[0].lpo_id > 0}
              <br><strong>Amount Paid:</strong> {$transfers[transfers].lpos_amount_paid|number_format:0:".":","} TZS<br>
              <strong>Total Balance:</strong> {$transfers[transfers].lpos_balance|number_format:0:".":","} TZS
              {else}
                -
              {/if}
          {/if}
        </td>
          <td class="text-center">
           {$transfers[transfers].expense_name}
          </td>
          {assign var=net_amount value=$transfers[transfers].net_amount-$transfers[transfers].wht_amount}
          <td class="text-center">{$net_amount|number_format:0:".":","} TZS </td>
          <td class="text-center">{if $transfers[transfers].tax_amount > 0}{$transfers[transfers].tax_amount|number_format:0:".":","} TZS {else}-{/if}</td>
          <td class="text-center">{if $transfers[transfers].wht_amount > 0}{$transfers[transfers].wht_amount|number_format:0:".":","} TZS{else}-{/if} </td>
          <td class="text-center">{if $transfers[transfers].job_id}<a style="text-decoration:none;" href="/jobs/progress?id={$transfers[transfers].job_id}" target="_blank">{$transfers[transfers].job_id}: </a>{$transfers[transfers].job_reference} - {$transfers[transfers].group_company}
          {else}
          {if $transfers[transfers].job_id_lpo}<a style="text-decoration:none;" href="/jobs/progress?id={$transfers[transfers].job_id_lpo}" target="_blank">{$transfers[transfers].job_id_lpo}: </a>{$transfers[transfers].job_reference_lpo} - {$transfers[transfers].group_company_lpo}{/if}
          {/if}</td>
          <td class="text-center">{if $transfers[transfers].status eq 'Issued'}{$transfers[transfers].employee_name}{else}-{/if}</td>

          <td class="text-center">{$transfers[transfers].remarks}</td>

          {* <td class="text-center"><span class="{if $transfers[transfers].status eq 'Pending'}text-danger{elseif $transfers[transfers].status eq 'Approved'}text-default{else}text-success{/if}">{$transfers[transfers].status} {if $transfers[transfers].status eq 'Closed' && $transfers[transfers].issued_to} - Issued to {$transfers[transfers].issued_to}{/if}{if $transfers[transfers].status eq 'Approved'} <br><i>by {$transfers[transfers].approval_user}</i>{/if}</span></td> *}
          <td class="text-center">{$transfers[transfers].user}</td>
          <td class="text-center">
             {if $privileges.petty_cash_mobile.approve}
             <a target="_blank" href="/petty_cash_mobile/list?actn=approve&id={$transfers[transfers].id}" class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Bank Transfer Record] Are you sure?', this.href); return false;" ><span class="fa fa-check"></span></a>
             {/if}
             <a target="_blank" href="/petty_cash_mobile/list?actn=cancel&id={$transfers[transfers].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Cancel" onclick="confirmAction('[Cancel Bank Transfer Record] Are you sure?', this.href); return false;" ><span class="fa fa-times"></span></a>
             <a target="_blank" href="/petty_cash_mobile/edit/?id={$transfers[transfers].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>


          </td>
        </tr>
        {if $transfers[transfers].items[0]}
       <tr>
         <td colspan="15">
            <table width="100%">
              <tr>
                <th>&nbsp;</th>
                <th>
                  {if $transfers[transfers].items[0].lpo_id > 0}
                  LPO
                  {else}
                  GRN
                  {/if}
                </th>
                <th>Date</th>
                <th>Invoice No</th>
                <th>Amount</th>
                <th>Amount Paid</th>
                <th>&nbsp;</th>
              </tr>
              {section name=items loop=$transfers[transfers].items}
              <tr>
               <td>&nbsp;</td>
                <td>
                  {if $transfers[transfers].items[0].lpo_id > 0}
                  <a title="View LPO" href="#" onclick="popupPDF('lpo', {$transfers[transfers].items[items].lpo_id});">
                   LPO-{$transfers[transfers].items[items].lpo_date|substr:0:4}-{$transfers[transfers].items[items].lpo_id|leading_zero:5}
                 </a>
                  {/if}
                  {if $transfers[transfers].items[0].grn_id > 0}
                  <a title="View GRN" href="#" onclick="popupPDF('grn', {$transfers[transfers].items[items].grn_id});" >
                  GRN-{$transfers[transfers].items[items].grn_date|substr:0:4}-{$transfers[transfers].items[items].grn_id|leading_zero:5}
                  </a>
                  {/if}
                </td>
                <td>{if $transfers[transfers].items[items].grn_date}{$transfers[transfers].items[items].grn_date|date_format:"%d %b %Y"}{else}{$transfers[transfers].items[items].lpo_date|date_format:"%d %b %Y"}{/if}</td>
                <td>{if $transfers[transfers].items[items].invoice_no}{$transfers[transfers].items[items].invoice_no}{else}-{/if}</td>
                <td>
                  {if $transfers[transfers].items[0].lpo_id > 0}
                  {$transfers[transfers].items[items].lpo_amount|number_format:2:".":","}
                  {else}
                  {$transfers[transfers].items[items].grn_amount|number_format:2:".":","}
                  {/if}
                </td>
                <td>
                {if $transfers[transfers].items[0].lpo_id > 0}
                {$transfers[transfers].items[items].amount_paid|number_format:2:".":","}
                {else}
                 {$transfers[transfers].items[items].grn_amount_paid|number_format:2:".":","}
                {/if}
                </td>
                <td>&nbsp;</td>
              </tr>
              {/section}
            </table>
         </td>
       </tr>
       {/if}
       <tr>
         <td colspan="15" style="padding:1px 0 !important; background:#ccc;"></td>
       </tr>
        {sectionelse}
        <tr>
          <td colspan="15">No records found.</td>
        </tr>
        {/section}
                  </tbody>
              </table>

          </div>
          </form>

      </div>

  </div>

</div>

<div class="col-md-12">

  <div class="panel panel-default">

      <div class="panel-heading">
        <h3 class="panel-title pc_title">Petty Cash</h3>
        <a href=""  class="btn btn-success approve_pc_btn" style="display:none;">Approve Selected</a>&nbsp;&nbsp;
        <a href=""  class="btn btn-warning cancel_pc_btn" style="display:none;">Cancel Selected</a>

      </div>
      <div class="panel-body panel-body-table">

          <form method="post" action="">
              <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
          <div class="table-responsive">
              <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                  <thead>
                      <tr>

                            <th width="40" class="text-center">
                                <input type="checkbox" id="approve_pc_check"/></th>
                         <th class="text-center">Reference</th>
                         <th class="text-center">Date</th>
                         <th class="text-center">Type</th>
                         <th class="text-center">LPO #</th>
                         <th class="text-center">Expense Type</th>
                         <th class="text-center">Net Amount</th>
                         <th class="text-center">Tax Amount</th>
                         <th class="text-center">WHT Amount</th>
                         <th class="text-center">Job Reference</th>
                         <th class="text-center">Issued To</th>
                         <th class="text-center">Remarks</th>
                         <th class="text-center">User</th>
                          <th class="text-center">Action</th>
                      </tr>
                  </thead>
                  <tbody>
                     {section name=pc_list loop=$pc_list}
        <tr>
           <td class="text-center">
              <input type="checkbox" name="approved_check[]" class="pc_check" value="{$pc_list[pc_list].id}" />
            </td>
          <td class="text-center">{if $pc_list[pc_list].reference}{$pc_list[pc_list].reference|leading_zero:5}{else}-{/if}</td>

          <td class="text-center">{$pc_list[pc_list].date_created|date_format:"%d %b %Y"} <br>  ({$pc_list[pc_list].date_created|date_format:"%H:%M:%S"})</td>
          <td class="text-center">
           {$pc_list[pc_list].type}
           {if $pc_list[pc_list].type == 'Supplier'}
           <br><i>{$pc_list[pc_list].supplier_name}</i>
           {/if}
          </td>
          <td class="text-center">
          {if $pc_list[pc_list].lpo_id}<a title="View LPO" href="#" onclick="popupPDF('lpo', {if $pc_list[pc_list].lpo_id}{$pc_list[pc_list].lpo_id}{else}0{/if});" >{$pc_list[pc_list].lpo_id}</a> - {$pc_list[pc_list].supplier_company}
            {if !$pc_list[pc_list].supplier_id}
            <br><strong>Amount Paid:</strong> {$pc_list[pc_list].amount_paid|number_format:0:".":","} TZS<br>
            <strong>Total Balance:</strong> {$pc_list[pc_list].lpo_balance|number_format:0:".":","} TZS
            {/if}
          {else}
            {if $pc_list[pc_list].items[0].lpo_id > 0}
            <br><strong>Amount Paid:</strong> {$pc_list[pc_list].lpos_amount_paid|number_format:0:".":","} TZS<br>
            <strong>Total Balance:</strong> {$pc_list[pc_list].lpos_balance|number_format:0:".":","} TZS
            {else}
              -
            {/if}
          {/if}
        </td>
          <td class="text-center">
           {if $pc_list[pc_list].expense_name}{$pc_list[pc_list].expense_name}{else}-{/if}
          </td>
          {assign var=net_amount value=$pc_list[pc_list].net_amount-$pc_list[pc_list].wht_amount}
          <td class="text-center">{$net_amount|number_format:0:".":","} TZS </td>
          <td class="text-center">{if $pc_list[pc_list].tax_amount > 0}{$pc_list[pc_list].tax_amount|number_format:0:".":","} TZS{else}-{/if}</td>


          <td class="text-center">{if $pc_list[pc_list].wht_amount > 0}{$pc_list[pc_list].wht_amount|number_format:0:".":","} TZS{else}-{/if} </td>
          <td class="text-center">{if $pc_list[pc_list].job_id}<a style="text-decoration:none;" href="/jobs/progress?id={$pc_list[pc_list].job_id}" target="_blank">{$pc_list[pc_list].job_id}: </a>{$pc_list[pc_list].job_reference} - {$pc_list[pc_list].group_company}
          {else}
            {if $pc_list[pc_list].job_id_lpo}<a style="text-decoration:none;" href="/jobs/progress?id={$pc_list[pc_list].job_id_lpo}" target="_blank">{$pc_list[pc_list].job_id_lpo}: </a>{$pc_list[pc_list].job_reference_lpo} - {$pc_list[pc_list].group_company_lpo}{/if}
            {/if}</td>
          <td class="text-center">{if $pc_list[pc_list].status eq 'Issued'}{$pc_list[pc_list].employee_name}{else}-{/if}</td>

          <td class="text-center">{$pc_list[pc_list].remarks}</td>
          {* <td class="text-center"><span class="{if $pc_list[pc_list].status eq 'Pending'}text-danger{elseif $pc_list[pc_list].status eq 'Approved'}text-default{else}text-success{/if}">{$pc_list[pc_list].status} {if $pc_list[pc_list].status eq 'Closed' && $pc_list[pc_list].issued_to} - Issued to {$pc_list[pc_list].issued_to}{/if}{if $pc_list[pc_list].status eq 'Approved'} <br><i>by {$pc_list[pc_list].approval_user}</i>{/if}</span></td> *}
          <td class="text-center">{$pc_list[pc_list].user}</td>
          <td class="text-center">

             <a target="_blank" href="/petty_cash/list?actn=approve&id={$pc_list[pc_list].id}" class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Petty Cash Record] Are you sure?', this.href); return false;" ><span class="fa fa-check"></span></a>
             <a target="_blank" href="/petty_cash/list?actn=cancel&id={$pc_list[pc_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Cancel" onclick="confirmAction('[Cancel Petty Cash Record] Are you sure?', this.href); return false;" ><span class="fa fa-times"></span></a>
             <a target="_blank" href="/petty_cash/edit/?id={$pc_list[pc_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
          </td>
        </tr>
         {if $pc_list[pc_list].items[0]}
        <tr>
          <td colspan="15">
             <table width="100%">
               <tr>
                 <th>&nbsp;</th>
                 <th>
                   {if $pc_list[pc_list].items[0].lpo_id > 0}
                   LPO
                   {else}
                   GRN
                   {/if}
                 </th>
                 <th>Date</th>
                 <th>Invoice No</th>
                 <th>Amount</th>
                 <th>Amount Paid</th>
                 <th>&nbsp;</th>
               </tr>
               {section name=items loop=$pc_list[pc_list].items}
               <tr>
                <td>&nbsp;</td>
                 <td>
                   {if $pc_list[pc_list].items[0].lpo_id > 0}
                   <a title="View LPO" href="#" onclick="popupPDF('lpo', {$pc_list[pc_list].items[items].lpo_id});">
                    LPO-{$pc_list[pc_list].items[items].lpo_date|substr:0:4}-{$pc_list[pc_list].items[items].lpo_id|leading_zero:5}
                  </a>
                   {/if}
                   {if $pc_list[pc_list].items[0].grn_id > 0}
                   <a title="View GRN" href="#" onclick="popupPDF('grn', {$pc_list[pc_list].items[items].grn_id});" >
                   GRN-{$pc_list[pc_list].items[items].grn_date|substr:0:4}-{$pc_list[pc_list].items[items].grn_id|leading_zero:5}
                   </a>
                   {/if}
                 </td>
                 <td>{if $pc_list[pc_list].items[items].grn_date}{$pc_list[pc_list].items[items].grn_date|date_format:"%d %b %Y"}{else}{$pc_list[pc_list].items[items].lpo_date|date_format:"%d %b %Y"}{/if}</td>
                 <td>{if $pc_list[pc_list].items[items].invoice_no}{$pc_list[pc_list].items[items].invoice_no}{else}-{/if}</td>
                 <td>
                   {if $pc_list[pc_list].items[0].lpo_id > 0}
                   {$pc_list[pc_list].items[items].lpo_amount|number_format:2:".":","}
                   {else}
                   {$pc_list[pc_list].items[items].grn_amount|number_format:2:".":","}
                   {/if}
                 </td>
                 <td>
                 {if $pc_list[pc_list].items[0].lpo_id > 0}
                  {$pc_list[pc_list].items[items].amount_paid|number_format:2:".":","}
                  {else}
                   {$pc_list[pc_list].items[items].grn_amount_paid|number_format:2:".":","}
                  {/if}
                 </td>
                 <td>&nbsp;</td>
               </tr>
               {/section}
             </table>
          </td>
        </tr>
        {/if}
        <tr>
          <td colspan="15" style="padding:1px 0 !important; background:#ccc;"></td>
        </tr>
        {sectionelse}
        <tr>
          <td colspan="15">No records found.</td>
        </tr>
        {/section}
         </tbody>
        </table>
      </div>
      </form>
    </div>
  </div>

</div>

    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
               <h3 class="panel-title dn_title">Delivery Notes</h3>
               <a href=""  class="btn btn-success approve_dn_btn" style="display:none;">Approve Selected</a>&nbsp;&nbsp;
               <a href=""  class="btn btn-warning cancel_dn_btn" style="display:none;">Cancel Selected</a>
            </div>
            <div class="panel-body panel-body-table">
             <form method="post" action="" id="subm">
              {if $privileges.deliveries.approve}
               <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
              {/if}
                <div class="table-responsive">

                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40" class="text-center"><input type="checkbox" id="approve_dn_check"/></th>
                                <th>Job #</th>
                                <th>Ref #</th>
							    <th>Date</th>
							    <th>Customer</th>
							    <th>Items #</th>

							    <th>User</th>
							    <th width="50">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=delivery_list loop=$delivery_list}
						  <tr>

                              <td class="text-center">
                                  <input type="checkbox" name="confirmed_check[]" class="dn_check" value="{$delivery_list[delivery_list].delivery_info.dn_id}" /></td>

                                <td class="text-center"><a title="View Job" href="/jobs/progress?id={$delivery_list[delivery_list].delivery_info.job_id}"  alt="View Job">{$delivery_list[delivery_list].delivery_info.job_id}</a></td>

                              <td><a title="View Delivery" href="/deliveries/view/?id={$delivery_list[delivery_list].delivery_info.dn_id}"  alt="View Delivery">{$delivery_list[delivery_list].delivery_info.dn_date_created|substr:0:4}-{$delivery_list[delivery_list].delivery_info.dn_date_created|substr:5:2}-{$delivery_list[delivery_list].delivery_info.dn_id|leading_zero:5}</a></td>

                						    <td>{$delivery_list[delivery_list].delivery_info.dn_date_created|date_format:"%d %B %Y"}</td>

                						    <td>{if $delivery_list[delivery_list].delivery_info.customer_id eq 0}{$delivery_list[delivery_list].delivery_info.delivery_customer}{else}{$delivery_list[delivery_list].delivery_info.group_company} - {$delivery_list[delivery_list].delivery_info.customer_fname} {$delivery_list[delivery_list].delivery_info.customer_lname}{/if}</td>
                						    <td class="text-center">{$delivery_list[delivery_list].delivery_items_num}</td>
                						    <td>{$delivery_list[delivery_list].delivery_info.user_fname} {$delivery_list[delivery_list].delivery_info.user_lname}</td>
                						    {if !$smarty.get.print}
                						    <td class="text-center">
                                <a title="View Delivery" target="_blank" href="/deliveries/view/?id={$delivery_list[delivery_list].delivery_info.dn_id}&jid={$delivery_list[delivery_list].delivery_info.job_id}"  alt="View Delivery" width="16" height="16" border="0" class="btn btn-success btn-flat btn-rad">View</a>
                                </td>
						    {/if}
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="12"><div align="center">No records found.</td>
						  </tr>
						 {/section}
                        </tbody>
                    </table>
                </div>
              </form>

            </div>

        </div>

    </div>
 </div>

<div class="col-md-12">

  <div class="panel panel-default">

      <div class="panel-heading">

          <h3 class="panel-title req_title">Requisitions</h3>

          <a href=""  class="btn btn-success approve_req_btn" style="display:none;">Approve Selected</a>&nbsp;&nbsp;
          <a href=""  class="btn btn-warning cancel_req_btn" style="display:none;">Cancel Selected</a>

      </div>
      <div class="panel-body panel-body-table">

        <form id="requisition_form" method="post" action="">

            <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
            <input type="submit" name="cancel_selected" id="cancel_selected" class="hidden" />


          <div class="table-responsive">

              <table class="table pad-10 table-bordered table-striped table-actions">
                  <thead>
                      <tr>

                        <th width="40" class="text-center">
                      <input type="checkbox" id="approve_req_check"/></th>


            <th width="40">ID</th>
            <th class="text-center">Date</th>
            <th>Job Reference</th>
            <th class="text-center">Department</th>
            <th class="text-center">User</th>
            {if !$smarty.get.print}
             <th class="text-center" width="15%">Action</th>
             {/if}
                      </tr>
                  </thead>
                  <tbody>
                     {section name=req_list loop=$requisition_list}
        <tr>


             <td class="text-center">
              <input type="checkbox" name="confirmed_check[]" class="req_check" value="{$requisition_list[req_list].requisition_id}" />
            </td>

          <td class="text-center">{$requisition_list[req_list].requisition_id|leading_zero:5}</td>
          <td class="text-center">
          {$requisition_list[req_list].date_created|date_format:"%d/%m/%Y"}
          <br>{$requisition_list[req_list].date_created|date_format:"%H:%M:%S"}
        </td>

        <td>
          {if $requisition_list[req_list].job_id}<a style="text-decoration:none;" href="/jobs/progress?id={$requisition_list[req_list].job_id}" target="_blank">
          {$requisition_list[req_list].job_id}: </a>{$requisition_list[req_list].job_reference} - {$requisition_list[req_list].group_company}{else}-{/if}
          {if $requisition_list[req_list].requisition_remarks} <p style="width:30em; text-overflow: ellipsis; overflow:hidden; white-space: nowrap;"><a style="text-decoration:none;" href="#" title="{$requisition_list[req_list].requisition_remarks}">{$requisition_list[req_list].requisition_remarks}</a></p> {/if}
        </td>
          <td class="text-center">
            {if $requisition_list[req_list].department_name}{$requisition_list[req_list].department_name}{else}-{/if}
            <br>{$requisition_list[req_list].requisition_location}
          </td>

          <td class="text-center">{$requisition_list[req_list].user}</td>
          {if !$smarty.get.print}
          <td class="text-center">

            <a href="/pendings/list?actn=approve_req&id={$requisition_list[req_list].requisition_id}" class="btn btn-success btn-rounded btn-condensed btn-sm" title="Approve" onclick="confirmAction('[Approve Requisition] Are you sure?', this.href); return false;" ><span class="fa fa-check"></span></a>

             {if !$requisition_list[req_list].ris_id}
             <a target="_blank" href="/requisition/edit?id={$requisition_list[req_list].requisition_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
             <a class="btn btn-default btn-rounded btn-condensed btn-sm cancelReq"
             data-requisition_id="{$requisition_list[req_list].requisition_id}"
             title="Cancel Requisition" href="/requisition/list?actn=cancel_req&id={$requisition_list[req_list].requisition_id}"
             onclick="return false;"><span class="fa fa-times"></span></a>
             {/if}

          </td>
          {/if}

        </tr>
        {assign var=items value=$requisition_list[req_list].items}
        <tr>
          <td colspan="7" style="padding:0 !important;">
             <table width="100%" class="table pad-5 table-striped">
               <tr>
                 <th>Item</th>
                 <th>Required Qty</th>
                 <th>Issued Qty</th>
                 <th>Balance Qty</th>
                 <th>Qty in Stock</th>
                 <th>Qty Ordered</th>
                 <th width="13%"></th>
               </tr>
               {section name=items loop=$items}
               <tr>
                <td
                 {if $items[items].item_description && $items[items].stock_id > 0} <p style="width:18em; text-overflow: ellipsis; overflow:hidden; white-space: nowrap;"><a style="text-decoration:none;" href="#" title="{$items[items].item_description}">{$items[items].item_description}</a></p> {/if}
                </td>
                <td>

                 {$items[items].quantity} {$items[items].units}

                </td>
                 <td>{if $items[items].issued_qty > 0}{$items[items].issued_qty} {$items[items].units}{else}-{/if}</td>
                 <td>{$items[items].balance_qty} {$items[items].units}</td>
                 <td>{$items[items].stock_qty} {$items[items].units}</td>
                 <td>
                   {if $items[items].qty_ordered > 0}
                  {$items[items].qty_ordered} {$items[items].units}
                  {if $items[items].lpo}<br><a title="View lpo" href="#" onclick="popupPDF('lpo', {$items[items].lpo});" >LPO #{$items[items].lpo}</a>{/if}
                  {else}
                   -
                  {/if}
                 </td>
                 <td>
                 </td>
               </tr>

                {sectionelse}
                <tr>
                  <td colspan="5">No items found</td>
                </tr>
               {/section}


             </table>
          </td>
        </tr>
        <tr>
          <td colspan="7" style="padding:1px 0 !important; background:#ccc;"></td>
        </tr>
        {sectionelse}
        <tr>
          <td colspan="7"><div align="center">No records found.</td>
        </tr>
       {/section}
                  </tbody>
                </table>

            </div>
            </form>


        </div>

        <div class="panel-heading">

        </div>


    </div>



</div>



</div>

</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">
       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>
    </div>
</div>
</div>
{/if}
