<!-- PAGE PLUGINS -->
<script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/js/jquery/jquery.livequery.min.js"></script>
<script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>
<!--  <script type="text/javascript" src="/js/plugins/smartwizard/jquery.smartWizard-2.0.min.js"></script>
<script type="text/javascript" src="/js/plugins/jquery-validation/jquery.validate.js"></script> -->

<!-- END PAGE PLUGINS -->

{literal}

<script type="text/javascript">

// LPOS approve checkboxes
$("#approve_lpos_check").on('change',function () {
    $(".lpos_check").prop('checked', $(this).prop("checked"));
    if($('.lpos_check:checked').length > 0){
      $('.approve_lpos_btn').show();
      $('.cancel_lpos_btn').show();
      $('.lpo_title').hide();
      approve_multi_lpos_uri();
    }else{
      $('.approve_lpos_btn').hide();
      $('.cancel_lpos_btn').hide();
      $('.lpo_title').show();
    }

});

$('.lpos_check').on('change', function($index){

  console.log($(this).val());
  if($('.lpos_check:checked').length > 0){
    $('.approve_lpos_btn').show();
    $('.cancel_lpos_btn').show();
    $('.lpo_title').hide();
    approve_multi_lpos_uri();
  }else{
    $('.approve_lpos_btn').hide();
    $('.cancel_lpos_btn').hide();
    $('.lpo_title').show();
  }

});

approve_multi_lpos_uri = function(){

  let lpoApproveUri = "/pendings/list?multi_approve_lpos=1";
  let lpoCancelUri = "/pendings/list?cancel_lpo=1";
  $('.lpos_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      lpoApproveUri += `&id[]=${id}`;
      lpoCancelUri += `&id[]=${id}`;
    }

  });

  $('.approve_lpos_btn').attr('href', lpoApproveUri);
  $('.cancel_lpos_btn').attr('href', lpoCancelUri);

}

// Transfers approve checkboxes
$("#approve_transfers_check").on('change',function () {
    $(".transfers_check").prop('checked', $(this).prop("checked"));
    if($('.transfers_check:checked').length > 0){
      $('.approve_transfers_btn').show();
      $('.cancel_transfers_btn').show();
      $('.transfers_title').hide();
      approve_multi_transfers_uri();
    }else{
      $('.approve_transfers_btn').hide();
      $('.cancel_transfers_btn').hide();
      $('.transfers_title').show();
    }

});

$('.transfers_check').on('change', function($index){

  console.log($(this).val());
  if($('.transfers_check:checked').length > 0){
    $('.approve_transfers_btn').show();
    $('.cancel_transfers_btn').show();
    $('.transfers_title').hide();
    approve_multi_transfers_uri();
  }else{
    $('.approve_transfers_btn').hide();
    $('.cancel_transfers_btn').hide();
    $('.transfers_title').show();
  }

});

approve_multi_transfers_uri = function(){

  let lpoApproveUri = "/pendings/list?multi_approve_transfers=1";
  let lpoCancelUri = "/pendings/list?cancel_transfer=1";
  $('.transfers_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      lpoApproveUri += `&id[]=${id}`;
      lpoCancelUri += `&id[]=${id}`;
    }

  });

  $('.approve_transfers_btn').attr('href', lpoApproveUri);
  $('.cancel_transfers_btn').attr('href', lpoCancelUri);

}


// PC approve checkboxes
$("#approve_pc_check").on('change',function () {
    $(".pc_check").prop('checked', $(this).prop("checked"));
    if($('.pc_check:checked').length > 0){
      $('.approve_pc_btn').show();
      $('.cancel_pc_btn').show();
      $('.pc_title').hide();
      approve_multi_pc_uri();
    }else{
      $('.approve_pc_btn').hide();
      $('.cancel_pc_btn').hide();
      $('.pc_title').show();
    }

});

$('.pc_check').on('change', function($index){

  console.log($(this).val());
  if($('.pc_check:checked').length > 0){
    $('.approve_pc_btn').show();
    $('.cancel_pc_btn').show();
    $('.pc_title').hide();
    approve_multi_pc_uri();
  }else{
    $('.approve_pc_btn').hide();
    $('.cancel_pc_btn').hide();
    $('.pc_title').show();
  }

});

approve_multi_pc_uri = function(){

  let pcApproveUri = "/pendings/list?multi_approve_pc=1";
  let pcCancelUri = "/pendings/list?cancel_pc=1";
  $('.pc_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      pcApproveUri += `&id[]=${id}`;
      pcCancelUri += `&id[]=${id}`;
    }

  });

  $('.approve_pc_btn').attr('href', pcApproveUri);
  $('.cancel_pc_btn').attr('href', pcCancelUri);

}


// DN approve checkboxes
$("#approve_dn_check").on('change',function () {
    $(".dn_check").prop('checked', $(this).prop("checked"));
    if($('.dn_check:checked').length > 0){
      $('.approve_dn_btn').show();
      $('.cancel_dn_btn').show();
      $('.dn_title').hide();
      approve_multi_dn_uri();
    }else{
      $('.approve_dn_btn').hide();
      $('.cancel_dn_btn').hide();
      $('.dn_title').show();
    }

});

$('.dn_check').on('change', function($index){

  console.log($(this).val());
  if($('.dn_check:checked').length > 0){
    $('.approve_dn_btn').show();
    $('.cancel_dn_btn').show();
    $('.dn_title').hide();
    approve_multi_dn_uri();
  }else{
    $('.approve_dn_btn').hide();
    $('.cancel_dn_btn').hide();
    $('.dn_title').show();
  }

});

approve_multi_dn_uri = function(){

  let dnApproveUri = "/pendings/list?multi_approve_dn=1";
  let dnCancelUri = "/pendings/list?cancel_dn=1";
  $('.dn_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      dnApproveUri += `&id[]=${id}`;
      dnCancelUri += `&id[]=${id}`;
    }

  });

  $('.approve_dn_btn').attr('href', dnApproveUri);
  $('.cancel_dn_btn').attr('href', dnCancelUri);

}

// Requisitions approve checkboxes
$("#approve_req_check").on('change',function () {
    $(".req_check").prop('checked', $(this).prop("checked"));
    if($('.req_check:checked').length > 0){
      $('.approve_req_btn').show();
      $('.cancel_req_btn').show();
      $('.req_title').hide();
      approve_multi_req_uri();
    }else{
      $('.approve_req_btn').hide();
      $('.cancel_req_btn').hide();
      $('.req_title').show();
    }

});

$('.req_check').on('change', function($index){

  console.log($(this).val());
  if($('.req_check:checked').length > 0){
    $('.approve_req_btn').show();
    $('.cancel_req_btn').show();
    $('.req_title').hide();
    approve_multi_req_uri();
  }else{
    $('.approve_req_btn').hide();
    $('.cancel_req_btn').hide();
    $('.req_title').show();
  }

});

approve_multi_req_uri = function(){

  let reqApproveUri = "/pendings/list?multi_approve_req=1";
  let reqCancelUri = "/pendings/list?cancel_multi_req=1";
  $('.req_check').each(function(){
    let id = $(this).val();
    if($(this).filter(":checked").length > 0){
      reqApproveUri += `&id[]=${id}`;
      reqCancelUri += `&id[]=${id}`;
    }

  });

  $('.approve_req_btn').attr('href', reqApproveUri);
  $('.cancel_req_btn').attr('href', reqCancelUri);

}

$('.cancelLPO').on('click', function(e) {
e.preventDefault();
lpo_id = $(this).data("lpo_id");
$('.modal-title').html('Cancel LPO #'+lpo_id);
$('#cancel_form').attr('action', $(this).attr('href'));
$('#lpo_id').val(lpo_id);
$('#cancelModal').modal('show');
});



</script>


{/literal}
