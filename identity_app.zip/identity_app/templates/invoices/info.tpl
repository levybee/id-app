<div class="panel panel-default">

       <div class="panel-heading">
          <h3 class="panel-title">Invoices Info</h3>
	 </div>
	 <div class="panel-body panel-body-table">

		   <div class="table-responsive">
		     <table class="table pad-10 table-striped">

			  <tr>
			    <td colspan="2"><div><strong>Customer</strong></div>

			     <div>{$smarty.session.qc.customer_information.customer_fname} {$smarty.session.qc.customer_information.customer_lname}<br />
			    {$smarty.session.qc.customer_information.group_company}<br />
			    {$smarty.session.qc.customer_information.customer_address}<br />
			    {$smarty.session.qc.customer_information.customer_city}, {$smarty.session.qc.customer_information.customer_country}<br />
			    <br />
			    Phone: {$smarty.session.qc.customer_information.customer_phone}<br />
			    Fax: {$smarty.session.qc.customer_information.customer_fax}<br />
			    Mobile: {$smarty.session.qc.customer_information.customer_mobile}<br />
			    Email: {$smarty.session.qc.customer_information.customer_email}<br />
          TIN: {$smarty.session.qc.customer_information.tin}<br />
          VRN: {$smarty.session.qc.customer_information.vrn}<br />

        </div>

			    </td>

			  </tr>
			  {*<tr>*}
			    {*<td colspan="2"><div><strong>Job #</strong></div>*}
			        {*<div>{$smarty.session.qc.job_no}</div>*}
			    {*</td>*}
			    {**}
			  {*</tr>*}

			  <tr>
			    <td colspan="2"><div><strong>Show Details</strong>    <input type="checkbox" name="show_summary" id="show_summary" value="Y" checked="checked" onclick="show_summary(this);" /></div></td>
			  </tr>
             </table>

           </div>
       </div>


</div>
