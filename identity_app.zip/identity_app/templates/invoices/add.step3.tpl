<div class="panel panel-default">
	       <div class="panel-body">
	       {if !$error_message}
	         {*<h3>Save &amp; Print!</h3>*}
	         <p>You have successfully raised
				 {*<strong>Invoice # {$invoice_id}</strong>. <br />The invoice is ready for PDF print / save. *}
			 </p>
	         {*<p>*}
	            {*<button name="Submit" type="submit" class="btn btn-primary" onclick="popupPDF('invoice', {if $invoice_id}{$invoice_id}{else}0{/if}, {if $invoice_template eq 'Blank'}1{else}0{/if});">View &amp; Print Invoice</button>*}
	            {*<button name="email_invoice" class="btn btn-primary" onclick="toggle2('email_form');">Email Email</button>*}
	         {*</p>*}
	     
	       {else}
	         <div class="alert alert-danger" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$error_message}
             </div>
	         
	        {/if}
	          
	       </div>
	     
	     </div>
	     

{include file='quotes/mail.tpl'}
	     
{*{if $invoice_id}*}
{*<div class="panel panel-default">*}
 {*<div class="panel-body">*}
  {**}
   {*<iframe style="width:100%;" height="500" src="/invoices/print?uid={$invoice_id}{if $invoice_template eq 'Blank'}&template=Blank{/if}"></iframe>*}
 {*</div>*}
{*</div>*}
{*{/if} *}
	     


