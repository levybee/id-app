
<div id="summary" class="panel panel-default" style="display:none;">
          
       <div class="panel-heading">
		        <h3 class="panel-title">Items</h3>   
		</div>
		<div class="panel-body panel-body-table">
		
		   <div class="table-responsive">
                    <table class="table table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                <th width="40">item #</th>
                                <th>Qty</th>
							    <th>Description</th>
							    <th>Unit Price {if $smarty.session.quote.step_1.quote_currency}({$smarty.session.quote.step_1.quote_currency}){/if}</th>
							    <th>Amount {if $smarty.session.quote.step_1.quote_currency}({$smarty.session.quote.step_1.quote_currency}){/if}</th>
							    <th width="50">Actions</th>
                            </tr>
                        </thead>
                        <tbody>  
                           {section name=items loop=$smarty.session.quote.items}
						  <tr>
						    <td class="text-center">{$smarty.section.items.rownum}</td>
						    <td>{$smarty.session.quote.items[items].item_quantity_1|number_format:0:".":","}</td>
						    <td>
						    {$smarty.session.quote.items[items].item_product[0].product_name} {if $smarty.session.quote.items[items].item_product_other}({$smarty.session.quote.items[items].item_product_other}){/if} - {$smarty.session.quote.items[items].item_title}
						    <p style="line-height:18px;">
						      Origination: {$smarty.session.quote.items[items].item_origination};{if $smarty.session.quote.items[items].item_delivery_days} Delivery Days: {$smarty.session.quote.items[items].item_delivery_days};{/if} Size: {$smarty.session.quote.items[items].item_paper_size[0].paper_size};
						      {if $smarty.session.quote.items[items].item_product[0].product_type eq 'Paper' || $smarty.session.quote.items[items].item_product[0].product_type eq 'Books'}{if $smarty.session.quote.items[items].item_orientation|capitalize}Orientation: {$smarty.session.quote.items[items].item_orientation|capitalize};{/if} {if $smarty.session.quote.items[items].item_num_pages} No of Pages: {$smarty.session.quote.items[items].item_num_pages};{/if}  Cover Paper: {$smarty.session.quote.items[items].item_cover_paper_type[0].paper_name} {if $smarty.session.quote.items[items].item_cover_paper_type_other}({$smarty.session.quote.items[items].item_cover_paper_type_other}){/if}; {if $smarty.session.quote.items[items].item_cover_paper_desc}Cover Paper Description: {$smarty.session.quote.items[items].item_cover_paper_desc};{/if} Paper Weight: {$smarty.session.quote.items[items].item_cover_paper_weight[0].weight_value} gsm; {if $smarty.session.quote.items[items].item_cover_color[0].color_name}Print: {$smarty.session.quote.items[items].item_cover_color[0].color_name} {if $smarty.session.quote.items[items].item_cover_color_other}({$smarty.session.quote.items[items].item_cover_color_other}){/if};{/if} {if $smarty.session.quote.items[items].item_cover_print_options}Print Options: {$smarty.session.quote.items[items].item_cover_print_options|capitalize};{/if}{/if}
						      {if $smarty.session.quote.items[items].item_product[0].product_type eq 'Books'}Inner Paper: {$smarty.session.quote.items[items].item_inner_paper_type[0].paper_name}; {if $smarty.session.quote.items[items].item_inner_paper_desc}Inner Paper Description: {$smarty.session.quote.items[items].item_inner_paper_desc};{/if} Inner Paper Weight: {$smarty.session.quote.items[items].item_inner_paper_weight[0].weight_value} gsm; Inner Print: {$smarty.session.quote.items[items].item_inner_color[0].color_name} {if $smarty.session.quote.items[items].item_inner_color_other}({$smarty.session.quote.items[items].item_inner_color_other}){/if}; {if $smarty.session.quote.items[items].item_inner_print_options}Inner Print Options: {$smarty.session.quote.items[items].item_inner_print_options|capitalize};{/if} {/if} {if $smarty.session.quote.items[items].item_print_process}Print Process: {$smarty.session.quote.items[items].item_print_process};{/if} 
						      Finishing: {section name=item_finishing_summary loop=$smarty.session.quote.items[items].item_finishing}
			            	            {$smarty.session.quote.items[items].item_finishing[item_finishing_summary][0].finishing_type}; 
							            {sectionelse}
							           	 	None;
							            {/section} 
						      
						      
						    </p>
						    {if $smarty.session.quote.items[items].item_notes}<p style="line-height:18px;">Notes: {$smarty.session.quote.items[items].item_notes}</p> {/if}
						    {if $smarty.session.quote.items[items].item_special_remarks}<p style="line-height:18px;">Special Remarks: {$smarty.session.quote.items[items].item_special_remarks}</p>{/if}
						    
						    </td>
						    <td>{$smarty.session.quote.items[items].item_price_1|thousand_sep} </td>
						    <td>{$smarty.session.quote.items[items].item_total_price|thousand_sep}</td>
						  
						    <td>
						      <a title="Edit Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/add/?subtask=edit&subid={$smarty.section.items.rownum}&popup=true" onclick="popupURL(this.href, 'EditQuoteItem', '1000', '500'); return false;"><span class="fa fa-pencil"></span></a> 
			                   <a title="Delete Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/add/?subtask=delete&subid={$smarty.section.items.rownum}"><span class="fa fa-times"></span></a>
						     </td>
						  
						  </tr>
						  
						  {sectionelse}
						  <tr>
						    <td colspan="6"><div>No Items have been added to this quotation yet.</td>
						  </tr>
						  {/section}
						  
						  {if $smarty.session.quote.items|@count gt 0}
						  <tr class="info">
						   <td colspan="4" align="right"><strong>Sub Total</strong></td><td>{$quote_totals.quote_subtotal|thousand_sep}</td><td></td>
						  </tr>
						  {if $smarty.session.quote.step_1.quote_tax eq 'Taxable'}
						  <tr class="warning" >
						   <td colspan="4" align="right"align="right"><strong>Taxes</strong></td><td>{$quote_totals.quote_taxes|thousand_sep}</td><td></td>
						  </tr>
						  {/if}
						  <tr class="success">
						   <td colspan="4" align="right"><strong>Total</strong></td><td>{$quote_totals.quote_grandtotal|thousand_sep}</td><td></td>
						  </tr>
						  {/if}
						   
                        </tbody>
                    </table>
                    
                    {if $smarty.get.debug eq 'lev'}
                     <pre> {$smarty.session.quote.items|@print_r}</pre>
                     
                    {/if}
                    
                </div>  
		
		   <!-- <div class="table-responsive">
		       {section name=items loop=$smarty.session.quote.items}
		       <table class="table table-striped" style="margin-bottom:15px">
		                   
		          <tr>
			        <td colspan="3" class="header_row title"><strong>Item # {$smarty.section.items.rownum}</strong></td>
			        <td>
			        <div align="right">
			          <a title="Edit Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/add/?subtask=edit&subid={$smarty.section.items.rownum}&popup=true" onclick="popupURL(this.href, 'EditQuoteItem', '1000', '500'); return false;"><span class="fa fa-pencil"></span></a> 
			          <a title="Delete Quote Item" class="btn btn-default btn-rounded btn-condensed btn-sm" href="/quotes/add/?subtask=delete&subid={$smarty.section.items.rownum}"><span class="fa fa-times"></span></a>
			        </div>
			        </td>
			      </tr>
			      <tr>
			        <td width="100" class="header_row"><div align="right"><strong>Item Type</strong></div></td>
			        <td width="200">{$smarty.session.quote.items[items].item_product[0].product_name} {if $smarty.session.quote.items[items].item_product_other}({$smarty.session.quote.items[items].item_product_other}){/if}</td>
			        <td width="100" class="header_row"><div align="right"><strong>Title</strong></div></td>
			        <td width="200">{$smarty.session.quote.items[items].item_title}</td>
			      </tr>
			      <tr>
			        <td class="header_row"><div align="right"><strong>Origination</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_origination}</td>
			        <td class="header_row"><div align="right"><strong>Delivery Days</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_delivery_days}</td>
			      </tr>
			      <tr>
			        <td class="header_row"><div align="right"><strong>Size</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_paper_size[0].paper_size} {if $smarty.session.quote.items[items].item_paper_size_other}({$smarty.session.quote.items[items].item_paper_size_other}){/if}</td>
			        <td class="header_row"><div align="right"><strong>Orientation</strong></div></td>
			        <td><label>{$smarty.session.quote.items[items].item_orientation|capitalize}</label>
			            <label></label>
			            <label></label></td>
			      </tr>
			      {if $smarty.session.quote.items[items].item_product[0].product_type eq 'Paper' || $smarty.session.quote.items[items].item_product[0].product_type eq 'Books'}
			      <tr>
			        <td class="header_row"><div align="right"><strong>Cover Paper</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_cover_paper_type[0].paper_name} {if $smarty.session.quote.items[items].item_cover_paper_type_other}({$smarty.session.quote.items[items].item_cover_paper_type_other}){/if}</td>
			        <td class="header_row"><div align="right"><strong>Description</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_cover_paper_desc}</td>
			      </tr>
			      <tr>
			        <td class="header_row"><div align="right"><strong>Paper Weight:</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_cover_paper_weight[0].weight_value} gsm</td>
			        <td class="header_row"><div align="right"><strong>Print</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_cover_color[0].color_name} {if $smarty.session.quote.items[items].item_cover_color_other}({$smarty.session.quote.items[items].item_cover_color_other}){/if}</td>
			      </tr>
			      <tr>
			        <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
			        <td><label>{$smarty.session.quote.items[items].item_cover_print_options|capitalize}</label>
			            <label></label></td>
			        <td class="header_row">&nbsp;</td>
			        <td>&nbsp;</td>
			      </tr>
			      {/if}
			      
			      {if $smarty.session.quote.items[items].item_product[0].product_type eq 'Books'}
			      <tr>
			        <td class="header_row"><div align="right"><strong>Inner Paper</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_inner_paper_type[0].paper_name} {if $smarty.session.quote.items[items].item_inner_paper_type_other}({$smarty.session.quote.items[items].item_inner_paper_type_other}){/if}</td>
			        <td class="header_row"><div align="right"><strong>Description</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_inner_paper_desc}</td>
			      </tr>
			      <tr>
			        <td class="header_row"><div align="right"><strong>Paper Weight</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_inner_paper_weight[0].weight_value} gsm</td>
			        <td class="header_row"><div align="right"><strong>Print</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_inner_color[0].color_name} {if $smarty.session.quote.items[items].item_inner_color_other}({$smarty.session.quote.items[items].item_inner_color_other}){/if}</td>
			      </tr>
			      <tr>
			        <td class="header_row"><div align="right"><strong>Print Options</strong></div></td>
			        <td><label>{$smarty.session.quote.items[items].item_inner_print_options|capitalize}</label>
			            <label></label></td>
			        <td class="header_row">&nbsp;</td>
			        <td>&nbsp;</td>
			      </tr>
			      
			     
			      <tr>
			        <td class="header_row"><div align="right"><strong>Print Process</strong></div></td>
			        <td colspan="3">{$smarty.session.quote.items[items].item_print_process}</td>
			      </tr>
			      <tr>
			        <td valign="top" class="header_row"><div align="right"><strong>Finishing</strong></div></td>
			        <td colspan="3">
			            {section name=item_finishing_summary loop=$smarty.session.quote.items[items].item_finishing}
			            	{$smarty.session.quote.items[items].item_finishing[item_finishing_summary][0].finishing_type}; 
			            {sectionelse}
			           	 	None
			            {/section}        </td>
			      </tr>
			      
			       {/if}
			       
			      <tr>
			        <td class="header_row"><div align="right"><strong>Payment Terms</strong></div></td>
			        <td colspan="3">{$smarty.session.quote.items[items].item_payment_terms}</td>
			      </tr>
			      <tr>
			        <td class="header_row"><div align="right"><strong>Quantity</strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_quantity_1|thousand_sep}</td>
			        <td class="header_row"><div align="right"><strong>Price{if $smarty.session.quote.step_1.currency} in {$smarty.session.quote.step_1.currency}{/if} </strong></div></td>
			        <td>{$smarty.session.quote.items[items].item_price_1|thousand_sep}</td>
			      </tr>
			      
			      <tr>
			        <td valign="top" class="header_row"><div align="right"><strong>Notes</strong></div></td>
			        <td colspan="3">{$smarty.session.quote.items[items].item_notes}</td>
			      </tr>
			      <tr>
			        <td valign="top" class="header_row"><div align="right"><strong>Special Remarks</strong></div></td>
			        <td colspan="3">{$smarty.session.quote.items[items].item_special_remarks}</td>
			      </tr>
		           
		                    
            </table>
            {sectionelse}
            <table class="table">
              <tr><td> <p>No Items have been added to this quotation yet.</p></td></tr>
            </table>
		    {/section}
        </div> -->
        
        
  </div> 
 
      
</div>