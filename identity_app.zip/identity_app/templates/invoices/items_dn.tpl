
<div id="summary" class="panel panel-default">
          
       <div class="panel-heading">
		        <h3 class="panel-title">Items</h3>   
		</div>
		<div class="panel-body panel-body-table">
			<form method="post" action="/invoices/add" id="subm">
				<input type="submit" name="complete" id="complete" class="hidden" />
				<input type="hidden" name="customer_id" value="{if $formdata.customer_id}{$formdata.customer_id}{else}{$smarty.session.customer_id}{/if}">

				<input type="hidden" name="quote_id" id="quote_id" value="">
				<input type="hidden" name="next_step" value="three" />
				 <input type="hidden" name="debug" value="{$smarty.get.debug}" >
		   		<div class="table-responsive">

                    <table class="table table-bordered table-striped ">
						<tr>
							<th rowspan='2'>QUOTE NO:</th>
							<th rowspan='2'>DN NO:</th>
							<th colspan='3' style="text-align: center;">ITEMS</th>
						</tr>


						<tr>

							<th>QTY</th>
							<th>DESCRIPTIONS</th>
							<th>ACTIONS</th>

						</tr>

						{foreach  from=$delivery_step_two key=key item=dls}
                          <tr>
                               <td rowspan="{$delivery_step_two[$key]|@count}">{$key}</td>
							

                               {assign var=last value=$dls|@end}

								{foreach from=$dls item=v}

									   <td>{$v.dn_id}</td>
									   <td>{$v.quantity}</td>
									   <td>{$v.description}</td>
									   <td>

										   <input type="checkbox" id="invoices" name="confirmed_check[]"  value="{$v.dn_item_id}" class="invoice_data q{$key} dn{$v.dn_id}"/></td>
                                           <input type="hidden" name="dn_id[{$key}][]" value="{$v.dn_id}" />
                                           <input type="hidden" name="dn_description[{$key}]" value="{$v.description}" />
									   {if $last.dn_id} </tr> {/if}

                                {/foreach}

							</tr>

						{/foreach}


                    </table>
                    
                    
		     </div>
		   
			</form>
			
		
        
        
  </div>
</div>