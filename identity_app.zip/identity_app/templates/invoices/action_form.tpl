<div class="modal" id="item_form" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close close_company_form" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead"></h4>
              </div>
              <form id="item_action_form" name="item_action_form" method="post" action="" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="response"></div>
	                 
	                 
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
			                 
			                
			                 <div class="panel-body">
			                     <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Reason</label>
									    <div class="col-md-8 col-xs-12"> 
									    <textarea name="reason" rows="4"  class="form-control"  required></textarea>
									    </div>          
									      
								</div>

			                   </div>

			             </div>
	              
	              </div>
	              <div class="modal-footer">
	                  <input type="submit" name="item_submit" class="btn btn-primary" value="Continue">
	                  <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button>
                  </div>
              </form>
              
          </div>
      </div>
  </div>