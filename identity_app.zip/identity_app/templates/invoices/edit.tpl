
{if $privileges.quotes.edit || $privileges.quotes.add}
	<ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/quotes/list">Quotes</a></li>
     <li class="active"><a href="">Edit Quote</a></li>
	 </ul>
	 <!-- END BREADCRUMB -->
	 <div class="page-title">                    
	    <h2><span class="fa fa-arrow-circle-o-left"></span>Edit Quote - Step {$step|capitalize}</h2>
	</div>

   
    <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
         <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
             <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
             {$message}
         </div>
        {/if}
        
        
	    
	    {if $smarty.get.subtask neq 'edit'}
	    
	     <div class="col-md-12">
	     <div class="panel panel-default">
	       <div class="panel-body panel-body-table">
	       
	          <table border="0" width="100%" cellpadding="5" cellspacing="0" id="progress_bar">
	          <thead>
	          <tr>
	            <th width="40%"  class="step {if $step eq 'one'}current{/if}" >Step 1</th>
	            <th width="60%"  class="step {if $step eq 'two'}current{/if}" >Step 2</th>
	          </tr>
	         
	          </thead>
	          <tbody>
	            <tr>
		            <td class="progress_information">Edit Quote</td>
                    <td class="progress_information">Save &amp; Print, or email</td>
	            </tr>
	            
		          <!-- <tr>
		            <td colspan="2" class="bar_body" style="padding-top:10px; padding-bottom:10px "><div align="center">
		             <a class="btn btn-default" href="/quotes/edit?id={$smarty.request.id}">Refresh</a>
		            <a class="btn btn-default" href="/quotes/edit?id={$smarty.request.id}&amp;step=two">Done? Save!</a>
		        
		            </div></td>
		          </tr> -->
	           </tbody>
	         </table>
	       </div>
	     
	     </div>
	     
	   </div>
	   	{/if}
	   
	   <div class="col-md-3">
		  
		     {include file='quotes/edit_quote_info.tpl'}
		
		  {if $step == 'one'} 
		   <div align="center" style="padding:10px 0 15px;">
             <a class="btn btn-default" href="/quotes/edit?id={$smarty.request.id}">Refresh</a>
             <a class="btn btn-default" href="/quotes/edit?id={$smarty.request.id}&amp;step=two">Done? Save!</a>
          </div>
         {/if} 
	   </div>  
	   <div class="col-md-9">
	      {if $step == 'two'}
		    {include file='quotes/edit.step2.tpl'}
		{else}
		<script type="text/javascript" src="/js/quote.js"></script>
		   
		
		    {if $smarty.get.subtask eq 'edit'}
		    {include file='quotes/edit.subtask.tpl'}
		    {else}
		    {include file='quotes/edit.standard.tpl'}
		    {/if}
		{/if}
	   </div>   
	 
	        

                                            

    </div>
  </div>
 </div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 
 {/if}   
    
    
   



{*
{if $smarty.get.subtask neq 'edit'}
<table border="0" align="right" cellpadding="5" cellspacing="0" id="progress_bar">
  <tr>
    <td width="75" class="step_1" {if $step eq 'one'}id="current"{/if}>Step 1</td>
    <td width="125" class="step_2" {if $step eq 'two'}id="current"{/if}>Step 2</td>
  </tr>
  <tr>
    <td class="progress_information">Edit Quote</td>
    <td class="progress_information">Save &amp; Print, or email</td>
  </tr>
  <tr>
    <td><div align="left"><a href="/quotes/edit?id={$smarty.request.id}"><strong>Refresh</strong></a></div></td>
    <td><div align="left"><a href="/quotes/edit?id={$smarty.request.id}&amp;step=two"><strong>Done? Save!</strong></a></div></td>
  </tr>
</table>
<br style="float:right" />
{/if}
{if $step == 'two'}
    {include file='quotes/edit.step2.tpl'}
{else}
<script type="text/javascript" src="/js/quote.js"></script>
    {if $smarty.get.subtask eq 'edit'}
    {include file='quotes/edit.subtask.tpl'}
    {else}
    {include file='quotes/edit.standard.tpl'}
    {/if}
{/if *}