
<div id="summary" class="panel panel-default">

       <div class="panel-heading">
		        <h3 class="panel-title">Items</h3>
		</div>
		<div class="panel-body panel-body-table">
			<form method="post" action="/invoices/add" id="subm">
				<input type="submit" name="complete" id="complete" class="hidden" />
				<input type="hidden" name="customer_id" value="{if $formdata.customer_id}{$formdata.customer_id}{else}{$smarty.session.customer_id}{/if}">

				<input type="hidden" name="quote_id" id="quote_id" value="">
				<input type="hidden" name="next_step" value="three" />
				 <input type="hidden" name="debug" value="{$smarty.get.debug}" >
		   		<div class="table-responsive">

                    <table class="table table-bordered table-striped ">
						<tr>
							<th rowspan='2'>QUOTE NO:</th>
							<th rowspan='2'>QC NO:</th>
							<th colspan='3' style="text-align: center;">ITEMS</th>
						</tr>


						<tr>

							<th>QTY</th>
							<th>DESCRIPTIONS</th>
							<th>ACTIONS</th>

						</tr>

						{foreach  from=$qc_step_two key=key item=dls}
                          <tr>
                               <td rowspan="{$qc_step_two[$key]|@count}">{$key}</td>


                               {assign var=last value=$dls|@end}

								{foreach from=$dls item=v}

									   <td>{$v.qc_id}</td>
									   <td>{$v.quantity}</td>
									   <td>{$v.description}</td>
									   <td>

										   <input type="checkbox" id="invoices" name="confirmed_check[]"  value="{$v.qc_id}" class="invoice_data q{$key} qc{$v.qc_id}"/></td>
                                           <input type="hidden" name="qc_id[{$key}][]" value="{$v.qc_id}" />
                                           <input type="hidden" name="description[{$key}]" value="{$v.description}" />
									   {if $last.qc_id} </tr> {/if}

                                {/foreach}

							</tr>

						{/foreach}


                    </table>


		     </div>

			</form>




  </div>
</div>
