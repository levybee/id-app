<!-- PAGE PLUGINS -->
       <script type='text/javascript' src='/js/plugins/icheck/icheck.min.js'></script>
       <script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
       <script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>
       <script type="text/javascript" src="/js/plugins/star-rating/jquery.rating.js"></script>
       <script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
       <script type="text/javascript" src="/js/jquery/jquery.livequery.min.js"></script>
       <script type="text/javascript" src="/js/plugins/datatables/jquery.dataTables.min.js"></script>
       <script type="text/javascript" src="/js/jquery/relcopy.js"></script>
       <script type="text/javascript" src="/js/new_company_ajax.js"></script>


       <script type='text/javascript' src='/js/plugins/jquery-validation/jquery.validate.js'></script>




{literal}

<script type="text/javascript">


$('#group_id').livequery('change',function() { //start function when any link is clicked


 obj = document.getElementById('customer_id');
 content_show = document.getElementById('group_id').value;

 ajaxLoad(content_show, obj);


});

function ajaxLoad(content_show, obj)
{

   // Load Content
   $.ajax({
     method: "get",url: "/modules/quotes/customers_ajax.php",data: "group="+content_show,
     dataType: "script",
     beforeSend: function(){ obj.options.length = 0; obj.options[obj.options.length] = new Option('Loading...','0'); }, //show loading just when link is clicked
     complete: function(){
       // Do nothing
     }, //stop showing loading when the process is complete
     success: function(script){ //so, if data is retrieved, store it in html

       console.log(script);

       var obj = document.getElementById('customer_id');

       // alert(script);
       obj.options.length = 0;
       obj.options[obj.options.length] = new Option('Please Select','0');
       eval(script); // process JS
               obj.options[obj.options.length - 1].selected = true;

       {/literal}
       {if $smarty.get.step_restart && !$smarty.post.next_step && $smarty.session.quote.step_1.customer_information.group_id}
         {literal}

       var customer_id =  {/literal}{$smarty.session.quote.step_1.customer_information.customer_id}{literal};

         $('#customer_id').val(customer_id).selected();


       {/literal}
       {/if}
         {literal}


      }
    }); //close $.ajax(

}

 // Add New Company Form
 $('.close_company_form').on('click', function(e){

   $('#new_company_form').modal('hide');

 });

 $('.auto-submit-star').rating({
      callback: function(value, link){

       document.getElementById('group_rating').value = value;

       // To submit the form automatically:
       //this.form.submit();

      }

     });


 // Keep summary details if checkbox is checked
 $(function(){

   if($('#show_summary').is(':checked')) {

     localStorage.show_summary = 'true';
   }

     var check_summary = localStorage.show_summary === 'true'? true: false;
     $('#show_summary').prop('checked', check_summary || false);

     if(localStorage.show_summary === 'true'){

       $('#summary').show();
     }
 });



 $('#show_summary').on('change', function() {
     localStorage.show_summary = $(this).is(':checked');
     console.log(localStorage.show_summary);
 });


   $("#delivery_id").select2({
       placeholder: "Type to search...",
       minimumInputLength: 1,
       ajax: {
           url: "/ajax/deliveries.php",
           dataType: 'json',
           delay: 250,
           data: function (params) {

               var customer_id = $('#customer_id').val();

               return {
                   q: params.term, // search term
         customer_id:customer_id
               };
           },
           processResults: function (data) { // parse the results into the format expected by Select2.
               // since we are using custom formatting functions we do not need to alter the remote JSON data

               // Debug:
               console.log("Data: " + JSON.stringify(data) );

               return { results: data };
           },
           cache: true
       }

   });

 $('#delivery_id').on('change', function (e) {
   var qt = $(this).select2('data')[0].quantity,
   price = $(this).select2('data')[0].price,
   desc = $(this).select2('data')[0].text,
   amount = 0,
   id = $(this).select2('data')[0].id,
   currency = $(this).select2('data')[0].currency;


   if(price === null)
       price = 0;
   if(desc === null)
       desc = "";
   if(qt === null)
       qt = 0;

   amount = (qt*price);

   $('#invoice_quantity').val(qt);
   $('#invoice_id').val(id);
   $('#invoice_price').val(price);
   $('#invoice_description').val(desc);
   $('#invoice_amount').val(amount);
   $('#invoice_currency').val(currency);

});


 $("#group_id").select2({
   placeholder: "Type to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/customers_group.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

             return {
                 q: params.term, // search term
                 with_jobs: 1
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });

 $('#group_id').on('change', function (e) {
    console.log('Company Select: ' + $(this).val());

    if($(this).val() == -1){

      //$('#new_company_form').css('display','block');
      $('#new_company_form').modal('show');

    }

      if($(this).val() > 1){

      console.log('Company Select2', $(this).select2('data'));
          $("#job_no").val($(this).select2('data')[0].job_id);
      $("#job_no").removeAttr('disabled');

      // lev: Fix - when more than one customers are in same group, value gets mixed up
      console.log('cust_id', $(this).select2('data')[0].customer_id);
      $("#cust_id").val($(this).select2('data')[0].customer_id);

    }

 });

 var quote_id = 0;

 {/literal}{if $step eq 'two'}{literal}
    quote_id = {/literal}{$smarty.session.delivery.quote_info[0].quote_id}{literal}

    console.log('Quote ID ', quote_id);

   {/literal}{/if}{literal}

 $("#job_no").select2({
   placeholder: "Type Job ID to search...",
   minimumInputLength: 1,
   ajax: {
         url: "/ajax/jobs.php",
         dataType: 'json',
         delay: 250,
         data: function (params) {

           var group_id = $('#group_id').val();
           var customer_id = $('#customer_id').val();

             return {
                 q: params.term, // search term
                 customer_id: customer_id,
                 status: 'in_prod_deliv',
                 quote_id: quote_id
             };
         },
         processResults: function (data) { // parse the results into the format expected by Select2.
             // since we are using custom formatting functions we do not need to alter the remote JSON data

             // Debug:
       //console.log("Data: " + JSON.stringify(data) );

             return { results: data };
         },
         cache: true
     }

 });


 $('#job_no').on('change', function (e) {
   console.log('Job data ', $(this).select2('data')[0].text);

   $('#job_info').val($(this).select2('data')[0].text);

 });

 //Delete/Cancel actions
 $('.do_action').on('click', function(e){

   e.preventDefault();

   console.log('action', $(this));
   var action = $(this).data('do');

   $('#item_action_form').attr('action', $(this).attr('href'));
   $('.modal-title').html(action+' Invoice');
   $('#item_form').modal('show');

 });




   {/literal}{if $smarty.get.id}{literal}


      // Quotes approval
       $('#approve').on('click', function(){

         console.log('Approval..');

         $('#approve_modal').modal('show');


       });

       $('#approve_form').submit(function(e){


       e.preventDefault();

       $('input[name="approve_quote"]').val('Sending...').attr('disabled','disabled');

         var post_url = "/quotes/ajax";
       var post_data = $(this).serialize();


       console.log('Post data ', post_data);

       $.ajax({
         type: 'POST',
         url: post_url,
         data: post_data,
         dataType:'json',
         success	:	function(data){


              console.log('Data:' + JSON.stringify(data));

              var alert_class = (data.error == true)? 'danger' : 'success';

              var msg_html = "<ul>";
              $.each(data.msg, function(i, item) {
                msg_html += "<li>"+ data.msg[i] +"</li>";
             });
              msg_html += "</ul>";

              $('#response').html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

              $('input[name="approve_quote"]').val('Submit').removeAttr('disabled');

              if(data.error == false){

                $('#approve_form').reset();

                setTimeout(function(){

                   $('#approve_modal').modal('hide');

               },4000);

                location.reload();

              }

           },
           error : function(XMLHttpRequest, textStatus,
               errorThrown) {

             console.log("Status: " + textStatus);
             console.log("Error: " + errorThrown);

           }


       });


       });





{/literal}{/if}{literal}


// step two invoices check list
(function(){
   var inv = $('.invoice_data'),
   btn = $("#complete_btn");

   // btn.on('click',function(){
   //     var f = $("#subm");
   //     f[0].submit();
   // });

   $("#subm").submit(function(e){


       $('#complete_btn').attr('disabled', true);
       inv.removeAttr('disabled');
       formStatus = formSubmit();

       if(formStatus){
           return true
       }else{
           e.preventDefault(); return false;
       }

   })

   $.each(inv,function(index,v){

       v.addEventListener('change',function(){
           var p = $($($(this).parent()).parent()).children()[0],
               p1 = p.innerText,
       chil = this.classList,
               p2 = chil[1].replace(/\D/g,''),
               ch1 = chil[2].replace(/\D/g,'');
           var c = document.querySelectorAll('input[type="checkbox"]:checked').length -1;
           console.log(c);
           if(c === 0){
               inv.prop('disabled',false);
               $('#quote_id').val('');
           }

           if(this.checked) {
               inv.prop('disabled',true);
               $('#quote_id').val(p2);
               $('.q'+p2).prop('disabled',false);
           }
       });

   });
})();

function postVFD() {


    // $.ajax({
    //     type: "POST",
    //     url: "https://virtual.tra.go.tz/efdmsRctApi/api/efdmsRctInfo", // add web service Name and web service Method Name
    //     data: "{'invoice':[]}", //web Service method Parameter Name and ,user Input value which in Name Variable.
    //     contentType: "application/json; charset=utf-8",
    //     dataType: "json",
    //     success: function (response) {
    //         console.log('vfd', response); //getting the Response from JSON
    //     },
    //     failure: function (msg) {
    //         console.log('vfd', msg);
    //     }
    // });

    var settings = {
  "url": "http://41.222.94.138:8082/vfd-dev/apis/receive.php",
  "method": "POST",
  "crossdomain": true,
  "timeout": 0,
  "headers": {
    "Content-Type": "application/json",
    "Cookie": "PHPSESSID=o7v11b59alh0nc8oj27m89ghc5",
     "Access-Control-Allow-Origin": "*",
    // "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
    // "Access-Control-Allow-Headers": "x-requested-with",
    // "Access-Control-Allow-Credentials": true,
    // "Access-Control-Max-Age": 604800


  },
  "data": JSON.stringify({
    "invoice": [
      {
        "idate": "2022-05-02",
        "itime": "17:32:46",
        "custinvoiceno": "9519",
        "custidtype": 1,
        "custid": "127614555",
        "custname": "Dough Works Ltd.",
        "mobilenum": "255713995558",
        "username": "Zahira",
        "branch": "Dar es salaam",
        "department": null,
        "invoiceDetails": [
          {
            "description": "standard Base Banner screen printing Roll Up Banner",
            "qty": "3.00",
            "taxcode": 1,
            "amt": "60000.00"
          },
          {
            "description": "A6 Flier Single sided Flyers",
            "qty": "500.00",
            "taxcode": 1,
            "amt": "250.00"
          },
          {
            "description": "A4 Trifold. Brochure",
            "qty": "2000.00",
            "taxcode": 1,
            "amt": "240.00"
          }
        ]
      }
    ]
  }),
};

$.ajax(settings).done(function (response) {
  console.log(response);
});

}

function postVFD2(){

    var data = JSON.stringify({
  "invoice": [
    {
      "idate": "2022-05-02",
      "itime": "17:32:46",
      "custinvoiceno": "9519",
      "custidtype": 1,
      "custid": "127614555",
      "custname": "Dough Works Ltd.",
      "mobilenum": "255713995558",
      "username": "Zahira",
      "branch": "Dar es salaam",
      "department": null,
      "invoiceDetails": [
        {
          "description": "standard Base Banner screen printing Roll Up Banner",
          "qty": "3.00",
          "taxcode": 1,
          "amt": "60000.00"
        },
        {
          "description": "A6 Flier Single sided Flyers",
          "qty": "500.00",
          "taxcode": 1,
          "amt": "250.00"
        },
        {
          "description": "A4 Trifold. Brochure",
          "qty": "2000.00",
          "taxcode": 1,
          "amt": "240.00"
        }
      ]
    }
  ]
});

var xhr = new XMLHttpRequest();
xhr.withCredentials = true;

xhr.addEventListener("readystatechange", function() {
  if(this.readyState === 4) {
    console.log(this.responseText);
  }
});

xhr.open("POST", "https://virtual.tra.go.tz/efdmsRctApi/api/efdmsRctInfo");
xhr.setRequestHeader("Content-Type", "application/json");
 xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
// xhr.setRequestHeader("Access-Control-Allow-Credentials", "*");
// xhr.setRequestHeader("Cookie", "PHPSESSID=o7v11b59alh0nc8oj27m89ghc5");

xhr.send(data);

}

 postVFD();
// PostVfd();

</script>
{/literal}


<!-- END PAGE PLUGINS -->
