<div class="panel panel-default">
          
       <div class="panel-heading">
            <h3 class="panel-title">Quotation Information</h3>         
			 </div>
			 <div class="panel-body panel-body-table">
			
			   <div class="table-responsive">
			     <table class="table table-striped">
			       <tr>
					    <td colspan="2"><div><strong>Quote #</strong></div>
					     <div>{$quote_data.quote_date|substr:0:4}-{$quote_data.quote_date|substr:5:2}-{$quote_data.quote_id|leading_zero:5}-{$quote_data.user_fname|substr:0:1}{$quote_data.user_lname|substr:0:1}</div>
					    </td>
					    
					  </tr>
					  <tr>
					    <td colspan="2"><div><strong>Quote Date</strong></div>
					      <div>{$quote_data.quote_date|date_format:"%d/%m/%Y"}</div>
					    </td>
					    
					  </tr>
					  <tr>
					    <td colspan="2"><div><strong>Customer</strong></div>
					      <div>
						    {if $quote_data.customer_id eq 0}
						    {$quote_data.customer_fname} {$quote_data.customer_lname}<br />
						    {$quote_data.group_company}<br />
						    {$quote_data.customer_address}<br />
						    {$quote_data.customer_city}, {$quote_data.customer_country}<br />
						    <br />
						    Phone: {$quote_data.customer_phone}<br />
						    Fax: {$quote_data.customer_fax}<br />
						    Mobile: {$quote_data.customer_mobile}<br />
						    Email: {$quote_data.customer_email}
						    {else}
						    {$quote_data.quote_customer}
						    {/if}    
					    </div>
					    
					    </td>
					    
					  </tr>
					  
			   {if $step neq 'two'}		  
			    <tr>
			    <td colspan="2"><div><strong>Show Details</strong>&nbsp;&nbsp;
			       <input type="checkbox" name="show_summary" id="show_summary" value="Y" onclick="show_summary(this);" checked />
			    </div>
			    </td>
			  </tr>
			 {/if} 
			  
             </table>        
           </div>
          </div>     
      
</div>