{if $action eq 'mail'}
<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/quotes/list">Quotes</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>Email Quote</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
    
    
{/if}   

{if $message} 
      <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
          {$message}
   </div>
 {/if}
 
 
<div id="email_form"   class="panel panel-default" {if !$smarty.get.show_details && $action neq 'mail'}style="display:none;"{/if}>
  {if !$form_hide}   
    <div class="panel-body">
      {if $action neq 'mail'}<h3>Email Quote</h3>{/if}
    {if $smarty.get.show_details || $show_details}
      <div class="table-responsive">
         <h4>Quotation Information</h4>
	     <table class="table table-striped">
	       <tr>
		    <td class="header_row"><div align="right"><strong>Quote #</strong></div></td>
		    <td>{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
		  </tr>
		  
		  <tr>
		    <td class="header_row"><div align="right"><strong>Quote Date</strong></div></td>
		    <td width="200">{$quote_info[0].quote_date|date_format:"%d/%m/%Y"}</td>
		  </tr>
		  <tr>
		    <td width="100" valign="top" class="header_row"><div align="right"><strong>Customer</strong></div></td>
		    <td>{$quote_info[0].customer_fname} {$quote_info[0].customer_lname} | {$quote_info[0].group_company}</td>
		  </tr>
		  <tr>
		    <td valign="top" class="header_row"><div align="right"><strong>View Quote</strong></div></td>
		    <td><a title="View Quote" href="/quotes/view/?id={$quote_info[0].quote_id}&popup=true" onclick="popupURL(this.href, 'ViewQuote', '800', '500'); return false;"><img src="/images/file_important.png" alt="View Quote" width="16" height="16" border="0"></a></td>
		  </tr>
		 
         </table>        
      </div>
    {/if}
    
    <div class="col-md-12">
    
    
    <form class="form-horizontal" method="post" action="/quotes/mail/?id={$quote_id}">
       <div class="form-group">                                        
                     <label class="col-md-3 control-label">Send To:</label>
                     <div class="col-md-9 col-xs-12">
                        <input name="mail_to" type="text" id="mail_to" class="form-control" value="{if $smarty.post.mail_to}{$smarty.post.mail_to}{else}{if $customer_email_id}{$customer_email_id}{else}{$quote_info[0].customer_email}{/if}{/if}" />         
                        <i>Comma separated emails</i>  
                     </div>
        </div>
        
        <div class="form-group">                                        
                     <label class="col-md-3 control-label">CC:</label>
                     <div class="col-md-9 col-xs-12">
                        <input name="mail_cc" type="text" id="mail_cc" class="form-control" value="{if $smarty.post.mail_cc}{$smarty.post.mail_cc}{/if}" /> 
                        <i>Comma separated emails</i>        
                     </div>
        </div>
        
        <div class="form-group">                                        
                     <label class="col-md-3 control-label">Subject:</label>
                     <div class="col-md-9 col-xs-12">
                        <input name="mail_subject" type="text" id="mail_subject" class="form-control" value=" {if $smarty.post.mail_subject}{$smarty.post.mail_subject}{else}RE: Quote Ref #{if $action eq 'mail'}{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_id|leading_zero:5}{else}{$quote_data.quote_date|substr:0:4}-{$quote_data.quote_date|substr:5:2}-{$quote_id|leading_zero:5}{/if}{/if}"  />         
                     </div>
        </div>
        <div class="form-group">                                        
                     <label class="col-md-3 control-label">Attachment:</label>
                     <div class="col-md-9 col-xs-12">
                       <p class="form-control-static"><a href="#" onclick="popupPDF('quote', {if $quote_id}{$quote_id}{else}0{/if}); return false;">Quote #{$quote_id}</a></p> 
                     </div>
        </div>
        <div class="form-group">                                        
                     <label class="col-md-3 control-label">Message:</label>
                     <div class="col-md-9 col-xs-12">
                       <textarea name="mail_message" id="mail_message" class="form-control" rows="5">{if $smarty.post.mail_message}{$smarty.post.mail_message}{else}{$config.template_mail_quote}{/if}</textarea>
                     </div>
        </div>
       <button type="submit" id="submit_quote" name="Submit"  class="btn btn-primary pull-right">Email Quote</button>
    </form>
    
    
   
    </div>   
   </div>
    
   {/if}
  </div>
  
  {if $action eq 'mail'}
  
 </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{/if} 
  

{*

<h1>Email Quote</h1>
{if $smarty.get.show_details || $show_details}
<h2>Quotation Information</h2>
<table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td class="header_row"><div align="right"><strong>Quote #</strong></div></td>
    <td>{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
  </tr>
  
  <tr>
    <td class="header_row"><div align="right"><strong>Quote Date</strong></div></td>
    <td width="200">{$quote_info[0].quote_date|date_format:"%d/%m/%Y"}</td>
  </tr>
  <tr>
    <td width="100" valign="top" class="header_row"><div align="right"><strong>Customer</strong></div></td>
    <td>{$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<br />
    {$quote_info[0].group_company}</td>
  </tr>
  <tr>
    <td valign="top" class="header_row"><div align="right"><strong>View Quote</strong></div></td>
    <td><a title="View Quote" href="/quotes/view/?id={$quote_info[0].quote_id}&popup=true" onclick="popupURL(this.href, 'ViewQuote', '800', '500'); return false;"><img src="/images/file_important.png" alt="View Quote" width="16" height="16" border="0"></a></td>
  </tr>
</table>
{/if}
<h2>Email Quote</h2>
<form action="/quotes/mail/?id={$quote_id}" method="post">
<table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Send To: </strong></div></td>
    <td><input name="mail_to" type="text" id="mail_to" size="50" value="{if $smarty.post.mail_to}{$smarty.post.mail_to}{else}{if $customer_email_id}{$customer_email_id}{else}{$quote_info[0].customer_email}{/if}{/if}" /></td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Subject:  </strong></div></td>
    <td><input name="mail_subject" type="text" id="mail_subject" value="{if $smarty.post.mail_subject}{$smarty.post.mail_subject}{else}RE: Quote #{$quote_id}{/if}" size="50" /></td>
  </tr>
  
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Attachment: </strong></div></td>
    <td><a href="#" onclick="popupPDF('quote', {if $quote_id}{$quote_id}{else}0{/if}); return false;">Quote #{$quote_id}</a></td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Message: </strong></div></td>
    <td><textarea name="mail_message" id="mail_message" cols="48" rows="8" style="overflow: auto;">{if $smarty.post.mail_message}{$smarty.post.mail_message}{else}{$config.template_mail_quote}{/if}</textarea></td>
  </tr>
</table>

<br />
<table width="400" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><div align="right">
        <input type="submit" id="submit_quote" name="Submit" value="Email Quote" class="input_button" />
      </div></td>
    </tr>
</table>
</form>*}