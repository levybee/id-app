
<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/invoices/list">Invoices</a></li>
     <li class="active"><a href="/reports">Reports</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>Reports > Invoices</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
             {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
  
            
         
             <div class="panel panel-default" {if $smarty.get.print eq '1'}style="display:none;"{/if}>
                 
                 <div class="panel-body form-group">
                    
                  <form class="form-inline" method="post" action="/invoices/reports?show=1">
                   <div class="form-group"  style="margin-right:15px;">
				     <label for="ec_id">By Company</label>
				     <br>
				     	<select class="form-control select" id="group_id" name="group_id" style="display:block; width:200px;" >
				              <option value="*">Please Select</option>
				            {section name=group_list loop=$group_list}        
				            <option value="{$group_list[group_list].group_id}">{$group_list[group_list].group_company}</option>
				            {/section}
				          </select>
				         
				    
				    </div>
				    
				    <div class="form-group"  style="margin-right:15px;">
				     <label for="ec_id">Last (Period):</label>
				     
				     	 <select name="invoice_date" class="form-control select" style="width: 150px;" onchange="periodDates(this.value, 'trigger3', 'trigger4');">
				          <option value="-7 Days" {if $smarty.post.invoice_date eq '-7 Days'}selected{/if}>7 Days</option>
				          <option value="-14 Days" {if $smarty.post.invoice_date eq '-14 Days'}selected{/if}>14 Days</option>
				          <option value="-21 Days" {if $smarty.post.invoice_date eq '-21 Days'}selected{/if}>21 Days</option>
				          <option value="-30 Days" {if $smarty.post.invoice_date eq '-30 Days'}selected{/if}>30 Days</option>
				          <option value="-60 Days" {if $smarty.post.invoice_date eq '-60 Days'}selected{/if}>60 Days</option>
				          <option value="-90 Days" {if $smarty.post.invoice_date eq '-90 Days'}selected{/if}>90 Days</option>
				          <option value="*" {if $smarty.post.invoice_date eq '*'}selected{/if}>Specific Period</option>
				        </select>
				         
				    
				    </div>
				    
				    <div class="form-group" style="margin-right:15px;">
				     <label for="from_date" >Date From:</label> 
				      <input  type="text" style="display:block;"  name="invoice_date_start"  class="form-control datepicker" value="{if $smarty.post.invoice_date_start}{$smarty.post.invoice_date_start|date_format:'%Y-%m-%d'}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" >
				    </div> 
				    
				   
				    
				     <div class="form-group"  style="margin-right:15px;">
				     <label for="to_date">Date To:</label>
				      <input type="text" class="form-control datepicker" style="display:block;"  name="invoice_date_end"  value="{if $smarty.post.invoice_date_end}{$smarty.post.invoice_date_end|date_format:'%Y-%m-%d'}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" >
				    
				    </div>
				    	
				     <div class="form-group" style="margin-top:20px;">
				     <input type="hidden" name="search" value="1" >
				     <input type="hidden" name="report" value="1" >
				     <input type="hidden" name="page" value="*" >
				     <button type="submit" class="btn btn-primary">Go</button>
				     </div>

			    </form>   
             </div>
            </div> 
            
       
            
            {if $smarty.get.show eq '1'}
           <div class="panel panel-default">
            
            <div class="panel-heading">
                 
                  {if $privileges.invoices.approve && $smarty.get.fby_param eq 'Draft'}<label for="approve_selected" name="approve_selected" class="btn btn-danger">Approve Selected</label>{/if}
                  <ul class="panel-controls panel-controls-title">   
                     <li>
                       <div class="form-group">
                          <a href="/reports/customer?popup=1&print=1" onClick="this.style.display = 'none'; window.print(); this.style.display = ''; return false;">
		                  <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
		                  </a> 
                       </div>  
                     </li>                                     
                     
                 </ul>         
            </div>

            <div class="panel-body panel-body-table">
             <form method="post" action="">
               <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">
                  
                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                                
                                <th width="20" class="text-center">#</th>
                                {if $smarty.get.fby_param eq 'Draft'}<th width="20" class="text-center"><input type="checkbox" id="check_all_confirmed"/></th>{/if}
                                <th width="105">Invoice #</th>
							    <th width="150">Date</th>
							    <th class="text-center">Company</th>
							    <th width="40">Items #</th>
							    <th class="text-center">Value</th>
							     <th class="text-center">Age</th>
							    <th class="text-center">User</th>
							    <th class="text-center">Status</th>
							   
                            </tr>
                        </thead>
                        <tbody>  
                           {section name=invoice_list loop=$invoice_list}
						  <tr>

						    <td class="text-center">{$start+$smarty.section.invoice_list.rownum}</td>
						    {if $smarty.get.fby_param eq 'Draft'}<td class="text-center"><input type="checkbox" name="drafts_check[]" class="confirmed_check" value="{$invoice_list[invoice_list].invoice_info.invoice_id}" /></td>{/if}
						    <td>

                                {*<a title="View invoice" href="/invoices/print?uid={$invoice_list[invoice_list].invoice_info.invoice_id}"  alt="View invoice"> </a>*}
                                    TI/{$invoice_list[invoice_list].invoice_info.invoice_date|substr:0:4}/{$invoice_list[invoice_list].invoice_info.invoice_id}</td>
						    <td>{$invoice_list[invoice_list].invoice_info.invoice_date|date_format:"%d %B %Y"}</td>
						    <td>{if $invoice_list[invoice_list].invoice_info.customer_id eq 0}{$invoice_list[invoice_list].invoice_info.quote_customer}{else}{$invoice_list[invoice_list].invoice_info.group_company}{/if}</td>
						    <td class="text-center">{$invoice_list[invoice_list].invoice_items_num}</td>
						    <td class="text-right">{$invoice_list[invoice_list].invoice_info.invoice_currency} {$invoice_list[invoice_list].invoice_info.invoice_value|number_format:0:".":","}</td>
						    <td class="text-center">{$invoice_list[invoice_list].invoice_info.age_diff} Days</td>
						    <td class="text-center">{$invoice_list[invoice_list].invoice_info.user_fname} {$invoice_list[invoice_list].invoice_info.user_lname}</td>

						    <td class="text-center">
                                {if $invoice_list[invoice_list].invoice_info.invoice_status|strtolower === 'complete'}
                                    Closed
                                {else}
                                {$invoice_list[invoice_list].invoice_info.invoice_status}
                                {/if}
                                
                            </td>
						    
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="8"><div align="center">No records found.</td>
						  </tr>
						 {/section}
                        </tbody>
                    </table>
                   
                    
                   
                </div>  
              </form>                           

            </div>
           
        </div> 
            {/if}
             
             
                                                             

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 


