<div class="panel panel-default">

	<div class="panel-heading">
		<h3 class="panel-title">Invoices Info</h3>
	</div>
	<div class="panel-body panel-body-table">

		<div class="table-responsive">
			<table class="table pad-10 table-striped">

				<tr>
					<td colspan="2"><div><strong>Customer</strong></div>

						<div>{$dn_data.customer_fname} {$dn_data.customer_lname}<br />
							{$dn_data.group_company}<br />
							{$dn_data.customer_address}<br />
							{$dn_data.customer_city}, {$dn_data.customer_country}<br />
							<br />
							Phone: {$dn_data.customer_phone}<br />
							Fax: {$dn_data.customer_fax}<br />
							Mobile: {$dn_data.customer_mobile}<br />
							Email: {$dn_data.customer_email}</div>

					</td>

				</tr>
				{*<tr>*}
				{*<td colspan="2"><div><strong>Job #</strong></div>*}
				{*<div>{$smarty.session.delivery.job_no}</div>*}
				{*</td>*}
				{**}
				{*</tr>*}

				{*<tr>*}
					{*<td colspan="2"><div><strong>Show Details</strong>    <input type="checkbox" name="show_summary" id="show_summary" value="Y" checked="checked" onclick="show_summary(this);" /></div></td>*}
				{*</tr>*}
			</table>

		</div>
	</div>


</div>