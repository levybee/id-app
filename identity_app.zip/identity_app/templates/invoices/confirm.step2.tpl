<div class="panel panel-default">
          
       
			 <div class="panel-body panel-body-table">
			   
			   <div class="table-responsive">
			   
			     <table class="table table-striped">
			       <tr>
				    <td colspan="2" class="header_row title">QUOTE INFORMATION</td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Quote # </strong></div></td>
				    <td width="200">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Quote Date </strong></div></td>
				    <td>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Customer </strong></div></td>
				    <td>{$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<input type="hidden" name="customer_id" id="customer_id" value="{$quote_info[0].customer_id}" /><input type="hidden" name="job_representative" id="job_representative" value="{$quote_info[0].job_representative}" /></td>
				  </tr>
				  <tr>
				    <td class="header_row"><div align="right"><strong>Representative </strong></div></td>
				    <td>{$smarty.post.job_representative}</td>
				  </tr>
				  
				  <tr>
				    <td colspan="2" class="header_row title">LPO INFORMATION</td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>LPO No. </strong></div></td>
				    <td>{$smarty.post.job_lpo} {if $smarty.post.job_lpo eq 'LPO Number'}: {$smarty.post.job_lpo_other}{/if}</td>
				  </tr>
				  <tr>
				    <td colspan="2" class="header_row title">WHAT'S NEXT</td>
				  </tr>
				  <tr>
				    <td colspan="2"><table class="table">
				        <tr>
				          <td><div align="center"><a href="/jobs/attach?group={$group_id}"><img src="/images/attach_large.png" alt="Attach Files" width="32" height="32" border="0" /></a></div></td>
				          <td>&nbsp;</td>
				          <td><div align="center"><a href="/quotes/makejob?id={$quote_id}"><img src="/images/make_jobs.png" alt="Attach Files" width="48" height="48" border="0" /></a></div></td>
				        </tr>
				        <tr>
				          <td><div align="center"><a href="/jobs/attach?group={$group_id}">Attach Files</a></div></td>
				          <td><div align="center"></div></td>
				          <td><div align="center"><a href="/quotes/makejob?id={$quote_id}">Make Jobs</a></div></td>
				        </tr>
				    </table></td>
				  </tr>
             </table>  
            
           </div>
          </div>     
      
</div>

{*
<h1>Quotes &gt; Confirm Quote</h1>
<table  border="1" cellpadding="5" cellspacing="5" class="table">
  <tr>
    <td colspan="2" class="header_row title">QUOTE INFORMATION</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Quote # </strong></div></td>
    <td width="200">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Quote Date </strong></div></td>
    <td>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Customer </strong></div></td>
    <td>{$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<input type="hidden" name="customer_id" id="customer_id" value="{$quote_info[0].customer_id}" /><input type="hidden" name="job_representative" id="job_representative" value="{$quote_info[0].job_representative}" /></td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Representative </strong></div></td>
    <td>{$smarty.post.job_representative}</td>
  </tr>
  
  <tr>
    <td colspan="2" class="header_row title">LPO INFORMATION</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>LPO No. </strong></div></td>
    <td>{$smarty.post.job_lpo} {if $smarty.post.job_lpo eq 'LPO Number'}: {$smarty.post.job_lpo_other}{/if}</td>
  </tr>
  <tr>
    <td colspan="2" class="header_row title">WHAT'S NEXT</td>
  </tr>
  <tr>
    <td colspan="2"><table border="0" align="right" cellpadding="5" cellspacing="0">
        <tr>
          <td><div align="center"><a href="/jobs/attach?group={$group_id}"><img src="/images/attach_large.png" alt="Attach Files" width="32" height="32" border="0" /></a></div></td>
          <td>&nbsp;</td>
          <td><div align="center"><a href="/quotes/makejob?id={$quote_id}"><img src="/images/make_jobs.png" alt="Attach Files" width="48" height="48" border="0" /></a></div></td>
        </tr>
        <tr>
          <td><div align="center"><a href="/jobs/attach?group={$group_id}">Attach Files</a></div></td>
          <td><div align="center"></div></td>
          <td><div align="center"><a href="/quotes/makejob?id={$quote_id}">Make Jobs</a></div></td>
        </tr>
    </table></td>
  </tr>
</table>

*}