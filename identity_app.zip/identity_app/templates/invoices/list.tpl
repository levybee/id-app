{if $privileges.invoices.list}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="#">Invoices</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Invoice List</h2>
</div>


 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">
     <a href="/invoices/add" class="btn btn-default" style="margin-bottom: 30px;margin-left: 20px">
         New Invoice
     </a>
  <div class="row">
    <div class="col-md-12">
            {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">

          <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a> <a href="/invoices/list?page=1" class="btn btn-default">Clear</a>  | Filter By Status: <a href="/invoices/list?page=1{if $search_str}&{$search_str}{/if}" class="btn {if !$smarty.get.fby_param}btn-success{/if} btn-flat btn-rad">All</a>


            <a href="/invoices/list?page=1&filter=1&fby=status&fby_param=Draft{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Draft'}btn-success{else}btn-default{/if}">Draft <span class="badge"> {$status_nos.Draft}</span></a>

            <a href="/invoices/list?page=1&filter=1&fby=status&fby_param=Approved{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Approved'}btn-success{else}btn-default{/if}">Approved <span class="badge"> {$status_nos.Approved}</span></a>


            <!-- <a href="/invoices/list?page=1&filter=1&fby=status&fby_param=Delivered{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Delivered'}btn-success{else}btn-default{/if}">Delivered</a>
             -->
            <a href="/invoices/list?page=1&filter=1&fby=status&fby_param=Issued{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Issued'}btn-success{else}btn-default{/if}">Issued <span class="badge"> {$status_nos.Issued}</span></a>

            <a href="/invoices/list?page=1&filter=1&fby=status&fby_param=Complete{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Complete'}btn-success{else}btn-default{/if}">Closed <span class="badge"> {$status_nos.Complete}</span></a>

            <a href="/invoices/list?page=1&filter=1&fby=status&fby_param=Cancelled{if $search_str}&{$search_str}{/if}" class="btn {if $smarty.get.fby_param eq 'Cancelled'}btn-success{else}btn-default{/if}">Cancelled <span class="badge"> {$status_nos.Cancelled}</span></a>

            {include file='search/mini.invoice.tpl'}
		</div>
        <div class="panel panel-default">

            <div class="panel-heading">
                 <!-- <h3 class="panel-title">Invoices Table</h3> -->
                  {if $privileges.invoices.approve && $smarty.get.fby_param eq 'Draft'}<label for="approve_selected" name="approve_selected" class="btn btn-danger">Approve Selected</label>{/if}
                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/invoices/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/invoices/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                          {* if $privileges.jobs.listprint}
					         <a href="/quotes/print?popup=1&print=1&page=*{if $search_str}&{$search_str}{/if}" onClick="popupURL(this.href, 'QuotesList', 800, 500); return false;">
					          <img src="/images/print.png" alt="Print" width="32" height="32" border="0" />
					         </a>
					      {/if *}

                     </form>
                     </li>

                 </ul>
            </div>

            <div class="panel-body panel-body-table">
             <form method="post" action="">
               <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">

                    <table class="table pad-10 table-bordered table-striped table-actions">
                        <thead>
                            <tr>

                                <th width="20" class="text-center">#</th>
                                {if $smarty.get.fby_param eq 'Draft'}<th width="20" class="text-center"><input type="checkbox" id="check_all_confirmed"/></th>{/if}
                                <th width="105">Invoice #</th>
							    <th width="150">Date</th>
							    <th class="text-center">Company</th>
							    <th width="40">Items #</th>
							    <th class="text-center" width="150">Value</th>
							    <th class="text-center">User</th>
							    <th class="text-center">Status</th>
							    <th class="text-center">VFD Status</th>
							    <th width="100">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=invoice_list loop=$invoice_list}
						  <tr>

						    <td class="text-center">{$start+$smarty.section.invoice_list.rownum}</td>
						    {if $smarty.get.fby_param eq 'Draft'}<td class="text-center"><input type="checkbox" name="drafts_check[]" class="confirmed_check" value="{$invoice_list[invoice_list].invoice_info.invoice_id}" /></td>{/if}
						    <td>

                                {*<a title="View invoice" href="/invoices/print?uid={$invoice_list[invoice_list].invoice_info.invoice_id}"  alt="View invoice"> </a>*}
                                    TI/{$invoice_list[invoice_list].invoice_info.invoice_date|substr:0:4}/{$invoice_list[invoice_list].invoice_info.invoice_id}</td>
						    <td>{$invoice_list[invoice_list].invoice_info.invoice_date|date_format:"%d %B %Y"}</td>
						    <td>{if $invoice_list[invoice_list].invoice_info.customer_id eq 0}{$invoice_list[invoice_list].invoice_info.quote_customer}{else}{$invoice_list[invoice_list].invoice_info.group_company}{/if}</td>
						    <td class="text-center">{$invoice_list[invoice_list].invoice_items_num}</td>
						    <td class="text-right">{$invoice_list[invoice_list].invoice_info.invoice_currency} {$invoice_list[invoice_list].invoice_info.invoice_value|number_format:0:".":","}</td>
						    <td class="text-center">{$invoice_list[invoice_list].invoice_info.user_fname} {$invoice_list[invoice_list].invoice_info.user_lname}</td>

						    <td class="text-center {if $invoice_list[invoice_list].invoice_info.invoice_status eq 'Complete'}text-success{elseif $invoice_list[invoice_list].invoice_info.invoice_status eq 'Issued'}text-warning{elseif $invoice_list[invoice_list].invoice_info.invoice_status eq 'Pending'}text-danger{else}text-default{/if}">
                                {if $invoice_list[invoice_list].invoice_info.invoice_status|strtolower === 'complete'}
                                    Closed
                                {else}
                                {$invoice_list[invoice_list].invoice_info.invoice_status}
                                {/if}

                            </td>
                            <td class="text-center">

                                            <a class="{if $invoice_list[invoice_list].invoice_info.vfd_status eq 'Success'}text-success{elseif $invoice_list[invoice_list].invoice_info.vfd_status eq 'Pending'}text-danger{else}text-default{/if}" title='{$invoice_list[invoice_list].invoice_info.vfd_api_response}' href="">{$invoice_list[invoice_list].invoice_info.vfd_status}</a>


                                        </td>
						    {if !$smarty.get.print}
						    <td class="text-center">
						      {*<a title="View Invoice" href="/invoices/print?uid={$invoice_list[invoice_list].invoice_info.invoice_id}"  alt="View Invoice" width="16" height="16" border="0"> PDF </a>*}

                                <a class="btn btn-default btn-rounded btn-condensed btn-sm" title="View Invoice" href="/invoices/view?uid={$invoice_list[invoice_list].invoice_info.invoice_id}"  alt="View Invoice" border="0"> <span class="fa fa-sticky-note-o"></span> </a>
						        {if ($privileges.invoices.print && $smarty.session.role_name != 'Sales') || ($smarty.session.role_name == 'Sales' && $invoice_list[invoice_list].invoice_info.invoice_status eq 'Complete')}
						                   <a class="btn btn-default btn-rounded btn-condensed btn-sm"  title="View PDF" href="/invoices/print?uid={$invoice_list[invoice_list].invoice_info.invoice_id}"  alt="View PDF" target = "_blank"><span class="fa fa-file-pdf-o"></span></a>
                                {/if}
                                {if $invoice_list[invoice_list].invoice_info.attachment}
                                  {assign var="path" value=$invoice_list[invoice_list].invoice_info.attachment}
                                  {assign var="parts" value="/"|explode:$path}
                                  {if $parts[1] == 'invoices'}
                                  <a title="View Attachment" href="/{$path}" class="btn btn-default btn-rounded btn-condensed btn-sm" target = "_blank">
                                  <span class="fa fa-paperclip"></span>
                                  </a>
                                  {else}
                                  <a class="btn btn-default btn-rounded btn-condensed btn-sm" title="View Attachment" href="/{$config.attachment_dir}{$invoice_list[invoice_list].invoice_info.attachment}" target = "_blank"  alt="View Attachment"><span class="fa fa-paperclip"></span></a>
                                  {/if}
                                {/if}

                                {if $privileges.invoices.open && $invoice_list[invoice_list].invoice_info.invoice_status eq 'Complete'}
                                 <a title="Open Invoice" href="/invoices/list?act=open&id={$invoice_list[invoice_list].invoice_info.invoice_id}"
                                 onclick="confirmAction('Open Invoice. Are you sure?', this.href); return false;"
                                 class="btn btn-warning btn-rounded btn-condensed btn-sm">
                                 <span class="fa fa-folder-open"></span></a>
                                {/if}

                                {if $privileges.invoices.add && $invoice_list[invoice_list].invoice_info.invoice_status eq 'Cancelled'}
                                 <a title="Duplicate Invoice" href="/invoices/list?dup={$invoice_list[invoice_list].invoice_info.invoice_id}"
                                 onclick="confirmAction('Dup0licate Invoice. Are you sure?', this.href); return false;"
                                 class="btn btn-default btn-rounded btn-condensed btn-sm">
                                 <span class="fa fa-copy"></span></a>
                                {/if}

						     </td>
						    {/if}
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="8"><div align="center">No records found.</td>
						  </tr>
						 {/section}
                        </tbody>
                    </table>

                </div>
              </form>

            </div>
             <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form"  method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/invoices/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/invoices/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>


                     </form>
                     </li>

                 </ul>
            </div>

        </div>

    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">

       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>

    </div>


</div>

</div>
{/if}
