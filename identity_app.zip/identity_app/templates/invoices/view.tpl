{if $privileges.invoices.view}
    <!-- START BREADCRUMB -->
    <ul class="breadcrumb">
        <li><a href="/">Home</a></li>
        <li><a href="/invoices/list">Invoices</a></li>
        <li class="active"><a href="#"> &nbsp; invoice
                #TI/{$invoice_info[0].invoice_date|substr:0:4}/{$invoice_info[0].invoice_id}</a></li>
    </ul>
    <!-- END BREADCRUMB -->

    <div class="page-title">
    <h2>
    <span class="fa fa-arrow-circle-o-left"></span>Invoice
    #TI/{$invoice_info[0].invoice_date|substr:0:4}/{$invoice_info[0].invoice_id}
    </h2>

    <ul class="panel-controls fa panel-controls-title">


        {if $invoice_info[0].invoice_status == "Issued" && ($invoice_info[0].vfd_status == "Processing" || $invoice_info[0].vfd_status == "Pending") && $privileges.invoices.edit}
            <li><a class="btn btn-default" title="VFD Process"
                   href="/invoices/view/?uid={$invoice_info[0].invoice_id}&vfd=1"><span
                            class="fa fa-check"></span>VFD Process</a>
            </li>
        {/if}

        {if $invoice_info[0].invoice_status != "Complete" && $invoice_info[0].invoice_status != "Cancelled" && $privileges.invoices.edit}
            <li><a class="btn btn-default" title="Edit Invoice"
                   href="/invoices/view/?uid={$invoice_info[0].invoice_id}&edit=true"><span
                            class="fa fa-pencil"></span>Edit</a>
            </li>
        {/if}

        {if $invoice_info[0].invoice_status == "Draft"
        && $privileges.invoices.approve}
            <li><a class="btn btn-default" title="Approve"
                   id="approve" href="/invoices/view/?approve&uid={$invoice_info[0].invoice_id}"><span
                            class="fa fa-check text-info"></span>Approve</a>
            </li>
        {/if}

        {if $invoice_info[0].invoice_status == "Approved" &&
        $privileges.invoices.issue}
            <li><a class="btn btn-default" title="Issue an invoice"
                   id="issue" href="/invoices/view/?issue&uid={$invoice_info[0].invoice_id}"><span
                            class="fa fa-check text-info"></span>Issue An Invoice</a>
            </li>
        {/if}

        {if $invoice_info[0].invoice_status == "Issued" && $privileges.invoices.complete}
            <li><a class="attach btn btn-default" title="Close this invoice"
                   id="complete" href="#"><span
                            class="fa fa-check text-info"></span>Close this Invoice</a>
            </li>
        {/if}

        {if $invoice_info[0].invoice_status == "Issued" || $invoice_info[0].invoice_status == "Complete"}
            <li><a class="btn btn-default" title="View PDF"
                   href="/invoices/print?uid={$invoice_info[0].invoice_id}" target="_blank"><span
                            class="fa fa-file-pdf-o text"></span>PDF</a></li>
        {/if}

        {if $invoice_info[0].invoice_status == "Draft" && $invoice_info[0].invoice_status != "Cancelled" && $privileges.invoices.cancel}

            <li><a class="btn btn-danger do_action" style="color: #fff;" title="Cancel This Invoice"
                   href="/invoices/cancel/?id={$invoice_info[0].invoice_id}" data-do="Cancel"><span
                            class="fa fa-times"></span>Cancel</a></li>
        {/if}

        {if ($invoice_info[0].invoice_status == 'Draft' || $invoice_info[0].invoice_status == 'Cancelled') && $privileges.invoices.delete}
            <li><a class="btn btn-danger" style="color: white" title="Delete Invoice" data-do="Delete"
                   href="/invoices/delete/?id={$invoice_info[0].invoice_id}"
                   onclick="confirmAction('[Delete Invoice] Deleting will permanently remove the Invoice from the system. Are you sure?', this.href); return false;"><span
                            class="fa fa-times"></span>Delete</a>
            </li>
        {/if}
    </ul>

    </div>

    {*<!-- PAGE CONTENT WRAPPER -->*}
    <div class="page-content-wrap">

        <div class="row">
            <div class="col-md-3">

                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title">Invoice Information</h3>
                    </div>
                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">
                            <table class="table pad-10 table-striped">
                                <tr>
                                    <td colspan="2">
                                        <div><strong>Invoice #</strong></div>
                                        <div>TI/{$invoice_info[0].invoice_date|substr:0:4}/{$invoice_info[0].invoice_id}</div>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2">
                                        <div><strong>Date</strong></div>
                                        <div>{$invoice_info[0].invoice_date|date_format:"%d %B %Y"}</div>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2"><div><strong>Customer</strong></div>

                                        <div>
                                            {if $invoice_info[0].customer_fname}{$invoice_info[0].customer_fname} {$invoice_info[0].customer_lname}<br />{/if}
                                            {if $invoice_info[0].group_company}{$invoice_info[0].group_company}<br />{/if}
                                            {if $invoice_info[0].customer_address}{$invoice_info[0].customer_address}<br />{/if}
                                            {if $invoice_info[0].customer_city}{$invoice_info[0].customer_city}, {/if}{if $invoice_info[0].customer_country}{$invoice_info[0].customer_country}{/if}<br />
                                            <br />
                                            {if $invoice_info[0].customer_phone}Phone: {$invoice_info[0].customer_phone}<br />{/if}
                                            {if $invoice_info[0].customer_fax}Fax: {$invoice_info[0].customer_fax}<br />{/if}
                                            {if $invoice_info[0].customer_mobile}Mobile: {$invoice_info[0].customer_mobile}<br />{/if}
                                            {if $invoice_info[0].customer_email}Email: {$invoice_info[0].customer_email}{/if}
                                        </div>

                                    </td>

                                </tr>

                                {*<tr>*}
                                {*<td colspan="2"><div><strong>Payment Terms</strong></div>*}
                                {*<div>{$invoice_info[0].invoice_payment_terms}</div>*}
                                {*</td>*}
                                {*</tr>*}

                                <tr>
                                    <td colspan="2"><div><strong>Status</strong></div>
                                        <div>{$invoice_info[0].invoice_status}</div>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2"><div><strong>Quote</strong></div>
                                        <div><a target="_blank" href="/quotes/view/?id={$quote_id}">{$quote_id}</a></div>
                                    </td>
                                </tr>
                                {if $lpo}
                                <tr>
                                    <td colspan="2"><div><strong>LPO</strong></div>
                                        <div>{$lpo}</div>
                                    </td>
                                </tr>
                                {/if}

                            </table>
                        </div>
                    </div>


                </div>

                {if $invoice_info[0].invoice_status eq 'Confirmed' || $invoice_info[0].invoice_status eq 'Approved'}
                    <div class="panel panel-default">

                        <div class="panel-heading">
                            <h3 class="panel-title">Attachments</h3>
                        </div>
                        <div class="panel-body panel-body-table">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-actions">
                                    <!-- <thead>
                                        <tr>
                                            <th width="50">#</th>
                                            <th>Description</th>
                                            <th width="50">Actions</th>

                                        </tr>
                                    </thead> -->
                                    <tbody>
                                    {section name=attachment_list loop=$attachment_list}
                                        <tr>
                                            <td>{$start+$smarty.section.attachment_list.rownum}. <a href="/{$config.attachment_dir}{$attachment_list[attachment_list].attachment_path}" target = "_blank">{$attachment_list[attachment_list].attachment_name}</a> |  <a title="Delete" href="/quotes/view?id={$invoice_info[0].invoice_id}&task=del_attachmnt&attach_id={$attachment_list[attachment_list].attachment_id}" onclick="confirmAction('Are you sure you want to delete this attachment?', this.href); return false;"><span
                                                            class="fa fa-times text-danger"></span></a></td>
                                        </tr>
                                        {sectionelse}
                                        <tr>
                                            <td>No attachments found</td>
                                        </tr>
                                    {/section}


                                    </tbody>
                                </table>

                            </div>
                        </div>

                    </div>

                {/if}


                {if $invoice_info[0].invoice_status == "Issued" && $privileges.invoices.complete}

                    <div id="attachmnt_form" class="panel panel-default" {if !$is_error}style="display:none;"{/if}>

                        <div class="panel-body">

                            <h4>Attach Documents</h4>

                            <form action="" method="post" class="form-horizontal" enctype="multipart/form-data" name="form1">

                                <div class="form-group">



                                    <label>Attachment</label>

                                    <input name="attachment_file" type="file" id="attachment_file" accept="application/pdf" class="form-control" />
                                    <input type="hidden" name="invoice_id" value="{$invoice_info[0].invoice_id}">
                                    <input type="hidden" name="lpo_other" value="{$lpo}" >

                                </div>



                                <input type="submit" name="close_invoice" value="Close Invoice" class="btn btn-primary" />

                            </form>


                        </div>



                    </div>



                {/if}

                   {if $invoice_info[0].invoice_status eq 'Complete'}

                    <div class="panel panel-default">

                        <div class="panel-heading">



                            <h3 class="panel-title">Attachments</h3>



                        </div>



                        <div class="panel-body panel-body-table">



                            <div class="table-responsive">



                                <table class="table table-bordered table-striped table-actions">


                                    {if $invoice_info[0].attachment}

                                    {assign var="path" value=$invoice_info[0].attachment}
                                    {assign var="parts" value="/"|explode:$path}

                                        <tr>

                                            <td>
                                              {if $parts[1] == 'invoices'}
                                              <a href="/{$path}" target = "_blank">
                                              {$parts[2]}
                                              </a>
                                              {else}
                                                <a href="/{$config.attachment_dir}{$invoice_info[0].attachment}" target = "_blank">
                                                {$invoice_info[0].attachment}
                                                </a> <!-- |   <a title="Delete" href="/deliveries/view?id={$invoice_info[0].invoice_id}&task=del_attachmnt&attach_id={$invoice_info[0].attachment}" onclick="confirmAction('Are you sure you want to delete this attachment?', this.href); return false;">
                                               <span class="fa fa-times text-danger"></span></a> -->
                                               {/if}
                                            </td>



                                        </tr>


                                    {else}


                                        <tr>

                                            <td>No attachments found</td>

                                        </tr>

                                    {/if}

                                    </tbody>



                                </table>


                            </div>



                        </div>

                    </div>

                {/if}

                <div class="clearfix" style="height:200px;"></div>


                {*<a class="attach btn btn-default" style="margin-bottom:10px;" href="#" ><span class="fa fa-paperclip"></span>Attach</a>*}

                {*<div id="attachmnt_form" class="panel panel-default" {if !$is_error}style="display:none;"{/if}>*}

                    {*<div class="panel-body">*}
                        {*<h4>Attach Documents</h4>*}
                        {*<form action="" method="post" class="form-horizontal" enctype="multipart/form-data" name="form1">*}
                            {*<div class="form-group">*}
                                {*<label>Attachment</label>*}
                                {*<input name="attachment_file" type="file" id="attachment_file" class="form-control" />*}
                            {*</div>*}
                            {*<div class="form-group">*}
                                {*<label>Description</label>*}
                                {*<input name="attachment_name" type="text" id="attachment_name" class="form-control" />*}
                            {*</div>*}

                            {*<input type="submit" name="submit_attachmnt" value="Submit" class="btn btn-primary" />*}

                        {*</form>*}
                    {*</div>*}
                {*</div>*}

            </div>

            <div class="col-md-9">


                {if $message}
                    <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        {$message}
                    </div>
                {/if}

                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title">Items</h3>
                    </div>
                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">
                            <table class="table pad-10 table-bordered table-striped table-actions">
                                <thead>
                                <tr>
                                    <th width="40" class="text-center">item #</th>
                                    <th class="text-center">Qty</th>
                                    <th class="text-left">Description</th>
                                    <th class="text-center">Unit Price {if
                                        $invoice_info[0].invoice_currency}({$invoice_info[0].invoice_currency}){/if}</th>
                                    <th class="text-center">Amount {if
                                        $invoice_info[0].invoice_currency}({$invoice_info[0].invoice_currency}){/if}</th>

                                    {if  $invoice_info[0].invoice_status != 'Complete' && $invoice_info[0].invoice_status != 'Cancelled' && $smarty.get.edit}
                                        <th width="40" >Action</th>	{/if}
                                </tr>
                                </thead>
                                <tbody>
                                {section name=items loop=$invoice_items}
                                    <tr>
                                        <td class="text-center">{$smarty.section.items.rownum}</td>

                                        <td class="text-center">{$invoice_items[items].item_quantity|number_format:2:".":","}</td>


                                        <td class="text-center">{$invoice_items[items].item_description}</td>

                                        <td class="text-right">{$invoice_items[items].item_price|number_format:2:".":","}</td>

                                        <td class="text-right">{$invoice_items[items].item_total_price|number_format:2:".":","}</td>

                                        {if  $invoice_info[0].invoice_status != 'Complete' && $invoice_info[0].invoice_status != 'Cancelled' && $smarty.get.edit}
                                            <td class="text-center">
                                            {*<a href="/invoices/edit/?id={$invoice_items[items].item_id}" class="btn btn-default fa fa-pencil">Edit</a>*}
                                            <a href="/invoices/deleteitem/?id={$invoice_items[items].item_id}" class="btn btn-danger fa fa-times delete" onclick="confirmAction('[Delete Invoice] Deleting will permanently remove the Invoice from the system. Are you sure?', this.href); return false;">Delete</a>
                                        </td>{/if}

                                    </tr>

                                    {sectionelse}
                                    <tr>
                                        <td colspan="5"><div>No Items have been added to this Invoice yet.</td>
                                    </tr>
                                {/section} {if $invoice_items|@count gt 0}
                                    <tr class="info">
                                        <td {if  $invoice_info[0].invoice_status != 'Complete' && $invoice_info[0].invoice_status != 'Cancelled' && $smarty.get.edit} colspan="5"{else} colspan="4"{/if} align="right"><strong>Sub Total {if
                                                $invoice_info[0].invoice_currency}({$invoice_info[0].invoice_currency}){/if}</strong></td>
                                        <td class="text-right">{$invoice_total.sub_total|number_format:2:".":","}</td>
                                    </tr>

                                    {if $quote_discount > 0}
                                     <tr class="info">
                                        <td {if  $invoice_info[0].invoice_status != 'Complete' && $invoice_info[0].invoice_status != 'Cancelled' && $smarty.get.edit} colspan="5"{else} colspan="4"{/if} align="right"><strong>Discount {if
                                                $invoice_info[0].invoice_currency}({$invoice_info[0].invoice_currency}){/if}</strong></td>
                                        <td class="text-right">{$quote_discount|number_format:2:".":","}</td>
                                    </tr>

                                    {/if}

                                    {if $invoice_info[0].tax eq 'Taxable'}
                                        <tr class="warning">
                                            <td {if  $invoice_info[0].invoice_status != 'Complete' && $invoice_info[0].invoice_status != 'Cancelled'  && $smarty.get.edit} colspan="5" {else}colspan="4"{/if} align="right" align="right"><strong>Taxes
                                                    {if
                                                    $invoice_info[0].invoice_currency}({$invoice_info[0].invoice_currency}){/if}</strong></td>
                                            <td class="text-right">{$invoice_total.taxes|number_format:2:".":","}</td>
                                        </tr>
                                    {/if}

                                    <tr class="success">
                                        <td {if  $invoice_info[0].invoice_status != 'Complete' && $invoice_info[0].invoice_status != 'Cancelled' && $smarty.get.edit} colspan="5"{else}colspan="4"{/if} align="right"><strong>Total {if
                                                $invoice_info[0].invoice_currency}({$invoice_info[0].invoice_currency}){/if}</strong></td>
                                        <td class="text-right">{$invoice_total.grand_total|number_format:2:".":","}</td>
                                    </tr>
                                {/if}

                                </tbody>
                            </table>

                        </div>
                       {if $smarty.get.debug}
                        <pre>{$invoice_info|@print_r}</pre>
                       {/if}
                    </div>

                </div>


                {include file="$section/action_form.tpl"}
                {include file="$section/approve_form.tpl"}



            </div>
        </div>
    </div>
    <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
    </div>
    <!-- END PAGE CONTAINER -->
{else}
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">

                <div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                    </button>
                    You are not authorized to view this section
                </div>

            </div>


        </div>

    </div>

{/if}
