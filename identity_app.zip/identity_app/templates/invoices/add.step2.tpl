{include file="invoices/items.tpl"}


{*<form id="invoice-form" class="form-horizontal" method="post" action="/invoices/add" autocomplete="off">*}
  {*<div class="panel panel-default">*}
      {*<div class="panel-heading">*}
          {*<h3 class="panel-title">Add Item</h3>*}
          {**}
      {*</div>*}
     {**}
      {*<div class="panel-body">                                                                        *}
          {**}
          {*<div class="row">*}
              {**}
              {*<div class="col-md-6">*}
                  {**}
                  {*<div class="form-group">*}
                      {*<label class="col-md-4 control-label">Item<span class="asterisk">*</span></label>*}
                      {*<div class="col-md-8">*}


                          {*<select name="delivery_id" id="delivery_id"  class="form-control" style="width:100%;" ></select>*}
                          {*<input type="hidden" id="dn_date" name="dn_date" value="{if $formdata.dn_date}{else}{$smarty.session.dn_date}{/if}">*}
                              {*<input type="hidden" name="customer_id" id="customer_id" value="{if $formdata.customer_id }{$formdata.customer_id}{else}{$smarty.session.customer_id}{/if}">*}
                          {*<input type="hidden" name="invoice_id" value="" id="invoice_id">*}
                          {*<input type="hidden" name="invoice_currency" value="" id="invoice_currency">*}

                          {*<input type="hidden" name="invoice_description" value="" id="invoice_description">*}
                          {*<input type="hidden" name="job_info" id="job_info" value="{$formdata.job_info}">*}
                      {*</div>*}
                  {*</div>*}
                  {**}
              {*</div>*}
              {**}
              {*<div class="col-md-6">*}

                  {*<div class="form-group">*}
                      {*<label class="col-md-4 control-label">Quantity <span class="asterisk">*</span></label>*}
                      {*<div class="col-md-8">*}

					    {*<input name="invoice_quantity" type="number" id="invoice_quantity" value="{$formdata.invoice_quantity}" class="form-control" />*}
                      {*</div>*}
                  {*</div>*}


              {*</div>*}

              {*<br>*}

              {*<div class="col-md-6">*}

                  {*<div class="form-group">*}
                      {*<label class="col-md-4 control-label">Price <span class="asterisk">*</span></label>*}
                      {*<div class="col-md-8">*}

                          {*<input name="invoice_price" type="number" id="invoice_price" value="{$formdata.invoice_price}" class="form-control" />*}
                      {*</div>*}
                  {*</div>*}


              {*</div>*}

              {*<br>*}
              {*<div class="col-md-6">*}

                  {*<div class="form-group">*}
                      {*<label class="col-md-4 control-label">Amount <span class="asterisk">*</span></label>*}
                      {*<div class="col-md-8">*}

                          {*<input name="invoice_amount" type="number" id="invoice_amount" value="{$formdata.invoice_amount}" class="form-control" />*}
                      {*</div>*}
                  {*</div>*}


              {*</div>*}


          {*</div>*}
     {*</div>     *}
      {*<div class="panel-footer"> *}
        {*<input type="hidden" name="next_step" id="next_step" value="three" />*}
        {*<input type="submit" name="add_item" class="btn btn-primary pull-right" value="Add Item" />         *}
          {**}
      {*</div>*}
  {*</div>*}
  {*</form>*}
