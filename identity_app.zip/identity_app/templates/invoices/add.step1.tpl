
<div id="response2"></div>

<form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h3 class="panel-title">Invoice Information </h3>
        </div>
        
        <div class="panel-body form-group">
         
            <div class="form-group">                                        
                <label class="col-md-3 col-xs-12 control-label">Date</label>
                <div class="col-md-6 col-xs-12">
                    <div class="input-group">
                        <span class="input-group-addon"><span class="fa fa-calendar"></span></span>
                        <input name="dn_date" type="text" class="form-control datepicker" value="{if $smarty.session.invoices.step_1.dn_date}{$smarty.session.invoices.step_1.dn_date}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" readonly="readonly">
                        <input type="hidden" value="" name="job_no" id="job_no">
                    </div>
                   
                </div>
            </div>
            
            <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Company / Group</label>
                <div class="col-md-6 col-xs-12">                                                                                            
                   
                    <select name="group_id" id="group_id"  class="form-control" required></select>
                    <input type="hidden" name="cust_id" id="cust_id" value="{$smarty.post.cust_id}">
                </div>
            </div>
            
             <div class="form-group" style="display: none">
                <label class="col-md-3 col-xs-12 control-label">Customer</label>
                <div class="col-md-6 col-xs-12"> 
                  
                   <select name="customer_id" id="customer_id" class="form-control">
		        	<option value="0">Please Select..</option>
		           </select> 
                </div>
                
            </div>
            
            {**}
             {*<div class="form-group" id="job_field">*}
                  {*<label class="col-md-3 col-xs-12 control-label">Job #</label>*}
                   {*<div class="col-md-6 col-xs-12">                                                                                            *}
                    {*<select name="job_no" id="job_no"  class="form-control" style="width:100%;" disabled="disabled" required></select>*}
                   {*</div>*}
                  {**}
              {*</div>*}
            
          
           <!--<div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Payment Terms</label>
                <div class="col-md-6 col-xs-12">                                                                                            
                     <select name="delivery_payment_terms" id="delivery_payment_terms" class="form-control">
				      <option value="0">Please Select</option>
				      
				      {section name=item_payment_terms loop=$item_payment_terms}
				      
				       <option value="{$item_payment_terms[item_payment_terms].payment_id}" {if $item_payment_terms[item_payment_terms].payment_id eq $formdata.item_payment_terms || $smarty.session.delivery.step_1.delivery_payment_terms[0].payment_id eq $item_payment_terms[item_payment_terms].payment_id}selected{/if}>{$item_payment_terms[item_payment_terms].payment_term}</option>
				      
				      {/section}
				    
				     </select>
                </div>
              
            </div>
            
             <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Quote Validity</label>
                <div class="col-md-6 col-xs-12">                                                                                            
                   
                   <input name="delivery_validity" type="text" class="form-control" value="{if $smarty.session.delivery.step_1.delivery_validity}{$smarty.session.delivery.step_1.delivery_validity}{else}{$smarty.post.delivery_validity}{/if}" > 
                    
                </div>
            </div>
            
             <div class="form-group">
                <label class="col-md-3 col-xs-12 control-label">Currency</label>
                <div class="col-md-6 col-xs-12">                                                                                            
                     <select name="currency" id="currency" class="form-control">
				            <option value="TZS"  {if $formdata.currency eq "TZS" || $smarty.session.delivery.step_1.delivery_currency eq "TZS"}selected{/if}>TZS</option>
				        	<option value="USD"  {if $formdata.currency eq "USD" || $smarty.session.delivery.step_1.delivery_currency eq "USD"}selected{/if}>USD</option>
				    	</select>   
                </div>
            </div> -->
            
         
            
                 
        </div>
        <div class="panel-footer">
            <input type="hidden" name="debug" value="{$smarty.get.debug}" /> 
            <input name="next_step" type="hidden" id="next_step" value="two" />
            <button type="submit" class="btn btn-primary pull-right">Next</button>
            
           
        </div>
       
        
        
    </div>
 </form>


 {include file = 'quotes/new_company_modal.tpl'}