

<div class="panel panel-default">
          
       
			 <div class="panel-body panel-body-table">
			   
			   <div class="table-responsive">
			   <form name="form1" method="post" action="/quotes/confirm?id={$smarty.get.id}" enctype="multipart/form-data">
			     <table class="table table-striped">
			        <tr>
				    <td colspan="2" class="header_row title">QUOTE INFORMATION</td>
				  </tr>
			       <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Quote # </strong></div></td>
				    <td width="200">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Quote Date </strong></div></td>
				    <td>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Customer </strong></div></td>
				    <td>{$quote_info[0].group_company} - {$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<input type="hidden" name="customer_id" id="customer_id" value="{$quote_info[0].customer_id}" /></td>
				  </tr>
				  <tr>
				    <td class="header_row"><div align="right"><strong>Representative </strong></div></td>
				    <td><input name="job_representative" type="text" id="job_representative" value="{$quote_info[0].job_representative}" class="form-control" style="max-width:300px;" /></td>
				  </tr>
				  
				  <tr>
				    <td colspan="2" class="header_row title">LPO INFORMATION</td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>LPO No. </strong></div></td>
				    <td><select name="job_lpo" id="job_lpo" class="form-control" style="max-width:150px; float:left;" onchange="checkOther(this.value, 'LPO Number', 'job_lpo_other');">
				        <option value="Signed Quote">Signed Quote</option>
				        <option value="Verbal Approval">Verbal Approval</option>
				        <option value="Email Confirmation">Email Confirmation</option>
				        <option value="LPO Number">LPO Number</option>
				      </select>
				        <input name="job_lpo_other" type="text" id="job_lpo_other" value="" size="10" class="form-control"  style="display:none; float:left; width:100px; margin-left:5px;" /></td>
				  </tr>
				  <tr>
				    <td colspan="2" class="header_row title">ATTACH DOCUMENTS</td>
				  </tr>
				   <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Attachment </strong></div></td>
				    <td><input name="attachment_file" type="file" id="attachment_file" class="form-control" style="max-width:300px;" /></td>
				  </tr>
				  <tr>
				    <td width="100" class="header_row"><div align="right"><strong>Description </strong></div></td>
				    <td><input name="attachment_name" type="text" id="attachment_name" class="form-control" style="max-width:300px;"/></td>
				  </tr>
				  <tr>
				    <td colspan="2"><div align="right"><input type="hidden" name="next_step" id="next_step" value="two" />
				     <input type="hidden" name="submit_attachmnt" value="1" />
				    
				     <button type="submit" name="Submit" class="btn btn-primary">Confirm Quote</button>
				    </div></td>
				  </tr>
             </table>  
             </form>      
           </div>
          </div>     
      
</div>

{*

<h1>Quotes &gt; Confirm Quote</h1>

<form name="form1" method="post" action="/quotes/confirm?id={$smarty.get.id}">
<table  border="1" cellpadding="5" cellspacing="5" class="table">
  <tr>
    <td colspan="2" class="header_row title">QUOTE INFORMATION</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Quote # </strong></div></td>
    <td width="200">{$quote_info[0].quote_date|substr:0:4}-{$quote_info[0].quote_date|substr:5:2}-{$quote_info[0].quote_id|leading_zero:5}-{$quote_info[0].user_fname|substr:0:1}{$quote_info[0].user_lname|substr:0:1}</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Quote Date </strong></div></td>
    <td>{$quote_info[0].quote_date|date_format:"%d %B %Y"}</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>Customer </strong></div></td>
    <td>{$quote_info[0].group_company} - {$quote_info[0].customer_fname} {$quote_info[0].customer_lname}<input type="hidden" name="customer_id" id="customer_id" value="{$quote_info[0].customer_id}" /></td>
  </tr>
  <tr>
    <td class="header_row"><div align="right"><strong>Representative </strong></div></td>
    <td><input name="job_representative" type="text" id="job_representative" value="{$quote_info[0].job_representative}" size="30" /></td>
  </tr>
  
  <tr>
    <td colspan="2" class="header_row title">LPO INFORMATION</td>
  </tr>
  <tr>
    <td width="100" class="header_row"><div align="right"><strong>LPO No. </strong></div></td>
    <td><select name="job_lpo" id="job_lpo" style="width:100px;" onchange="checkOther(this.value, 'LPO Number', 'job_lpo_other');">
        <option value="Signed Quote">Signed Quote</option>
        <option value="Verbal Approval">Verbal Approval</option>
        <option value="Email Confirmation">Email Confirmation</option>
        <option value="LPO Number">LPO Number</option>
      </select>
        <input name="job_lpo_other" type="text" id="job_lpo_other" value="" size="10" style="display:none;" /></td>
  </tr>
  <tr>
    <td colspan="2"><div align="right"><input type="hidden" name="next_step" id="next_step" value="two" /><input type="submit" name="Submit" value="Confirm Quote" class="input_button" />
    </div></td>
  </tr>
</table>
</form>
*}