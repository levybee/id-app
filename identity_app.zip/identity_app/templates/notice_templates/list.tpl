{if $privileges.notice_templates.list}

<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/notice_templates/list">Notice Templates</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>Notice Templates</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">

             {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}


        <div class="col-md-12" style="margin-bottom:10px;">

        
           <a href="/notice_templates/add" class="btn btn-default">New Template</a>
           <br><br>
         
      </div>

        <div class="panel panel-default">

            <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/notice_templates/list{if $search_str}?{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/notice_templates/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}
								    <option value="1" selected>Page 1</option>
								  {/section}

							     </select>
                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>
                     </li>

                 </ul>
            </div>
            <div class="panel-body panel-body-table">

                <form method="post" action="">
                    <input type="submit" name="approve_selected" id="approve_selected" class="hidden" />
                <div class="table-responsive">
                    <table class="table pad-6 no-wrap table-bordered table-striped table-actions">
                        <thead>
                            <tr>
                               <th class="text-center">#</th>
                               <th class="text-center">Name</th>
              								 <th class="text-center">Type</th>
              								 <th class="text-center">Content</th>
              							   <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                           {section name=tpl_list loop=$tpl_list}
						  <tr>
						    <td class="text-center">{$tpl_list[tpl_list].id}</td>
                <td class="text-center">{$tpl_list[tpl_list].tpl_name}</td>
                <td class="text-center">{$tpl_list[tpl_list].tpl_type}</td>
						    <td><a href="#" data-toggle="popover" data-placement="top" data-content="{$tpl_list[tpl_list].tpl_content|strip_tags}">{$tpl_list[tpl_list].tpl_content|strip_tags|truncate:500}</a></td>
						    <td class="text-center">
                   <a href="/notice_templates/edit/?id={$tpl_list[tpl_list].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit" ><span class="fa fa-pencil"></span></a>
                   <a title="Delete" href="/notice_templates/delete/?id={$tpl_list[tpl_list].id}" onclick="return confirm('Are you sure you want to delete?')" class="btn btn-danger btn-rounded btn-condensed btn-sm"><span class="fa fa-times"></span></a>
                </td>
						  </tr>
						  {sectionelse}
						  <tr>
						    <td colspan="11">No records found.</td>
						  </tr>
						  {/section}
                        </tbody>
                    </table>

                </div>
                </form>


            </div>

     {if $smarty.get.dbg}
     {$privileges.notices|@print_r}
     {/if}

        </div>

 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->

<div class="modal" id="attachmentModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="defModalHead">Close Notice for <span class="item_name"></span></h4>
            </div>
            <form id="attachment_form" name="attachment_form" method="post" action="/notice_templates/list" class="form-horizontal" enctype="multipart/form-data">
              <div class="modal-body">
                 <div id="response"></div>


                 <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">
                     <div class="panel-body form-group">
                       <div class="row">
                         <div class="form-group">
                             <label>Attachment</label>
                             <input name="attachment_file" type="file" id="attachment_file" class="form-control" style="width:50%;" />
                         </div>
                 </div>

              </div>



        </div>
    </div>
    <div class="modal-footer">
        <input type="hidden" name="notice_id" value="" >
        <input type="hidden" name="close" value="1" >
        <input type="hidden" name="attachment_path" value="" >
        <input type="submit" name="item_submit" class="btn btn-primary" value="Submit">
        {* <button type="button" class="btn btn-default close_item_form" data-dismiss="modal">Close</button> *}
      </div>
      </form>
</div>

{else}
<div class="row">
    <div class="col-md-12">


       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>




</div>

</div>
{/if}
