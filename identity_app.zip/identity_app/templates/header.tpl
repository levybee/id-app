<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- META SECTION -->
        <title>{$software}</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <link rel="icon" href="/favicon.ico" type="/image/x-icon" />
        <!-- END META SECTION -->

        <!-- CSS INCLUDE -->

        <link rel="stylesheet" type="text/css" id="theme" href="/css/theme-dark.css"/>
        <link rel="stylesheet" type="text/css" id="theme" href="/css/custom.css"/>
        <link  type="text/css" rel="stylesheet" href="/js/plugins/star-rating/jquery.rating.css"/>
        <link  type="text/css" rel="stylesheet" href="/js/plugins/select2/select2.css"/>

        <link  type="text/css" rel="stylesheet" href="/css/chat/chat-pop.css"/>

        <!-- EOF CSS INCLUDE -->
    </head>
    <body>

        <!-- START PAGE CONTAINER -->
        <div class="page-container">

        {if !$smarty.get.popup}{include file="sidebar.tpl"}{/if}

            <!-- PAGE CONTENT -->
            <div class="page-content">

                {if !$smarty.get.popup}

                <!-- START X-NAVIGATION VERTICAL -->
                <ul class="x-navigation x-navigation-horizontal x-navigation-panel">
                    <!-- TOGGLE NAVIGATION -->
                    <li class="xn-icon-button">
                        <a href="#" class="x-navigation-minimize"><span class="fa fa-dedent"></span></a>
                    </li>
                    <!-- END TOGGLE NAVIGATION -->
                    <!-- TO MENU -->
                    <li class="xn-button hidden-sm hidden-xs" >
                        <a  href="#">Create New</a>
                        <ul class="xn-drop-left xn-drop-white animated zoomIn">
                            <li><a href="/quotes/add">Quote</a></li>
                            <li><a href="/jobs/add">Job Order</a></li>
                            <li><a href="/customers/add">Customer</a></li>
                            <li><a href="/customers_group/add">Company</a></li>
                            <li><a href="/suppliers/add">Supplier</a></li>
                            <li><a href="/stock/add">Stock</a></li>
                            <li><a href="/lpo/add">LPO</a></li>
                            <li><a href="/deliveries/add">Delivery Note</a></li>
                            <li><a href="/invoices/add">Invoices</a></li>
                        </ul>
                    </li>
                    <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/quotes/list">Quotes</a>
                    </li>
                    <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/jobs/list">Order Board</a>
                    </li>
                    <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/requisition/list">Requisitions</a>
                    </li>
                    <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/lpo/list">Purchase Orders</a>
                    </li>
                    <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/qc/list">QC</a>
                    </li>
                       <!-- Billing menu -->
                    <li class="xn-button hidden-sm hidden-xs" >
                        <a  href="#">Billing</a>
                        <ul class="xn-drop-left xn-drop-white animated zoomIn">
                            <li><a href="/invoices/list">Invoices </a></li>
                            <li><a href="/deliveries/list">Delivery Notes</a></li>
                            <li><a href="/bills/summary">Outstanding</a></li>
                            {* <li><a href="/quotes_outstanding/list">Exempt Outstanding</a></li> *}
                             <li><a href="/exempt_outstanding/list">Exempt Outstanding DN</a></li>
                            <li><a href="/receipts/list">Receipts</a></li>
                            <li><a href="/credit_notes/list">Credit Notes</a></li>
                            <li><a href="/gmr/list">GMR</a></li>
                        </ul>
                    </li>
                    {if $smarty.session.role_name == 'Administrator' || $smarty.session.role_name == 'Accounts' || $smarty.session.role_name == 'Accounts Exempt'}
                      <li class="xn-button hidden-sm hidden-xs" >
                        <a  href="#">Finance</a>
                        <ul class="xn-drop-left xn-drop-white animated zoomIn">
                            <li><a href="/ledger_accounts/list"></span> Account Ledgers</a></li>
                            <li><a href="/customer_ledgers/list">Customer Ledgers</a></li>  
                            <li><a href="/exempt_ledgers/list">Exempt Ledgers</a></li>   
                            <li><a href="/supplier_ledgers/list">Supplier Ledgers</a></li>
                            <li><a href="/vat_ledger/list">VAT Ledger</a></li>
                            <li><a href="/finance_reports/sales">Sales Report</a></li> 
                            <li><a href="/finance_reports/exempt_sales">Exempt Sales Report</a></li>   
                            <li><a href="/finance_reports/expenses">Expenses Report</a></li> 
                            <li><a href="/finance_reports/purchase_expense">Purchase Expenses Report</a></li>    
                        </ul>
                    </li>
                    {/if}

                     <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/job_schedule/list">Job Schedule</a>
                    </li>
                    <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/vehicle_schedule/list">Vehicle Schedule</a>
                    </li>
                    <!-- <li class="xn-button hidden-sm hidden-xs">
                      <a  href="/jobs/schedule">Production Schedule</a>
                    </li> -->
                    <li class="xn-button">
                      <a  href="/search">Search</a>
                    </li>
                    <!-- END TO MENU -->
                    <!-- SEARCH -->
                    <!-- <li class="xn-search">
                        <form role="form">
                            <input type="text" name="search" placeholder="Search..."/>
                        </form>
                    </li>  -->
                    <!-- END SEARCH -->

                    <!-- POWER OFF -->
                    <li class="xn-button pull-right last">
                        <a href="/logout" class="mb-control" data-box="#mb-signout">{$user_data[0].user_fname} {$user_data[0].user_lname} <span class="fa fa-power-off"></span></a>
                        {*
                        <ul class="xn-drop-left animated zoomIn">
                            <li><a href="pages-lock-screen.html"><span class="fa fa-lock"></span> Lock Screen</a></li>
                            <li><a href="/logout" class="mb-control" data-box="#mb-signout"><span class="fa fa-sign-out"></span> Sign Out</a></li>
                        </ul>
                        *}
                    </li>
                    <!-- END POWER OFF -->

                </ul>
                <!-- END X-NAVIGATION VERTICAL -->
                {/if}
