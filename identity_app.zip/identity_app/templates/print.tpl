{include file="header.tpl"}
{include file="$section/$action.tpl"}
{include file="footer.tpl"}