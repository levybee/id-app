<div id="search" class="panel panel-default" style="{if !$smarty.get.filter}display:none;{/if} margin-top:15px;">
    <div class="panel-body"><form class="form-inline" method="get" action="/expense_budgets/list">
        <input type="hidden" name="filter" value="1">
        <div class="form-group" style="margin-right:15px;"><label>Month</label><br><input type="month" name="target_month" class="form-control datepicker" value="{$smarty.get.target_month}"></div>
        <div class="form-group" style="margin-right:15px;"><label>Expense</label><br><select name="expense_id" class="form-control select2" style="width:200px;"><option value="">All</option>{foreach from=$expenses item=expense}<option value="{$expense.expense_id}" {if $smarty.get.expense_id eq $expense.expense_id}selected{/if}>{$expense.expense_name}</option>{/foreach}</select></div>
        {* <div class="form-group" style="margin-right:15px;"><label>Status</label><br><select name="status" class="form-control"><option value="">All</option>{foreach from=$sales_target_statuses item=status}<option value="{$status}" {if $smarty.get.status eq $status}selected{/if}>{$status}</option>{/foreach}</select></div> *}
        <button type="submit" class="btn btn-primary" style="margin-top:20px;">Search</button>
    </form></div>
</div>
