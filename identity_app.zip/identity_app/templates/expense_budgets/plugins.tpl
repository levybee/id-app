<!-- PAGE PLUGINS -->
<script type="text/javascript" src="/js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script><!-- Sales targets use native month controls; no module-specific scripts are required. -->
{literal}

<script type="text/javascript">

   $(".select2").select2();

</script>
{/literal}