{if $privileges.expense_budgets.add || $privileges.expense_budgets.edit}
<ul class="breadcrumb">
    <li><a href="/">Home</a></li>
    <li><a href="/expense_budgets/list">Expense Budgets</a></li>
    <li class="active">{$action|capitalize}</li>
</ul>
<div class="page-title"><h2><span class="fa fa-bullseye"></span> {$action|capitalize} Expense Budgets {if $formdata.budget_month}- {$formdata.budget_month|date_format:'%b %Y'}{/if}</h2></div>

<div class="page-content-wrap"><div class="row"><div class="col-md-12">
    {if $message}<div class="alert alert-{if $is_error}danger{else}success{/if}">{$message}</div>{/if}
    {if !$hide_form}
    <form method="post" action="/expense_budgets/{$action}{if $action == 'edit'}?id={$smarty.get.id}{/if}" class="form-horizontal">
  
 <div class="panel panel-default">
                 <div class="panel-heading">
                      <h3 class="panel-title"><strong>Expense Budget</strong> Form</h3> 
                     {* <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul> *}
                 </div>
        
                 <div class="panel-body form-group">

                 <div class="form-group">
    <label class="col-md-2 control-label">Budget Month</label>
    <div class="col-md-4">
      <input type="month" name="budget_month" class="form-control datepicker" style="width: 150px;" value="{if $smarty.post.budget_month}{$smarty.post.budget_month|date_format:'%Y-%m-%d'}{elseif $formdata.budget_month}{$formdata.budget_month|date_format:'%Y-%m-%d'}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" {if $action == 'edit'}disabled{else} readonly="readonly" required{/if} >
    </div>
  </div>

  <table class="table table-bordered">
    <thead>
      <tr><th>Expense Name</th><th>Category</th><th>Budget Amount</th></tr>
    </thead>
    <tbody>
      {foreach from=$expenses item=expense}
        <tr>
          <td>{$expense.expense_name}</td>
          <td>{$expense.expense_category}</td>
          <td>
            <input type="text" name="amount[{$expense.expense_id}]" class="form-control" value="{$formdata.expenses[$expense.expense_id]|default:''}" style="width: 80%;">
          </td>
        </tr>
      {/foreach}
    </tbody>
  </table>

                 </div>
                 <div class="panel-footer">
                     <button type="submit" class="btn btn-primary pull-right">Save</button>
                 </div>
             </div>
</form>
    {/if}
</div></div></div>
{else}<div class="alert alert-danger">You are not authorized to use sales targets.</div>{/if}
