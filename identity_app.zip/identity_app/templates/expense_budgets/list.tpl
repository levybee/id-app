{if $privileges.expense_budgets.list}
<ul class="breadcrumb"><li><a href="/">Home</a></li><li class="active">Expense Budgets</li></ul>
<div class="page-title"><h2><span class="fa fa-bullseye"></span> Expense Budgets</h2></div>
<div class="page-content-wrap"><div class="row"><div class="col-md-12">
    {if $message}<div class="alert alert-{if $is_error}danger{else}success{/if}">{$message}</div>{/if}
    <div class="col-md-12" style="margin-bottom:10px;">
        {if $privileges.expense_budgets.add}<a href="/expense_budgets/add" class="btn btn-default">New Expense Budget</a>{/if}
        <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a>
        <a href="/expense_budgets/list" class="btn btn-default">Clear</a>
        {include file="$section/search.tpl"}
    </div>
    <div class="panel panel-default"><div class="panel-heading"><div class="pull-right">Displaying {$resultsCount}</div><div class="clearfix"></div></div>
        <div class="panel-body panel-body-table"><div class="table-responsive"><table class="table pad-6 no-wrap table-bordered table-striped table-actions">
            <thead><tr><th class="text-center">Month</th><th class="text-center">Expense</th><th class="text-center">Category</th><th class="text-center">Budget Amount (TZS)</th>
            {* <th class="text-center">Currency</th><th class="text-center">Status</th> *}
            <th class="text-center">Created By</th><th class="text-center">Action</th></tr></thead>
            <tbody>{section name=row loop=$expense_budgets_list}<tr>
                {* <td class="text-center">{$expense_budgets_list[row].id}</td> *}
                <td class="text-center">{$expense_budgets_list[row].budget_month|date_format:'%b %Y'}</td>
                <td>{$expense_budgets_list[row].expense_name}</td>
                <td class="text-center">{$expense_budgets_list[row].expense_category}</td>
                <td class="text-center">{$expense_budgets_list[row].budget_amount|number_format:2:'.':','}</td>
                {* <td class="text-center">{$expense_budgets_list[row].currency}</td>
                <td class="text-center">{$expense_budgets_list[row].status}</td> *}
                <td class="text-center">{$expense_budgets_list[row].created_by_name}</td>
                <td class="text-center">{if $privileges.expense_budgets.edit}<a href="/expense_budgets/edit?id={$expense_budgets_list[row].id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="Edit"><span class="fa fa-pencil"></span></a>{/if}</td>
            </tr>{sectionelse}<tr><td colspan="8">No expense budgets found.</td></tr>{/section}</tbody>
        </table></div></div>
    </div>
</div></div></div>
{else}<div class="alert alert-danger">You are not authorized to view expense budgets.</div>{/if}