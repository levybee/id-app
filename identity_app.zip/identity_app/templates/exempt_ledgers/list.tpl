{if $privileges.exempt_ledgers.list}

  <!-- START BREADCRUMB -->
  <ul class="breadcrumb">
      <li><a href="/">Home</a></li>
      <li><a href="/exempt_ledgers/list">Exempt Ledgers</a></li>
      <li class="active"><a href="">{$action|capitalize}</a></li>
  </ul>
  <!-- END BREADCRUMB -->

  <div class="page-title">
      <h2><span class="fa fa-arrow-circle-o-left"></span> Exempt Ledgers</h2>
  </div>

  <!-- PAGE CONTENT WRAPPER -->
  <div class="page-content-wrap">

    <div class="row">
      <div class="col-md-12">

          {if $msg || $message}
          <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
              <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
              {$msg}
              {$message}
          </div>
          {/if}

          <div class="col-md-12" style="margin-bottom:10px;">

              <a href="#search" class="btn btn-default" onclick="toggleSearch('search'); return false;">Search</a>
              <a href="/exempt_ledgers/list?page=1" class="btn btn-default">Clear</a>
{* 
              | Filter By Status:
              <a href="/exempt_ledgers/list?page=1" class="btn {if !$smarty.get.status}btn-success{/if} btn-flat btn-rad">All</a>
              <a href="/exempt_ledgers/list?page=1&filter=1&status=Active" class="btn {if $smarty.get.status eq 'Active'}btn-success{else}btn-default{/if}">Active</a>
              <a href="/exempt_ledgers/list?page=1&filter=1&status=Closed" class="btn {if $smarty.get.status eq 'Closed'}btn-success{else}btn-default{/if}">Closed</a> *}

              {include file="$section/search.tpl"} <!-- Assuming you have a shared search form -->
          </div> 

          <div class="panel panel-default">

              <div class="panel-heading">

                  <ul class="panel-controls panel-controls-title">
                     <li>

                     <form class="form-inline" role="form" method="post">
                         <div class="form-group">
                           </div>
                         <div class="form-group">
                             <a href="/exempt_ledgers/list{if $search_str}?search=1&{$search_str}&page={$page-1}{else}?page={$page-1}{/if}">&lt; Previous Page</a> | <a href="/bills/list{if $search_str}?{$search_str}&page={$page+1}{else}?page={$page+1}{/if}">Next Page &gt;</a>

                             <label>| Displaying {$resultsCount}</label>
                         </div>
                         <div class="form-group">

                                 <select name="page" id="page" class="form-control">
								  {section name=pagination loop=$numPages}

								    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
								  {sectionelse}

								    <option value="1" selected>Page 1</option>


								  {/section}

							     </select>

                         </div>
                         <button name="submit" type="submit" class="btn btn-danger">Go</button>
                     </form>
                     </li>

                 </ul>
              </div>

              <div class="panel-body panel-body-table">

                  <div class="table-responsive">
                      <table class="table table-bordered table-striped table-actions">
                          <thead>
                              <tr>
                                  <th width="15" class="text-center">ID</th>
                                  <th width="60%" class="text-center">Company</th>
                                  {* <th class="text-center">Credit Terms</th> *}
                                  <th class="text-center">Outstanding Balance</th>
                                  <th width="50" class="text-center">Actions</th>
                              </tr>
                          </thead>
                          <tbody>
                              {section name=row loop=$ledger_list}
                                  <tr>
                                      <td class="text-center">{$ledger_list[row].group_id}</td>
                                      <td>{$ledger_list[row].group_company}</td>
                                      {* <td class="text-center">{$ledger_list[row].credit_terms}</td> *}
                              <td class="text-right">{$ledger_list[row].due_amount|number_format:2} {if $ledger_list[row].due_amount != 0}{$ledger_list[row].currency}{/if}</td>
                                      {* <td class="text-center">
                                          <span class="{if $ledger_list[row].status eq 'Active'}text-success{else}text-danger{/if}">
                                              {$ledger_list[row].status}
                                          </span>
                                      </td> *}
                                     
                                      <td class="text-center">
                                          <a target="_blank" href="/exempt_ledgers/view?group_id={$ledger_list[row].group_id}" class="btn btn-default btn-rounded btn-condensed btn-sm" title="View Customer Ledger">
                                              <span class="fa fa-eye"></span>
                                          </a>
                                      </td>
                                  </tr>
                              {sectionelse}
                                  <tr>
                                      <td colspan="5" class="text-center">No customer ledgers found.</td>
                                  </tr>
                              {/section}
                          </tbody>
                      </table>
                  </div>

              </div>

          </div>

      </div>
  </div>
  <!-- END PAGE CONTENT WRAPPER -->
  </div>
  <!-- END PAGE CONTENT -->

{else}
  <div class="row">
      <div class="col-md-12">
          <div class="alert alert-danger" role="alert">
              <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
              You are not authorized to view this section
          </div>
      </div>
  </div>
{/if}