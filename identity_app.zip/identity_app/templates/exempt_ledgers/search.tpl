


<div id="search" class="panel panel-default" style="{if !$smarty.get.filter}display: none;{/if} margin-top:15px;">

<div class="panel-body">
   <form id="form2" name="form2" class="form-inline"  method="post" action="/exempt_ledgers/list?search=1{if $search_str}{$search_str}{/if}">


     <div class="form-group"  style="margin-right:15px;">
     <label for="ec_id">Company</label>
     <br>
     	<select class="form-control select" id="group_id" name="group_id" style="display:block; width:200px;">
      </select>

    </div>
     {* <div class="form-group"  style="margin-right:15px;">
      <label>Credit Terms</label>
      <select name="credit_terms" id="credit_terms" class="form-control" style="display:block; width:150px;">
        <option value="">Please Select..</option>
        <option value="0"  {if $smarty.post.credit_terms eq "0" || $edit_customer[0].credit_terms eq "0"}selected{/if}>0 Days</option>
        <option value="30"  {if $smarty.post.credit_terms eq "30" || $edit_customer[0].credit_terms eq "30"}selected{/if}>30 Days</option>
        <option value="45"  {if $smarty.post.credit_terms eq "45" || $edit_customer[0].credit_terms eq "45"}selected{/if}>45 Days</option>
        <option value="60"  {if $smarty.post.credit_terms eq "60" || $edit_customer[0].credit_terms eq "60"}selected{/if}>60 Days</option>
        <option value="100"  {if $smarty.post.credit_terms eq "100" || $edit_customer[0].credit_terms eq "100"}selected{/if}>100 Days</option>
      </select>
     </div> *}
     {* <div class="form-group" style="margin-right:15px;">
        <label>Sales Person</label><br>
        <select name="user_id" style="display:block; width:160px;"   class="form-control select2">
        <option value="">Select..</option>
        {section name=users loop=$users}
          <option value="{$users[users].user_id}">{$users[users].user_fname} {$users[users].user_lname}</option>
        {/section}
        </select>

      </div> *}
      {* <div class="form-group" style="margin-right:15px;">
        <label>Status</label><br>
        <select name="status" style="display:block; width:160px;"   class="form-control">
        <option value="">Select..</option>
          <option value="Active" {if $smarty.post.status eq "Active"}selected{/if}>Active</option>
          <option value="Pending" {if $smarty.post.status eq "Pending"}selected{/if}>Pending</option>
          <option value="Inactive" {if $smarty.post.status eq "Inactive"}selected{/if}>Inactive</option>
        </select>   

      </div> *}

     <div class="form-group" style="margin-top:20px;">
       <input type="hidden" name="debug" value="{$smarty.get.s_debug}" >
       <button type="submit" class="btn btn-primary">Go</button>
     </div>


</form>


</div>



</div>
