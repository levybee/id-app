<!-- PAGE PLUGINS -->
<script type="text/javascript" src="/js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="/js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="/js/plugins/bootstrap/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="/js/plugins/select2/select2.min.js"></script>

{literal}
<script type="text/javascript">
$('.select2').select2();
$(document).ready(function(){


  $("#group_id").select2({
  placeholder: "Type to search...",
  minimumInputLength: 1,
  ajax: {
        url: "/ajax/customers_group.php",
        dataType: 'json',
        delay: 250,
        data: function (params) {

            return {
                q: params.term, // search term
            };
        },
        processResults: function (data) { // parse the results into the format expected by Select2.
            // since we are using custom formatting functions we do not need to alter the remote JSON data

            // Debug:
      console.log("Data: " + JSON.stringify(data) );

            return { results: data };
        },
        cache: true
    }

});

   $.fn.reset = function () {
     $(this).each (function() { this.reset(); });
   }
  $(".adjustBtn").on('click', function(e){
    e.preventDefault();
    $("#adjustModal").modal('show');
  });

  $('#adjuct_form').submit(function(e){
    e.preventDefault();
    submit_form('#adjuct_form', 'adjust_submit', '#adjustResponse', '#adjustModal');
  });

 var submit_form = function(form_name, btn_name, response_element='', modal_element=''){


   $('input[name="'+ btn_name +'"]').val('Sending...').attr('disabled','disabled');


   var post_url = $(form_name).attr('action');;
   var post_data = $(form_name).serialize();
   $.ajax({
     type: 'POST',
     url: post_url,
     data: post_data,
     dataType:'json',
     success	:	function(data){

       console.log(data);

          var alert_class = (data.error == true)? 'danger' : 'success';

          var msg_html = "<ul>";
          $.each(data.msg, function(i, item) {
            msg_html += "<li>"+ data.msg[i] +"</li>";
         });
          msg_html += "</ul>";


          $('input[name="'+ btn_name +'"]').val('Submit').removeAttr('disabled');

            $(response_element).html('<div class="alert alert-'+alert_class+'" role="alert"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>'+msg_html+'</div>');

            if(!data.error){

             // $(form_name)[0].reset();

              setTimeout(function(){

                 //$('.item_list').prop('checked', false);
                 $(modal_element).modal('hide');
                 location.reload();

             },5000);

            }



       },
       error : function(XMLHttpRequest, textStatus,
           errorThrown) {

         console.log("Status: " + textStatus);
         console.log("Error: " + errorThrown);

       }

   });

 }

 function formatNumber(num) {
    console.log('num', num);
    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
  }

 });

</script>
{/literal}

<!-- END PAGE PLUGINS -->
