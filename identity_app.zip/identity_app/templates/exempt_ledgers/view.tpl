{if $privileges.exempt_ledgers.view}
    <!-- START BREADCRUMB -->
    <ul class="breadcrumb">
        <li><a href="/">Home</a></li>
        <li><a href="/exempt_ledgers/list">Exempt Ledgers</a></li>
        <li class="active"><a href="#"> &nbsp; Exempt Ledger -
              {$company.group_company}</a></li>
    </ul>
    <!-- END BREADCRUMB -->

    <div class="page-title">
    <h2>
    <span class="fa fa-arrow-circle-o-left"></span>Exempt Ledger Account -
    {$company.group_company}
    </h2>

    <ul class="panel-controls fa panel-controls-title">
    <li>
           <button type="button" class="btn btn-default adjustBtn">Adjustment</button>
          </li>
        <li>
          <form class="form-inline"  method="post" action="/exempt_ledgers/view?group_id={$smarty.get.group_id}">
                 <input type="hidden"  name="start_date"  value="{$start_date}">
                 <input type="hidden"  name="end_date" value="{$end_date}">
                 <input type="hidden"  name="csv" value="1">
                 <button name="submit" type="submit" class="btn btn-default">CSV Export</button>
          </form>
        </li>
    </ul>

    </div>

    {*<!-- PAGE CONTENT WRAPPER -->*}
    <div class="page-content-wrap">

        <div class="row">
          {if $message}
      		<div class="col-md-12">
      			<div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
      					<button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
      					{$message}
      			</div>
      		</div>
      			{/if}

            <div class="col-md-3">

                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title">Customer Information</h3>
                    </div>
                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">
                            <table class="table pad-10 table-striped">
                                <tr>
                                    <td colspan="2">
                                            {if $company.group_company}{$company.group_company}<br />{/if}
                                            {if $company.customer_address}{$company.customer_address}<br />{/if}
                                            {if $company.customer_city}{$company.customer_city}, {/if}{if $company.customer_country}{$company.customer_country}{/if}<br />
                                            {if $company.customer_email}Email: {$company.customer_email}<br>{/if}
                                            {if $company.customer_mobile}Mobile: {$company.customer_mobile}<br />{/if}
                                            <br />
                                            {* {if $company.tin}TIN: {$company.tin}<br />{/if}
                                            {if $company.vrn}VRN: {$company.vrn}<br />{/if} *}
                                    </td>

                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-9">




                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title">Entries</h3>
                        <ul class="panel-controls panel-controls-title">
                          <li>
                          <form class="form-inline"  method="post" action="/exempt_ledgers/view?group_id={$smarty.get.group_id}">
                              <div class="form-group">
                                <label>From:</label>
                                 <input type="text"  name="start_date" style="width:100px;"  value="{if $smarty.post.start_date}{$smarty.post.start_date|date_format:'%Y-%m-%d'}{else}{$start_date}{/if}" autocomplete="off" class="form-control datepicker" >
                              </div>
                              <div class="form-group">
                                <label>&nbsp;To:</label>
                                 <input type="text"  name="end_date" style="width:100px;"  value="{if $smarty.post.end_date}{$smarty.post.end_date|date_format:'%Y-%m-%d'}{else}{$end_date}{/if}" autocomplete="off" class="form-control datepicker" >
                              </div>
                              <button name="submit" type="submit" class="btn btn-succes">Go</button>
                          </form>
                          </li>
                        </ul>
                    </div>
                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">
                            <table class="table pad-5 table-bordered table-striped table-actions">
                                <thead>
                                <tr>
                                    <th class="text-center" width="15%">Date</th>
                                    <th class="text-center" width="40%">Description</th>
                                    <th class="text-center" width="15%">Type</th>
                                    {* <th class="text-center">Ref #</th> *}
                                    <th class="text-center">Debit</th>
                                    <th class="text-center">Credit</th>
                                </tr>
                                </thead>
                                <tbody>
                                {section name=item loop=$entries}
                                    <tr>
                                        <td class="text-center">{$entries[item].entry_date|date_format:'%d/%m/%Y'}</td>
                                        <td>
                                          {if !$entries[item].entry_type || $entries[item].entry_type == 'Float Account' || $entries[item].entry_type == 'Adjustment'} 
                                          {$entries[item].description}
                                          {/if}
                                          {if $entries[item].entry_type == 'Credit Sales'}
                                           <a  title="View Delivery Note" href="/deliveries/view?id={$entries[item].entry_id}" target = "_blank">DN #{$entries[item].entry_id}</a>
                                          - <a  title="View Quote" href="/quotes/view?id={$entries[item].quote_id}" target = "_blank">Q#{$entries[item].quote_id}</a>
                                          {/if}
                                          {if $entries[item].entry_type == 'Receipt'}
                                          {$entries[item].description} - Receipt <a  title="View Receipt" href="/receipts/view?id={$entries[item].entry_id}" target = "_blank">#{$entries[item].entry_id}</a>
                                          {/if}
                                          {if $entries[item].entry_type == 'On Account'}
                                           On Account  - Receipt <a  title="View Receipt" href="/receipts/view?id={$entries[item].entry_id}" target = "_blank">#{$entries[item].entry_id}</a>
                                          {/if}
                                        </td>
                                        <td class="text-center">{$entries[item].entry_type}</td>
                                        <td class="text-right">{if $entries[item].debit > 0 || $entries[item].description == 'Opening Balance'}
                                        {$entries[item].debit|number_format:2:".":","}  
                                        {/if}
                                        </td>
                                        <td class="text-right">{if $entries[item].credit > 0}{$entries[item].credit|number_format:2:".":","}{/if}</td>
                                    </tr>
                                    {sectionelse}
                                    <tr>
                                        <td colspan="5"><div>No entries found.</td>
                                    </tr>
                                {/section}
                                {if $entries|@count > 0}
                                    <tr>
                                        <td colspan="3"></td>
                                        <td class="text-right"><strong>{$total_debit|number_format:2:".":","}</strong></td>
                                        <td class="text-right"><strong>{$total_credit|number_format:2:".":","}</strong></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td>Closing Balance</td>
                                        <td colspan="2"></td>
                                        <td class="text-right"><strong>{$closing_balance|number_format:2:".":","}</strong></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3"></td>
                                        <td class="text-right"><strong>{$total_debit|number_format:2:".":","}</strong></td>
                                        <td class="text-right"><strong>{$total_debit|number_format:2:".":","}</strong></td>
                                    </tr>

                                {/if}

                                </tbody>
                            </table>

                        </div>
                       {if $smarty.get.debug}
                        <pre>{$invoice_info|@print_r}</pre>
                       {/if}
                    </div>

                </div>


            {include file="$section/adjust_modal.tpl"}


            </div>
        </div>
    </div>
    <!-- END PAGE CONTENT WRAPPER -->
    </div>
    <!-- END PAGE CONTENT -->
    </div>
    <!-- END PAGE CONTAINER -->
{else}
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">

                <div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert">
                        <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                    </button>
                    You are not authorized to view this section
                </div>

            </div>


        </div>

    </div>

{/if}
