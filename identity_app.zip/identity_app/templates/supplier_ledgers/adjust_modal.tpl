<!-- NEW COMPANY MODAL -->
  <div class="modal" id="adjustModal" tabindex="-1" role="dialog" aria-labelledby="defModalHead" aria-hidden="true">
      <div class="modal-dialog modal-md">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <h4 class="modal-title" id="defModalHead">Adjustment</h4>
              </div>
              <form id="adjuct_form" name="item_action_form" method="post" action="/supplier_ledgers/view?supplier_id={$smarty.get.supplier_id}" class="form-horizontal">
	              <div class="modal-body">
	                 <div id="adjustResponse"></div>
			             <div class="panel panel-default" style="border:0; box-shadow:none; -moz-box-shadow:none; -webkit-box-shadow:none;">


			             <div class="panel-body form-group">
	                   <div class="row">
                           <div class="form-group">
						<label class="col-md-3 col-xs-12 control-label">Type</label>
						<div class="col-md-6 col-xs-12">
						<select name="type" id="type" class="form-control select"> 
						    <option value="">Select..</option>
							<option value="debit"  {if $smarty.post.type eq "debit"}selected{/if}>Debit</option>
							<option value="credit"  {if $smarty.post.type eq  "credit"}selected{/if}>Credit</option>
						</select>
						</div>
						</div>

			               <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Amount</label>
									    <div class="col-md-6 col-xs-12">
									     <input name="amount" type="number"  step="0.1" value="" class="form-control" required/>
									    </div>
									  </div>

									  <div class="form-group">
									    <label class="col-md-3 col-xs-12 control-label">Remarks</label>
									    <div class="col-md-6 col-xs-12">
									      <textarea name="remarks" rows="3" class="form-control" required></textarea>
                                         </div>
									  </div>
									  </div>
			             </div>


			                 </div>

			             </div>

                   <div class="modal-footer">
				       <input type="hidden" name="currency" value="{$currency}">
					   <input type="hidden" name="adjust" value="1">
                       <input type="submit" name="adjust_submit" class="btn btn-primary" value="Submit">
                     </div>

					  </form>

	              </div>

             

          </div>
      </div>
