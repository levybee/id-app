{if $privileges.supplier_ledgers.view}

    <!-- START BREADCRUMB -->
    <ul class="breadcrumb">
        <li><a href="/">Home</a></li>
        <li><a href="/supplier_ledgers/list">Supplier Ledgers</a></li>
        <li class="active">
            <a href="">Ledger for {if $supplier.supplier_company}{$supplier.supplier_company}{else}{$supplier.supplier_name}{/if}</a>
        </li>
    </ul>
    <!-- END BREADCRUMB -->

    <div class="page-title">
        <h2>
            <span class="fa fa-book"></span> Supplier Ledger - {if $supplier.supplier_company}{$supplier.supplier_company}{else}{$supplier.supplier_name}{/if}
        </h2>

        <ul class="panel-controls panel-controls-title">
         <li>
           <button type="button" class="btn btn-default adjustBtn">Adjustment</button>
          </li>
            <li>
                <form class="form-inline" method="post" action="/supplier_ledgers/view?supplier_id={$smarty.get.supplier_id}">
                    <input type="hidden" name="start_date" value="{$start_date}">
                    <input type="hidden" name="end_date" value="{$end_date}">
                    <input type="hidden" name="csv" value="1">
                    <button name="submit" type="submit" class="btn btn-default">CSV Export</button>
                </form>
            </li>
        </ul>
    </div>

    <div class="page-content-wrap">
        <div class="row">
            {if $msg || $message}
                <div class="col-md-12">
                    <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span
                                class="sr-only">Close</span></button>
                        {$msg}
                        {$message}
                    </div>
                </div>
            {/if}

            <div class="col-md-3">

                <div class="panel panel-default">

                    <div class="panel-heading">
                        <h3 class="panel-title">Supplier Info</h3>
                    </div>
                    <div class="panel-body panel-body-table">

                        <div class="table-responsive">
                            <table class="table pad-10 table-striped">
                                <tr>
                                    <td colspan="2">
                                        {if $supplier.supplier_company}{$supplier.supplier_company}{else}{$supplier.supplier_name}{/if}<br>
                                        {if $supplier.supplier_address}{$supplier.supplier_address}<br />{/if}
                                        {if $supplier.supplier_city}{$supplier.supplier_city},
                                            {/if}{if $supplier.supplier_country}{$supplier.supplier_country}{/if}<br />
                                            {if $supplier.supplier_email}Email: {$supplier.supplier_email}<br>{/if}
                                            {if $supplier.supplier_mobile}Mobile: {$supplier.supplier_mobile}<br />{/if}
                                            <br />
                                            {* {if $supplier.tin}TIN: {$supplier.tin}<br />{/if}
                                            {if $supplier.vrn}VRN: {$supplier.vrn}<br />{/if} *}
                                        </td>

                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-9">

                    <div class="panel panel-default">
                        <div class="panel-heading">
                        <h3 class="panel-title">Entries</h3>
                        <ul class="panel-controls panel-controls-title">
                          <li>
                          <form class="form-inline"  method="post" action="/supplier_ledgers/view?supplier_id={$smarty.get.supplier_id}">
                              <div class="form-group">
                                <label>From:</label>
                                 <input type="text"  name="start_date" style="width:100px;"  value="{if $smarty.post.start_date}{$smarty.post.start_date|date_format:'%Y-%m-%d'}{else}{$start_date}{/if}" autocomplete="off" class="form-control datepicker" >
                              </div>
                              <div class="form-group">
                                <label>&nbsp;To:</label>
                                 <input type="text"  name="end_date" style="width:100px;"  value="{if $smarty.post.end_date}{$smarty.post.end_date|date_format:'%Y-%m-%d'}{else}{$end_date}{/if}" autocomplete="off" class="form-control datepicker" >
                              </div>
                              <button name="submit" type="submit" class="btn btn-succes">Go</button>
                          </form>
                          </li>
                        </ul>
                    </div>

                        <div class="panel-body panel-body-table">

                            <div class="table-responsive">
                                <table class="table pad-5 table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Date</th>
                                            <th class="text-center">Description</th>
                                            <th class="text-center" width="100">Type</th>
                                            <th class="text-center">Debit ({$currency})</th>
                                            <th class="text-center">Credit ({$currency})</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {foreach from=$entries item=entry}
                                            <tr>
                                                <td class="text-center">{$entry.entry_date|date_format:'%d/%m/%Y'}</td>
                                                <td>
                                                {if $entry.entry_type == 'Bank Transfer'}
                                                    {assign var="link" value="/petty_cash_mobile/list?filter=1&pc_id={$entry.entry_id}"}
                                                {/if}
                                                {if $entry.entry_type == 'Exempt Cash'}
                                                    {assign var="link" value="/exemptcash/list?filter=1&ec_id={$entry.entry_id}"}
                                                {/if}
                                                {if $entry.entry_type == 'GRN'}
                                                    {assign var="link" value="/grn/list?search=1&grn_id={$entry.entry_id}"}
                                                {/if}
                                                {if $link}
                                                <a  title="View {$entry.entry_type}" href="{$link}"  target = "_blank">{$entry.description}</a>
                                                {else}
                                                {$entry.description}
                                                {/if}
                                                {assign var="link" value=""}
                                                </td>
                                                <td class="text-center">{$entry.entry_type}</td>
                                                 <td class="text-right">{if $entry.debit > 0 || $entry.description == 'Opening Balance'}
                                                    {$entry.debit|number_format:2}
                                                   {/if}
                                        </td>

                                                <td class="text-right">{if $entry.credit}{$entry.credit|number_format:2}{/if}
                                                </td>
                                            </tr>
                                        {/foreach}
                                        {if $entries|@count > 0}
                                            <tr>
                                                <td colspan="3"></td>
                                                <td class="text-right"><strong>{$total_debit|number_format:2:".":","}</strong></td>
                                                <td class="text-right"><strong>{$total_credit|number_format:2:".":","}</strong></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td>Closing Balance</td>
                                                <td colspan="2"></td>
                                                <td class="text-right"><strong>{$closing_balance|number_format:2:".":","}</strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3"></td>
                                                <td class="text-right"><strong>{$total_debit|number_format:2:".":","}</strong></td>
                                                <td class="text-right"><strong>{$total_debit|number_format:2:".":","}</strong></td>
                                            </tr>

                                        {/if}

                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END PAGE CONTENT WRAPPER -->
         {include file="$section/adjust_modal.tpl"}

    {else}
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-danger" role="alert">
                    You are not authorized to view supplier ledger.
                </div>
            </div>
        </div>
    {/if}