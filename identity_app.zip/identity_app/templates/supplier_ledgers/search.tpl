
<div id="search" class="panel panel-default" style="{if !$smarty.get.search}display: none;{/if} margin-top:15px;">

<div class="panel-body">
   <form id="form2" name="form2" class="form-inline"  method="post" action="/supplier_ledgers/list?search=1{if $search_str}{$search_str}{/if}">

     <div class="form-group"  style="margin-right:15px;">
     <label for="ec_id">Company</label>
     <br>
     	<select class="form-control select2" id="supplier_id" name="supplier_id" style="display:block; width:200px;">
          {section name=suppliers_list loop=$suppliers_list}
            <option value="{$suppliers_list[suppliers_list].supplier_id}" {if $smarty.post.supplier_id eq $suppliers_list[suppliers_list].supplier_id}selected{/if}>{$suppliers_list[suppliers_list].supplier_company|default:$suppliers_list[suppliers_list].supplier_name}</option>
          {/section}
      </select>

    </div>

     <div class="form-group" style="margin-top:20px;">
       <button type="submit" class="btn btn-primary">Go</button>
     </div>


</form>


</div>



</div>

