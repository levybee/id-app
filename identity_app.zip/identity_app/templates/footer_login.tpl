 <div class="login-footer">
                    <div style="text-align:center">
                        &copy; <a href="http://www.redappleprint.com" target="_blank">Red Apple Print</a>, {$smarty.now|date_format:"%Y"}. All Rights Reserved. <br>
                        Designed &amp; Developed by  <a href="http://www.extremewebtechnologies.com" target="_blank">Extreme Web Technologies</a></span>
                    </div>
                    
                </div>
            </div>
            
        </div>
        
   </body>
</html>     