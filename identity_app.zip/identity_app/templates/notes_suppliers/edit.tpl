{if $privileges.notes_suppliers.edit || $privileges.notes_suppliers.add}
<h1>Notes Management &gt; {$action|capitalize} Notes</h1>
<form name="form1" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}{if $smarty.get.group}/?group={$smarty.get.group}{/if}">
 <table  border="1" cellspacing="5" cellpadding="5" class="table">
  <tr>
    <td width="50" class="header_row"><div align="right"><strong>Date</strong></div></td>
    <td>
        <table border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td><input name="note_date" type="text" id="note_date" value="{if $edit_note[0].note_date}{$edit_note[0].note_date|date_format:'%Y-%m-%d'}{else}{$smarty.now|date_format:'%Y-%m-%d'}{/if}" size="10" readonly style="text-align:center; "></td>
            <td>&nbsp;</td>
            <td><input name="trigger" id="trigger" type="image" src="/images/cal.png" width="24" height="20" border="0" style="border:0;"></td>
          </tr>
        </table>    </td>
    </tr>
  
  
  <tr>
    <td class="header_row"><div align="right"><strong>Body </strong></div></td>
    <td><textarea name="note_body" cols="82" rows="20" id="note_body" style="width: 98%;">{$edit_note[0].note_body}</textarea></td>
  </tr>
  
  <tr>
    <td class="header_row"><div align="right"><strong>Supplier</strong></div></td>
    <td><select name="supplier_id" id="supplier_id">
      		{section name=suppliers_list loop=$suppliers_list}
            <option value="{$suppliers_list[suppliers_list].supplier_id}" {if $edit_note}{if $edit_note[0].supplier_id eq $suppliers_list[suppliers_list].supplier_id}selected{/if}{else}{if $supplier_data[0].supplier_id eq $suppliers_list[suppliers_list].supplier_id}selected{/if}{/if}>{$suppliers_list[suppliers_list].supplier_company}</option>
            {/section}
        </select></td>
    </tr>
  <tr>
    <td colspan="2"><div align="right">
      <input type="submit" name="Submit" value="{$action|capitalize} Note" class="input_button">
    </div></td>
    </tr>
</table>
</form>
{dhtml_calendar inputField="note_date" button="trigger" singleClick=true ifFormat="%Y-%m-%d"}
{/if}
{include file="$section/list.tpl"}
<br />