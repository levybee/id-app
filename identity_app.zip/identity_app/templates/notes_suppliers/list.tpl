{if $privileges.notes_suppliers.list}
<h1>Notes Management &gt; List Notes {if $supplier_data}&gt; {$supplier_data[0].supplier_company}{/if}</h1>
<form action="/{$section}/list{if $smarty.get.supplier}/?supplier={$smarty.get.supplier}{/if}{if $sort_str}{$sort_str}{/if}" method="post">
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td><div align="left"><strong>Displaying {$resultsCount}</strong></div></td>
		<td>
			<div align="right">
			  <select name="page" id="page">
			  {section name=pagination loop=$numPages}
			  
			    <option value="{$numPages[pagination]}" {if $numPages[pagination] eq $page}selected{/if}>Page {$numPages[pagination]}</option>
			    
			  {sectionelse}
			  
			    <option value="1" selected>Page 1</option>
			    
			  {/section}
			
		      </select>
			  <input name="submit" type="submit" value="Go" class="input_button">
	      </div></td>
	</tr>
</table>
</form>
<br>
<table width="100%"  border="1" cellspacing="0" cellpadding="5" class="table" bordercolor="#000000">
  <tr class="header_row">
    <td width="50"><div align="center"><strong>#</strong></div></td>
    <td width="150"><div align="center"><strong>Date</strong></div></td>
    <td><div align="center"><strong>Note</strong></div></td>
    {if !$supplier_data}
    <td><div align="center"><strong>Supplier</strong></div></td>
    {/if}
    <td width="50"><div align="center"><strong>Actions</strong></div></td>
  </tr>
  {section name=note_list loop=$note_list}
  <tr class="{cycle values='alternate_row_1,alternate_row_2'}">
    <td width="50"><div align="center">{$start+$smarty.section.note_list.rownum}</div></td>
    <td width="150"><div align="center">{$note_list[note_list].note_date|date_format:"%d %b %Y"}</div></td>
    <td><div>{$note_list[note_list].note_body}</div></td>
    {if !$supplier_data}
    <td><div align="center">{$note_list[note_list].supplier_company}</div></td>
    {/if}
    <td width="50"><div align="center">
    	<a href="/{$section}/edit/?id={$note_list[note_list].note_id}{if $supplier_data[0].supplier_id}&supplier={$supplier_data[0].supplier_id}{/if}"><img src="/images/edit.png" alt="Edit" width="16" height="16" border="0"></a> 
        <a href="/{$section}/delete/?id={$note_list[note_list].note_id}{if $supplier_data[0].supplier_id}&supplier={$supplier_data[0].supplier_id}{/if}"><img src="/images/delete.png" alt="Delete" width="16" height="16" border="0"></a>
     	</div>
    </td>
  </tr>
  {sectionelse}
  <tr>
  	<td colspan="{if $supplier_data}4{else}5{/if}"><div align="center">No records found</div></td>
  </tr>
  {/section}
</table>
<form action="/notes_suppliers/add" method="get" name="add_note">
<br />
<div align="right">
    <input type="submit" name="add_note_button" value="Add Note" class="input_button" />
    {if $supplier_data}<input type="hidden" name="supplier" value="{$supplier_data[0].supplier_id}" />{/if}
</div>
</form>
{/if}