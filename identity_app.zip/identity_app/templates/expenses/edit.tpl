{if $privileges.expenses.edit || $privileges.expenses.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/expenses/list">Expenses</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Expense</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message}
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
        {if !$hide_form}
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Expense</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">


                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Expense Name</label>
                         <div class="col-md-6 col-xs-12">
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                 <input type="text" name="expense_name" value="{if $smarty.post.expense_name}{$smarty.post.expense_name}{elseif $edit_expense[0].expense_name}{$edit_expense[0].expense_name}{/if}" class="form-control"/>
                             </div>

                         </div>
                     </div>
                     
                    <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Expense Code</label>
					    <div class="col-md-6 col-xs-12">
					        <div class="input-group">
					            <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
					            <input type="text" name="expense_code" value="{if $smarty.post.expense_code}{$smarty.post.expense_code}{elseif $edit_expense[0].expense_code}{$edit_expense[0].expense_code}{/if}" class="form-control"/>
					        </div>

					    </div>
					</div>
                     <div class="form-group">
					    <label class="col-md-3 col-xs-12 control-label">Department</label>
					    <div class="col-md-6 col-xs-12">
					        <select name="expense_category" class="form-control select">
                                <option value="">Select..</option>
                                {foreach from=$categories item=category}
                                    <option value="{$category}" {if $smarty.post.expense_category eq $category || $edit_expense[0].expense_category eq $category}selected{/if}>{$category}</option>
                                {/foreach}
                            </select>

					    </div>
					</div>
                    {if $action eq 'edit'}
                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Status</label>
                         <div class="col-md-6 col-xs-12">
                             <select name="expense_status" class="form-control select">
                                  <option value="Active" {if $smarty.post.expense_status eq 'Active' || $edit_expense[0].expense_status eq 'Active'}selected{/if}>Active</option>
                                  <option value="Inactive" {if $smarty.post.expense_status eq 'Inactive' || $edit_expense[0].expense_status eq 'Inactive'}selected{/if}>Inactive</option>
                             </select>

                         </div>
                     </div>
                     {/if}

                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Expense</button>
                 </div>
             </div>
            </form>
           {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->
 </div>
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->


{/if}
