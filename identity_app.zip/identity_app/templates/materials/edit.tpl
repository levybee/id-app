{if $privileges.materials.edit || $privileges.materials.add}


<!-- START BREADCRUMB -->
 <ul class="breadcrumb">
     <li><a href="/">Home</a></li>
     <li><a href="/materials/list">Materials</a></li>
     <li class="active"><a href="">{$action|capitalize}</a></li>
 </ul>
 <!-- END BREADCRUMB -->
 <div class="page-title">                    
    <h2><span class="fa fa-arrow-circle-o-left"></span>{$action|capitalize} Material</h2>
</div>
 <!-- PAGE CONTENT WRAPPER -->
 <div class="page-content-wrap">

  <div class="row">
    <div class="col-md-12">
        {if $message} 
             <div class="alert alert-{if $is_error}danger{else}success{/if}" role="alert">
                 <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                 {$message}
             </div>
             {/if}
        {if !$hide_form}    
        <form class="form-horizontal" method="post" action="/{$section}/{$action}{if $action eq 'edit'}/?id={$smarty.get.id}{/if}">
             <div class="panel panel-default">
                 <div class="panel-heading">
                     <h3 class="panel-title"><strong>Material</strong> Form</h3>
                     <ul class="panel-controls">
                         <li><a href="#" class="panel-remove"><span class="fa fa-times"></span></a></li>
                     </ul>
                 </div>
                 <div class="panel-body">
                     <p></p>
                 </div>
                 <div class="panel-body form-group">
                      
                     <div class="form-group">
                         <label class="col-md-3 col-xs-12 control-label">Material</label>
                         <div class="col-md-6 col-xs-12">                                            
                             <div class="input-group">
                                 <span class="input-group-addon"><span class="fa fa-pencil"></span></span>
                                 <input type="text" name="material_name" value="{if $smarty.post.material_name}{$smarty.post.material_name}{elseif $edit_materials[0].material_name}{$edit_materials[0].material_name}{/if}" class="form-control"/>
                             </div>                                            
                             
                         </div>
                     </div>
                      
                    

                 </div>
                 <div class="panel-footer">
                     <button type="reset" onClick="this.form.reset()"  class="btn btn-default">Clear Form</button>                                    
                     <button type="submit" class="btn btn-primary pull-right">{$action|capitalize} Material</button>
                 </div>
             </div>
             </form>                                           
             {/if}
    </div>
 </div>
</div>
 <!-- END PAGE CONTENT WRAPPER -->  
 </div>            
  <!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER --> 

{else}
<div class="row">
    <div class="col-md-12">
    <div class="panel panel-default">
       
       <div class="alert alert-danger" role="alert">
	      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	      You are not authorized to view this section
	  </div>
      
    </div>

  
</div>            
  
</div> 
{/if}
