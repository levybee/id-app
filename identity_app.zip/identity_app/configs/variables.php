<?php

	// Debug
  //  ini_set("display_errors", true);
    // ini_set("error_reporting", E_ALL & ~E_NOTICE);

	// Change PHP Timezone
		date_default_timezone_set('Africa/Dar_es_Salaam');

	// Session
  if(!isset($_SESSION)){
    session_start();
  }

	// Fix PHP56 upgrade
		include 'fix_mysql.inc.php';

		/* Ereg to Eregi*/
		// Source: https://stackoverflow.com/a/22420393
		if(!function_exists('ereg'))            { function ereg($pattern, $subject, &$matches = []) { return preg_match('/'.$pattern.'/', $subject, $matches); } }
        if(!function_exists('eregi'))           { function eregi($pattern, $subject, &$matches = []) { return preg_match('/'.$pattern.'/i', $subject, $matches); } }
        if(!function_exists('ereg_replace'))    { function ereg_replace($pattern, $replacement, $string) { return preg_replace('/'.$pattern.'/', $replacement, $string); } }
        if(!function_exists('eregi_replace'))   { function eregi_replace($pattern, $replacement, $string) { return preg_replace('/'.$pattern.'/i', $replacement, $string); } }
        if(!function_exists('split'))           { function split($pattern, $subject, $limit = -1) { return preg_split('/'.$pattern.'/', $subject, $limit); } }
        if(!function_exists('spliti'))          { function spliti($pattern, $subject, $limit = -1) { return preg_split('/'.$pattern.'/i', $subject, $limit); } }

	    // Magic Quotes
	    // https://github.com/lirantal/daloradius/issues/22#issuecomment-275864252
	    if (!function_exists('set_magic_quotes_runtime')) {
            function set_magic_quotes_runtime($arg1) {
             return true;
            }
        }
	    if (!function_exists('get_magic_quotes_runtime')) {
            function get_magic_quotes_runtime() {
             return false;
            }
        }

	// Database Variables
		include 'db.variables.php';

	// Other Variables
		$error_path = '/error.php';
		$debugg = 0;

	// Database Connections
		$db_connect = @ mysql_connect($db_server, $db_user, $db_pass) or header("Location: $error_path");
		@ mysql_select_db($db_name) or header("Location: $error_path");
		//@ mysql_query("SET time_zone = 'Africa/Tanzania'");

	// Folder Paths
		define('TEMPLATES', realpath('templates/') . '/');
		define('MODULES', realpath('modules/') . '/');
		define('TEMP', realpath('tmp/') . '/');
		define('TEMP_WEB', '/tmp/');

		define('HOME_DIR', realpath('home/identity/public_html/app/'));

		// SMTP Server details
		// define('SMTP_HOST', 'server1.identitytz.com');
		define('SMTP_HOST', 'mail.identitytz.com');
		define('SMTP_USERNAME', 'smtp@identity.co.tz');
		define('SMTP_PASSWORD', 'RXSRV_0@u7r3');


	// Software Variables
		$software = 'Job Order System';
		$session_time_out = 120; // in minutes
		$user_ip = $_SERVER['REMOTE_ADDR'];
		$numLimit_default = 100; // default # records per page
		$backup_dir = 'backup/'; // backup directory

	// Email Templates
		$email_templates = array();

		// Get Price Notification
		$email_templates['job_get_price']['subject'] = 'Job Order: Get Price Notification';
		$email_templates['job_get_price']['body'] = "Hi,
Someone has requested you to enter price on the job order they were creating.

The Job Order # which requires your attention is: {param_job_id}.";

		// Job Progressed Notification
		$email_templates['job_progressed']['subject'] = 'Job Production: Progress Updated';
		$email_templates['job_progressed']['body'] = "To: Accounts,

New progress added on Job Order # {param_job_id}.
Please add delivery order # and issue invoice.

Brief Progress Report
---------------------
Job Order #: {param_job_id}
Quantity: {param_progress_quantity}
Product Type: {param_product_type}
Client: {param_client_name}
---------------------";

?>
