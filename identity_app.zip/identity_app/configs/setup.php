<?

	// load smarty library
		// require('libs/Smarty.class.php');
		require('libs/Smarty/libs/Smarty.class.php'); // Updated @Mohsin 2023-05-07

	// an extension of the smarty library to set the variables by default
		class Smarty_Setup extends Smarty {
			function Smarty_Setup() {
					// Class Constructor. These automatically get set with each new instance.
					$this->Smarty();
					$this->template_dir = 'templates/';
					$this->compile_dir = 'templates_c/';
					$this->config_dir = 'configs/';
					$this->cache_dir = 'cache/';
					$this->caching = false;
					$this->clear_compiled_tpl();
					// Load Plugins
					require_once $this->_get_plugin_filepath('function', 'leading_zeros');
			}
		}

?>
