<?
   header("Location: ../");
?>
