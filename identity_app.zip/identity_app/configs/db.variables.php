<?

	// Database Variables
		$db_server     = '127.0.0.1';
		$db_name       = 'idlocal_db';
		$db_user       = 'root';
		$db_pass       = '';

?>
