<?php

// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$root_dir = '/home/identity/public_html/app/';
if(isset($local) && $local == true){
  $root_dir = $_SERVER['DOCUMENT_ROOT'].'/';
}

// Load Composer's autoload (if using Composer)
require_once($root_dir.'vendor/autoload.php');
require_once($root_dir."configs/variables.php");

// OR, manually include PHPMailer files (if not using Composer)
// require 'path_to_phpmailer/PHPMailer.php';
// require 'path_to_phpmailer/SMTP.php';
// require 'path_to_phpmailer/Exception.php';

// Create a function to send emails
function send_email($params) {
    // Create a new PHPMailer instance



    $from_email = isset($params['from_email'])? $params['from_email'] : 'info@identitytz.com';
    $from_name = isset($params['from_name'])? $params['from_name'] : 'Identity Promotions Ltd';
    $subject = $params['subject'];
    $email_to = $params['email_to'];
    $html = isset($params['html'])? $params['html'] : true;
    $body = $params['body'];

    if(!$body){
      return "Message content is missing";
    }

    $mail = new PHPMailer(true);
    // $mail->SMTPDebug = 3; // 0=off, 1=client, 2=client+server, 3=verbose
    // $mail->Debugoutput = function($str, $level) {
    // error_log("PHPMailer [$level]: $str");
    // };

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;  // Replace with your SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME; // SMTP username
        $mail->Password = SMTP_PASSWORD; // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587; // Change to 465 if using SSL
        $mail->isHTML($html);

        // Email Headers
        $mail->setFrom($from_email, $from_name);

        foreach ($email_to as $email) {
          $mail->addAddress($email); // Recipient email
        }

        if(isset($params['reply_to'])){
          $mail->addReplyTo($params['reply_to']); // Optional
        }

        if(isset($params['attachments'])){
          foreach ($params['attachments'] as $attch) {
            $mail->addAttachment($attch); // Recipient email
          }
        }

        // Email Content
        $mail->Subject = $subject;
        $mail->Body = $body;

//         error_log("SMTP Host: " . SMTP_HOST);
// error_log("SMTP User: " . SMTP_USERNAME);
// error_log("SMTP Port: " . $mail->Port);
// error_log("SMTP Secure: " . $mail->SMTPSecure);
// error_log("Recipients: " . implode(',', $email_to));

        // Send email
        $sent = $mail->send(); // Returns true if successful
        if($sent){
          if(isset($params['attachments']) && isset($params['unlink'])){
            foreach ($params['attachments'] as $attch) {
              unlink($attch);
            }
          }
        }

        return $sent;

    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: " . $mail->ErrorInfo);
        return "Message could not be sent. Mailer Error: " . $mail->ErrorInfo;
    }
}


?>
