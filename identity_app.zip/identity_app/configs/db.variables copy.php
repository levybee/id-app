<?php

	// Database Variables
		$db_server     = 'localhost';
		$db_name       = 'identity_app';
		$db_user       = 'identity_app';
		$db_pass       = '%HyU*hWqOHJb';

?>
