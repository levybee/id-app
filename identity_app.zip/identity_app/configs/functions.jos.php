<?
	
	// Load Industries Drop Down
	// To be used for preparing drop down on edit/add customer group
	function load_Industries () {
		
		$sql = "SELECT `industry_id`, `industry_name` FROM `jos_industries` ORDER BY `industry_name` ASC;";
		return smartsql($sql);
		
	}
	
	
	// Load Companies Drop Down
	// To be used for New Customer Creation
	function load_CustomersGroup () {
		
		$sql = "SELECT `group_id`, `group_company` FROM `jos_customers_group` ORDER BY `group_company` ASC;";
		return smartsql($sql);
		
	}
	
	function load_CustomersGroupInfo ($group_id = false) {
	    
	    if($group_id){
	        $sql_ext = " WHERE group_id=$group_id ";
	    }
	
	    $sql = "SELECT * FROM `jos_customers_group` $sql_ext ORDER BY `group_company` ASC;";
	    return smartsql($sql);
	
	}
	
	// Load Customers Drop Down
	// To be used for New Quote, Job, etc Creation
	function load_Customers ( $fields=0, $customer_id=0, $group_id=0) {
	    
	    $sql_fields = null;
	    $sql_ext = null;
		
		// Check if specific fields were requested, else LOAD default
		if(!is_array($fields)) { 
			$fields = array ( 'g.group_company', 'c.*' );
		} 
			
		for($i=0; $i<count($fields); $i++) {
			
			// Add Comma if fields already added
			if($sql_fields) { $sql_fields .= ','; }
			// Add Field
			$sql_fields .= $fields[$i];
			
		}
		
		if($customer_id > 0) { 
			$sql_ext = " c.customer_id = '$customer_id' ";
		}
		
		if($group_id > 0) { 
			if($sql_ext) { $sql_ext .= ' AND '; }
			$sql_ext = " c.group_id = '$group_id' ";
		} 
		
		if($sql_ext) { 
			$sql_ext = " WHERE $sql_ext ";
		}
		
		$sql = "SELECT $sql_fields,g.tin,g.vrn,g.company_type
				FROM `jos_customers` as c 
				LEFT JOIN `jos_customers_group` as g
					ON g.group_id = c.group_id 
				$sql_ext
				ORDER BY g.group_company, c.customer_fname, c.customer_lname ASC;";
				
		return smartsql($sql);
		
	}
	
	// Data Validation
	// Quotation Module
	// New Customer
	function validate_Quotation_NewCustomer ($step) { 
		
		if($_POST['customer_fname'] == '') {
			$message[] = 'First Name is a required field.';
		}
		if($_POST['customer_lname'] == '') {
			$message[] = 'Surname is a required field.';
		}
		if($_POST['group_id'] == '' || $_POST['group_id'] == '0') {
			$message[] = 'Company is a required field.';
		} else {
			// Group Info
			$this_group_id = $_POST['group_id'];
			$group_info = smartsql("SELECT `group_company` FROM `jos_customers_group` WHERE `group_id` = '$this_group_id';");
			$group_company = $group_info[0]['group_company'];
		}
		if($_POST['customer_email'] == '') {
			$message[] = 'Email Address is a required field.';
		}
		
		return $message;
		
	}
	
/**
 * Function: maillog
 * @return string
 * @param string $date
 * @desc returns the converted date from the 'yyyy-mm-dd' string format
*/
	function maillog ( $mail_to, $mail_subject, $mail_body, $quote_id ) {
		
		global $db_connect, $user_ip;
		$user_id = $_SESSION['user_id'];
		
		$sql = 'INSERT INTO `jos_maillogs` SET  `mail_date` = NOW(), 
												`mail_to` = \'' . CMSvar($mail_to) . '\', 
												`mail_subject` = \'' . CMSvar($mail_subject) . '\', 
												`mail_body` = \'' . CMSvar($mail_body) . '\', 
												`quote_id` = \'' . CMSvar($quote_id) . '\', 
												`user_ip` = \'' . CMSvar($user_ip) . '\', 
												`user_id` = \'' . CMSvar($user_id) . '\';';
									   
		if($db_connect) {
			@ mysql_query($sql, $db_connect);
		}
		
		return NULL;
		
	}
	

?>
