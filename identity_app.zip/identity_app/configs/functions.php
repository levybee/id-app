<?php
/**
 * Function: Date Conversion
 * @return string
 * @param string $date
 * @desc returns the converted date from the 'yyyy-mm-dd' string format
*/
	function convertDate ( $date, $format='d F Y' ) {

	    if(!$date){
	        return '';
	    }

		$yy = (int) substr($date, 0, 4);
		$mm = (int) substr($date, 5, 2);
		$dd = (int) substr($date, 8, 2);

		$datetime = date($format, mktime(0, 0, 0, $mm, $dd, $yy));
		return $datetime;

	}

/**
 * Function: query database, and return records as multidimensional array for smarty
 * Database has to be connected - it only works with a single connect, or accesses the last connection
 * $sql conteins a normal sql command string
 * in case of an error, the return value contains the error code and error message
 * @param string $slq
 * returns array
*/

	function smartsql($sql){
		$record=@mysql_query($sql);
		$rec=[];
		if(!$record) {
			$rec=array("code"=>mysql_errno(), "msg"=>mysql_error());
		} else {
			while($row=mysql_fetch_assoc($record)){
				$rec[]=$row;
			}
		}
		return $rec;
	}

/**
 * Function: PDF Redirect
 * @param string $pdfobj
 * @param string $pdf
 * @desc Checks if PDF exists, deletes it if it does and redirects to pdf
*/
	function pdfRedirect($pdfobj, $pdf, $email=NULL, $TMP_DIR=false) {
		// Path to PDF
		$redirect_to = constant('TEMP') . $pdf .'.pdf';
		$redirect_to_web = constant('TEMP_WEB') . $pdf .'.pdf';



		if($TMP_DIR){
			$TMP_DIR = '/home/identity/public_html/app/tmp/';
			$redirect_to = $TMP_DIR . $pdf .'.pdf';
			$redirect_to_web = $TMP_DIR . $pdf .'.pdf';
		}

		// Already Exists?
			if(file_exists(constant('TEMP') . $pdf . '.pdf')) {

			    if($email) {
			// Get Out! - attempting to fix: FPDF error: Unable to create output file
			return true;
			    }

				// Delete it!
				unlink($redirect_to);
				// Prevent cache views - add random
				$random = '?rand=' . date('U');
			}

// 			if($_SESSION['user_id'] == 24){
// 			    echo $redirect_to;
// 			    exit;
// 			}

		// Generate PDF
			@ $pdfobj->Output($redirect_to, 'F');

		// Email?
		if($email) {
			// Email...
			// Do Nothing.
			return true;
		} else {
			// Redirect to PDF
				header("Location: $redirect_to_web$random");
		}
	}

/**
 * Function: Upload v2, modified: May 06, 2006 02:34:43
 * @return boolean
 * @param string $file_to_save
 * @param array $extensions_allowed
 * @param string $path_to_save
 * @desc returns path_to_file if successfully uploaded and error if an error occurred
*/
	function upload ( $file_to_save, $extensions_allowed, $path_to_save, $dimensions=0, $removeChars=true ) {

		$extensions_allowed = explode(',', $extensions_allowed);

		$upload_file_name = $file_to_save['name'];
		$upload_file_name_array = explode('.', $upload_file_name);

		// File extension
		$upload_file_ext = $upload_file_name_array[count($upload_file_name_array) - 1];

		// Remove special chars
		if($removeChars){
			$filename = preg_replace('/[^A-Za-z0-9\-]/', '', $upload_file_name_array[count($upload_file_name_array) - 2]);
      if (empty($filename)) $filename = 'file';
		}else{
      $filename = $upload_file_name_array[count($upload_file_name_array) - 2];
		}





		// Rename file to overcome 'file already exists' possibility
		$renamed_file = $filename . '-' . date('U') . '.' . $upload_file_ext;
		// $renamed_file = $upload_file_name_array[count($upload_file_name_array) - 2] . '.' . $upload_file_ext;

		// Check if extension is allowed
		for($i=0; $i<count($extensions_allowed); $i++) {
			if(strtolower($upload_file_ext) == trim(strtolower($extensions_allowed[$i])) && !isset($ext_verified)) {
				$ext_verified = 1;
			}
		}

		if(in_array('all', $extensions_allowed)) {
			$ext_verified = 1;
		}

		if($dimensions) {
			list($img_width, $img_height, $img_type, $img_attr) = getimagesize($file_to_save['tmp_name']);

			if($dimensions['width'] == $img_width && $dimensions['height'] == $img_height) {
				$check_dim = true;
			} else {
				$check_dim = false;
			}
		} else {
			$check_dim = true;
		}

		if($check_dim == false) {

			return 'err4';

		} else if($ext_verified == 1) {
			// Upload file
			if(!file_exists($path_to_save . $renamed_file)) {

			    if(file_exists($file_to_save['tmp_name'])){

			        if(move_uploaded_file($file_to_save['tmp_name'], $path_to_save . $renamed_file)) {
			            return array($path_to_save . $renamed_file, $renamed_file);
			        } else {
			            // echo $path_to_save.$renamed_file;
			            // var_dump(move_uploaded_file($file_to_save['tmp_name'], $path_to_save . $renamed_file));
			            // exit;
									error_log("Upload failed: tmp_name not found or move failed. Path: " . $file_to_save['tmp_name']);
			            return 'err1';
			        }

			    }else{

			        return 'err1';
			    }


			} else {
				return 'err3';
			}

		} else {
			return 'err2';
		}

	}


// Re-format posted multiple files for a cleaner array
	function reArrayFiles(&$file_post) {

    $file_ary = array();
    $file_count = count($file_post['name']);
    $file_keys = array_keys($file_post);

    for ($i=0; $i<$file_count; $i++) {
        foreach ($file_keys as $key) {
            $file_ary[$i][$key] = $file_post[$key][$i];
        }
    }

    return $file_ary;
}

/**
 * Function: systemlog
 * @return string
 * @param string $date
 * @desc returns the converted date from the 'yyyy-mm-dd' string format
*/

    // function CMSvar($string){
    //   return mysql_real_escape_string($string);
    // }

	function systemlog ( $user_message, $system_log=0 ) {

		global $db_connect, $user_ip;
		$log_page = '/index.php?' . $_SERVER['QUERY_STRING'];
		$user_id = $_SESSION['user_id'];

		if(!$system_log) {
			$system_log = addslashes( $user_message );
		}

		$sql = 'INSERT INTO `cms_logs` SET 	`log_date` = NOW(),
									   		`log_description` = \'' . CMSvar($system_log) . '\',
									   		`log_page` = \'' . CMSvar($log_page) . '\',
									   		`user_ip` = \'' . CMSvar($user_ip) . '\',
									   		`user_id` = \'' . CMSvar($user_id) . '\';';

		if($db_connect) {
			@ mysql_query($sql, $db_connect);
		}

		return $user_message;

	}

/**
 * Function: Leading Zero
 * @return string
 * @param string $aNumber
 * @param string $intPart
 * @param string $floatPart
 * @param string $dec_point
 * @param string $thousands_sep
 * @desc returns the number with leading zeros
*/
	function leading_zero( $aNumber, $intPart=8, $floatPart=NULL, $dec_point=NULL, $thousands_sep=NULL) {

		$intPart = $intPart - 1;

		$formattedNumber = $aNumber;
		if (!is_null($floatPart)) {
			$formattedNumber = number_format($formattedNumber, $floatPart, $dec_point, $thousands_sep);
		}

		$secNo = ($intPart + -1 - floor(log10($formattedNumber)));

	    $secNo = (int) $secNo;


		if($secNo > 0) {

			$formattedNumber = str_repeat("0",$secNo).$formattedNumber;
		}

		return $formattedNumber;
	}

/**
 * Function: Thousand Separator
 * @return string
 * @param string $amount
 * @desc returns the amount into xxx,xxx.xx format
*/
	function thousand_sep($amount) {
	    if(is_numeric($amount)){

	        return number_format($amount, 2, '.', ',');

	    }else{

	       return false;
	    }

	}

/**
 * Function: Random String Generator
 * @return string
 * @desc returns a randomly generated alphanumeric string
*/
function randompass(){
	$alphanum = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
	$chars = sizeof($alphanum);
	$a = time();
	mt_srand($a);
	for ($i=0; $i < 6; $i++) {
	  $randnum = intval(mt_rand(0,56));
	  $password .= $alphanum[$randnum];
	}

	return $password;
}

/**
 * Function: Transactions > General
 * @param string $action
 * @desc processes the action type of transaction
*/
function mysql_transaction($action)
{

	switch($action) {

		case 'start':
			$sql = 'START TRANSACTION;';
			break;

		case 'commit':
			$sql = 'COMMIT;';
			break;

		case 'rollback':
			$sql = 'ROLLBACK;';
			break;

	}

	if($sql) {
		@ mysql_query($sql);
	}

}

/**
 * Function: Transactions > Process
 * @param string $sql
 * @desc processes the action type of transaction
*/
function mysql_transaction_process($sql)
{

	$output = array();

	mysql_transaction('start');
	$result = @ mysql_query($sql);

	if($result) {
		$output['result'] = $result;
		$action = 'commit';
	} else {
		$action = 'rollback';
	}

	mysql_transaction($action);
	$output['action'] = $action;
	return $output;

}

/**
 * Function: Amount Conversion
 * @return string
 * @param string $amount
 * @desc returns $amount without thousand_separator
*/
	function removeThousandSeparator ( $value ) {

		$value = ereg_replace(',','',$value);
		return $value;

	}


	/**
	 * Function:Get Client IP adress
	 * @return string
	 * @desc returns client IP address
	 * @source http://itman.in/en/how-to-get-client-ip-address-in-php/
	 */
	function getRealIpAddr()
	{
	    if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
	    {
	        $ip=$_SERVER['HTTP_CLIENT_IP'];
	    }
	    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
	    {
	        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	    }
	    else
	    {
	        $ip=$_SERVER['REMOTE_ADDR'];
	    }
	    return $ip;
	}

	/**
	 * Function: Batch Update
	 * @return int
	 * @param string $table - table to be updated
	 * @param array $data - array of values to be updated
	 * @param string $key - reference key for row update
	 * @param array $update_columns - array of columns to be updated
	 * @desc returns number rows affected
	*/

	function lev_batch_update($table, $data, $key, $update_columns){

		// $table = 'jos_stock';
		// $key = 'stock_id';
		// $update_columns = array('unit_price','currency');
		//
		// $data = array(
		// 	   array(
		// 	      'stock_id' => 1199 ,
		// 	      'unit_price' => 133000  ,
		// 	      'currency' => 'TZS'
		// 	   ),
		// 	   array(
		// 	      'stock_id' => 1661,
		// 	      'unit_price' => 130,
		// 	      'currency' => 'USD'
		// 	   )
		// 	);


    	$data_chunks = array_chunk($data, 50);


			if($_GET['debug'] == 'cron'){
				print_r($data_chunks);
				exit;
			}

            $affected_rows = 0;
			foreach ($data_chunks as $data) {

				// Create array of key value to implode
				$key_values = array();
				foreach ($data as $arr) {
					$key_values[] = $arr[$key];
				}

				$keys_str = "'".implode("','", $key_values)."'";

				$sql = "UPDATE $table SET";

				$lastElement = end($update_columns);
				$comma = ',';
				foreach ($update_columns as $col) {
					$sql .= " $col = CASE";
	        foreach ($data as $arr) {
						$key_val = $arr[$key];
						$col_val = $arr[$col];
	        	$sql .= " WHEN $key = '$key_val' THEN '$col_val'";
	        }
					if($col == $lastElement){
						$comma = '';
					}
					$sql .= " ELSE '$col' END$comma";
				}

				$sql .= " WHERE $key IN ($keys_str)";

				// if($_GET['debug'] == 'sql'){
				// 	echo $sql;
				// 	exit;
				// }

				$sql_qry = mysql_query($sql) or die(mysql_error());

				$affected_rows += mysql_affected_rows();

			}


			return $affected_rows;

	}

	function reverse_log_item($log_type, $item_ids){

		    $item_ids_str = implode(',', $item_ids);
			$log_qry = mysql_query("SELECT * FROM jos_stock_log WHERE $log_type IN ($item_ids_str)");



			if(mysql_num_rows($log_qry) > 0) {

				$log_ids = array();
				while ($row = mysql_fetch_assoc($log_qry)) {

          $stock_id = $row['stock_id'];
					$log_quantity = $row['log_quantity'];
					$log_movement = $row['log_movement'];
					$sign = ($log_movement == 'In')? '-' : '+';
					$log_ids[] = $row['log_id'];

					$stock_update_sql = "UPDATE jos_stock
	        SET stock_qty = stock_qty $sign $log_quantity
	        WHERE stock_id = $stock_id;";



	        $stock_query = mysql_query($stock_update_sql);


				}

				if($stock_query){

				$log_ids_str = implode(',', $log_ids);

				$log_update_sql = "UPDATE jos_stock_log
				SET reversed  = 'Yes'
				WHERE log_id IN ($log_ids_str)";

				mysql_query($log_update_sql);

				return true;


				}



			}

      return false;

	}

	function close_lpo_pcv($lpo_id){

		// Check stock balances, complete LPO if no more items are pending
			$lpo_items_sql = "SELECT i.*, gi.lpo_item_id, gi.grn_item_qty, js.units,
			grn.attachment_path, grn.user_id,
			(SELECT SUM(log_quantity) FROM
					jos_stock_log WHERE log_lpo_item_id = i.item_id AND reversed IS NULL) as stock_received
			FROM `jos_lpo_items` as i
			LEFT JOIN `jos_grn_items` as gi
			ON i.item_id = gi.lpo_item_id
			LEFT JOIN jos_grn as grn
			ON i.lpo_id = grn.lpo_id
			LEFT JOIN `jos_stock` as js
			ON js.stock_id = i.stock_id
			WHERE i.lpo_id = '$lpo_id' AND grn.attachment_path IS NOT NULL;";

		 $lpo_items = smartsql($lpo_items_sql);

//          echo "<pre>";
// 		 print_r($lpo_items);
// 		 echo "</pre>";
// 		 exit;

		 $complete = false;

		 // Check stock levels and change status if no more stock is pending if LPO items = posted GRN items
		// if($num_items == count($lpo_items)){ check is unnecessary some GRN items are received in partials of total LPO qty

			 foreach ($lpo_items as $item){

					 $complete = ($item['item_qty'] - $item['stock_received'] == 0)? true : false;
					 if(!$complete){
							 break;
					 }

			 }

			// $complete = true;

			 $lpo_status = ($complete == true)? 'Complete' : 'Approved';

			 //echo $lpo_status;
			 //exit;


			 if($lpo_status == 'Complete'){ // Close LPO

				 $lpo_status_sql = "UPDATE jos_lpo SET lpo_status = '$lpo_status' WHERE lpo_id = '$lpo_id' LIMIT 1;";

				$lpo_status_qry = mysql_query($lpo_status_sql);


			 if(mysql_affected_rows() == 1 || $lpo_status == 'Complete') {// Close PCV



				 $pcv_date = date('Y-m-d H:i:s');
				 $pcv_user = $lpo_items[0]['user_id'];
				 $file = $lpo_items[0]['attachment_path'];

				 $pcv_sql = "UPDATE jos_petty_cash SET status = 'Closed', attachment = '$file', date_updated = '$pcv_date', user_id = '$pcv_user' WHERE lpo_id = '$lpo_id' AND status = 'Issued'";
				 mysql_query($pcv_sql);

				 $pcvm_sql = "UPDATE jos_petty_cash_mobile SET status = 'Closed', attachment = '$file', date_updated = '$pcv_date', user_id = '$pcv_user' WHERE lpo_id = '$lpo_id' AND status = 'Issued'";
				 mysql_query($pcvm_sql);

			 }else{

				 // Error
					// $message[] = systemlog('An unknown error occurred while updating LPO status.', 'LPO Receive: Error updating status - DEBUG: ' . mysql_error());

			 }


			 }



			return $complete;


	}


	function close_pcv($lpo_id){

		// Check stock balances, complete LPO if no more items are pending
			$lpo_items_sql = "SELECT i.*, gi.lpo_item_id, gi.grn_item_qty, js.units,
			grn.attachment_path, grn.user_id,
			(SELECT SUM(log_quantity) FROM
					jos_stock_log WHERE log_lpo_item_id = i.item_id AND reversed IS NULL) as stock_received
			FROM `jos_lpo_items` as i
			LEFT JOIN `jos_grn_items` as gi
			ON i.item_id = gi.lpo_item_id
			LEFT JOIN jos_grn as grn
			ON i.lpo_id = grn.lpo_id
			LEFT JOIN `jos_stock` as js
			ON js.stock_id = i.stock_id
			WHERE i.lpo_id = '$lpo_id' AND grn.attachment_path IS NOT NULL;";

		 $lpo_items = smartsql($lpo_items_sql);



			 $complete = true;

			 $lpo_status = ($complete == true)? 'Complete' : 'Approved';


			 if($lpo_status == 'Complete'){ // Close LPO

				//  $lpo_status_sql = "UPDATE jos_lpo SET lpo_status = '$lpo_status' WHERE lpo_id = '$lpo_id' LIMIT 1;";
				//
				// $lpo_status_qry = mysql_query($lpo_status_sql);


			 if($lpo_status == 'Complete') {// Close PCV



				 $pcv_date = date('Y-m-d H:i:s');
				 $pcv_user = $lpo_items[0]['user_id'];
				 $file = $lpo_items[0]['attachment_path'];

				 $pcv_sql = "UPDATE jos_petty_cash SET status = 'Closed', attachment = '$file', date_updated = '$pcv_date', user_id = '$pcv_user' WHERE lpo_id = '$lpo_id' AND status = 'Issued'";
				 mysql_query($pcv_sql);

				 $pcvm_sql = "UPDATE jos_petty_cash_mobile SET status = 'Closed', attachment = '$file', date_updated = '$pcv_date', user_id = '$pcv_user' WHERE lpo_id = '$lpo_id' AND status = 'Issued'";
				 mysql_query($pcvm_sql);

				 return $complete;

			 }else{

				 // Error
					// $message[] = systemlog('An unknown error occurred while updating LPO status.', 'LPO Receive: Error updating status - DEBUG: ' . mysql_error());

			 }


			 }


       return false;

	}

function array_sort($array, $on, $order=SORT_ASC)
{
    $new_array = array();
    $sortable_array = array();

    if (count($array) > 0) {
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $k2 => $v2) {
                    if ($k2 == $on) {
                        $sortable_array[$k] = $v2;
                    }
                }
            } else {
                $sortable_array[$k] = $v;
            }
        }

        switch ($order) {
            case SORT_ASC:
                asort($sortable_array);
            break;
            case SORT_DESC:
                arsort($sortable_array);
            break;
        }

        foreach ($sortable_array as $k => $v) {
            $new_array[$k] = $array[$k];
        }
    }

    return $new_array;
}

function check_lpo_status($lpo_id){

	// Check stock balances, complete LPO if no more items are pending
		// $lpo_items_sql = "SELECT i.*, gi.lpo_item_id, gi.grn_item_qty, js.units, (SELECT SUM(log_quantity) FROM
		// 		jos_stock_log WHERE log_lpo_item_id = i.item_id AND reversed IS NULL) as stock_received
		// FROM `jos_lpo_items` as i
		// LEFT JOIN `jos_grn_items` as gi
		// ON i.item_id = gi.lpo_item_id
		// LEFT JOIN `jos_stock` as js
		// ON js.stock_id = i.stock_id
		// WHERE i.lpo_id = '$lpo_id';";

		// 18/02/2024 Revised query: Function was not working querying from stock log as logs are now created at grn closure.
		$lpo_items_sql = "SELECT lpoi.*, gi.lpo_item_id, SUM(gi.grn_item_qty) as grn_item_qty
		FROM `jos_lpo_items` as lpoi
		LEFT JOIN `jos_grn_items` as gi
		ON lpoi.item_id = gi.lpo_item_id
		LEFT JOIN jos_grn grn
              ON grn.grn_id = gi.grn_id
		LEFT JOIN `jos_stock` as js
		ON js.stock_id = lpoi.stock_id
		WHERE lpoi.lpo_id = '$lpo_id' AND grn.status = 'Closed' GROUP BY lpoi.item_id";


	 $lpo_items = smartsql($lpo_items_sql);

	 $complete = false;

	 // Check stock levels and change status if no more stock is pending if LPO items = posted GRN items
	// if($num_items == count($lpo_items)){ check is unnecessary some GRN items are received in partials of total LPO qty

		 foreach ($lpo_items as $item){

				 $complete = ($item['item_qty'] - $item['grn_item_qty'] == 0)? true : false;
				 if(!$complete){
						 break;
				 }

		 }

		 $lpo_status = ($complete == true)? 'Complete' : '';

// 		 if($_SESSION['user_id'] == 24){
// 		     echo $lpo_status;
// 		     exit;
// 		 }

         if($lpo_status){

             $lpo_status_sql = "UPDATE jos_lpo SET lpo_status = '$lpo_status' WHERE lpo_id = '$lpo_id'";

		     $lpo_status_qry = mysql_query($lpo_status_sql);

         }



		if(mysql_affected_rows() == 1) {
           $message[] = systemlog("LPO [#$lpo_id] Completed.", "LPO [#$lpo_id] Completed by user - {$_SESSION['user_id']}");
		}else{

			// Error
			 // $message[] = systemlog('An unknown error occurred while updating LPO status.', 'LPO Receive: Error updating status - DEBUG: ' . mysql_error());

		}

		return $complete;


}


// For sending cUrl requests
function curl_request2($url, $json_data){



        $curl = curl_init();

curl_setopt_array($curl, array(

    // https://virtual.tra.go.tz/efdmsRctApi/api/efdmsRctInfo
  CURLOPT_URL => 'http://41.222.94.138:8082/vfd-dev/apis/receive.php',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_POSTFIELDS =>'{
   "invoice":[
      {
         "idate":"2022-05-02",
         "itime":"17:32:46",
         "custinvoiceno":"9519",
         "custidtype":1,
         "custid":"127614555",
         "custname":"Dough Works Ltd.",
         "mobilenum":"255713995558",
         "username":"Zahira",
         "branch":"Dar es salaam",
         "department":null,
         "invoiceDetails":[
            {
               "description":"standard Base Banner screen printing Roll Up Banner",
               "qty":"3.00",
               "taxcode":1,
               "amt":"60000.00"
            },
            {
               "description":"A6 Flier Single sided Flyers",
               "qty":"500.00",
               "taxcode":1,
               "amt":"250.00"
            },
            {
               "description":"A4 Trifold. Brochure",
               "qty":"2000.00",
               "taxcode":1,
               "amt":"240.00"
            }
         ]
      }
   ]
}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    'Cookie: PHPSESSID=7aos49vbomp06urcmb4tv0q7q3'
  ),
));

// $response = curl_exec($curl);

// curl_close($curl);
// echo "response: ".$response;

// exit;

//		$curl = curl_init($url);

//		$headers = ["Content-Type: application/json"];

// 		 curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
// 		 curl_setopt($curl, CURLOPT_POST, true);
// 		 curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
// 		 curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
// 		 curl_setopt($curl, CURLOPT_POSTFIELDS, $json_data);
// 		 curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);


		 curl_setopt($curl, CURLOPT_VERBOSE, true);
         $streamVerboseHandle = fopen('php://temp', 'w+');
         curl_setopt($curl, CURLOPT_STDERR, $streamVerboseHandle);

		 $results = curl_exec($curl);

		 if($results === FALSE){
		     printf("cUrl error (#%d): %s<br>\n",
             curl_errno($curl),
             htmlspecialchars(curl_error($curl)));

						 rewind($streamVerboseHandle);
$verboseLog = stream_get_contents($streamVerboseHandle);

echo "cUrl verbose information:\n",
     "<pre>", htmlspecialchars($verboseLog), "</pre>\n";

		 }

		 curl_close($curl);

		 return $results;

 }

 function curl_request($url, $post_fields){
   // $url = 'http://vfd.levybee.com/apis/receive.php';


//     $post_fields = '{
//   "invoice":[
//      {
//         "idate":"2022-06-07",
//         "itime":"17:32:46",
//         "custinvoiceno":"TRED9519",
//         "custidtype":1,
//         "custid":"127614555",
//         "custname":"Dough Works Ltd.",
//         "mobilenum":"255713995558",
//         "username":"Zahira",
//         "branch":"Dar es salaam",
//         "department":null,
//         "invoiceDetails":[
//           {
//               "description":"standard Base Banner screen printing Roll Up Banner",
//               "qty":"3.00",
//               "taxcode":1,
//               "amt":"60000.00"
//           },
//           {
//               "description":"A6 Flier Single sided Flyers",
//               "qty":"500.00",
//               "taxcode":1,
//               "amt":"250.00"
//           },
//           {
//               "description":"A4 Trifold. Brochure",
//               "qty":"2000.00",
//               "taxcode":1,
//               "amt":"240.00"
//           }
//         ]
//      }
//   ]
// }';

    $headers = ["Content-Type: application/json","Accept: application/json"];
    $curl = curl_init($url);

    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_fields);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);


     if($_SESSION['user_id'] == 24){
         curl_setopt($curl, CURLOPT_VERBOSE, true);
         $streamVerboseHandle = fopen('php://temp', 'w+');
         curl_setopt($curl, CURLOPT_STDERR, $streamVerboseHandle);
     }


		 $results = curl_exec($curl);


		 if($results === FALSE && $_SESSION['user_id'] == 24){

		     printf("cUrl error (#%d): %s<br>\n",
             curl_errno($curl),
             htmlspecialchars(curl_error($curl)));

						 rewind($streamVerboseHandle);
$verboseLog = stream_get_contents($streamVerboseHandle);

echo "cUrl verbose information:\n",
     "<pre>", htmlspecialchars($verboseLog), "</pre>\n";

		 }

		 curl_close($curl);

		 return $results;

}

// Returns the key at the end of the array
function endKey($array){
 end($array);
 return key($array);
}

/**
 * Clean JSON string before decoding
 *
 * @param string $json
 * @return string
 */
function cleanJsonString($json) {
    // Remove all control characters except common whitespace
    $json = preg_replace('/[\x00-\x1F\x7F\x{200B}-\x{200D}\x{2060}\x{FEFF}]/u', '', $json);

    return $json;
}

function debug_log($message) {
    $logDir = __DIR__ . '/../logs';

    if (!is_dir($logDir)) {
        mkdir($logDir, 0777, true);
    }

    $logFile = $logDir . '/debug-' . date('Y-m-d') . '.log';

    if (is_array($message) || is_object($message)) {
        $message = print_r($message, true);
    }

    error_log("[" . date('Y-m-d H:i:s') . "] " . $message . "\n", 3, $logFile);
}

/**
 * Pluck an array of values from an array. (Only for PHP 5.3+)
 *
 * @param  $array - data
 * @param  $key - value you want to pluck from array
 *
 * @return plucked array only with key data
 */
function array_pluck($array, $key) {
    return array_map(function($v) use ($key) {
      return is_object($v) ? $v->$key : $v[$key];
    }, $array);
}



// Remove trailing zeros after decimal + clean comma formatting
function cleanNumberFormat($value){
  if(!$value) return $value;	
  //return rtrim(rtrim(number_format($number, 10, '.', ','), '0'), '.');
  // remove commas first
$value = str_replace(',', '', $value);

// remove trailing zeros + dot if needed
$value = rtrim(rtrim($value, '0'), '.');

// format back with comma if needed
$value = number_format($value, strpos($value, '.') !== false ? strlen(substr(strrchr($value, "."), 1)) : 0);
return $value;
}





?>
