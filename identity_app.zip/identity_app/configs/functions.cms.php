<?
	
	// CMS Functions File
	function update_LastLogin ( ) {
		
		$user_id = $_SESSION['user_id'];
		
		if($user_id > 0) { 
			
			$sql = "UPDATE `cms_users` SET `user_last_login` = NOW() WHERE `user_id` = '$user_id';";
			$query = mysql_query($sql);
			
			if(!$query) {
				systemlog('System Message: Last Login Update failed for User ID ' . $user_id);
			}
		
		} 
		
	}	
	
	// Load Categories
	function load_Categories () {
		
		$sql = 'SELECT `category_id`, `category_name` FROM `cms_categories` WHERE `category_show` = "Y";';
		return smartsql($sql);
		
	}
	
	
	// Prepare CSV Array
	function prepare_CSVArray ($csv_data, $enclosed='"', $separator=',') {
		
		$tmpArray = explode($separator, $csv_data);
		
		$count = count($tmpArray);
		
		for($i=0; $i<$count; $i++) {
			
			$text = $tmpArray[$i];
			$text = str_replace($enclosed, '', $text); 
			$data[] = trim($text);
			
		}
		
		return $data;
		
	}
	
	// System Notify
	function system_notify ($notify, $template, $params=array()) {
		
		// Global
		global $email_templates, $config;
		
		// Replace params
		$params2 = array();
		
		foreach($params as $param_name => $param_value) {
			$params2[$param_name] = "$param_value";
		}
		
		unset($params);
		$params = $params2;
		unset($params2);
		
		// Load PHPMailer	
		require("class.phpmailer.php");
		
		$mail = new PHPMailer();
		
		$mail->From     = $config['notification_from_email'];
		$mail->FromName = $config['notification_from_name'];
		$mail->Host     = "localhost";
		$mail->Mailer   = "mail";
		
		// Pick template from global
		if(array_key_exists($template, $email_templates)) {
			
			$text_subject = $email_templates[$template]['subject'];
			$text_body = $email_templates[$template]['body'];
			
			$search = preg_match_all('/{.*?}/', $text_body, $matches);
			$matches = $matches[0];
			$matches_total = count($matches);
			
			for($i=0; $i<$matches_total; $i++) {
				
				$var_name = $matches[$i]; 
					$var_name_only = substr($var_name, 1, (strlen($var_name)-2) );
				$var_value = $params[$var_name_only]; 
				$pattern = "{$var_name}";
				$text_body = eregi_replace($pattern, $var_value, $text_body);
				
			}
			
		} else {
			
			$text_body = $email_template['standard'];
			
		}
	
		// Notify
		$notify = $config[$notify];
		$emails_to = explode(",", $notify);
		
		$mail->Subject = $text_subject;
		$mail->Body = $text_body;
		
		foreach($emails_to as $email)
		{
		    $mail->AddAddress(trim($email));
		}
		
		if($mail->Send()) {
			$output = array ( true, "Success" );
		} else {
			$output = array ( false, "There has been a mail error sending to " . $notify );
		}
	
		// Clear all addresses and attachments for next loop
		$mail->ClearAddresses();
		$mail->ClearAttachments();
		
		return $output;
		
	}
	
	// Variables
	// Make Variable Clean
	function CMSvar ( $data_var ) {
		
	    $data_var = trim($data_var);
		return mysql_real_escape_string($data_var);
		
	}

?>
